#!/usr/bin/env python3
"""Summarise an OpenAPI/Swagger spec into a tool-design brief.

Prints the facts Phase 1 of the ``gsage-tool-builder`` skill needs: servers,
auth schemes, and a compact endpoint table (method, path, operationId, params,
mutating?), so a large spec never has to be read into context whole.

Usage
-----
    python inspect_openapi.py <file-or-url>
    python inspect_openapi.py spec.yaml --grep vm            # filter paths/ids
    python inspect_openapi.py spec.yaml --tag Compute        # filter by tag
    python inspect_openapi.py spec.yaml --detail listVms     # one operation
    python inspect_openapi.py spec.yaml --detail /vms/{id}   # or by path

Reads JSON natively; YAML needs PyYAML. URLs need httpx (both ship with the
project's requirements.txt).
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Optional

_METHODS = ("get", "post", "put", "patch", "delete", "head", "options")
_MUTATING = {"post", "put", "patch", "delete"}


def _load(source: str) -> dict:
    if source.startswith(("http://", "https://")):
        try:
            import httpx
        except ImportError:
            sys.exit("httpx is required to fetch a spec over HTTP")
        raw = httpx.get(source, timeout=30, follow_redirects=True).text
    else:
        with open(source, "r", encoding="utf-8") as fh:
            raw = fh.read()

    try:
        return json.loads(raw)
    except ValueError:
        pass
    try:
        import yaml
    except ImportError:
        sys.exit("spec is not JSON and PyYAML is not installed (pip install pyyaml)")
    return yaml.safe_load(raw)


def _resolve(spec: dict, node: Any, _depth: int = 0) -> Any:
    """Follow a local ``$ref`` one level at a time (bounded)."""
    if _depth > 10 or not isinstance(node, dict):
        return node
    ref = node.get("$ref")
    if not isinstance(ref, str) or not ref.startswith("#/"):
        return node
    target: Any = spec
    for part in ref[2:].split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        if not isinstance(target, dict) or part not in target:
            return node
        target = target[part]
    return _resolve(spec, target, _depth + 1)


def _param_brief(spec: dict, params: list) -> str:
    bits: list[str] = []
    for raw in params or []:
        p = _resolve(spec, raw)
        if not isinstance(p, dict):
            continue
        name = p.get("name", "?")
        loc = p.get("in", "?")
        req = "*" if p.get("required") else ""
        bits.append(f"{name}{req}({loc[:1]})")
    return ",".join(bits) or "-"


def _body_brief(spec: dict, op: dict) -> str:
    body = _resolve(spec, op.get("requestBody") or {})
    if not isinstance(body, dict) or not body.get("content"):
        return ""
    for mime, media in body["content"].items():
        schema = _resolve(spec, media.get("schema") or {})
        name = ""
        if isinstance(media.get("schema"), dict):
            ref = media["schema"].get("$ref", "")
            name = ref.rsplit("/", 1)[-1] if ref else ""
        if not name and isinstance(schema, dict):
            props = list((schema.get("properties") or {}).keys())[:6]
            name = "{" + ",".join(props) + "}" if props else schema.get("type", "?")
        return f" body[{mime}:{name}]"
    return ""


def _operations(spec: dict) -> list[dict]:
    out: list[dict] = []
    for path, item in (spec.get("paths") or {}).items():
        item = _resolve(spec, item)
        if not isinstance(item, dict):
            continue
        shared = item.get("parameters") or []
        for method in _METHODS:
            op = item.get(method)
            if not isinstance(op, dict):
                continue
            out.append({
                "method": method.upper(),
                "path": path,
                "op_id": op.get("operationId") or "",
                "summary": (op.get("summary") or op.get("description") or "")
                .strip()
                .split("\n")[0][:90],
                "tags": op.get("tags") or [],
                "params": _param_brief(spec, list(shared) + list(op.get("parameters") or [])),
                "body": _body_brief(spec, op),
                "mutating": method in _MUTATING,
                "_raw": op,
            })
    return out


def _print_header(spec: dict) -> None:
    info = spec.get("info") or {}
    print(f"# {info.get('title', '(untitled API)')} {info.get('version', '')}".rstrip())
    desc = (info.get("description") or "").strip().split("\n")[0]
    if desc:
        print(f"  {desc[:160]}")

    print("\n## Servers")
    servers = spec.get("servers") or []
    if servers:
        for s in servers:
            print(f"  - {s.get('url')}  {(s.get('description') or '')[:60]}")
    elif spec.get("host"):  # swagger 2.0
        schemes = spec.get("schemes") or ["https"]
        print(f"  - {schemes[0]}://{spec['host']}{spec.get('basePath', '')}")
    else:
        print("  (none declared — base_url must be a config field)")

    print("\n## Auth schemes")
    schemes = (spec.get("components") or {}).get("securitySchemes") or spec.get(
        "securityDefinitions"
    ) or {}
    if not schemes:
        print("  (none declared)")
    for name, raw in schemes.items():
        s = _resolve(spec, raw)
        kind = s.get("type", "?")
        extra = ""
        if kind == "apiKey":
            extra = f" name={s.get('name')} in={s.get('in')}"
        elif kind in ("http", "basic"):
            extra = f" scheme={s.get('scheme', kind)}"
        elif kind in ("oauth2", "openIdConnect"):
            flows = list((s.get("flows") or {}).keys())
            extra = f" flows={flows or s.get('flow', '?')}"
        print(f"  - {name}: {kind}{extra}")
        print(f"    -> config field(s): {_config_hint(kind, s)}")


def _config_hint(kind: str, s: dict) -> str:
    if kind == "apiKey":
        return "api_key (sensitive: True)"
    if kind in ("http", "basic"):
        scheme = (s.get("scheme") or kind).lower()
        if scheme == "bearer":
            return "api_key / token (sensitive: True)"
        return "username, password (sensitive: True)"
    if kind in ("oauth2", "openIdConnect"):
        return "client_id, client_secret (sensitive: True), token_url/tenant, scope"
    return "TODO"


def _print_table(ops: list[dict]) -> None:
    reads = [o for o in ops if not o["mutating"]]
    writes = [o for o in ops if o["mutating"]]

    for title, group, hint in (
        ("Read operations", reads, "-> <system>_read, requires_approval=False, <system>:read"),
        ("Mutating operations", writes, "-> <system>_manage, requires_approval=True, <system>:write"),
    ):
        print(f"\n## {title} ({len(group)})  {hint}")
        if not group:
            print("  (none)")
            continue
        for o in sorted(group, key=lambda x: (x["tags"][:1], x["path"], x["method"])):
            tag = f"[{o['tags'][0]}] " if o["tags"] else ""
            print(f"  {o['method']:6} {o['path']}")
            print(f"         {tag}{o['op_id']}  params={o['params']}{o['body']}")
            if o["summary"]:
                print(f"         {o['summary']}")


def _print_detail(spec: dict, ops: list[dict], needle: str) -> None:
    hits = [
        o for o in ops
        if needle.lower() in (o["op_id"] or "").lower() or needle.lower() in o["path"].lower()
    ]
    if not hits:
        print(f"no operation matches {needle!r}")
        return
    for o in hits:
        print(f"\n### {o['method']} {o['path']}  ({o['op_id'] or 'no operationId'})")
        print(json.dumps(o["_raw"], indent=2, ensure_ascii=False)[:6000])


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("source", help="path or URL of the OpenAPI/Swagger document")
    ap.add_argument("--grep", help="only operations whose path or operationId matches")
    ap.add_argument("--tag", help="only operations carrying this tag")
    ap.add_argument("--detail", help="dump the raw definition of one operation")
    args = ap.parse_args()

    spec = _load(args.source)
    if not isinstance(spec, dict):
        sys.exit("spec did not parse into an object")

    ops = _operations(spec)
    if args.grep:
        n = args.grep.lower()
        ops = [o for o in ops if n in o["path"].lower() or n in (o["op_id"] or "").lower()]
    if args.tag:
        ops = [o for o in ops if args.tag in o["tags"]]

    if args.detail:
        _print_detail(spec, ops, args.detail)
        return

    _print_header(spec)
    print(f"\n(total operations after filters: {len(ops)})")
    _print_table(ops)

    tags = sorted({t for o in ops for t in o["tags"]})
    if tags:
        print(f"\n## Tags (candidate action groupings)\n  {', '.join(tags)}")
    print(
        "\n## Next\n"
        "  Collapse these into 2-3 action-dispatcher tools split by risk, not by\n"
        "  resource. See references/design-guide.md."
    )


if __name__ == "__main__":
    main()
