---
name: gsage-tool-builder
description: Build a new gSage AI MCP tool from an input spec — an OpenAPI/Swagger file or URL, API docs, curl examples, a Postman collection, or an existing SDK/CLI. Use whenever the user asks to "create a tool", "integrate <system> into gSage", "wrap this API as a tool", "add an MCP tool", or hands over API documentation and expects a BaseTool implementation. Covers intake of the API surface, choosing tool granularity, writing the client + tool modules + config schema + tests, and the verification/rollout steps.
---

# Building a gSage AI MCP tool from an API

Turn an API (or any callable surface) into tools that plug into the gSage
`BaseTool` framework: auto-discovered, permission-gated, org-scoped config,
audited, and agent-friendly.

**Read `references/contract.md` before writing any code.** It is the condensed
framework contract. The full narrative lives in `docs/dev/TOOLS.md`; read that
only when the contract file does not answer the question.

## The one rule that shapes everything

The agent sees a **catalog**, not an API. A 60-endpoint API must not become 60
MCP tools. Collapse endpoints into a handful of `action`-dispatcher tools split
by *risk level*, not by URL. See `references/design-guide.md`.

---

## Workflow

### Phase 1 — Intake the API surface

Gather the facts a tool needs. Do not start writing code until you can fill in
this table:

| Fact | Why it matters |
|---|---|
| Base URL (and whether it is per-tenant/self-hosted) | `config_schema` field vs. constant |
| Auth scheme (API key / bearer / OAuth2 / basic / token pair / mTLS) | which `config_schema` fields are `sensitive: true` |
| Endpoint list with method, path, params, response shape | the `action` enum and `params_schema` |
| Which endpoints mutate state | which tool gets `requires_approval = True` |
| Pagination style | `max_results` handling + `result_export` |
| Rate limits / quotas | `rate_limit_per_minute`, and whether to `@cached` |
| Error codes and their retryability | the `XError.code` → `_failure(retryable=)` map |
| Whether one org may have several instances of the system | `supports_multiple_configs` |

How to get them, in order of preference:

1. **OpenAPI / Swagger** — run
   `python .claude/skills/gsage-tool-builder/scripts/inspect_openapi.py <file-or-url>`
   for an endpoint table, auth schemes, and schema names. Use `--grep` to
   narrow a large spec, `--detail <operationId|path>` for one endpoint.
2. **Live docs page** — WebFetch it; extract the same table by hand.
3. **curl examples / Postman collection** — read them directly.
4. **Existing Python SDK** — prefer `httpx` against the REST API over adding a
   dependency, unless the SDK carries real protocol complexity (SOAP, gRPC,
   signed requests, an auth dance). If you do add a dependency, add it to
   `requirements.txt` and import it defensively (see `soc/ticket/rt/_client.py`).

If the API is *not* HTTP (a CLI, a DB, a filesystem, a Python lib), the same
workflow applies — only `_client.py` changes.

### Phase 2 — Choose the shape

Decide before writing. `references/design-guide.md` has the full decision table;
the short version:

- **1–3 endpoints, one concern** → a single module, no `_client.py`.
  Model: `src/mcp_server/tools/soc/threat_intel/cisa_kev.py`.
- **A whole system** → a package: `_client.py` (transport + errors + config
  schema) plus 2–3 tools split by risk:
  - `<system>_read` — read-only, no approval;
  - `<system>_manage` — mutations, `requires_approval = True`;
  - `<system>_dashboard` — optional aggregate/overview.
  Models: `src/mcp_server/tools/devops/proxmox/`,
  `src/mcp_server/tools/soc/threat_intel/shodan/`.

Always read the closest existing package end-to-end before writing. Match its
idiom rather than the templates when the two disagree.

### Phase 3 — Confirm what cannot be inferred

Ask the user (one `AskUserQuestion` round, only for what the input truly does
not settle):

- **Destination** — `custom_code/tools/<pkg>/` (operator code, survives core
  upgrades — the default for a customer-specific integration) or
  `src/mcp_server/tools/<area>/<pkg>/` (ships with the product).
- **Permission tags** — propose `<system>:read` / `<system>:write` and confirm.
- **Category** — one of the established values in `references/contract.md`.
- **Multi-instance** — does one org ever have two of these systems?
- **Approval** — which mutations must be gated.

If the user already answered any of these in their request, do not re-ask.
Pick sensible defaults for the rest, state them, and proceed.

### Phase 4 — Write the code

Copy from `templates/` and adapt. Never leave a template placeholder behind.

| File | Template | When |
|---|---|---|
| `__init__.py` | `templates/package_init.py.tmpl` | package layout |
| `_client.py` | `templates/_client.py.tmpl` | package layout |
| `<system>_read.py` | `templates/tool_action.py.tmpl` | package layout |
| `<system>_manage.py` | `templates/tool_action.py.tmpl` | mutating tool |
| `<name>.py` | `templates/tool_simple.py.tmpl` | single-module tool |
| `tests/test_<system>.py` | `templates/test_live.py.tmpl` | always |

Non-negotiables while writing:

1. **Validate every param.** LLM input is untrusted; `params_schema` only
   guarantees required-key presence, never types.
2. **Never reimplement** permissions, retries, audit, config decryption, or
   state persistence inside `execute()` — `BaseTool.run()` owns those.
3. **Secrets live in `config_schema` with `sensitive: true`**, never in
   `state`, never in a param, never in a log line. Mask tokens in logs.
4. **List results go through `src/mcp_server/tools/result_export.py`** —
   `build_agent_payload()` + `summarize()`. Never hand-roll CSV or truncation.
5. **Every error path returns `self._failure(CODE, msg, retryable=...)`** with a
   stable, agent-readable code — never a raw traceback, never a bare `raise`.
6. **Docstrings are agent-facing.** The class docstring, `summary`, and every
   `description` in `params_schema` are what the LLM reads to decide whether and
   how to call the tool. Write them for that reader: say what an action does,
   what it costs (credits, quota), and what it requires.
7. **No HTML or ad-hoc dialogs** for user input — use
   `self.interaction.form(...)`.

### Phase 5 — Verify

Run, from the repo root, and report actual output:

```bash
# 1. syntax
python3 -m py_compile <every new .py>

# 2. lint, if ruff is available
ruff check <package path>

# 3. discovery — the tool must appear in the registry
python3 -c "
from src.mcp_server.registry.registry import build_registry
r = build_registry()
print([t['name'] for t in r.list_all() if '<system>' in t['name']])
"

# 4. regenerate the auto-generated zones (only if config fields changed)
python3 scripts/generate_env_defaults.py
python3 scripts/generate_tools_docs.py

# 5. live smoke test, when credentials exist
pytest <tests path> -m <marker> -v
```

If step 3's helper name differs, inspect `src/mcp_server/registry/registry.py`
rather than guessing. If the registry cannot be built in this environment
(missing DB/Redis), say so plainly instead of claiming discovery passed.

Then walk `references/checklist.md` and report the result honestly — including
anything left for the operator (permission grant, org config, MCP restart).

---

## What "done" means

The tool is done when a new file exists, compiles, is discovered by the
registry, has an agent-legible schema, and the user has been told exactly which
operator steps remain (grant the permission tag to a group, configure the org,
restart `mcp-server`). Those last three cannot be done from code.
