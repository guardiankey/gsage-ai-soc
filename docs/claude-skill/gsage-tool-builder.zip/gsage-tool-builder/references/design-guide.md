# From an API to a tool catalog

How to decide *what tools to create* before deciding how to write them.

## 1. Granularity: never one tool per endpoint

The MCP catalog is a prompt the LLM must reason over. Sixty tools named
`system_get_user`, `system_list_users`, `system_update_user`… destroy the
agent's ability to pick correctly and blow up the token budget.

Collapse endpoints into **action dispatchers**: one tool, one `action` enum
param, a handler per action.

```
action: "list_vms" | "get_vm" | "list_storage" | "recent_tasks" | ...
```

### The split axis is risk, not resource

| Tool | Contains | Flags |
|---|---|---|
| `<system>_read` | every read-only query | `requires_approval=False`, permission `<system>:read` |
| `<system>_manage` | every mutation (create/update/delete/restart/block) | `requires_approval=True`, permission `<system>:write` |
| `<system>_dashboard` | pre-composed aggregate views over several reads | read permission |

Why risk and not resource: the approval gate, the permission tag, and the audit
posture are per-tool. Mixing a `delete_vm` into the read tool means either
over-gating every read or under-gating a destructive call.

### When to split further

Split a dispatcher only when:

- the action list passes roughly 12–15 and the actions fall into genuinely
  separate domains (e.g. Azure: `azure_inventory` / `azure_metrics` /
  `azure_costs` / `azure_manage`); or
- a subset needs a different `timeout_seconds`, `rate_limit_per_minute`, or
  `always_background` posture (a long scan vs. a quick lookup).

### When *not* to build a dispatcher

One or two endpoints serving one concern → a single flat tool with real
parameters and no `action`. `action` with two values is noise.

## 2. Choose the layout

| Situation | Layout |
|---|---|
| 1–3 endpoints, no shared auth complexity | single module, client inline |
| A system with auth + several endpoints | package with `_client.py` |
| Multiple views over the same client | add `_views.py` for row shaping |
| Expensive repeated reads | add `_cache.py` or `@cached` helpers |

Package layout (the standard):

```
<pkg>/
  __init__.py        # docstring: what the system is, tools, auth, permission
  _client.py         # transport, XError, CONFIG_SCHEMA, CONFIG_DEFAULTS, builder
  _views.py          # optional: raw API dict -> flat agent/CSV row
  <system>_read.py
  <system>_manage.py
  tests/test_<system>.py
```

`_client.py` owns the config schema so every tool in the family shares it, and
each tool sets `config_namespace = "<system>"` so they also share the config row
and env-var prefix.

Reference implementations, in increasing complexity:

- `src/mcp_server/tools/soc/threat_intel/shodan/` — API key, httpx, one read tool
- `src/mcp_server/tools/soc/ticket/rt/` — SDK-backed, several tools, error mapping
- `src/mcp_server/tools/devops/proxmox/` — multi-cluster profiles, views, cache

## 3. Design the `action` enum

Name actions after the *user's intent*, not the HTTP route:
`list_vms` not `get_cluster_resources_type_vm`.

Rules:

- `_ACTIONS = frozenset({...})` at module level; feed `sorted(_ACTIONS)` into the
  schema `enum` so the agent sees the exact allowed set.
- Dispatch by convention: `getattr(self, f"_do_{action}")`, after validating
  `action in _ACTIONS`. Never `getattr` on unvalidated input.
- Prefix each conditional param's description with the action(s) it belongs to:
  `"[get_vm] Target guest VMID."` — the LLM has one flat schema and needs the
  mapping.
- Document per-action cost or side effects in the description
  (`"1 query credit per page"`, `"restarts the guest"`).

## 4. Design the params

- `additionalProperties: False` always.
- `required` holds only what *every* action needs — usually just `action`.
  Per-action requirements are validated in code (raise a `_ParamError`, catch it,
  return `INVALID_PARAMS`).
- Give every enum an explicit `enum` list; give every bounded number
  `minimum`/`maximum`.
- Cap result sizes: `max_results` with a module-level `_DEFAULT_RESULTS` and
  `_MAX_RESULTS`, clamped with `min(...)`.
- Add the `result_export` quartet (`export_csv`, `export_json`, `group_by`,
  `top_n`) to any tool that can return a list.

## 5. Design the config

Everything deployment-specific belongs in `config_schema`, nothing in code:

| API trait | Config field |
|---|---|
| self-hosted | `host` / `base_url`, `port`, `verify_ssl` |
| API key | `api_key` (`sensitive: True`) |
| token pair | `token_id`, `token_secret` (`sensitive: True`) |
| OAuth2 client credentials | `client_id`, `client_secret` (`sensitive`), `tenant`/`scope` |
| basic auth | `username`, `password` (`sensitive: True`) |
| slow API | `timeout` with `minimum`/`maximum` |

Set `requires_config = True` whenever the tool cannot do anything without
credentials — it fails fast with a clear message instead of a confusing 401.

Two ways to support several instances of the same system for one org — pick one
and stay consistent inside a package:

1. **Platform profiles** — `supports_multiple_configs = True`; the framework
   injects a `config_profile` param and stores one `GSageToolConfig` row per
   profile. Preferred: the admin console understands it.
2. **In-config profiles** — a `profiles` object inside a single config row, with
   a `profile` param the tool resolves itself (the Proxmox pattern). Use when a
   profile is a whole nested cluster config.

## 6. Design the errors

Define one exception in `_client.py` carrying a stable `code` and `retryable`,
map the API's failures onto it once, and translate to `_failure()` in the tool:

| Upstream | code | retryable |
|---|---|---|
| 400 / bad params | `INVALID_PARAMS` | no |
| 401 | `AUTH_FAILED` | no |
| 403 | `PERMISSION_DENIED` | no |
| 404 | `NOT_FOUND` | no |
| 409 | `CONFLICT` | no |
| 429 | `RATE_LIMITED` | yes |
| 5xx | `UPSTREAM_ERROR` | yes |
| timeout | `TIMEOUT` | yes |
| DNS/TLS/connection | `CONNECTION_ERROR` | yes |
| missing credentials | `CONFIG_MISSING` | no |

The message is read by the LLM and shown to a human: say what failed, for which
target, and what to do about it. Never leak a secret, a full request URL with a
token in the query string, or a raw traceback.

## 7. Shape the response for an agent

The agent pays for every token of your response. A raw upstream JSON dump is
almost always the wrong answer.

- Flatten and rename to a stable, documented row shape (a `_compact_*()` or
  `_views.py` function).
- Drop fields nobody will act on; decode numeric enums to labels; resolve IDs to
  names when it is one extra call, not N.
- For single-object reads, return a curated summary plus the details that matter.
- For lists, hand everything to `build_agent_payload()` — the agent gets 100 rows
  plus a CSV artifact link, not 5000 rows.
- Always echo the `action` in `data` so the audit log and the agent transcript
  are self-describing.

## 8. Decide the runtime posture

| Question | Sets |
|---|---|
| Can a call take > 30s? | raise `timeout_seconds`, or set `background_threshold_seconds` |
| Is it always slow (a scan, a full sync)? | `always_background = True` |
| Slow only for big inputs? | override `should_run_background(params, config)` |
| Does the upstream throttle hard? | lower `rate_limit_per_minute`, add `@cached` |
| Does it change the world? | `requires_approval = True` + a `:write` permission |
| Should the agent see it by default? | almost always `core_tool = False` |
