# Review & rollout checklist

Walk this before declaring a tool done. Report each unchecked item to the user
rather than silently skipping it.

## Code

- [ ] Concrete `BaseTool` subclass, unique `name`, `execute()` implemented.
- [ ] `__init__.py` exists in every new subpackage (registry recursion).
- [ ] `summary`, `category`, `permissions`, `params_schema` all set.
- [ ] `available` is not left at `False` (copied from `example_tool.py`).
- [ ] `core_tool` is `False` unless the tool truly belongs in every conversation.
- [ ] `params_schema` has `additionalProperties: False`; enums are explicit;
      numeric bounds set; per-action params prefixed `[action]` in descriptions.
- [ ] Every param is type-validated in code, not just declared in the schema.
- [ ] `action` (if present) is validated against `_ACTIONS` before any `getattr`.
- [ ] Secrets only in `config_schema` with `sensitive: True`; none in `state`,
      params, log lines, or error messages.
- [ ] `requires_config = True` if the tool is useless without credentials.
- [ ] Every failure path returns `_failure()` with a stable code and a correct
      `retryable` flag. No bare `raise` escaping `execute()`, no traceback in the
      message.
- [ ] Broad `except Exception` logs with `log.exception` and returns
      `INTERNAL_ERROR`.
- [ ] List results go through `build_agent_payload()` / `summarize()`; rows are
      normalised before export; `export_csv`/`export_json`/`group_by`/`top_n`
      are in the schema.
- [ ] Result size is capped (`max_results` clamped to a module `_MAX_RESULTS`).
- [ ] `state` is mutated in place, never reassigned.
- [ ] `run()` is not overridden — or, if it is, it delegates to `super().run()`.
- [ ] Mutating tools set `requires_approval = True` and a `:write` permission,
      and are still safe if invoked directly.
- [ ] `audit_field_mapping` maps the fields an auditor would search by.
- [ ] Class docstring, `summary`, and schema descriptions are written for the
      LLM: intent, cost, prerequisites.
- [ ] HTTP client closes cleanly (async context manager); timeouts come from
      config; `verify_ssl` is configurable but defaults to `True`.
- [ ] New third-party imports are in `requirements.txt` and imported
      defensively if optional.

## Verification (run it, report real output)

- [ ] `python3 -m py_compile <files>`
- [ ] `ruff check <path>` (if ruff is installed)
- [ ] Registry discovery:
      `python3 -c "from src.mcp_server.registry.registry import build_registry; print([t['name'] for t in build_registry().list_all()])"`
- [ ] `python3 scripts/generate_env_defaults.py` — if config fields changed
- [ ] `python3 scripts/generate_tools_docs.py` — if config/schema changed
- [ ] `pytest <tests> -m <marker> -v` — if credentials are available

## Handoff to the operator (cannot be done from code)

State these explicitly in the final message:

1. Grant the permission tag(s) to a group.
2. Configure the tool for the target organization (admin console, or
   `TOOL_<TOOL_NAME>__<FIELD>` env vars), including which fields are secrets.
3. Restart `mcp-server` (and `celery-tools` if the tool can run in background)
   so the registry picks it up and syncs `gsage_tools` / `gsage_permissions`.
4. Verify via `search_tools` (or `list_tools` if `core_tool=True`).

## For a customer deployment

If the tool lives in `custom_code/tools/`, remember it is bind-mounted from the
host (`/opt/gsage/shared/custom_code`) and imported as `custom_code.tools.*` —
imports inside the package must use that path, not `src.mcp_server.tools.*`.
Check `CUSTOM_TOOLS_MODULE` is not empty in the target containers.
