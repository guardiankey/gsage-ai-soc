# The `BaseTool` contract (condensed)

Source of truth: `src/mcp_server/tools/base.py`,
`src/mcp_server/tools/result_export.py`,
`src/mcp_server/registry/registry.py`, `src/shared/cache/`.
Narrative version: `docs/dev/TOOLS.md`.

## Minimum viable tool

A concrete, non-abstract `BaseTool` subclass with a `name` ClassVar and an
`execute()` implementation, living under a scanned package. **There is no
registration step** — the registry discovers it at MCP startup.

```python
from __future__ import annotations
from typing import ClassVar, Optional

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.shared.security.context import AgentContext


class MyTool(BaseTool):
    name: ClassVar[str] = "my_tool"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = "One line the LLM reads in search_tools"
    category: ClassVar[str] = "utility"
    permissions: ClassVar[list[str]] = ["utility:run"]

    params_schema: ClassVar[dict] = {
        "type": "object",
        "required": ["value"],
        "properties": {"value": {"type": "string", "description": "..."}},
        "additionalProperties": False,
    }

    async def execute(self, agent_context, params, config, state) -> ToolResult:
        raw = params.get("value")
        if not isinstance(raw, str) or not raw.strip():
            return self._failure("INVALID_PARAMS", "'value' must be a non-empty string")
        return self._success({"value": raw.strip()})
```

Scanned packages: `src/mcp_server/tools/{core,soc,crud,devops,marketing,enterprise}/…`
and `CUSTOM_TOOLS_MODULE` (default `custom_code.tools`). Every subpackage needs
an `__init__.py` for `walk_packages` to recurse into it.

## ClassVars

### Discovery / agent UX

| Attr | Req | Meaning |
|---|---|---|
| `name` | yes | unique tool id, `snake_case` |
| `version` | no | default `"1.0.0"`; bump on schema change |
| `summary` | yes in practice | one line shown by `search_tools` |
| `category` | yes in practice | see list below |
| `core_tool` | no | `True` → may appear in `list_tools`. Default `False`. **Keep it False** unless the tool belongs in every conversation |
| `available` | no | `False` → skipped by the registry (use for stubs) |
| `config_namespace` | no | share config rows/env vars across a tool family (e.g. all `proxmox_*` tools read the `proxmox` namespace) |

Categories in use: `dns`, `network`, `email`, `threat_intel`, `file`,
`document`, `itsm`, `edr`, `kb`, `crud`, `firewall`, `security`, `utility`,
`devops`.

### Safety / runtime

| Attr | Default | Meaning |
|---|---|---|
| `permissions` | `[]` | required tags, e.g. `["proxmox:read"]` |
| `rate_limit_per_minute` | `60` | per org+tool+profile, Redis-backed |
| `timeout_seconds` | `30` | wraps `execute()` |
| `use_circuit_breaker` | `True` | Redis circuit breaker on retryable failures |
| `requires_approval` | `False` | marks the tool approval-sensitive; the gate lives in the agent layer, so `execute()` must still be safe if called directly |
| `always_background` | `False` | always dispatch to Celery |
| `background_threshold_seconds` | `None` | on timeout, fall back to background instead of failing |
| `supports_multiple_configs` | `False` | multiple config profiles per org; adds a `config_profile` param |
| `audit_field_mapping` | `{}` | map params into audit context, e.g. `{"action": "action", "target_entities": "name"}` |
| `audit_output` | `True` | store `ToolResult.data` in the audit log |

### Config / state

| Attr | Default | Meaning |
|---|---|---|
| `params_schema` | `None` | JSON-Schema-ish input contract shown to the LLM |
| `config_schema` | `None` | org-scoped config schema; mark secrets `"sensitive": True` |
| `config_defaults` | `{}` | lowest-priority config layer |
| `requires_config` | `False` | fail early when no usable config exists |
| `state_schema` / `state_defaults` | `None` / `{}` | persisted JSONB runtime state |
| `reset_policy` | `"never"` | `daily` \| `monthly` \| `never` |

Prefer the JSON Schema shape (`type`/`properties`/`required`/
`additionalProperties`) for both `params_schema` and `config_schema`.

## What `run()` already does — never duplicate it in `execute()`

1. strips framework params (`config_profile`, `_audit_context`)
2. profile-aware permission check
3. Redis rate limiting
4. circuit breaker
5. config load + decrypt + 5-minute Redis cache (`toolcfg:{org}:{tool}:{profile}`)
6. state load
7. optional background pre-flight dispatch
8. required-param presence check from `params_schema` (**presence only — not types**)
9. timeout + up to 2 retries (1s, 2s backoff) for `retryable=True` failures
10. circuit breaker feedback
11. auto-persist the mutated `state` dict
12. audit write to Elasticsearch

Overriding `run()` is an advanced move — do it only to inject a `ContextVar`
(e.g. the DB session for a `@cached` helper) or a feature-flag pre-check, and
always delegate to `super().run(...)`.

## Config resolution order

1. `config_defaults` (class) — plus a same-stem `<module>.yaml` next to the
   module, which class defaults override on collision
2. env vars `TOOL_<TOOL_NAME>__<FIELD>` (coerced via `config_schema`)
3. encrypted `GSageToolConfig` row (highest priority)

A tool configured only through env vars counts as configured. After adding or
changing config fields run `python scripts/generate_env_defaults.py` and
`python scripts/generate_tools_docs.py`.

## Permissions

Declare the plain base tag (`proxmox:read`). At runtime the platform also
honours `proxmox:read:*`, `proxmox:read:<profile_id>`, and `fnmatch` globs like
`proxmox:*`. Admins refine by profile in the DB — the class declares the base
tag only.

A correct tool stays invisible until a group is granted the tag.

## `ToolResult` helpers

```python
self._success(data: dict, execution_time_ms: int = 0)
self._failure(code: str, message: str, retryable: bool = False, execution_time_ms: int = 0)
self._partial(data: dict, code: str, message: str, retryable: bool = False, ...)
```

Use stable, uppercase, agent-readable codes. Conventions in the codebase:
`INVALID_PARAMS`, `INVALID_INPUT`, `CONFIG_MISSING`, `AUTH_FAILED`,
`NOT_FOUND`, `PERMISSION_DENIED`, `RATE_LIMITED`, `CONNECTION_ERROR`,
`TIMEOUT`, `INTERNAL_ERROR`, `NOT_IMPLEMENTED`.

`retryable=True` only for transient conditions: timeouts, connection errors,
429, 5xx. Never for validation, auth, or not-found.

## `AgentContext`

Frozen dataclass (`src/shared/security/context.py`) with `org_id`, `user_id`,
`group_ids`, `permissions`, `request_id`, `source`, `api_key_id`, `dept_id`,
`user_credentials`. Use `org_id`/`user_id`/`dept_id` for scoping and file
access control; never trust anything else as identity.

`agent_context.user_credentials.get(self.name)` holds per-user decrypted
credentials from the keychain when the deployment uses them — prefer them over
org config for tools that must act as the individual user.

## Large / tabular results — `result_export.py`

```python
from src.mcp_server.tools.result_export import (
    AGENT_PREVIEW_ROWS, build_agent_payload, summarize,
)

summary = summarize(rows, group_by=params.get("group_by") or None,
                    top_n=int(params.get("top_n", 10) or 10),
                    default_keys=("severity", "status", "type"))

payload = await build_agent_payload(
    tool=self, rows=rows,
    export_csv=bool(params.get("export_csv", False)),
    export_json=bool(params.get("export_json", False)),
    filename_prefix=f"{self.name}_{action}",
    agent_context=agent_context,
)

return self._success({
    "rows_total": payload["rows_total"],
    "rows_overflow": payload["rows_overflow"],
    "rows_preview_limit": AGENT_PREVIEW_ROWS,
    "artifacts": payload["artifacts"],
    "agent_hint": payload["agent_hint"],
    "summary": summary,
    "rows": payload["rows_preview"],
})
```

Inline preview caps at `AGENT_PREVIEW_ROWS` (100); overflow forces CSV export on
even when `export_csv=False`. Normalise and enrich rows (decode enums, resolve
names, flatten nesting) **before** calling `build_agent_payload` so the preview
and the CSV agree.

Add to `params_schema` for any list-style tool: `export_csv` (bool, default
False), `export_json` (bool, default False), `group_by` (array of string),
`top_n` (integer).

## Files

- `await self._store_file(...)` → uploads to MinIO + DB row, returns
  `file_id`, `filename`, `content_type`, `size_bytes`. Use it for generated
  reports/exports.
- `await self._load_file(file_id, org_id=..., user_id=..., dept_id=...)` →
  metadata + bytes, with ownership checks. No `session=` needed in a normal
  `execute()` flow.

## State

Plain JSONB, per org+profile, **not encrypted** — no secrets. Mutate the dict in
place so `run()` auto-saves it:

```python
state["queries_used"] = state.get("queries_used", 0) + 1
```

Reassigning `state = {...}` does nothing. Use `update_state_atomic()` for
counters under concurrency.

## Result cache — `@cached`

For idempotent, read-like helpers only. Never for writes or approval-sensitive
work.

```python
from src.shared.cache import cached

@cached(ttl=3600, scope="org",
        key_fn=lambda *, domain, **_: f"dns:{domain.lower()}",
        logical_name="my_tool")
async def _lookup(*, domain: str, org_id: uuid.UUID, session: AsyncSession) -> dict:
    ...
```

Requires a `session=` kwarg (else cache is bypassed) and `org_id=` for
`scope="org"`. Since `execute()` has no session, bridge one with a thin `run()`
override + `ContextVar` — see `cisa_kev`, `nvd_lookup`, `datastore`.

This is separate from the automatic 5-minute Redis **config** cache, which needs
no code.

## User input — the Interaction Service

Never emit HTML or a custom dialog. Declare a `Form` and await it:

```python
from src.shared.interaction import Form, TextField, SelectField, ResumeMode

class IncidentForm(Form):
    titulo = TextField(label="Título", required=True)
    severidade = SelectField(label="Severidade", options=[
        {"value": "alta", "label": "Alta"}, {"value": "baixa", "label": "Baixa"}])

data = await self.interaction.form(
    IncidentForm, title="Criar Incidente",
    resume=ResumeMode.CONTINUE_TOOL, context={"ticket_id": params.get("ticket_id")})
```

`CONTINUE_TOOL` blocks and returns the dict. `REPLAN_AGENT` raises
`InteractionReplanRequested` and lets the agent replan. Fields: `TextField`,
`TextAreaField`, `NumberField`, `SelectField`, `CheckboxField`, `RadioField`,
`DateField`. Not available in background (Celery) tools — those should return a
`USER_INPUT_REQUIRED` failure instead.

## Pitfalls

1. Manual registration — there is none.
2. Reimplementing permission/retry/audit/config logic in `execute()`.
3. Trusting LLM param types.
4. `core_tool=True` on too many tools — `list_tools` is deliberately small.
5. Secrets in `state`.
6. Forgetting the permission grant — the tool stays invisible.
7. Confusing the config cache (automatic) with the result cache (opt-in).
8. Rebuilding the `state` dict instead of mutating it.
9. Overriding `run()` without delegating to `super()`.
10. Hand-rolled CSV instead of `result_export`.
11. HTML dialogs instead of the Interaction Service.
