# Guia — criando uma tool do gSage com a skill `gsage-tool-builder`

Para quem vai integrar um sistema externo (normalmente uma API) ao gSage e
nunca escreveu uma tool. Do zero até a tool no ar.

A skill é um conjunto de instruções que o Claude Code carrega para conduzir
esse trabalho: ela sabe o contrato do `BaseTool`, os padrões do repo e o que
verificar no fim. Você traz o insumo e as decisões de negócio; ela escreve o
código.

---

## Antes de começar (uma vez só)

1. Instale o Claude Code.
2. Clone o repositório. **A skill já vem junto** — ela mora em
   `.claude/skills/gsage-tool-builder/`, versionada com o código.
3. Abra o Claude Code **na raiz do repo**:

   ```bash
   cd gsage-ai-soc
   claude
   ```

   Abrir numa subpasta funciona, mas os caminhos dos comandos de verificação
   assumem a raiz.
4. Confirme que a skill foi carregada: digite `/` e veja se
   `gsage-tool-builder` aparece na lista.

> **Pegadinha nº 1:** skills de projeto são lidas **na inicialização da
> sessão**. Se você deu `git pull` (ou editou a skill) com o Claude Code já
> aberto, ela não existe para a sessão atual. Saia e entre de novo.

Não precisa instalar mais nada. O script auxiliar da skill usa só `httpx` e
`PyYAML`, que já estão no `requirements.txt` do projeto.

---

## Passo 1 — Junte o insumo

Quanto melhor o insumo, menos a skill precisa adivinhar.

| Insumo | O que fazer | Qualidade |
|---|---|---|
| Spec OpenAPI / Swagger (URL ou arquivo) | passe a URL ou o caminho | melhor caso — ela extrai tudo sozinha |
| Página de documentação | cole a URL | bom |
| Exemplos de `curl` | cole no chat | bom para APIs pequenas |
| Coleção Postman | passe o caminho do `.json` | bom |
| SDK ou CLI existente | aponte o pacote/repo | funciona, mas confirme se vale a dependência |

Opcional, mas ajuda muito: **credenciais de teste** (conta sandbox, token
read-only). Com elas a skill roda o teste ao vivo no fim e você sai com a
certeza de que a tool funciona, não só de que ela compila.

### A pergunta que você precisa responder antes de invocar

> *O que um analista vai querer **fazer** com esse sistema no meio de um
> incidente?*

É isso que define o recorte da tool — não a lista de endpoints. Uma API grande
não vira uma tool grande; vira duas ou três tools pequenas cobrindo as ações
que alguém realmente executa sob pressão.

---

## Passo 2 — Invoque a skill

Três formas, todas equivalentes:

**a) Pelo nome** — quando você quer deixar explícito:

```
/gsage-tool-builder
```

**b) Descrevendo a tarefa** — a skill dispara sozinha pela descrição dela:

```
Cria uma tool do Zabbix pro gsage. Spec: https://exemplo/openapi.json
```

**c) Só jogando a documentação:**

```
Integra esse sistema no gsage: <cola o curl / a URL da doc>
```

### Como escrever um bom prompt de abertura

Um prompt bom traz **insumo + recorte + destino** numa frase. Compare:

| ❌ Fraco | ✅ Forte |
|---|---|
| "faz uma tool da Cloudflare" | "Cria tool da Cloudflare pro gsage a partir de `<url do spec>`. Recorte: DNS records, regras de firewall/WAF e purge de cache — o resto da API não interessa. Vai em `src/mcp_server/tools/soc/firewall/cloudflare/`, seguindo o padrão do `opnsense/`." |

O prompt forte pula a rodada de perguntas e vai direto ao código. Se você não
souber responder tudo, tudo bem — mande o que tem, ela pergunta o resto.

---

## Passo 3 — Responda as perguntas

A skill faz **uma** rodada de perguntas, só com o que o insumo não resolve.
São quatro, tipicamente:

| Pergunta | O que está em jogo | Padrão razoável |
|---|---|---|
| **Escopo** — quais partes da API entram | Uma API de 3000 endpoints não vira 3000 tools. Recorte pelo que o analista faz. | as operações de triagem + as de resposta |
| **Destino** — onde o código mora | `custom_code/tools/` sobrevive a upgrades do core e é o certo para integração de um cliente específico. `src/mcp_server/tools/<área>/` é o que vai no produto. | `custom_code/` se for de um cliente |
| **Permissão** — qual tag exigir | Controla quem enxerga e quem executa. | `<sistema>:read` e `<sistema>:write` |
| **Aprovação** — o que exige gate humano | Toda ação que muda o mundo (criar, apagar, bloquear, reiniciar). | tudo que não é leitura |

Se o repo já tiver um pacote do mesmo domínio, **diga isso** — a skill vai ler
esse pacote e seguir o mesmo idioma em vez do template genérico. Ex.: "segue o
padrão do `opnsense/`".

---

## Passo 4 — O que ela faz sozinha

A partir daqui é trabalho dela. O que esperar:

**Escreve os arquivos.** Para uma API com auth e vários endpoints, o formato
padrão é um pacote:

```
<pacote>/
├── __init__.py            # o que o sistema é, quais tools, auth, permissão
├── _client.py             # transporte HTTP + erros + schema de config
├── _views.py              # dict cru da API -> linha achatada (opcional)
├── <sistema>_read.py      # leitura — sem aprovação
├── <sistema>_manage.py    # escrita — requires_approval=True
└── tests/test_<sistema>.py
```

Para uma API de 1–3 endpoints, é um arquivo `.py` só.

**Corta as tools por risco, não por recurso.** Leitura de DNS fica junto de
leitura de firewall; escrita de DNS junto de escrita de firewall. Motivo: o
gate de aprovação, a tag de permissão e a auditoria são por *tool*, não por
endpoint. Misturar um `delete` na tool de leitura obrigaria a exigir aprovação
em toda consulta.

**Verifica.** Roda e te mostra a saída real de:

- `python3 -m py_compile` nos arquivos novos
- `ruff check` no pacote
- checagem de *discovery*: a tool aparece mesmo no registry?
- `scripts/generate_env_defaults.py` e `scripts/generate_tools_docs.py`, se
  você mexeu em campos de config
- `pytest`, se houver credenciais

---

## Passo 5 — Revise (não pule)

O código foi escrito por um modelo. Cinco coisas que merecem olho humano:

1. **As descrições do schema.** O agente escolhe a tool lendo `summary`,
   a docstring da classe e cada `description` dos parâmetros. Se estiver
   vago ali, a tool vai ser chamada errado — ou nunca.
2. **Os segredos.** Toda credencial tem que estar no `config_schema` com
   `sensitive: True`. Nunca em `state`, nunca num parâmetro, nunca numa linha
   de log ou mensagem de erro.
3. **A flag de aprovação.** Confira uma a uma: toda ação destrutiva está na
   tool com `requires_approval = True`?
4. **Os códigos de erro.** `retryable=True` só para o que é transitório
   (timeout, 429, 5xx). Marcar um 401 como retryable faz o framework tentar
   três vezes com a credencial errada.
5. **O formato da resposta.** O agente paga token por cada campo. Despejo do
   JSON cru da API quase sempre está errado — o certo é linha achatada e
   enxuta, e listas grandes passando pelo `result_export` (o agente recebe 100
   linhas + link do CSV, não 5000 linhas).

---

## Passo 6 — Colocar no ar

Três coisas que **não dá para fazer por código** — a skill vai te lembrar
delas no fim, mas alguém precisa executá-las:

1. **Conceder a tag de permissão** a um grupo. Sem isso a tool existe e fica
   invisível — é a causa nº 1 de "criei a tool e ela não aparece".
2. **Configurar a organização** — pelo admin console, ou por variáveis
   `TOOL_<NOME_DA_TOOL>__<CAMPO>`.
3. **Reiniciar o `mcp-server`** (e o `celery-tools`, se a tool roda em
   background) para o registry descobrir a tool e sincronizar as tabelas
   `gsage_tools` e `gsage_permissions`.

Verifique pelo `search_tools` no chat do gSage. Se você marcou
`core_tool = True` — o que raramente é o certo — ela aparece também no
`list_tools`.

---

## Armadilhas comuns

| Sintoma | Causa |
|---|---|
| A skill não aparece com `/` | Sessão aberta antes do `git pull`. Reinicie. |
| "Criei a tool e ela não aparece no gSage" | Faltou conceder a tag de permissão a um grupo, ou faltou reiniciar o `mcp-server`. |
| A tool aparece mas o agente nunca a usa | `summary` e descrições vagas. Reescreva pensando em quem lê: o modelo. |
| A tool nem foi descoberta pelo registry | Faltou `__init__.py` em algum subpacote novo, ou `available` ficou `False` (é o padrão do `example_tool.py`). |
| O agente chama a tool com parâmetro errado | Faltou prefixar as descrições com a ação: `"[get_item] ID do objeto."` |
| Erro 401 sendo tentado 3 vezes | `retryable` marcado errado. |

E a armadilha conceitual, que é a mais cara: **pedir uma tool por endpoint.**
O catálogo MCP é prompt que o modelo tem que ler inteiro para escolher. Trinta
tools chamadas `sistema_get_user`, `sistema_list_users`, `sistema_update_user`
destroem a capacidade de escolha do agente. Se você se pegar pedindo isso, pare
e volte para a pergunta do Passo 1.

---

## Exemplo do começo ao fim

**Sistema:** Cloudflare. **Insumo:** o spec OpenAPI oficial (24MB, 3408
operações).

**O que você digita:**

```
Cria uma tool da Cloudflare pro gsage.
Spec: https://raw.githubusercontent.com/cloudflare/api-schemas/main/openapi.json
Recorte: DNS records, regras de firewall/WAF/IP access e purge de cache.
Vai em src/mcp_server/tools/soc/firewall/cloudflare/, no padrão do opnsense/.
```

**O que ela faz:** roda o script de inspeção no spec — que resume 24MB em uma
tabela sem jogar nada disso no contexto —, identifica que a auth é bearer token
(com par legado e-mail + key como alternativa), separa as operações em leitura
e escrita, e propõe:

```
soc/firewall/cloudflare/
├── _client.py               # httpx, CloudflareError, CF_CONFIG_SCHEMA
├── cloudflare_firewall.py   # cloudflare:read, sem aprovação
│     list_zones, get_zone, list_dns_records, get_dns_record,
│     export_dns_records, list_firewall_rules, list_ip_access_rules,
│     list_waf_rulesets, get_analytics
└── cloudflare_manage.py     # cloudflare:write, requires_approval=True
      block_ip, unblock_ip, create_dns_record, update_dns_record,
      delete_dns_record, purge_cache, set_under_attack_mode
```

3408 operações viraram **duas tools**. Config compartilhada pelas duas
(`api_token` sensível, `account_id`, `timeout`), com suporte a mais de uma
conta Cloudflare por organização.

---

## Onde a skill mora (e como melhorá-la)

Tudo em `.claude/skills/gsage-tool-builder/`:

| Arquivo | Para quê |
|---|---|
| `SKILL.md` | o fluxo das 5 fases e as regras não-negociáveis |
| `references/contract.md` | o contrato do `BaseTool` condensado |
| `references/design-guide.md` | como recortar uma API em tools |
| `references/checklist.md` | revisão + passos de rollout |
| `templates/*.tmpl` | esqueletos de client, tool e testes |
| `scripts/inspect_openapi.py` | resume um spec OpenAPI em tabela de endpoints |

É código versionado como qualquer outro. Se você descobrir um padrão melhor
ou uma pegadinha nova, edite e mande PR — a próxima pessoa herda o aprendizado.

A referência completa e narrativa do framework continua sendo
`docs/dev/TOOLS.md`; a skill é a versão operacional dela.
