# Catalog Authoring Guide — Instructions & Processes

> **Audience:** AI agents and developers creating or editing YAML definitions in the Instruction Catalog and Process Catalog.
> **Version:** 1.0 | **Date:** 2026-07-14
> **Based on:** `SPEC-licitacoes-engine.md`, `SPEC-licitacao_artefatos.md`, `SPEC-prompts.md`, `SPEC-licitacoes.md`

---

## 1. The Two Catalogs — What They Are

The system has **two distinct but complementary catalogs** for domain knowledge. They serve different purposes and must not be confused:

| Dimension | **Instruction Catalog** | **Process Catalog** |
|:----------|:------------------------|:--------------------|
| **Location** | `instruction_catalog/definitions/instructions/` | `process_catalog/definitions/` |
| **Answers the question** | *"What do I need to know to do this well?"* | *"What is the sequence of steps?"* |
| **Content type** | Cognitive assets: rules, checklists, templates, examples, schemas | Procedural assets: steps, states, decisions, document models |
| **Unit of composition** | `asset` (rule, checklist, template, example, schema) | `step` (task, decision, gate, sub-process) |
| **Activation** | `applies_when` DSL — condition-based | Facts → Inference → Normative Resolution → Capabilities → DAG |
| **Loading** | Lazy — agent loads on demand before a task | Eager — resolved by `process_catalog.classify()` → `resolve()` → `compose()` |
| **Output** | Knowledge injected into agent context | Workflow DAG with ordered steps |
| **Storage format** | YAML with typed `assets[]` | YAML with `steps[]`, `lifecycle`, `documents` |

### The golden rule

> - **Instruction** = *"What should I consider to execute well?"* (knowledge, criteria, warnings)
> - **Process Catalog** = *"What is the order of steps?"* (workflow, DAG)
> - **Agent** = *"How do I execute concretely using both?"*

The Instruction Catalog **never** describes a sequence of tool calls — that is the Process Catalog's responsibility.

---

## 2. Instruction Catalog — Authoring Rules

### 2.1 File structure

Each instruction is a single YAML file under:
```
instruction_catalog/definitions/instructions/{category}/{instruction_id}.yaml
```

Categories map to directories: `licitacoes/`, `compliance/`, `soc/`.

### 2.2 Required fields

```yaml
instruction:
  id: string            # snake_case, unique. Pattern: ^[a-z][a-z0-9_]*$
  version: string        # SemVer: "1.0.0"
  title: string          # Human-readable, in Portuguese for licitacoes
  summary: string        # One-line description (max 200 chars)
  category: string       # Logical group: licitacoes, compliance, soc, geral
  assets: array          # Min 1 item — the core content
```

### 2.3 Optional fields

| Field | Type | Description |
|:------|:-----|:------------|
| `tags` | `string[]` | Search/discovery tags. Use `modelo_oficial` for official SGD models, `portaria-*` for specific portarias |
| `applies_when` | object | Activation rule using `all_of` / `any_of` DSL with operators: `equals`, `not_equals`, `in`, `gt`, `lt`, `gte`, `lte` |
| `priority` | integer (0–100) | Higher = more specific, overrides lower priority. Tool-level = 100, entrypoints = 100, models = 85-90, operational = 60-80 |
| `asset_refs` | array | References to external resources (templates, other instructions, documents) |
| `metadata` | object | `author`, `created`, `updated` |

### 2.4 Asset types

Every instruction contains one or more **assets** — typed, atomic content blocks:

| `type` | Purpose | Example |
|:-------|:--------|:--------|
| `rule` | Mandatory guidance, legal basis, or constraint | *"The object must be described clearly, without bias toward any supplier."* |
| `checklist` | Verification items (Markdown task list) | `- [ ] Object defined without bias` |
| `template` | Inline structured output format (Markdown table or section structure) | Table with columns: Campo, Valor, Observação |
| `example` | Concrete input → output example | *"Input: Domain example-phish.com, Creation: 2026-07-01 → Output: suspicious indicators in bold"* |
| `schema` | JSON Schema for structured validation of document fields | `{type: object, properties: {metrica_software: {type: string, enum: [...]}}}` |
| `reasoning_policy` | Decision logic for the agent (e.g., when to use PNCP vs ComprasGovBr) | *"ALWAYS check IRP/SRP before starting a new TIC procurement"* |

Every asset has:
- `type` (required)
- `content` (required — string for text assets, object for `schema`)
- `priority` (optional, default 10 — controls ordering within the instruction)

### 2.5 `applies_when` — activation rules

Uses the same RuleEvaluator DSL as the Process Catalog. The agent evaluates these against `runtime_context`:

```yaml
# Activate when the domain is TIC
applies_when:
  all_of:
    - field: dominio.tic
      operator: equals
      value: true

# Activate for whois OR rdap tools
applies_when:
  any_of:
    - field: tool_name
      operator: equals
      value: whois
    - field: tool_name
      operator: equals
      value: rdap

# Activate for specific solution types (official models)
applies_when:
  all_of:
    - field: tipo_solucao
      operator: equals
      value: desenvolvimento
```

### 2.6 `asset_refs` — external references

Instructions reference external resources rather than duplicating them:

| `source` | What it references | How the agent resolves it |
|:---------|:-------------------|:--------------------------|
| `process_catalog` | Document models (YAML → Markdown) | `process_catalog(action="get_document", document_id=ref_id)` |
| `user_templates` | User-uploaded templates (GSageFile) | `document_templates` → `generate_document(template_id=ref_id)` |
| `instruction_catalog` | Another instruction to load together | `instruction_catalog(action="get", instruction_id=ref_id)` |
| `knowledge_base` | Document in Weaviate | `knowledge_base(query=ref_id)` |

### 2.7 Template references — inline vs external

| Form | When to use | Example |
|:-----|:------------|:--------|
| **Inline** (`assets[{type: template, content: ...}]`) | Simple, instruction-specific, no expected reuse | Markdown table for whois output |
| **Reference** (`asset_refs[{source, ref_type, ref_id}]`) | Template already exists in Process Catalog, `user_templates`, or is shared across multiple instructions | TR model, official DOCX from gov.br |

**Rule of thumb:** If the template already exists elsewhere → **reference it**. If it's simple and specific → **embed it**.

---

## 3. Process Catalog — Authoring Rules

### 3.1 Architecture layers

The Process Catalog has a layered architecture:

```
authorities → obligations → capabilities → modules (aggregators) → process definitions
```

| Layer | Purpose | Example |
|:------|:--------|:--------|
| **Authority** | Legal source with weight + role | Lei 14.133/2021 (mandatory, creates_obligation) |
| **Obligation** | Normative requirement with activation rules | `obrig_alinhamento_pdtic` — triggered when `dominio.tic == true` |
| **Capability** | Atomic unit of workflow composition | `exige_alinhamento_pdtic` — adds a step to the DAG |
| **Module** | Organizational aggregator (no logic) | `tic_in94` — groups TIC-related capabilities |
| **Process Definition** | Concrete workflow with states, steps, lifecycle | `contratacao_tic_in94` — 11 steps from DFD to contract signature |

### 3.2 Process definition structure

```yaml
process:
  id: string              # snake_case, unique
  name: string            # Human-readable
  version: string         # SemVer
  category: string
  tags: string[]
  status: active
  owner: string           # area_tic, area_administrativa, etc.

  applicability:
    description: string
    triggers:             # manual, sub_process, auto

  lifecycle:
    initial_state: string
    final_states: string[]
    states:               # Named states with transitions

  steps:                  # Ordered tasks, decisions, gates
    - id: string
      name: string
      type: task | decision | gate
      state: string
      objective: string
      responsible_role: string
      depends_on: string[]      # DAG dependencies
      next_steps: array
      guidance:
        questions_to_ask: []
        warnings: []
        tool_hints: []
      checklist:
        completion: []
      documents: []

  documents:
    generated:            # Document models produced by this process
      - id: string
        name: string
        model_ref: string # Path to Markdown template
```

### 3.3 Key principles

1. **Facts ≠ Inferences ≠ Decisions**: Facts come from the user. Inferences are derived classifications. Decisions are engine outputs. Never mix them.

2. **Composition over branching**: Instead of `if TIC then branch_x else branch_y`, each facet *adds* requirements to the base flow.

3. **Full traceability**: Every requirement traces back through the chain: `step → capability → obligation → dispositivo → authority`.

4. **Declarativity**: Rules are declarative (YAML), not programmatic. New norms = new YAML files, no code changes.

5. **DAG-based ordering**: Step ordering is always resolved by `depends_on` + topological sort. No positional injection (`inject_after`, `inject_before`).

6. **Capability as atomic unit**: The smallest decision unit is the capability (e.g., `exige_alinhamento_pdtic`), not the module (e.g., `tic_in94`).

7. **Document Model ≠ Renderer**: Documents have a **canonical model** (structure, sections, placeholders) independent of output format. Markdown is the default rendering format, but the model survives format changes (MD → HTML, PDF, DOCX).

---

## 4. Relationship Between Instructions and Processes

### 4.1 Unidirectional: Capability → Instruction

```mermaid
flowchart LR
    subgraph ProcessCatalog["Process Catalog"]
        O[Obligation] --> C[Capability]
        C --> S[Steps in DAG]
    end
    subgraph InstructionCatalog["Instruction Catalog"]
        I[Instruction]
    end
    C -->|suggested_instructions| I
```

A capability declares `suggested_instructions`. The instruction does **NOT** reference back — avoids bidirectional inconsistency.

### 4.2 Integration flow

```
Agent receives: "I need to hire TIC support"
    │
    ▼
1. instruction_catalog(action="get", instruction_id="contratacao_tic")
   → Loads domain knowledge: norms, tools, documents, warnings
    │
    ▼
2. process_catalog(action="classify")
   → Classification Engine: asks progressive questions → contract_facts
    │
    ▼
3. process_catalog(action="infer")
   → Inference Engine: derives classifications from facts → inferences
    │
    ▼
4. process_catalog(action="resolve")
   → Decision Engine: evaluates obligations → capabilities → DAG
    │
    ▼
5. process_catalog(action="compose")
   → Workflow Engine: topological sort of steps
    │
    ▼
6. For each step, agent loads relevant instructions:
   instruction_catalog(action="search", query="TR")
   → Loads elaboracao_tr, modelo_desenvolvimento_750, etc.
    │
    ▼
7. Agent executes step with instruction knowledge in context
```

### 4.3 When to create what

| Scenario | Create |
|:---------|:-------|
| "Here's how to write a good TR" | **Instruction** — cognitive knowledge |
| "The procurement process has these 11 steps in order" | **Process Definition** — procedural workflow |
| "Check if IRP/SRP exists before starting a new procurement" | **Obligation** + **Capability** — blocking condition |
| "For development contracts, these specific fields must be validated" | **Instruction** (modelo_oficial with `schema` asset) |
| "The contract management lifecycle: start → execute → renew → close" | **Process Definition** with lifecycle states |

---

## 5. Official Documents Policy — NEVER INVENT

### 5.1 The cardinal rule

> **Every template, model, or normative reference MUST be anchored in an official source. Never fabricate document structures, legal references, or schema fields.**

### 5.2 Hierarchy of sources

| Priority | Source | Example |
|:---------|:-------|:--------|
| 1 — **Mandatory** | Official gov.br templates (DOCX/ODT) | `anexos/15-termo-de-recebimento-definitivo.docx` |
| 2 — **Official** | SGD/MGI Portarias (normative acts) | Portaria SGD/MGI nº 750/2023 |
| 3 — **Reference** | AGU model templates | `modelo-de-termo-de-contrato-tic-servicos-lei-no-14-133-ago-25.docx` |
| 4 — **Adapted** | Older regime templates adapted to current law | IN 1/2019 Termo de Encerramento → adapt to Lei 14.133 |
| 5 — **Not allowed** | Invented structures, fictional fields, made-up legal bases | ❌ Do not do this |

### 5.3 Pipeline: official DOCX/ODT → Markdown → instruction asset

When an official template exists in DOCX or ODT format on gov.br:

```
gov.br (DOCX/ODT)
  → download via urllib
  → convert: markitdown (docx) or pandoc (odt)
  → extract key sections
  → summarize as asset (rule/template/checklist) in instruction YAML
  → add asset_ref with official URL
```

**Available conversion tools in the project venv:**

| Format | Tool | Quality |
|:-------|:-----|:--------|
| `.docx` | `markitdown` (Python lib, v0.1.5+) | Excellent — tables, headers, formatting preserved |
| `.odt` | `pandoc` (CLI) | Functional — extracts structure, grid tables less clean |

### 5.4 Schema fields — extract from normative text

For `schema` assets in official model instructions (portarias 750, 1070, 5950, 2715, 370):

- **DO** extract fields from the portaria's own description of required artifacts
- **DO** follow the pattern established in `modelo_desenvolvimento_750.yaml`
- **DO NOT** invent fields that are not mentioned in the normative text

Example — the 750 portaria mentions:
- Software metrics (APF, Pontos de Função)
- Payment modalities
- Warranty periods

These become schema fields: `metrica_software`, `modalidade_pagamento`, `garantia_meses`.

### 5.5 When the official template does NOT exist for the current regime

Example: **Termo de Encerramento** — exists for IN 1/2019 (Lei 8.666) but NOT for IN 94/2022 (Lei 14.133).

**Procedure:**
1. Reference the closest official template (IN 1/2019 ODT)
2. Add a clear warning noting the adaptation requirement
3. Summarize the structure extracted from the official template
4. Note which sections need adaptation for the current legal regime
5. Add `asset_ref` with the official URL

**Never** create a fictional "official template for Lei 14.133" when one does not exist.

---

## 6. Normative References

### 6.1 Authority weight and role

Not all sources carry the same weight. The agent must distinguish:

| Weight | Meaning | Example |
|:-------|:--------|:--------|
| `mandatory` | Must comply | Lei 14.133, Decreto, IN (within scope) |
| `binding` | Binding in specific context | AGU Referential Opinion (for analogous cases) |
| `authoritative` | Strong institutional authority | MGI Guide, AGU Manual, ANPD guidance |
| `persuasive` | Should be considered | TCU Ruling, case law |
| `informative` | Technical reference or best practice | ISO 27001, ITIL, OWASP |

| Role | Meaning | Example |
|:-----|:--------|:--------|
| `creates_obligation` | Creates the obligation | Lei 14.133, art. 18 |
| `details` | Details how to comply | IN SGD 94, art. 10, §2º |
| `interprets` | Interprets scope | TCU Ruling 2.471/2021 |
| `recommends` | Recommends practices | MGI Guide, Section 3.2 |
| `references` | Complementary reference | ISO/IEC 38500:2024 |

### 6.2 Key normative framework for TIC procurement

| Norm | Role | Regime |
|:-----|:-----|:-------|
| **Lei 14.133/2021** | General procurement law | Current |
| **IN SGD/ME nº 94/2022** | TIC procurement process (SISP) | Current |
| **IN SGD/MGI nº 6/2023** | TIC procurement approval (alçadas) | Current |
| **IN SEGES/ME nº 65/2021** | Price research | Current |
| **IN SEGES/ME nº 58/2022** | Digital ETP | Current |
| **IN SEGES/ME nº 81/2022** | Digital TR | Current |
| **Decreto 11.462/2023** | SRP (Price Registration System) | Current |
| **Decreto 11.246/2022** | Procurement agent, support team, inspectors | Current |
| **Decreto 10.947/2022** | Annual Procurement Plan (PCA) | Current |
| **Portaria SGD/MGI nº 750/2023** | Software development model | Current |
| **Portaria SGD/MGI nº 1.070/2023** | Infrastructure & user support model | Current |
| **Portaria SGD/MGI nº 5.950/2023** | Cloud services model | Current |
| **Portaria SGD/MGI nº 2.715/2023** | Workstation model | Current |
| **Portaria SGD/MGI nº 370/2023** | Print outsourcing model | Current |
| **LGPD (Lei 13.709/2018)** | Data protection | Current |

**Revoked (cite only, do not implement):**
- Lei 10.520/2002 (Pregão)
- Lei 8.666/1993 (Licitações)
- Decreto 7.892/2013 (SRP old)
- IN SGD/ME nº 1/2019 (old TIC process — templates may be referenced with adaptation notes)

---

## 7. User Input — The `collect_user_input` Tool

### 7.1 What it is

`collect_user_input` is a **core MCP tool** (`src/mcp_server/tools/core/collect_user_input.py`) that lets the agent present a **dynamic form** to the user and receive structured responses. It is the bridge between the agent's reasoning and the human operator.

The agent invokes it during process execution or instruction following whenever it needs information from the user:

```
Agent decides "I need to know X"
  → calls collect_user_input(params={title, fields:[...]})
  → user fills the form in the UI
  → responses flow back to agent as [INTERACTION_RESPONSE]
  → agent replans and continues
```

**Key behaviors:**
- **Non-blocking**: Uses `REPLAN_AGENT` resume mode — the agent does not halt; it replans when the response arrives.
- **Conditional fields**: Fields can declare `depends_on` to show/hide based on other field values.
- **Structured output**: Responses return as a JSON object keyed by field `id`.

### 7.2 Tool reference — full parameters

```json
{
  "title": "Form title shown in the modal header",
  "description": "Optional subtitle below the title",
  "fields": [
    {
      "id": "field_identifier",
      "field_type": "text | textarea | number | select | checkbox | checkbox_group | radio | date",
      "label": "Human-readable label",
      "required": true | false,
      "placeholder": "Placeholder text",
      "hint": "Helper text below the field",
      "description": "Longer description",
      "value": "Pre-filled default value",
      "options": [                           // select / radio / checkbox_group only
        {"value": "opt_a", "label": "Option A"}
      ],
      "min": 0,                              // number fields
      "max": 100,                            // number fields
      "max_length": 500,                     // text / textarea
      "min_length": 3,                       // text
      "rows": 4,                             // textarea
      "depends_on": {                        // conditional visibility
        "field": "parent_field_id",
        "value": "value_that_must_match"
      }
    }
  ],
  "submit_label": "Custom submit button text",
  "cancel_label": "Custom cancel button text",
  "size": "sm | md | lg | xl"
}
```

### 7.3 The Classification Engine flow (Process Catalog)

The system uses **progressive conditional forms** to classify procurements. The agent **NEVER** starts by asking about documents (DFD, ETP). It first classifies:

```
Level 1 — Object:  What do you want to procure?
  → Bem | Serviço | Obra | Locação | Alienação | ...

Level 2 — Refinement (conditional on Level 1):
  → If TIC: Software | Hardware | SaaS | Cloud | Development | ...
  → If Serviço: Common | Intellectual | Continuous | Outsourcing | ...

Level 3 — Ready solution?  Sim | Não | Parcialmente

Level 4 — Solution nature:  Purchase | Rental | Service | Subscription | License | Outsourcing

Level 5 — Complexity:  Innovation? High risk? Integration? Secrecy? LGPD? Mission-critical? Legacy?

Level 6 — Estimated value:  R$ _______
```

The Process Catalog's `classify` action builds these forms from the `contract_facts` schema. Each capability can declare `questions[]` that are added to the form when the capability activates.

### 7.4 How processes reference `collect_user_input`

**Process steps** declare what to ask and why via `guidance.questions_to_ask`:

```yaml
# In a process definition step:
- id: elaborar_etp_tic
  name: Elaborar ETP de TIC
  type: task
  guidance:
    questions_to_ask:
      - "Foi utilizado o Modelo de ETP elaborado pela SGD (art. 8º, §2º, IN 94/2022)?"
      - "O ETP contempla todos os elementos do art. 11 da IN SGD 94/2022?"
      - "A análise de TCO foi realizada para 3-5 anos?"
      - "Foram analisadas pelo menos 3 alternativas de solução?"
    warnings:
      - "O ETP deve ser elaborado preferencialmente no sistema ETP Digital."
      - "Nunca pule a análise de mercado — é obrigatória."
    tool_hints:
      - |
        Use collect_user_input to gather TCO data:
        fields: periodo_anos, custo_aquisicao, custo_manutencao, custo_operacao
```

**Capabilities** declare structured questions with field types:

```yaml
# In a capability definition:
capability:
  id: exige_alinhamento_pdtic
  questions:
    - id: pdtic_alinhado
      text: "A contratação está alinhada ao PDTIC vigente?"
      field_type: radio
      options: ["Sim", "Não", "Parcialmente"]
    - id: pdtic_ano
      text: "Ano de vigência do PDTIC?"
      field_type: number
      min: 2020
      max: 2030
      depends_on:
        field: pdtic_alinhado
        value: "Sim"
```

The agent translates these declarations into `collect_user_input` calls with the appropriate `field_type` and `options`.

### 7.5 How instructions guide the agent on WHAT to ask

Instructions do **NOT** define forms directly — they provide the **knowledge** the agent uses to:
- Explain *why* each question is being asked (normative basis)
- Validate answers against legal requirements
- Suggest next questions based on answers received
- Warn about common pitfalls when interpreting user responses

**Example — instruction guiding the agent about form questions:**

```yaml
# In an instruction YAML:
instruction:
  id: elaboracao_tr
  assets:
    - type: rule
      content: >
        **Key questions the agent MUST ask the user before generating a TR:**
        • What is the procurement object? (precise, no bias)
        • Is the solution available on the market? (Sim/Não/Parcialmente)
        • What is the estimated value? (R$)
        • Does it involve personal data (LGPD)? (Sim/Não)
        • What are the mandatory vs. desirable technical requirements?
        Use collect_user_input to present these as a structured form.
      priority: 5
```

### 7.6 When to collect input — decision flow

```
Agent executes a step from the Process Catalog DAG
  │
  ├─ Step has guidance.questions_to_ask?
  │   └─ YES → collect_user_input with those questions
  │
  ├─ Step needs data from user to proceed?
  │   └─ YES → collect_user_input with contextual fields
  │
  └─ Instruction loaded for this step says "you MUST ask X"?
      └─ YES → collect_user_input with instructed fields
```

### 7.7 Conditional field patterns

The `depends_on` mechanism enables progressive disclosure — fields only appear when relevant:

**Pattern 1 — Refinement after classification:**
```json
// First ask:
{"id": "tic_envolve", "field_type": "radio", "options": ["Sim", "Não"]}

// Only show if TIC is involved:
{"id": "subtipo_tic", "field_type": "select",
 "options": ["Software", "Hardware", "SaaS", "Nuvem", "Desenvolvimento"],
 "depends_on": {"field": "tic_envolve", "value": "Sim"}}
```

**Pattern 2 — Conditional detail:**
```json
// First ask:
{"id": "lgpd_envolve", "field_type": "radio", "options": ["Sim", "Não"]}

// Only if LGPD applies:
{"id": "encarregado_dpo", "field_type": "text", "label": "Nome do Encarregado de Dados (DPO)",
 "depends_on": {"field": "lgpd_envolve", "value": "Sim"}}
```

**Pattern 3 — Gate check (blocking condition):**
```json
// The obligation requires this check before proceeding:
{"id": "aprovacao_sgd", "field_type": "radio", "label": "A contratação foi aprovada pela SGD?",
 "options": ["Sim", "Não", "Não se aplica"],
 "hint": "Obrigatório para contratações > R$20M (IN 94/2022, art. 8º, §3º)"}
```

### 7.8 Anti-patterns — what NOT to do

| ❌ Wrong | ✅ Right |
|:---------|:---------|
| Ask "What documents do you need?" as the first question | First classify the procurement, THEN determine which documents are needed |
| Ask the user to decide the modality (pregão/dispensa) | The Decision Engine derives modality deterministically from facts |
| Mix facts and decisions in the same form | Keep `contract_facts` pure — decisions are engine outputs |
| Ask redundant questions already answered in previous steps | Use `depends_on` to skip irrelevant fields |
| Present all 50 questions in a single form | Break into progressive forms: classify → refine → validate |

---

## 8. Quick Reference — Do's and Don'ts

### ✅ DO

- Reference official gov.br templates via `asset_refs` with URLs
- Extract schema fields from normative text in the portarias
- Use `markitdown` (DOCX) or `pandoc` (ODT) to convert official templates to Markdown
- Summarize converted content into instruction assets — don't dump raw MD
- Add clear warnings when adapting older-regime templates to current law
- Run `python -m src.mcp_server.tools.enterprise.instruction_catalog.index_generator` after any YAML change
- Keep `priority` values consistent: entrypoints=100, models=85-90, operational=60-80
- Use `tags: [modelo_oficial, portaria-XXX]` for official SGD models
- Declare `guidance.questions_to_ask` in process steps — the agent uses these to build `collect_user_input` forms
- Use `depends_on` for progressive disclosure in forms — don't show irrelevant fields
- Let the Decision Engine derive modality and procedure — don't ask the user to decide

### ❌ DON'T

- Invent document structures, legal bases, or schema fields
- Create fictional "official templates" when none exist for the current regime
- Use `extends` to reference a base instruction that does not exist as a file
- Duplicate template content — reference via `asset_refs` instead
- Hard-code tool names that don't match the actual MCP tool registry (e.g., `sei_pen` when the tool is `sei_pen_write`)
- Describe tool call sequences in instructions — that's the Process Catalog's job
- Mix facts, inferences, and decisions in the same object
- Ask the user "What documents do you need?" as the first question — classify first
- Present all possible questions in a single monolithic form — use progressive forms

---

## 9. Directory Reference

```
src/mcp_server/tools/
├── core/
│   └── collect_user_input.py           # Dynamic form tool (see Section 7)
│
├── enterprise/
│   ├── instruction_catalog/
│   │   ├── instruction_catalog.py      # MCP tool implementation
│   │   ├── index_generator.py          # Regenerates INDEX.yaml
│   │   ├── schemas/
│   │   │   └── instruction_definition.schema.json
│   │   └── definitions/
│   │       ├── INDEX.yaml              # Auto-generated manifest
│   │       └── instructions/
│   │           ├── compliance/
│   │           ├── licitacoes/
│   │           └── soc/
│   │
│   ├── process_catalog/
│   │   ├── process_catalog.py          # MCP tool implementation
│   │   └── definitions/
│   │       ├── INDEX.yaml
│   │       ├── bpmn_map.yaml           # BPMN ↔ YAML traceability
│   │       ├── documents/              # Markdown document models (*.md)
│   │       │   └── service_procurement/
│   │       ├── procurement/            # Process definitions
│   │       ├── obligations/            # Normative obligations
│   │       ├── capabilities/           # Atomic workflow units
│   │       └── modules/                # Organizational aggregators
│   │
│   └── CATALOG_AUTHORING_GUIDE.md      # ← THIS FILE
```

## 10. Related Documentation

- `docs-local/prompts/SPEC-licitacoes-engine.md` — Full decision + workflow engine architecture
- `docs-local/prompts/SPEC-licitacao_artefatos.md` — TIC procurement artifact inventory & implementation plan
- `docs-local/prompts/SPEC-prompts.md` — Instruction Catalog specification (asset-based, applies_when DSL)
- `docs-local/prompts/SPEC-licitacoes.md` — Early procurement classification design discussion
- `docs/dev/TOOLS.md` — How to add MCP tools
- `limbo/modelos.txt` — Official gov.br template links (IN 94/2022 and IN 1/2019)
- `src/mcp_server/tools/core/collect_user_input.py` — Dynamic form tool implementation & API reference
