"""gSage AI — Process Catalog MCP tool.

Provides the LLM agent with structured, on-demand access to operational
process definitions stored as version-controlled YAML files.

This is a consultive knowledge tool — it does not execute workflows or
persist instance state. The LLM reads process metadata, step guidance,
decision points, and document-model references to navigate conversations.

See: docs-local/prompts/SPECS-process_tools.md
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, ClassVar, Optional

import yaml

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

# ── Paths ──────────────────────────────────────────────────────────────────
_DEFINITIONS_DIR = Path(__file__).parent / "definitions"
_INDEX_PATH = _DEFINITIONS_DIR / "INDEX.yaml"
_OBLIGATIONS_DIR = _DEFINITIONS_DIR / "obligations"
_CAPABILITIES_DIR = _DEFINITIONS_DIR / "capabilities"
_MODULES_DIR = _DEFINITIONS_DIR / "modules"

# ── Helpers ────────────────────────────────────────────────────────────────


def _load_index() -> dict:
    """Load the process catalog index (INDEX.yaml)."""
    if not _INDEX_PATH.exists():
        return {"processes": []}
    data = yaml.safe_load(_INDEX_PATH.read_text(encoding="utf-8")) or {}
    return data


def _find_process_in_index(process_id: str) -> Optional[dict]:
    """Locate a process entry in INDEX.yaml by id."""
    index = _load_index()
    for proc in index.get("processes", []):
        if proc.get("id") == process_id:
            return proc
    return None


def _resolve_yaml_path(process_id: str) -> Optional[Path]:
    """Resolve the filesystem path for a process YAML file via INDEX.yaml."""
    entry = _find_process_in_index(process_id)
    if not entry:
        return None
    file_rel = entry.get("file", "")
    if not file_rel:
        return None
    path = _DEFINITIONS_DIR / file_rel
    if path.exists():
        return path
    return None


def _load_yaml(process_id: str) -> Optional[dict]:
    """Load and parse a process definition YAML file."""
    path = _resolve_yaml_path(process_id)
    if path is None:
        return None
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return data


def _resolve_document_ref(process_id: str, document_id: str) -> Optional[Path]:
    """Resolve the filesystem path for a Markdown document model."""
    yaml_data = _load_yaml(process_id)
    if yaml_data is None:
        return None
    for doc in yaml_data.get("documents", {}).get("generated", []):
        if doc.get("id") == document_id:
            model_ref = doc.get("model_ref", "")
            if model_ref:
                path = _DEFINITIONS_DIR / model_ref
                if path.exists():
                    return path
            return None
    return None


def _resolve_sub_process_meta(sub_process_ref: dict) -> Optional[dict]:
    """Resolve metadata for a referenced sub-process.

    Loads the referenced process YAML via INDEX.yaml and returns a
    lightweight metadata summary suitable for inlining in step responses.
    Returns None if the referenced process is not found in the catalog.
    """
    ref_process_id = sub_process_ref.get("process_id", "").strip()
    if not ref_process_id:
        return None

    # Check the index first (fast path — no YAML parse).
    index_entry = _find_process_in_index(ref_process_id)
    if index_entry is None:
        return None

    # Load the full YAML for richer metadata.
    ref_yaml = _load_yaml(ref_process_id)
    if ref_yaml is None:
        # Fall back to index-only metadata.
        return {
            "process_id": ref_process_id,
            "name": index_entry.get("name", ref_process_id),
            "version": index_entry.get("version", "?"),
            "status": index_entry.get("status", "unknown"),
            "step_count": index_entry.get("step_count", 0),
            "state_count": index_entry.get("state_count", 0),
        }

    ref_meta = ref_yaml.get("process", {})
    ref_lifecycle = ref_yaml.get("lifecycle", {})
    ref_steps = ref_yaml.get("steps", [])

    return {
        "process_id": ref_process_id,
        "name": ref_meta.get("name", ref_process_id),
        "version": ref_meta.get("version", "?"),
        "category": ref_meta.get("category", ""),
        "status": ref_meta.get("status", "unknown"),
        "purpose": ref_yaml.get("objective", {}).get("purpose", ""),
        "initial_state": ref_lifecycle.get("initial_state", ""),
        "final_states": ref_lifecycle.get("final_states", []),
        "step_count": len(ref_steps),
        "state_count": len(ref_lifecycle.get("states", [])),
    }


def _build_list_response(
    index: dict,
    query: Optional[str] = None,
    category: Optional[str] = None,
) -> tuple[list[dict], int]:
    """Build the filtered process list for action='list'."""
    processes: list[dict] = index.get("processes", [])

    if category:
        processes = [p for p in processes if p.get("category") == category]

    if query:
        q = query.lower()
        processes = [
            p
            for p in processes
            if q in p.get("name", "").lower()
            or q in p.get("summary", "").lower()
            or any(q in t.lower() for t in p.get("tags", []))
        ]

    return processes, len(processes)


def _abridge_step(step: dict) -> dict:
    """Return an abridged step suitable for action='get' summary views."""
    result = {
        "id": step.get("id"),
        "name": step.get("name"),
        "type": step.get("type"),
        "state": step.get("state"),
        "summary": step.get("objective", ""),
        "next_steps": [ns.get("step") for ns in step.get("next_steps", [])],
        "has_guidance": bool(step.get("guidance")),
        "has_inputs": bool(step.get("inputs", {}).get("required") or step.get("inputs", {}).get("optional")),
        "has_checklist": bool(step.get("checklist", {}).get("completion")),
        "has_documents": bool(step.get("documents")),
    }
    # Resolve sub-process reference when present.
    if step.get("type") == "sub_process" and step.get("sub_process_ref"):
        result["sub_process"] = _resolve_sub_process_meta(step["sub_process_ref"])
    return result


# ── Classification questionnaire (Phase 1: classify action) ───────────────

# Questionnaire levels: each level has a question, field definitions
# (compatible with collect_user_input), and logic to determine the next level.
_CLASSIFICATION_LEVELS: dict[int, dict] = {
    1: {
        "level": 1,
        "title": "Classificação da Contratação — Nível 1",
        "description": "Vamos classificar sua contratação. Primeiro, qual o objeto?",
        "fields": [
            {
                "id": "objeto_tipo",
                "field_type": "radio",
                "label": "O que você pretende contratar?",
                "required": True,
                "options": [
                    {"value": "bem", "label": "Bem"},
                    {"value": "servico", "label": "Serviço"},
                    {"value": "obra", "label": "Obra"},
                    {"value": "locacao", "label": "Locação"},
                    {"value": "alienacao", "label": "Alienação"},
                    {"value": "outro", "label": "Outro"},
                ],
            },
        ],
        "next_level": 2,
    },
    2: {
        "level": 2,
        "title": "Classificação da Contratação — Nível 2",
        "description": "Agora precisamos refinar o tipo de contratação.",
        "fields": [
            {
                "id": "servico_natureza",
                "field_type": "select",
                "label": "Qual a natureza do serviço?",
                "required": False,
                "options": [
                    {"value": "comum", "label": "Serviço comum"},
                    {"value": "intelectual", "label": "Serviço intelectual"},
                    {"value": "continuado", "label": "Serviço continuado"},
                    {"value": "terceirizacao", "label": "Terceirização"},
                    {"value": "manutencao", "label": "Manutenção"},
                    {"value": "capacitacao", "label": "Capacitação"},
                    {"value": "consultoria", "label": "Consultoria"},
                    {"value": "outro", "label": "Outro"},
                ],
                "depends_on": {"field": "objeto_tipo", "value": "servico"},
                "hint": "Só aparece se o objeto for Serviço.",
            },
            {
                "id": "tic_envolve",
                "field_type": "radio",
                "label": "Envolve Tecnologia da Informação e Comunicação (TIC)?",
                "required": True,
                "options": [
                    {"value": "true", "label": "Sim"},
                    {"value": "false", "label": "Não"},
                ],
            },
        ],
        "next_level": 3,
    },
    3: {
        "level": 3,
        "title": "Classificação da Contratação — Nível 3",
        "description": "Vamos entender melhor a solução desejada.",
        "fields": [
            {
                "id": "tic_subtipo",
                "field_type": "select",
                "label": "Qual o tipo de solução de TIC?",
                "required": False,
                "options": [
                    {"value": "software", "label": "Software"},
                    {"value": "hardware", "label": "Hardware"},
                    {"value": "saas", "label": "SaaS"},
                    {"value": "nuvem", "label": "Nuvem"},
                    {"value": "desenvolvimento", "label": "Desenvolvimento"},
                    {"value": "sustentacao", "label": "Sustentação"},
                    {"value": "consultoria_tic", "label": "Consultoria de TIC"},
                    {"value": "seguranca", "label": "Segurança"},
                    {"value": "ia", "label": "IA"},
                    {"value": "outro", "label": "Outro"},
                ],
                "depends_on": {"field": "tic_envolve", "value": "true"},
                "hint": "Só aparece se envolver TIC.",
            },
            {
                "id": "solucao_disponivel",
                "field_type": "radio",
                "label": "Existe solução pronta disponível no mercado?",
                "required": True,
                "options": [
                    {"value": "sim", "label": "Sim"},
                    {"value": "nao", "label": "Não"},
                    {"value": "parcialmente", "label": "Parcialmente"},
                    {"value": "nao_sei", "label": "Não sei"},
                ],
            },
        ],
        "next_level": 4,
    },
    4: {
        "level": 4,
        "title": "Classificação da Contratação — Nível 4",
        "description": "Qual a natureza da aquisição?",
        "fields": [
            {
                "id": "aquisicao_natureza",
                "field_type": "radio",
                "label": "Será:",
                "required": True,
                "options": [
                    {"value": "compra", "label": "Compra"},
                    {"value": "locacao", "label": "Locação"},
                    {"value": "servico", "label": "Serviço"},
                    {"value": "assinatura", "label": "Assinatura"},
                    {"value": "licenca", "label": "Licença"},
                    {"value": "outsourcing", "label": "Outsourcing"},
                    {"value": "outro", "label": "Outro"},
                ],
            },
        ],
        "next_level": 5,
    },
    5: {
        "level": 5,
        "title": "Classificação da Contratação — Nível 5",
        "description": "Avalie a complexidade e os riscos da contratação.",
        "fields": [
            {
                "id": "complexidade_lgpd",
                "field_type": "checkbox",
                "label": "Envolve tratamento de dados pessoais (LGPD)?",
                "required": False,
            },
            {
                "id": "complexidade_integracao",
                "field_type": "checkbox",
                "label": "Envolve integração com outros sistemas?",
                "required": False,
            },
            {
                "id": "complexidade_legado",
                "field_type": "checkbox",
                "label": "Envolve sistemas legados?",
                "required": False,
            },
            {
                "id": "complexidade_sigilo",
                "field_type": "checkbox",
                "label": "Envolve informações sigilosas?",
                "required": False,
            },
            {
                "id": "complexidade_missao_critica",
                "field_type": "checkbox",
                "label": "É missão crítica?",
                "required": False,
            },
            {
                "id": "complexidade_inovacao",
                "field_type": "checkbox",
                "label": "Envolve inovação tecnológica?",
                "required": False,
            },
        ],
        "next_level": 6,
    },
    6: {
        "level": 6,
        "title": "Classificação da Contratação — Nível 6",
        "description": "Por fim, informe o valor estimado e o contexto administrativo.",
        "fields": [
            {
                "id": "valor_estimado",
                "field_type": "number",
                "label": "Valor estimado da contratação (R$)",
                "required": True,
                "min": 0,
            },
            {
                "id": "fonte_recurso",
                "field_type": "text",
                "label": "Fonte do recurso",
                "required": False,
                "placeholder": "Ex: Tesouro Nacional, Convênio...",
            },
        ],
        "next_level": None,  # Final level
    },
}


def _build_classify_response(level: int, facts_raw: dict) -> dict:
    """Build the response for the classify action at a given questionnaire level.

    Args:
        level: Current level number (1-6).
        facts_raw: Previously collected facts (may be empty for level 1).

    Returns:
        Dict with ``level``, ``question`` metadata, ``fields`` (for collect_user_input),
        ``contract_facts`` (accumulated so far), and ``complete`` flag.
    """
    level_data = _CLASSIFICATION_LEVELS.get(level)
    if level_data is None:
        return {
            "complete": True,
            "contract_facts": facts_raw,
            "message": (
                "Classification complete. Call action='infer' with the "
                "contract_facts to compute inferences, then action='resolve' "
                "to determine applicable norms, obligations, and decisions."
            ),
        }

    # Merge accumulated facts into the response
    result: dict = {
        "complete": level_data["next_level"] is None,
        "level": level_data["level"],
        "next_level": level_data["next_level"],
        "title": level_data["title"],
        "description": level_data["description"],
        "fields": level_data["fields"],
        "contract_facts": facts_raw,
        "_collect_input": {
            "use_tool": "collect_user_input",
            "title_hint": level_data["title"],
            "description_hint": level_data["description"],
            "fields": level_data["fields"],
        },
    }
    return result


# ── Phase 2 helpers: obligations, capabilities, decisions ──────────────────


def _load_all_obligations() -> list[dict]:
    """Load all obligation YAML files from the obligations/ directory tree."""
    obligations: list[dict] = []
    if not _OBLIGATIONS_DIR.exists():
        return obligations
    for yaml_path in _OBLIGATIONS_DIR.rglob("*.yaml"):
        try:
            data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
            if data and "obligation" in data:
                obligations.append(data)
        except Exception:
            log.warning("Failed to load obligation: %s", yaml_path, exc_info=True)
    return obligations


def _load_capability(capability_id: str) -> Optional[dict]:
    """Load a single capability YAML by id."""
    if not _CAPABILITIES_DIR.exists():
        return None
    target_file = f"{capability_id}.yaml"
    for yaml_path in _CAPABILITIES_DIR.rglob("*.yaml"):
        if yaml_path.name == target_file:
            try:
                data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
                return data
            except Exception:
                log.warning("Failed to load capability: %s", yaml_path, exc_info=True)
    return None


def _resolve_norm_version(obligation: dict) -> str:
    """Extract a human-readable norm version string from an obligation's sources."""
    sources = obligation.get("sources", [])
    if not sources:
        return ""
    primary = sources[0]
    auth = primary.get("authority", "")
    disp = primary.get("dispositivo", "")
    if disp:
        return f"{auth}, {disp}"
    return auth


def _derive_decisions(
    facts: Any,
    inferences: Any,
    active_capability_ids: set[str],
) -> dict:
    """Derive procurement decisions from facts, inferences, and capabilities.

    These are deterministic rules. The user NEVER chooses modality/procedure.
    """
    decisions: dict = {
        "modalidade": None,
        "modalidade_fundamento": "",
        "procedimento": {
            "registro_precos": False,
            "cotacao_eletronica": False,
        },
        "criterio_julgamento": None,
        "dispensa": False,
        "inexigibilidade": False,
    }

    # ── Modalidade ─────────────────────────────────────────────────────
    # Default: pregão for common goods/services
    valor = facts.valor.estimado if facts.valor else None
    is_comum = inferences.execucao.comum
    is_obra = facts.objeto.tipo == "obra"
    is_engenharia = (_resolve_field_safe(inferences, "dominio.engenharia") or False)

    if is_obra or is_engenharia:
        decisions["modalidade"] = "concorrencia"
        decisions["modalidade_fundamento"] = "Lei 14.133/2021, art. 28, II — obras e serviços de engenharia"
        decisions["criterio_julgamento"] = "menor_preco"
    elif is_comum:
        decisions["modalidade"] = "pregao"
        decisions["modalidade_fundamento"] = "Lei 14.133/2021, art. 28, I — bens e serviços comuns"
        decisions["criterio_julgamento"] = "menor_preco"
    else:
        decisions["modalidade"] = "pregao"
        decisions["modalidade_fundamento"] = "Lei 14.133/2021, art. 28, I"
        decisions["criterio_julgamento"] = "menor_preco"

    # ── Dispensa / Inexigibilidade ─────────────────────────────────────
    # Simplified — full logic in future phases.
    # Dispensa por valor (art. 75, I e II): depends on updated limits
    if valor is not None and valor < 50000:
        decisions["dispensa"] = True
        decisions["modalidade"] = "dispensa"
        decisions["modalidade_fundamento"] = "Lei 14.133/2021, art. 75, II"

    return decisions


def _resolve_field_safe(obj: Any, field_path: str) -> Any:
    """Resolve a dot-notation field path, returning None on any failure."""
    parts = field_path.split(".")
    target = obj
    for part in parts:
        if target is None:
            return None
        if isinstance(target, dict):
            target = target.get(part)
        else:
            target = getattr(target, part, None)
    return target


# Node shape mapping per step type.
_NODE_SHAPES: dict[str, tuple[str, str]] = {
    "task": ("[", "]"),        # rectangle
    "decision": ("{", "}"),    # diamond
    "parallel": ("{{", "}}"),  # hexagon
    "sub_process": ("([", "])"),  # stadium / rounded
    "wait": (("((", "))")),    # circle
}


def _sanitize_mermaid(text: str) -> str:
    """Escape characters that would break Mermaid syntax."""
    return text.replace('"', "'").replace("\n", " ").strip()


def _generate_mermaid(yaml_data: dict) -> str:
    """Generate a Mermaid flowchart from a process definition.

    Returns a ``flowchart TD`` diagram with:
    - Subgraphs per lifecycle state (swimlanes)
    - Different node shapes per step type (task, decision, parallel, etc.)
    - Labeled edges for decision branches
    - Start/end markers for initial and final states
    """
    lifecycle = yaml_data.get("lifecycle", {})
    steps = yaml_data.get("steps", [])
    meta = yaml_data.get("process", {})
    initial_state = lifecycle.get("initial_state", "")
    final_states: list[str] = lifecycle.get("final_states", [])
    states: list[dict] = lifecycle.get("states", [])

    lines: list[str] = []
    lines.append(f"flowchart TD")
    lines.append(f"    %% {meta.get('name', 'Process')} v{meta.get('version', '?')}")
    lines.append("")

    # ── Build a lookup: state_id → list of steps ──────────────────────
    state_steps: dict[str, list[dict]] = {}
    for step in steps:
        sid = step.get("state", "")
        state_steps.setdefault(sid, []).append(step)

    # ── Track which states have steps (to avoid empty subgraphs) ─────
    states_with_steps = {sid for sid in state_steps}

    # ── Subgraphs per state ──────────────────────────────────────────
    for state in states:
        sid = state.get("id", "")
        if sid not in states_with_steps:
            continue
        sname = _sanitize_mermaid(state.get("name", sid))
        lines.append(f"    subgraph {sid}[\"{sname}\"]")
        for step in state_steps.get(sid, []):
            step_id = step.get("id", "")
            step_name = _sanitize_mermaid(step.get("name", step_id))
            step_type = step.get("type", "task")
            open_b, close_b = _NODE_SHAPES.get(step_type, ("[", "]"))

            if step_type == "sub_process":
                ref = step.get("sub_process_ref", {})
                ref_name = ref.get("process_id", step_name)
                lines.append(f"        {step_id}{open_b}\"{step_name}\\n({ref_name})\"{close_b}")
            else:
                lines.append(f"        {step_id}{open_b}\"{step_name}\"{close_b}")
        lines.append("    end")
        lines.append("")

    # ── Start marker ─────────────────────────────────────────────────
    lines.append(f"    start((\"Start\"))")
    lines.append("")

    # ── Edges ────────────────────────────────────────────────────────
    # Collect all edges: (from_id, to_id, label)
    edges: list[tuple[str, str, str]] = []

    for step in steps:
        step_id = step.get("id", "")
        step_type = step.get("type", "task")

        # -- Decision branches --
        if step_type == "decision":
            for dp in step.get("decision_points", []):
                for outcome in dp.get("outcomes", []):
                    when = outcome.get("when", {})
                    then = outcome.get("then", {})
                    target = then.get("next_step", "")
                    explanation = then.get("explanation", "")
                    if target:
                        label = _sanitize_mermaid(explanation or str(when))
                        # Truncate long labels
                        if len(label) > 40:
                            label = label[:37] + "..."
                        edges.append((step_id, target, label))
            # Also add unconditional next_steps from decision
            for ns in step.get("next_steps", []):
                target = ns.get("step", "")
                if target:
                    edges.append((step_id, target, ""))

        # -- Parallel: connect each branch output (implicit finish) ─
        elif step_type == "parallel":
            for ns in step.get("next_steps", []):
                target = ns.get("step", "")
                if target:
                    edges.append((step_id, target, ""))

        # -- Regular task / sub_process / wait ──────────────────────
        else:
            for ns in step.get("next_steps", []):
                target = ns.get("step", "")
                if target:
                    edges.append((step_id, target, ""))

    # ── Render edges ─────────────────────────────────────────────────
    edge_ids: set[tuple[str, str]] = set()
    for from_id, to_id, label in edges:
        key = (from_id, to_id)
        if key in edge_ids:
            continue
        edge_ids.add(key)
        if label:
            lines.append(f"    {from_id} -->|\"{label}\"| {to_id}")
        else:
            lines.append(f"    {from_id} --> {to_id}")

    # ── Start → initial state's first step ───────────────────────────
    if initial_state and initial_state in state_steps:
        first_steps = state_steps[initial_state]
        if first_steps:
            lines.append(f"    start --> {first_steps[0].get('id', '')}")

    # ── Final states markers ─────────────────────────────────────────
    for fs in final_states:
        safe = _sanitize_mermaid(fs)
        lines.append(f"    {fs}_end((\"{safe}\"))")

    # Connect terminal steps (no outgoing edges) to final markers.
    # If the step's state matches a final state, use that marker.
    # Otherwise, connect to the first final state as a fallback.
    fallback_final = final_states[0] if final_states else None
    for step in steps:
        step_state = step.get("state", "")
        step_type = step.get("type", "task")

        # A step is terminal iff it has NO way to go forward:
        # no unconditional next_steps, no decision outcomes, no parallel branches
        has_outgoing = bool(step.get("next_steps"))
        if step_type == "decision":
            for dp in step.get("decision_points", []):
                for outcome in dp.get("outcomes", []):
                    if outcome.get("then", {}).get("next_step"):
                        has_outgoing = True
        if has_outgoing:
            continue

        # Exact match: step is in a final state
        if step_state in final_states:
            lines.append(f"    {step.get('id')} --> {step_state}_end")
        elif fallback_final:
            # Step is in a non-final state but has no outgoing edges.
            # Connect it to the first final state to complete the graph.
            lines.append(f"    {step.get('id')} --> {fallback_final}_end")

    return "\n".join(lines)


def _compute_statistics(yaml_data: dict) -> dict:
    """Compute summary statistics for a process definition."""
    steps = yaml_data.get("steps", [])
    lifecycle = yaml_data.get("lifecycle", {})

    type_counts: dict[str, int] = {}
    state_counts: dict[str, int] = {}
    total_checklist_items = 0
    total_documents = 0
    total_decision_points = 0

    for step in steps:
        # Type counts
        t = step.get("type", "task")
        type_counts[t] = type_counts.get(t, 0) + 1

        # State counts
        s = step.get("state", "")
        state_counts[s] = state_counts.get(s, 0) + 1

        # Checklist items
        checklist = step.get("checklist", {}).get("completion", [])
        total_checklist_items += len(checklist)

        # Documents
        docs = step.get("documents", [])
        total_documents += len(docs)

        # Decision points
        dps = step.get("decision_points", [])
        total_decision_points += len(dps)

    return {
        "total_steps": len(steps),
        "total_states": len(lifecycle.get("states", [])),
        "initial_state": lifecycle.get("initial_state", ""),
        "final_states": lifecycle.get("final_states", []),
        "steps_by_type": type_counts,
        "steps_by_state": state_counts,
        "total_checklist_items": total_checklist_items,
        "total_documents": total_documents,
        "total_decision_points": total_decision_points,
    }


def _extract_roles(yaml_data: dict) -> list[dict]:
    """Extract unique roles with their assigned steps."""
    steps = yaml_data.get("steps", [])
    role_map: dict[str, list[str]] = {}

    for step in steps:
        role = step.get("responsible_role", "").strip()
        if not role:
            continue
        role_map.setdefault(role, []).append(step.get("id", ""))

    return [
        {"role": role, "step_count": len(step_ids), "step_ids": step_ids}
        for role, step_ids in sorted(role_map.items())
    ]


def _get_step_detail(yaml_data: dict, step_id: str) -> Optional[dict]:
    """Extract full detail for a single step."""
    for step in yaml_data.get("steps", []):
        if step.get("id") == step_id:
            return step
    return None


def _get_document_meta(yaml_data: dict, document_id: str) -> Optional[dict]:
    """Extract metadata for a single document."""
    for doc in yaml_data.get("documents", {}).get("generated", []):
        if doc.get("id") == document_id:
            # Collect required inputs from the linked step
            step_id = doc.get("step", "")
            required_inputs: list[str] = []
            for step in yaml_data.get("steps", []):
                if step.get("id") == step_id:
                    for inp in step.get("inputs", {}).get("required", []):
                        required_inputs.append(inp.get("name", ""))
                    break
            return {
                "id": doc.get("id"),
                "name": doc.get("name"),
                "type": "generated",
                "description": doc.get("description", ""),
                "model_ref": doc.get("model_ref", ""),
                "required_inputs": required_inputs,
                "generation": doc.get("generation", {}),
            }
    return None


# ── Tool class ─────────────────────────────────────────────────────────────


class ProcessCatalogTool(BaseTool):
    """
    Navigate the Process Catalog — a library of operational process definitions.

    Use this tool to discover available business processes, retrieve their
    step-by-step structure, read guidance for specific steps, and inspect
    document-model metadata.

    This is a consultive knowledge tool — it does not execute or persist
    process instances. Use the returned information to guide the user
    through the workflow conversationally.

    Actions
    -------
    - ``list`` — discover available processes (optionally filter by category or free-text query).
    - ``get`` — retrieve the full definition of a process (lifecycle states + abridged steps + mermaid diagram + statistics).
    - ``get_step`` — retrieve detailed guidance, inputs, checklists, and decision rules for one step.
    - ``get_step_fields`` — (NEW) get step inputs pre-converted to ``collect_user_input`` field format.
    - ``get_document`` — retrieve document-model metadata (model_ref, generation hints, required inputs).
    - ``diagram`` — return only the Mermaid flowchart markup for a process (no JSON — raw string).
    - ``classify`` — (Phase 1) start or continue the progressive classification questionnaire. Returns the next question level and field definitions for ``collect_user_input``. Builds ``contract_facts`` incrementally.
    - ``infer`` — (Phase 1) given complete ``contract_facts``, compute ``inferences`` deterministically via ``InferenceEngine``.

    Examples
    --------
    - ``{"action": "list"}``
    - ``{"action": "list", "category": "procurement", "query": "service"}``
    - ``{"action": "get", "process_id": "service_procurement"}``
    - ``{"action": "get_step", "process_id": "service_procurement", "step_id": "estimate_value"}``
    - ``{"action": "get_step_fields", "process_id": "service_procurement", "step_id": "estimate_value"}``
    - ``{"action": "get_document", "process_id": "service_procurement", "document_id": "technical_specification"}``
    - ``{"action": "diagram", "process_id": "service_procurement"}``
    - ``{"action": "classify"}`` — start Level 1 of the classification questionnaire
    - ``{"action": "classify", "level": 2, "contract_facts": {...}}`` — continue to Level 2 with partial facts
    - ``{"action": "infer", "contract_facts": {...}}`` — compute inferences from complete facts
    """

    name: ClassVar[str] = "process_catalog"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Navigate operational process definitions: discover processes, "
        "retrieve step guidance, decision rules, and document-model metadata. "
        "IMPORTANT: get_step returns a `_collect_input` block with ready-to-use "
        "fields — pass them directly to `collect_user_input` to gather data "
        "via structured forms instead of asking in chat."
    )
    category: ClassVar[str] = "utility"
    core_tool: ClassVar[bool] = False

    # No permissions required — available to all authenticated users.
    permissions: ClassVar[list[str]] = []
    use_circuit_breaker: ClassVar[bool] = False
    rate_limit_per_minute: ClassVar[int] = 120
    timeout_seconds: ClassVar[int] = 10

    params_schema: ClassVar[dict] = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["list", "get", "get_step", "get_step_fields", "get_document", "diagram", "classify", "infer", "resolve", "compose"],
                "description": (
                    "What to do: 'list' available processes, "
                    "'get' a full process, 'get_step' a single step, "
                    "'get_step_fields' step inputs as collect_user_input fields, "
                    "'get_document' document info, 'diagram' mermaid flowchart, "
                    "'classify' progressive classification questionnaire, "
                    "'infer' compute inferences from contract_facts, "
                    "'resolve' evaluate obligations and derive decisions, "
                    "'compose' build workflow DAG from active capabilities."
                ),
                "default": "list",
            },
            "process_id": {
                "type": "string",
                "description": "Process identifier. Required for 'get', 'get_step', 'get_document'.",
            },
            "step_id": {
                "type": "string",
                "description": "Step identifier. Required for 'get_step', 'get_step_fields'.",
            },
            "document_id": {
                "type": "string",
                "description": "Document identifier. Required for 'get_document'.",
            },
            "category": {
                "type": "string",
                "description": (
                    "Filter by category. Used with action='list'."
                ),
            },
            "query": {
                "type": "string",
                "description": (
                    "Free-text search across process names, descriptions, tags. "
                    "Used with action='list'."
                ),
            },
            "level": {
                "type": "integer",
                "minimum": 1,
                "maximum": 6,
                "description": (
                    "Classification questionnaire level (1-6). "
                    "Used with action='classify'. 1 starts the questionnaire."
                ),
            },
            "contract_facts": {
                "type": "object",
                "description": (
                    "Partial or complete contract_facts object. "
                    "Used with action='classify' (to carry forward previous answers), "
                    "action='infer' (to compute inferences), "
                    "and action='resolve' (to evaluate obligations)."
                ),
            },
            "inferences": {
                "type": "object",
                "description": (
                    "Pre-computed inferences object. Optional for action='resolve'. "
                    "If omitted, inferences are computed automatically."
                ),
            },
            "active_capabilities": {
                "type": "array",
                "description": (
                    "List of active capabilities from the 'resolve' action output. "
                    "Required for action='compose'."
                ),
                "items": {"type": "object"},
            },
        },
        "required": [],
        "additionalProperties": False,
    }

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        start = time.monotonic()
        action: str = params.get("action", "list")

        # ── action: list ──────────────────────────────────────────────────
        if action == "list":
            index = _load_index()
            processes, count = _build_list_response(
                index,
                query=params.get("query"),
                category=params.get("category"),
            )
            return self._success(
                data={"processes": processes, "count": count},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── All other actions require process_id ──────────────────────────
        process_id: str = (params.get("process_id") or "").strip()
        if not process_id:
            return self._failure(
                code="MISSING_PROCESS_ID",
                message="The 'process_id' parameter is required for this action.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        yaml_data = _load_yaml(process_id)
        if yaml_data is None:
            return self._failure(
                code="PROCESS_NOT_FOUND",
                message=f"Process '{process_id}' not found in the catalog.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        meta = yaml_data.get("process", {})
        objective = yaml_data.get("objective", {})

        # ── action: get ───────────────────────────────────────────────────
        if action == "get":
            lifecycle = yaml_data.get("lifecycle", {})
            steps = yaml_data.get("steps", [])
            # Build document summary so the LLM can discover available
            # document models without drilling into every step individually.
            docs_section = yaml_data.get("documents", {})
            doc_summary: list[dict] = []
            for doc in docs_section.get("generated", []):
                doc_summary.append({
                    "id": doc.get("id"),
                    "name": doc.get("name"),
                    "step": doc.get("step"),
                    "model_ref": doc.get("model_ref"),
                    "has_template": bool(doc.get("model_ref")),
                })
            for doc in docs_section.get("required", []):
                doc_summary.append({
                    "id": doc.get("id"),
                    "name": doc.get("name"),
                    "type": "required",
                    "provided_by": doc.get("provided_by"),
                })
            return self._success(
                data={
                    "process": {
                        "id": meta.get("id"),
                        "name": meta.get("name"),
                        "version": meta.get("version"),
                        "category": meta.get("category"),
                        "status": meta.get("status"),
                        "purpose": objective.get("purpose", ""),
                        "lifecycle": {
                            "initial_state": lifecycle.get("initial_state"),
                            "final_states": lifecycle.get("final_states", []),
                            "states": [s.get("id") for s in lifecycle.get("states", [])],
                        },
                        "steps": [_abridge_step(s) for s in steps],
                        "documents": doc_summary,
                        "statistics": _compute_statistics(yaml_data),
                        "roles": _extract_roles(yaml_data),
                        "mermaid": _generate_mermaid(yaml_data),
                    }
                },
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: get_step ──────────────────────────────────────────────
        if action == "get_step":
            step_id: str = (params.get("step_id") or "").strip()
            if not step_id:
                return self._failure(
                    code="MISSING_STEP_ID",
                    message="The 'step_id' parameter is required for action='get_step'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            step = _get_step_detail(yaml_data, step_id)
            if step is None:
                return self._failure(
                    code="STEP_NOT_FOUND",
                    message=f"Step '{step_id}' not found in process '{process_id}'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            # Attach resolved sub-process metadata when applicable.
            if step.get("type") == "sub_process" and step.get("sub_process_ref"):
                step = dict(step)  # shallow copy to avoid mutating cached data
                step["sub_process"] = _resolve_sub_process_meta(step["sub_process_ref"])

            # Auto-inject collect_user_input fields when the step has
            # required inputs — the agent can pass these directly to
            # collect_user_input without any conversion or extra calls.
            response_data: dict = {"step": step}
            inputs = step.get("inputs", {})
            if inputs.get("required") or inputs.get("optional"):
                from src.shared.interaction.catalog_bridge import catalog_inputs_to_fields
                fields = catalog_inputs_to_fields(inputs)
                if fields:
                    response_data["_collect_input"] = {
                        "use_tool": "collect_user_input",
                        "title_hint": step.get("name", "Step Input"),
                        "description_hint": step.get("objective", ""),
                        "fields": fields,
                    }

            return self._success(
                data=response_data,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: get_step_fields ──────────────────────────────────────
        if action == "get_step_fields":
            step_id: str = (params.get("step_id") or "").strip()
            if not step_id:
                return self._failure(
                    code="MISSING_STEP_ID",
                    message="The 'step_id' parameter is required for action='get_step_fields'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            step = _get_step_detail(yaml_data, step_id)
            if step is None:
                return self._failure(
                    code="STEP_NOT_FOUND",
                    message=f"Step '{step_id}' not found in process '{process_id}'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            from src.shared.interaction.catalog_bridge import catalog_inputs_to_fields
            fields = catalog_inputs_to_fields(step.get("inputs", {}))
            return self._success(
                data={
                    "step_id": step.get("id"),
                    "step_name": step.get("name"),
                    "collect_user_input_fields": fields,
                },
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: get_document ──────────────────────────────────────────
        if action == "get_document":
            document_id: str = (params.get("document_id") or "").strip()
            if not document_id:
                return self._failure(
                    code="MISSING_DOCUMENT_ID",
                    message="The 'document_id' parameter is required for action='get_document'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            doc_meta = _get_document_meta(yaml_data, document_id)
            if doc_meta is None:
                return self._failure(
                    code="DOCUMENT_NOT_FOUND",
                    message=f"Document '{document_id}' not found in process '{process_id}'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            return self._success(
                data={"document": doc_meta},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: compose ────────────────────────────────────────────────
        if action == "compose":
            from src.shared.decision.dag_composer import DAGComposer, CycleDetectedError

            capabilities_raw: list = params.get("active_capabilities") or []
            if not capabilities_raw:
                return self._failure(
                    code="MISSING_CAPABILITIES",
                    message=(
                        "The 'active_capabilities' parameter is required for action='compose'. "
                        "Pass the 'active_capabilities' list from the 'resolve' action output."
                    ),
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

            # Wrap each capability in the expected format if needed
            wrapped: list[dict] = []
            for cap in capabilities_raw:
                if isinstance(cap, dict) and "capability" in cap:
                    wrapped.append(cap)
                elif isinstance(cap, dict):
                    wrapped.append({"capability": cap})
                else:
                    wrapped.append({"capability": {"id": str(cap), "steps": []}})

            composer = DAGComposer()
            try:
                dag = composer.compose(wrapped)
                return self._success(
                    data={
                        "workflow_dag": dag,
                    },
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            except CycleDetectedError as exc:
                return self._failure(
                    code="CYCLE_DETECTED",
                    message=str(exc),
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

        # ── action: diagram ───────────────────────────────────────────────
        if action == "diagram":
            return self._success(
                data={"mermaid": _generate_mermaid(yaml_data)},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: classify ──────────────────────────────────────────────
        if action == "classify":
            level: int = params.get("level", 1)
            facts_raw: dict = params.get("contract_facts") or {}
            return self._success(
                data=_build_classify_response(level, facts_raw),
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: infer ─────────────────────────────────────────────────
        if action == "infer":
            from src.shared.decision.inference_engine import InferenceEngine
            from src.shared.models.contract_facts import ContractFacts

            facts_raw: dict = params.get("contract_facts") or {}
            if not facts_raw:
                return self._failure(
                    code="MISSING_CONTRACT_FACTS",
                    message="The 'contract_facts' parameter is required for action='infer'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            try:
                facts = ContractFacts(**facts_raw)
            except Exception as exc:
                return self._failure(
                    code="INVALID_CONTRACT_FACTS",
                    message=f"Failed to parse contract_facts: {exc}",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            engine = InferenceEngine()
            inferences = engine.apply(facts)
            return self._success(
                data={
                    "inferences": inferences.model_dump(mode="json"),
                    "contract_facts_id": facts.id,
                },
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: resolve ────────────────────────────────────────────────
        if action == "resolve":
            from src.shared.decision.inference_engine import InferenceEngine
            from src.shared.decision.rule_evaluator import SimpleRuleEvaluator
            from src.shared.decision.provenance import create_provenance
            from src.shared.models.contract_facts import ContractFacts, Inferences

            facts_raw: dict = params.get("contract_facts") or {}
            inferences_raw: dict = params.get("inferences") or {}

            if not facts_raw:
                return self._failure(
                    code="MISSING_CONTRACT_FACTS",
                    message="The 'contract_facts' parameter is required for action='resolve'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

            try:
                facts = ContractFacts(**facts_raw)
            except Exception as exc:
                return self._failure(
                    code="INVALID_CONTRACT_FACTS",
                    message=f"Failed to parse contract_facts: {exc}",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

            # Compute inferences if not provided
            if inferences_raw:
                try:
                    inferences = Inferences(**inferences_raw)
                except Exception as exc:
                    return self._failure(
                        code="INVALID_INFERENCES",
                        message=f"Failed to parse inferences: {exc}",
                        retryable=False,
                        execution_time_ms=int((time.monotonic() - start) * 1000),
                    )
            else:
                engine = InferenceEngine()
                inferences = engine.apply(facts)

            # ── Etapa 1: Applicability Resolution ──────────────────────────
            evaluator = SimpleRuleEvaluator()
            obligations_all = _load_all_obligations()
            active_obligations: list[dict] = []

            for ob_yaml in obligations_all:
                ob = ob_yaml.get("obligation", {})
                activation = ob.get("activation", {})
                if evaluator.evaluate(activation, facts, inferences):
                    capability_id = ob.get("capability", "")
                    # Build activated obligation entry with provenance
                    reason_parts = []
                    for cond in activation.get("all_of", []):
                        reason_parts.append(f"{cond['field']} {cond['operator']} {cond['value']}")
                    reason = " AND ".join(reason_parts) if reason_parts else "always"

                    entry: dict = {
                        "id": ob.get("id"),
                        "description": ob.get("description", ""),
                        "capability": capability_id,
                        "provenance": create_provenance(
                            obligation_id=ob.get("id", ""),
                            rule_id=f"obligation.{ob.get('id', '')}",
                            reason=reason,
                            norm_version=_resolve_norm_version(ob),
                        ),
                        "sources": ob.get("sources", []),
                        "evidence": ob.get("evidence", {}),
                        "consequences": ob.get("consequences", []),
                        "exceptions": ob.get("exceptions", []),
                    }
                    active_obligations.append(entry)

            # ── Etapa 2: Normative Resolution — resolve capabilities ───────
            active_capability_ids: set[str] = set()
            for ob in active_obligations:
                cap_id = ob.get("capability", "")
                if cap_id:
                    active_capability_ids.add(cap_id)

            active_capabilities: list[dict] = []
            for cap_id in sorted(active_capability_ids):
                cap_yaml = _load_capability(cap_id)
                if cap_yaml:
                    active_capabilities.append(cap_yaml.get("capability", {"id": cap_id}))

            # ── Etapa 3: Derive decisions ──────────────────────────────────
            decisions = _derive_decisions(facts, inferences, active_capability_ids)

            # ── Collect applicable authorities ─────────────────────────────
            authorities_map: dict[str, dict] = {}
            for ob in active_obligations:
                for src in ob.get("sources", []):
                    auth_name = src.get("authority", "")
                    if auth_name not in authorities_map:
                        authorities_map[auth_name] = {
                            "authority": auth_name,
                            "authority_type": src.get("authority_type", ""),
                            "authority_weight": src.get("authority_weight", ""),
                            "activated_by_obligations": [],
                        }
                    authorities_map[auth_name]["activated_by_obligations"].append(ob["id"])

            return self._success(
                data={
                    "runtime_context": {
                        "facts_ref": facts.id,
                        "inferences": inferences.model_dump(mode="json"),
                        "decisions": decisions,
                        "active_obligations": active_obligations,
                        "active_capabilities": active_capabilities,
                        "applicable_authorities": sorted(
                            authorities_map.values(), key=lambda a: a["authority"]
                        ),
                        "capability_count": len(active_capabilities),
                        "obligation_count": len(active_obligations),
                    }
                },
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── Unknown action ────────────────────────────────────────────────
        return self._failure(
            code="UNKNOWN_ACTION",
            message=f"Unknown action: '{action}'. Valid actions: list, get, get_step, get_step_fields, get_document, diagram, classify, infer, resolve, compose.",
            retryable=False,
            execution_time_ms=int((time.monotonic() - start) * 1000),
        )
