"""gSage AI — Process Catalog MCP tool.

Provides the LLM agent with structured, on-demand access to operational
process definitions stored as version-controlled YAML files.

This is a consultive knowledge tool — it does not execute workflows or
persist instance state. The LLM reads process metadata, step guidance,
decision points, and document-model references to navigate conversations.

See: docs-local/prompts/SPECS-process_tools.md
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import ClassVar, Optional

import yaml

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

# ── Paths ──────────────────────────────────────────────────────────────────
_DEFINITIONS_DIR = Path(__file__).parent / "definitions"
_INDEX_PATH = _DEFINITIONS_DIR / "INDEX.yaml"

# ── Helpers ────────────────────────────────────────────────────────────────


def _load_index() -> dict:
    """Load the process catalog index (INDEX.yaml)."""
    if not _INDEX_PATH.exists():
        return {"processes": []}
    data = yaml.safe_load(_INDEX_PATH.read_text(encoding="utf-8")) or {}
    return data


def _find_process_in_index(process_id: str) -> Optional[dict]:
    """Locate a process entry in INDEX.yaml by id."""
    index = _load_index()
    for proc in index.get("processes", []):
        if proc.get("id") == process_id:
            return proc
    return None


def _resolve_yaml_path(process_id: str) -> Optional[Path]:
    """Resolve the filesystem path for a process YAML file via INDEX.yaml."""
    entry = _find_process_in_index(process_id)
    if not entry:
        return None
    file_rel = entry.get("file", "")
    if not file_rel:
        return None
    path = _DEFINITIONS_DIR / file_rel
    if path.exists():
        return path
    return None


def _load_yaml(process_id: str) -> Optional[dict]:
    """Load and parse a process definition YAML file."""
    path = _resolve_yaml_path(process_id)
    if path is None:
        return None
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return data


def _resolve_document_ref(process_id: str, document_id: str) -> Optional[Path]:
    """Resolve the filesystem path for a Markdown document model."""
    yaml_data = _load_yaml(process_id)
    if yaml_data is None:
        return None
    for doc in yaml_data.get("documents", {}).get("generated", []):
        if doc.get("id") == document_id:
            model_ref = doc.get("model_ref", "")
            if model_ref:
                path = _DEFINITIONS_DIR / model_ref
                if path.exists():
                    return path
            return None
    return None


def _build_list_response(
    index: dict,
    query: Optional[str] = None,
    category: Optional[str] = None,
) -> tuple[list[dict], int]:
    """Build the filtered process list for action='list'."""
    processes: list[dict] = index.get("processes", [])

    if category:
        processes = [p for p in processes if p.get("category") == category]

    if query:
        q = query.lower()
        processes = [
            p
            for p in processes
            if q in p.get("name", "").lower()
            or q in p.get("summary", "").lower()
            or any(q in t.lower() for t in p.get("tags", []))
        ]

    return processes, len(processes)


def _abridge_step(step: dict) -> dict:
    """Return an abridged step suitable for action='get' summary views."""
    return {
        "id": step.get("id"),
        "name": step.get("name"),
        "type": step.get("type"),
        "state": step.get("state"),
        "summary": step.get("objective", ""),
        "next_steps": [ns.get("step") for ns in step.get("next_steps", [])],
        "has_guidance": bool(step.get("guidance")),
        "has_inputs": bool(step.get("inputs", {}).get("required") or step.get("inputs", {}).get("optional")),
        "has_checklist": bool(step.get("checklist", {}).get("completion")),
        "has_documents": bool(step.get("documents")),
    }


def _get_step_detail(yaml_data: dict, step_id: str) -> Optional[dict]:
    """Extract full detail for a single step."""
    for step in yaml_data.get("steps", []):
        if step.get("id") == step_id:
            return step
    return None


def _get_document_meta(yaml_data: dict, document_id: str) -> Optional[dict]:
    """Extract metadata for a single document."""
    for doc in yaml_data.get("documents", {}).get("generated", []):
        if doc.get("id") == document_id:
            # Collect required inputs from the linked step
            step_id = doc.get("step", "")
            required_inputs: list[str] = []
            for step in yaml_data.get("steps", []):
                if step.get("id") == step_id:
                    for inp in step.get("inputs", {}).get("required", []):
                        required_inputs.append(inp.get("name", ""))
                    break
            return {
                "id": doc.get("id"),
                "name": doc.get("name"),
                "type": "generated",
                "description": doc.get("description", ""),
                "model_ref": doc.get("model_ref", ""),
                "required_inputs": required_inputs,
                "generation": doc.get("generation", {}),
            }
    return None


# ── Tool class ─────────────────────────────────────────────────────────────


class ProcessCatalogTool(BaseTool):
    """
    Navigate the Process Catalog — a library of operational process definitions.

    Use this tool to discover available business processes, retrieve their
    step-by-step structure, read guidance for specific steps, and inspect
    document-model metadata.

    This is a consultive knowledge tool — it does not execute or persist
    process instances. Use the returned information to guide the user
    through the workflow conversationally.

    Actions
    -------
    - ``list`` — discover available processes (optionally filter by category or free-text query).
    - ``get`` — retrieve the full definition of a process (lifecycle states + abridged steps).
    - ``get_step`` — retrieve detailed guidance, inputs, checklists, and decision rules for one step.
    - ``get_document`` — retrieve document-model metadata (model_ref, generation hints, required inputs).

    Examples
    --------
    - ``{"action": "list"}``
    - ``{"action": "list", "category": "procurement", "query": "service"}``
    - ``{"action": "get", "process_id": "service_procurement"}``
    - ``{"action": "get_step", "process_id": "service_procurement", "step_id": "estimate_value"}``
    - ``{"action": "get_document", "process_id": "service_procurement", "document_id": "technical_specification"}``
    """

    name: ClassVar[str] = "process_catalog"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Navigate operational process definitions: discover processes, "
        "retrieve step guidance, decision rules, and document-model metadata."
    )
    category: ClassVar[str] = "utility"
    core_tool: ClassVar[bool] = False

    # No permissions required — available to all authenticated users.
    permissions: ClassVar[list[str]] = []
    use_circuit_breaker: ClassVar[bool] = False
    rate_limit_per_minute: ClassVar[int] = 120
    timeout_seconds: ClassVar[int] = 10

    params_schema: ClassVar[dict] = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["list", "get", "get_step", "get_document"],
                "description": (
                    "What to do: 'list' available processes, "
                    "'get' a full process, 'get_step' a single step, "
                    "'get_document' document info."
                ),
                "default": "list",
            },
            "process_id": {
                "type": "string",
                "description": "Process identifier. Required for 'get', 'get_step', 'get_document'.",
            },
            "step_id": {
                "type": "string",
                "description": "Step identifier. Required for 'get_step'.",
            },
            "document_id": {
                "type": "string",
                "description": "Document identifier. Required for 'get_document'.",
            },
            "category": {
                "type": "string",
                "description": (
                    "Filter by category. Used with action='list'."
                ),
            },
            "query": {
                "type": "string",
                "description": (
                    "Free-text search across process names, descriptions, tags. "
                    "Used with action='list'."
                ),
            },
        },
        "required": [],
        "additionalProperties": False,
    }

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        start = time.monotonic()
        action: str = params.get("action", "list")

        # ── action: list ──────────────────────────────────────────────────
        if action == "list":
            index = _load_index()
            processes, count = _build_list_response(
                index,
                query=params.get("query"),
                category=params.get("category"),
            )
            return self._success(
                data={"processes": processes, "count": count},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── All other actions require process_id ──────────────────────────
        process_id: str = (params.get("process_id") or "").strip()
        if not process_id:
            return self._failure(
                code="MISSING_PROCESS_ID",
                message="The 'process_id' parameter is required for this action.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        yaml_data = _load_yaml(process_id)
        if yaml_data is None:
            return self._failure(
                code="PROCESS_NOT_FOUND",
                message=f"Process '{process_id}' not found in the catalog.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        meta = yaml_data.get("process", {})
        objective = yaml_data.get("objective", {})

        # ── action: get ───────────────────────────────────────────────────
        if action == "get":
            lifecycle = yaml_data.get("lifecycle", {})
            steps = yaml_data.get("steps", [])
            return self._success(
                data={
                    "process": {
                        "id": meta.get("id"),
                        "name": meta.get("name"),
                        "version": meta.get("version"),
                        "category": meta.get("category"),
                        "status": meta.get("status"),
                        "purpose": objective.get("purpose", ""),
                        "lifecycle": {
                            "initial_state": lifecycle.get("initial_state"),
                            "final_states": lifecycle.get("final_states", []),
                            "states": [s.get("id") for s in lifecycle.get("states", [])],
                        },
                        "steps": [_abridge_step(s) for s in steps],
                    }
                },
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: get_step ──────────────────────────────────────────────
        if action == "get_step":
            step_id: str = (params.get("step_id") or "").strip()
            if not step_id:
                return self._failure(
                    code="MISSING_STEP_ID",
                    message="The 'step_id' parameter is required for action='get_step'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            step = _get_step_detail(yaml_data, step_id)
            if step is None:
                return self._failure(
                    code="STEP_NOT_FOUND",
                    message=f"Step '{step_id}' not found in process '{process_id}'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            return self._success(
                data={"step": step},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: get_document ──────────────────────────────────────────
        if action == "get_document":
            document_id: str = (params.get("document_id") or "").strip()
            if not document_id:
                return self._failure(
                    code="MISSING_DOCUMENT_ID",
                    message="The 'document_id' parameter is required for action='get_document'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            doc_meta = _get_document_meta(yaml_data, document_id)
            if doc_meta is None:
                return self._failure(
                    code="DOCUMENT_NOT_FOUND",
                    message=f"Document '{document_id}' not found in process '{process_id}'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )
            return self._success(
                data={"document": doc_meta},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── Unknown action ────────────────────────────────────────────────
        return self._failure(
            code="UNKNOWN_ACTION",
            message=f"Unknown action: '{action}'. Valid actions: list, get, get_step, get_document.",
            retryable=False,
            execution_time_ms=int((time.monotonic() - start) * 1000),
        )
