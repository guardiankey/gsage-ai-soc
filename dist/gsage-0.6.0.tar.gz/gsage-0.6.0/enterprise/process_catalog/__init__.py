# Process Catalog — operational process definitions for the AI agent.
# Auto-discovered by the MCP server registry at startup.
