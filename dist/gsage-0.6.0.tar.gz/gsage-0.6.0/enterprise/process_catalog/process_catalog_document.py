"""gSage AI — Process Catalog Document Model loader.

Loads the Markdown content of document models referenced by the process
catalog. This tool is called only when the LLM needs the full document
model content to prepare a generated document.

See: docs-local/prompts/SPECS-process_tools.md
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import ClassVar, Optional

import yaml

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

_DEFINITIONS_DIR = Path(__file__).parent / "definitions"

_DEFAULT_MAX_CHARS = 12000


def _load_index() -> dict:
    """Load the process catalog index (INDEX.yaml)."""
    index_path = _DEFINITIONS_DIR / "INDEX.yaml"
    if not index_path.exists():
        return {"processes": []}
    data = yaml.safe_load(index_path.read_text(encoding="utf-8")) or {}
    return data


def _find_process_in_index(process_id: str) -> Optional[dict]:
    index = _load_index()
    for proc in index.get("processes", []):
        if proc.get("id") == process_id:
            return proc
    return None


def _resolve_yaml_path(process_id: str) -> Optional[Path]:
    entry = _find_process_in_index(process_id)
    if not entry:
        return None
    file_rel = entry.get("file", "")
    if not file_rel:
        return None
    path = _DEFINITIONS_DIR / file_rel
    if path.exists():
        return path
    return None


def _load_yaml(process_id: str) -> Optional[dict]:
    path = _resolve_yaml_path(process_id)
    if path is None:
        return None
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


class ProcessCatalogDocumentTool(BaseTool):
    """
    Load the Markdown content of a document model from the Process Catalog.

    After calling ``process_catalog(action="get_document", ...)`` to obtain
    document metadata, call this tool to retrieve the actual Markdown model
    content. Use that content as the base for document generation via the
    ``generate_document`` tool.

    The document model is a Markdown skeleton with section structure and
    placeholder guidance — the LLM fills in collected user data before
    passing the final content to ``generate_document``.

    Examples
    --------
    - ``{"process_id": "service_procurement", "document_id": "technical_specification"}``
    - ``{"process_id": "service_procurement", "document_id": "contract_draft", "max_chars": 5000}``
    """

    name: ClassVar[str] = "process_catalog_document"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Load the Markdown content of a document model from the Process Catalog "
        "to prepare content for generate_document."
    )
    category: ClassVar[str] = "document"
    core_tool: ClassVar[bool] = False

    permissions: ClassVar[list[str]] = []
    use_circuit_breaker: ClassVar[bool] = False
    rate_limit_per_minute: ClassVar[int] = 60
    timeout_seconds: ClassVar[int] = 10

    params_schema: ClassVar[dict] = {
        "type": "object",
        "properties": {
            "process_id": {
                "type": "string",
                "description": "Process identifier. Required.",
            },
            "document_id": {
                "type": "string",
                "description": "Document identifier declared in documents.generated[]. Required.",
            },
            "max_chars": {
                "type": "integer",
                "description": (
                    "Optional hard cap for returned Markdown content. "
                    "Default 12000."
                ),
                "minimum": 1000,
                "maximum": 50000,
            },
        },
        "required": ["process_id", "document_id"],
        "additionalProperties": False,
    }

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        start = time.monotonic()

        process_id: str = (params.get("process_id") or "").strip()
        document_id: str = (params.get("document_id") or "").strip()
        max_chars: int = int(params.get("max_chars", _DEFAULT_MAX_CHARS))

        if not process_id:
            return self._failure(
                code="MISSING_PROCESS_ID",
                message="The 'process_id' parameter is required.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )
        if not document_id:
            return self._failure(
                code="MISSING_DOCUMENT_ID",
                message="The 'document_id' parameter is required.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # Load YAML to find the model_ref for this document
        yaml_data = _load_yaml(process_id)
        if yaml_data is None:
            return self._failure(
                code="PROCESS_NOT_FOUND",
                message=f"Process '{process_id}' not found in the catalog.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # Locate the document entry
        doc_entry: Optional[dict] = None
        for doc in yaml_data.get("documents", {}).get("generated", []):
            if doc.get("id") == document_id:
                doc_entry = doc
                break

        if doc_entry is None:
            return self._failure(
                code="DOCUMENT_NOT_FOUND",
                message=f"Document '{document_id}' not found in process '{process_id}'.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        model_ref: str = doc_entry.get("model_ref", "")
        if not model_ref:
            return self._failure(
                code="NO_MODEL_REF",
                message=f"Document '{document_id}' has no model_ref defined.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # Resolve and read the Markdown model file
        model_path = _DEFINITIONS_DIR / model_ref
        if not model_path.exists():
            return self._failure(
                code="MODEL_FILE_NOT_FOUND",
                message=(
                    f"Document model file not found: {model_ref}. "
                    "The model_ref points to a file that does not exist on disk."
                ),
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        try:
            content_raw = model_path.read_text(encoding="utf-8")
        except Exception:
            return self._failure(
                code="READ_ERROR",
                message=f"Failed to read document model file: {model_ref}.",
                retryable=False,
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        content = content_raw[:max_chars] if len(content_raw) > max_chars else content_raw

        return self._success(
            data={
                "document_model": {
                    "document_id": document_id,
                    "model_ref": model_ref,
                    "content_markdown": content,
                    "generation": doc_entry.get("generation", {}),
                }
            },
            execution_time_ms=int((time.monotonic() - start) * 1000),
        )
