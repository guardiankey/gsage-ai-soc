# Termo de Ciência — TIC

> Modelo baseado no template oficial da SGD.
> Fonte: https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/
> Anexo do Termo de Referência. Preencha os marcadores `{{...}}`.

## Identificação

**Contrato:** {{contrato_numero}}
**Processo Administrativo:** {{processo_admin}}
**Órgão:** {{org_name}}

## Declaração

Pelo presente instrumento, o representante legal da empresa **{{razao_social}}**, inscrita no CNPJ sob o nº **{{cnpj}}**, doravante denominada **CONTRATADA**, declara ter ciência de que:

1. Deverá observar todas as normas, critérios, procedimentos e padrões estabelecidos pelo órgão contratante para a execução dos serviços objeto do Contrato nº {{contrato_numero}};

2. Está ciente das obrigações e responsabilidades assumidas perante a **CONTRATANTE**, especialmente quanto:
   - Ao cumprimento dos prazos estabelecidos;
   - À qualidade dos serviços prestados;
   - À confidencialidade das informações a que tiver acesso;
   - À observância das normas de segurança da informação do órgão;

3. Tem pleno conhecimento do Termo de Referência, do Edital e de todos os anexos que integram o Contrato;

4. Declara possuir capacidade técnica e operacional para a execução dos serviços contratados, dispondo de instalações, equipamentos e pessoal técnico adequado;

5. Compromete-se a manter, durante toda a execução do contrato, todas as condições de habilitação e qualificação exigidas na contratação;

6. Está ciente das sanções administrativas aplicáveis em caso de descumprimento das obrigações contratuais, nos termos da Lei 14.133/2021.

## Assinatura

| Representante Legal | Testemunha |
|---------------------|------------|
| Nome: {{nome_representante}} | Nome: {{nome_testemunha}} |
| CPF: {{cpf_representante}} | CPF: {{cpf_testemunha}} |
| Cargo: {{cargo_representante}} | |

**{{local}}, {{data}}**

---

> **Nota:** Modelo simplificado. Template oficial SGD disponível em: https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/
