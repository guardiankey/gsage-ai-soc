# Especificação Técnica

> Modelo de documento para especificação técnica de contratação de serviços.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Objeto

{{object_description}}

## 2. Justificativa

A presente contratação justifica-se pela necessidade de {{justification}}.

## 3. Requisitos Técnicos

### 3.1 Requisitos Obrigatórios

{{requirements}}

### 3.2 Qualificação Técnica

O fornecedor deverá comprovar:
- Experiência comprovada na prestação de serviços similares
- Corpo técnico qualificado
- Regularidade fiscal e trabalhista

## 4. Prazo e Local de Execução

**Prazo:** {{contract_duration_months}} meses
**Local:** {{execution_location}}

## 5. Obrigações das Partes

### 5.1 Obrigações da Contratada

{{contractor_obligations}}

### 5.2 Obrigações da Contratante

{{contracting_obligations}}

## 6. Valor Estimado

O valor total estimado para esta contratação é de **R$ {{estimated_value}}**.

## 7. Critérios de Aceitação

{{acceptance_criteria}}

## 8. Fundamentação Legal

- Lei 14.133/2021 — Lei de Licitações e Contratos Administrativos
- {{additional_regulations}}

---

*Gerado a partir do modelo de documento do Catálogo de Processos.*
