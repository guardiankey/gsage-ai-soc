# Planilha de Custos e Formação de Preços

> Modelo conforme Anexo VII-D da IN SEGES 5/2017.
> Adaptar às especificidades do serviço e necessidades do órgão.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Identificação

**Contrato:** {{contract_number}}
**Fornecedor:** {{supplier_name}}
**CNPJ:** {{supplier_cnpj}}
**Objeto:** {{object_description}}
**Vigência:** {{contract_duration_months}} meses

## 2. Módulo 1 — Remuneração da Mão de Obra

| Função (CBO) | Qtd | Salário Base | Adicional | Subtotal (por empregado) | Total |
|-------------|-----|-------------|-----------|-------------------------|-------|
| {{cbo_1}} | {{qty_1}} | R$ {{salary_1}} | R$ {{extra_1}} | R$ {{subtotal_1}} | R$ {{total_1}} |
| {{cbo_2}} | {{qty_2}} | R$ {{salary_2}} | R$ {{extra_2}} | R$ {{subtotal_2}} | R$ {{total_2}} |

**Subtotal Módulo 1:** R$ {{module_1_subtotal}}

## 3. Módulo 2 — Encargos e Benefícios

| Encargo | Percentual | Base de Cálculo | Valor |
|---------|-----------|----------------|-------|
| Grupo A — INSS | {{inss_pct}}% | Módulo 1 | R$ {{inss_value}} |
| Grupo B — FGTS | {{fgts_pct}}% | Módulo 1 | R$ {{fgts_value}} |
| Grupo C — 13º, Férias | {{group_c_pct}}% | Módulo 1 | R$ {{group_c_value}} |
| Grupo D — Vale Transporte | {{group_d_pct}}% | Módulo 1 | R$ {{group_d_value}} |
| Grupo E — Outros | {{group_e_pct}}% | Módulo 1 | R$ {{group_e_value}} |

**Subtotal Módulo 2:** R$ {{module_2_subtotal}}

## 4. Módulo 3 — Insumos

| Insumo | Quantidade | Valor Unitário | Total |
|--------|-----------|---------------|-------|
| {{input_1_name}} | {{input_1_qty}} | R$ {{input_1_unit}} | R$ {{input_1_total}} |
| {{input_2_name}} | {{input_2_qty}} | R$ {{input_2_unit}} | R$ {{input_2_total}} |

**Subtotal Módulo 3:** R$ {{module_3_subtotal}}

## 5. Módulo 4 — Custos Indiretos, Tributos e Lucro

| Componente | Percentual | Base de Cálculo | Valor |
|-----------|-----------|----------------|-------|
| Custos Indiretos | {{indirect_pct}}% | Módulos 1-3 | R$ {{indirect_value}} |
| Lucro | {{profit_pct}}% | Módulos 1-3 | R$ {{profit_value}} |
| Tributos (PIS, COFINS, ISS) | {{taxes_pct}}% | Total | R$ {{taxes_value}} |

**Subtotal Módulo 4:** R$ {{module_4_subtotal}}

## 6. Valor Total do Contrato

| Módulo | Valor |
|--------|-------|
| Módulo 1 — Remuneração | R$ {{module_1_subtotal}} |
| Módulo 2 — Encargos e Benefícios | R$ {{module_2_subtotal}} |
| Módulo 3 — Insumos | R$ {{module_3_subtotal}} |
| Módulo 4 — Custos Indiretos, Tributos e Lucro | R$ {{module_4_subtotal}} |
| **Valor Total Mensal** | **R$ {{monthly_total}}** |
| **Valor Total do Contrato ({{contract_duration_months}} meses)** | **R$ {{contract_total}}** |

---

*Modelo conforme Anexo VII-D da IN SEGES 5/2017. Adaptado às especificidades do serviço.*
