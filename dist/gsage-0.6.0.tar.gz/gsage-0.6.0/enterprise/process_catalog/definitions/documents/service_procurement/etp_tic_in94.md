# Estudo Técnico Preliminar de TIC

> Modelo conforme IN SGD/ME nº 94/2022, Art. 11 e Art. 9º, §7º.
> O ETP deve ser elaborado preferencialmente no sistema ETP Digital (https://www.gov.br/compras).
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Informações Básicas

| Campo | Valor |
|-------|-------|
| **Processo Administrativo nº** | {{processo_admin}} |
| **Órgão** | {{org_name}} |
| **Categoria** | CONTRATAÇÕES DE TIC |
| **Data** | {{date}} |

## 2. Descrição da Necessidade

{{descricao_necessidade}}

> Descrever a necessidade da contratação, evidenciando o problema identificado e a real necessidade que ele gera. Contextualizar a demanda, sua motivação, breve histórico e alinhamento estratégico.

### Alinhamento Estratégico

- **PDTIC:** {{alinhamento_pdtic}}
- **Estratégia de Governo Digital:** {{alinhamento_egd}}
- **Plataforma gov.br (Decreto 8.936/2016):** {{integracao_govbr}}

## 3. Área Requisitante

| Identificação da Área | Nome do Responsável |
|-----------------------|---------------------|
| {{area_requisitante}} | {{responsavel}} |
| {{area_requisitante_2}} | {{responsavel_2}} |

## 4. Necessidades de Negócio

> Funções, funcionalidades, componentes, capacidades e características que a solução deve possuir para atender à demanda (responsabilidade do Integrante Requisitante).

1. {{necessidade_negocio_1}}
2. {{necessidade_negocio_2}}
3. {{necessidade_negocio_n}}

## 5. Necessidades Tecnológicas

> Bens e serviços de TIC necessários, considerando padrões, capacidades, metodologias, segurança da informação, infraestrutura existente e projetos futuros (responsabilidade do Integrante Técnico).

1. {{necessidade_tecnologica_1}}
2. {{necessidade_tecnologica_2}}
3. {{necessidade_tecnologica_n}}

## 6. Demais Requisitos Necessários à Escolha da Solução

> Requisitos com completude suficiente para selecionar a natureza/tipo da solução (Art. 11, I, IN SGD 94/2022).

### 6.1 Requisitos de Segurança da Informação e Privacidade (SIP)

{{requisitos_sip}}

### 6.2 Requisitos de Garantia (quando aplicável)

{{requisitos_garantia}}

### 6.3 Requisitos de Manutenção e Assistência Técnica

{{requisitos_manutencao}}

### 6.4 Outros Requisitos Relevantes

{{outros_requisitos}}

## 7. Estimativa da Demanda — Quantidade de Bens e Serviços

> Descrever a memória de cálculo com: premissas, fórmulas, parâmetros de entrada e cálculos realizados. Anexar documentos de suporte quando necessário.

### Premissas

{{premissas}}

### Memória de Cálculo

| Item | Descrição | Quantidade | Unidade | Justificativa |
|------|-----------|------------|---------|---------------|
| {{item_1}} | {{desc_1}} | {{qtd_1}} | {{un_1}} | {{just_1}} |
| {{item_n}} | {{desc_n}} | {{qtd_n}} | {{un_n}} | {{just_n}} |

## 8. Levantamento de Soluções

> Identificar diferentes alternativas conforme Art. 11, II da IN SGD 94/2022: soluções em outros órgãos, alternativas de mercado, softwares da Portaria STI/MP 46/2016, políticas e padrões de governo (ePing, eMag, ePwg, ICP-Brasil), adequação do ambiente, diferentes modelos de prestação, etc.

| ID | Descrição da Solução (ou Cenário) |
|----|----------------------------------|
| 1 | {{solucao_1}} |
| 2 | {{solucao_2}} |
| N | {{solucao_n}} |

## 9. Análise Comparativa das Soluções

| Requisito | Cenário 1 | Cenário 2 | Cenário N |
|-----------|-----------|-----------|-----------|
| **Negócio:** | | | |
| {{req_negocio_1}} | {{atende/não atende}} | {{atende/não atende}} | {{atende/não atende}} |
| {{req_negocio_n}} | {{atende/não atende}} | {{atende/não atende}} | {{atende/não atende}} |
| **Tecnológico:** | | | |
| {{req_tec_1}} | {{atende/não atende}} | {{atende/não atende}} | {{atende/não atende}} |
| {{req_tec_n}} | {{atende/não atende}} | {{atende/não atende}} | {{atende/não atende}} |
| **Resultado** | {{viavel/inviavel}} | {{viavel/inviavel}} | {{viavel/inviavel}} |

> Verificar Catálogos de Soluções de TIC: https://www.gov.br/governodigital/pt-br/contratacoes/catalogo-de-solucoes-de-tic
> Caso a solução contenha item do Catálogo, utilizar todos os elementos constantes nele (Art. 9º, §6º, IN SGD 94/2022).

## 10. Registro de Soluções Consideradas Inviáveis

> Registrar e justificar as soluções descartadas (Art. 11, §1º, IN SGD 94/2022).

| Solução | Justificativa da Inviabilidade |
|---------|-------------------------------|
| {{solucao_inviavel_1}} | {{justificativa_inviabilidade_1}} |

## 11. Análise Comparativa de Custos (TCO)

> Custo Total de Propriedade ao longo do ciclo de vida. Utilizar mecanismos da IN SEGES 65/2021 para estimativa de preços.

### Solução Viável {{N}} — {{descricao_solucao_N}}

| Componente de Custo | Ano 1 | Ano 2 | Ano 3 | Ano N |
|---------------------|-------|-------|-------|-------|
| {{componente_1}} | R$ {{custo_1_ano1}} | R$ {{custo_1_ano2}} | R$ {{custo_1_ano3}} | R$ {{custo_1_anoN}} |
| {{componente_n}} | R$ {{custo_n_ano1}} | R$ {{custo_n_ano2}} | R$ {{custo_n_ano3}} | R$ {{custo_n_anoN}} |
| **Custo Total no Ano** | R$ {{total_ano1}} | R$ {{total_ano2}} | R$ {{total_ano3}} | R$ {{total_anoN}} |
| Valor Depreciado | R$ {{deprec_ano1}} | R$ {{deprec_ano2}} | R$ {{deprec_ano3}} | R$ {{deprec_anoN}} |
| **TCO da Solução** | **R$ {{tco_solucao_N}}** |

### Mapa Comparativo Consolidado

| Solução | TCO Total |
|---------|-----------|
| Solução Viável 1 | R$ {{tco_solucao_1}} |
| Solução Viável N | R$ {{tco_solucao_n}} |

> Documentar as origens dos valores (forma, método, ferramenta de obtenção).

## 12. Descrição da Solução de TIC a Ser Contratada

{{descricao_solucao_escolhida}}

> Justificar a escolha com base nos benefícios e vantagens que a diferenciam das demais alternativas.

## 13. Estimativa de Custo Total da Contratação

| Item | Descrição | Quantidade | Valor Unitário | Valor Total |
|------|-----------|------------|----------------|-------------|
| {{item_1}} | {{desc_item_1}} | {{qtd_item_1}} | R$ {{vu_item_1}} | R$ {{vt_item_1}} |
| {{item_n}} | {{desc_item_n}} | {{qtd_item_n}} | R$ {{vu_item_n}} | R$ {{vt_item_n}} |
| **Total** | | | | **R$ {{custo_total}}** |

## 14. Justificativa Técnica da Escolha da Solução

{{justificativa_tecnica}}

> Registrar ganhos técnicos: performance, eficiência energética, ganhos logísticos, durabilidade, garantia, manutenção, etc.

### 14.1 Do Parcelamento Decorrente de Aspectos Técnicos

{{parcelamento_tecnico}}

## 15. Justificativa Econômica da Escolha da Solução

{{justificativa_economica}}

### 15.1 Do Parcelamento Decorrente de Aspectos Econômicos

{{parcelamento_economico}}

## 16. Benefícios a Serem Alcançados com a Contratação

> Registrar resultados benéficos estimados (economicidade, eficácia, eficiência, efetividade).

1. {{beneficio_1}}
2. {{beneficio_n}}

## 17. Providências a Serem Adotadas

> Informar providências prévias à celebração do contrato: capacitação de servidores, adequação do ambiente, etc.

{{providencias}}

## 18. Declaração de Viabilidade

**Resultado:** {{viabilidade}} *(Viável / Viável com restrições / Inviável)*

### 18.1 Justificativa

{{justificativa_viabilidade}}

> Fundamentar com: razões da escolha, benefícios em termos de eficácia, eficiência, efetividade e economicidade, alinhamento aos instrumentos estratégicos.

## 19. Responsáveis

> Equipe de Planejamento da Contratação instituída pela Portaria nº {{portaria_epc}}, de {{data_portaria}}.

| **Integrante Técnico** | **Integrante Requisitante** |
|------------------------|-----------------------------|
| {{nome_tecnico}} | {{nome_requisitante}} |
| Matrícula/SIAPE: {{siape_tecnico}} | Matrícula/SIAPE: {{siape_requisitante}} |
| {{local}}, {{data}} | {{local}}, {{data}} |

## 20. Aprovação e Declaração de Conformidade

Aprovo este Estudo Técnico Preliminar e atesto sua conformidade às disposições da Instrução Normativa SGD/ME nº 94, de 23 de dezembro de 2022.

| **Autoridade Máxima da Área de TIC** |
|--------------------------------------|
| {{nome_autoridade_tic}} |
| Matrícula/SIAPE: {{siape_autoridade}} |
| {{local}}, {{data}} |

---

> **Referências:** IN SGD/ME nº 94/2022, Art. 9º, Art. 11. Lei 14.133/2021, Art. 18, §1º. Sistema ETP Digital: https://www.gov.br/compras
