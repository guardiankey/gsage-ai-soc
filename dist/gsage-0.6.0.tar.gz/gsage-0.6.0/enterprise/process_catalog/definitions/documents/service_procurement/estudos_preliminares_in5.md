# Estudos Preliminares (ETP)

> Modelo de Estudo Técnico Preliminar para contratação de serviços conforme ato do Secretário de Gestão da SGD/ME.
> O Anexo III original da IN SEGES 5/2017 foi revogado pela IN nº 49/2020.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Identificação

| Campo | Valor |
|-------|-------|
| **Processo Administrativo nº** | {{processo_admin}} |
| **Órgão** | {{org_name}} |
| **Setor Requisitante** | {{setor_requisitante}} |
| **Data** | {{date}} |

## 2. Necessidade da Contratação

{{necessidade}}

> Descrever o problema a ser resolvido e por que a contratação é a solução adequada.

### 2.1 Alinhamento ao Planejamento Estratégico

{{alinhamento_estrategico}}

### 2.2 Referência a Outros Instrumentos de Planejamento

{{instrumentos_planejamento}}

## 3. Requisitos da Contratação

### 3.1 Classificação do Serviço

- [ ] Serviço comum (padrões de desempenho objetivamente definidos — Art. 14, IN 5/2017)
- [ ] Serviço contínuo (essencial, permanente, mais de 1 exercício — Art. 15, IN 5/2017)
- [ ] Serviço não continuado / por escopo (específico, período predeterminado — Art. 16, IN 5/2017)
- [ ] Com dedicação exclusiva de mão de obra (Art. 17, IN 5/2017)

**Justificativa da classificação:** {{justificativa_classificacao}}

### 3.2 Duração Inicial do Contrato

{{duracao_contrato}} meses

**Justificativa para duração superior a 12 meses (se aplicável):** {{justificativa_duracao}}

### 3.3 Critérios de Sustentabilidade

{{criterios_sustentabilidade}}

> Consultar Guia Nacional de Contratações Sustentáveis da AGU.

### 3.4 Necessidade de Transição Contratual

{{transicao_contratual}}

> Avaliar se a contratada deverá promover transição com transferência de conhecimento, tecnologia e técnicas empregadas.

## 4. Estimativa das Quantidades

### 4.1 Método de Estimativa

{{metodo_estimativa}}

### 4.2 Memória de Cálculo

| Item | Descrição | Quantidade | Unidade | Fonte |
|------|-----------|------------|---------|-------|
| {{item_1}} | {{desc_1}} | {{qtd_1}} | {{un_1}} | {{fonte_1}} |
| {{item_n}} | {{desc_n}} | {{qtd_n}} | {{un_n}} | {{fonte_n}} |

> Utilizar informações de contratações anteriores, se disponíveis. Anexar documentos de suporte.

## 5. Levantamento de Mercado

### 5.1 Soluções Disponíveis

| Solução | Fornecedores Identificados | Vantagens | Desvantagens |
|---------|---------------------------|-----------|--------------|
| {{solucao_1}} | {{fornecedores_1}} | {{vantagens_1}} | {{desvantagens_1}} |
| {{solucao_n}} | {{fornecedores_n}} | {{vantagens_n}} | {{desvantagens_n}} |

### 5.2 Contratações Similares em Outros Órgãos

{{contratacoes_similares}}

### 5.3 Justificativa da Escolha do Tipo de Solução

{{justificativa_solucao}}

## 6. Estimativas de Preços

### 6.1 Método de Estimativa

{{metodo_precos}}

> Utilizar Painel de Preços oficial e seguir diretrizes da IN SEGES 65/2021.

### 6.2 Preços Referenciais

| Item | Preço Unitário | Fonte | Data da Pesquisa |
|------|---------------|-------|-----------------|
| {{item_1}} | R$ {{preco_1}} | {{fonte_preco_1}} | {{data_pesquisa_1}} |
| {{item_n}} | R$ {{preco_n}} | {{fonte_preco_n}} | {{data_pesquisa_n}} |

## 7. Descrição da Solução como um Todo

{{descricao_solucao}}

> Descrever todos os elementos que devem ser produzidos/contratados/executados para que a contratação produza os resultados pretendidos.

## 8. Justificativa para o Parcelamento ou Não da Solução

{{parcelamento}}

> Regra: parcelar sempre que o objeto for divisível, sem prejuízo ao conjunto ou perda de economia de escala.

- [ ] É técnica e economicamente viável o parcelamento?
- [ ] Há perda de economia de escala com o parcelamento?
- [ ] O parcelamento amplia a competitividade?

## 9. Demonstrativo dos Resultados Pretendidos

### 9.1 Economicidade

{{economicidade}}

### 9.2 Melhor Aproveitamento de Recursos

{{aproveitamento_recursos}}

## 10. Providências para Adequação do Ambiente

| Atividade | Responsável | Prazo |
|-----------|-------------|-------|
| {{atividade_1}} | {{resp_1}} | {{prazo_1}} |
| {{atividade_n}} | {{resp_n}} | {{prazo_n}} |

> Incluir necessidade de capacitação de servidores para fiscalização do contrato.

## 11. Contratações Correlatas e/ou Interdependentes

{{contratacoes_correlatas}}

## 12. Declaração de Viabilidade

**Conclusão:** {{declaracao_viabilidade}} *(Viável / Viável com restrições / Inviável)*

**Justificativa:** {{justificativa_viabilidade}}

## 13. Responsáveis

**Equipe de Planejamento da Contratação:**

| Nome | Função | Matrícula/SIAPE |
|------|--------|-----------------|
| {{nome_1}} | {{funcao_1}} | {{siape_1}} |
| {{nome_n}} | {{funcao_n}} | {{siape_n}} |

**Aprovação:**

__________________________________________
{{nome_autoridade}}
Autoridade Competente

**Data:** {{date}}

---

> **Referências:** IN SEGES 5/2017 (atualizada). Lei 14.133/2021, Art. 18, §1º. Ato do Secretário de Gestão da SGD/ME.
