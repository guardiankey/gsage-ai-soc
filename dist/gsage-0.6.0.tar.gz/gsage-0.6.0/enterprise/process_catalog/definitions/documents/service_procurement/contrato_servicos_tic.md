# Contrato de Serviços de TIC

> Modelo baseado no template oficial da AGU (ago/2025).
> Fonte: https://www.gov.br/agu/pt-br/composicao/cgu/cgu/modelos/licitacoesecontratos/14133/bens-e-servicos-de-tic
> Lei 14.133/2021. Preencha os marcadores `{{...}}`.

## 1. Partes

| Contratante | Contratada |
|-------------|------------|
| **Órgão:** {{org_name}} | **Razão Social:** {{razao_social}} |
| **CNPJ:** {{org_cnpj}} | **CNPJ:** {{cnpj}} |
| **Endereço:** {{org_endereco}} | **Endereço:** {{endereco}} |
| **Representante:** {{org_representante}} | **Representante:** {{representante}} |

## 2. Fundamentação Legal

Este contrato rege-se pela Lei 14.133/2021, pela IN SGD/ME nº 94/2022 e, subsidiariamente, pelas demais normas aplicáveis à contratação de soluções de TIC.

**Processo Administrativo:** {{processo_admin}}
**Modalidade:** {{modalidade}} — **Edital nº:** {{edital_numero}}

## 3. Objeto

{{objeto_contrato}}

Conforme especificações detalhadas no **Termo de Referência (Anexo I)** e na **Proposta da Contratada (Anexo II)**, que integram este instrumento independentemente de transcrição.

## 4. Prazo e Vigência

| Campo | Valor |
|-------|-------|
| **Prazo de Execução** | {{prazo_execucao}} meses |
| **Início da Vigência** | {{data_inicio}} |
| **Término da Vigência** | {{data_termino}} |
| **Possibilidade de Prorrogação** | {{prorrogacao}} |

## 5. Valor e Forma de Pagamento

**Valor Total:** R$ {{valor_total}}
**Valor Mensal Estimado:** R$ {{valor_mensal}}

### 5.1 Forma de Pagamento

{{forma_pagamento}}

> O pagamento está condicionado ao cumprimento das metas e indicadores definidos no Instrumento de Medição de Resultado (IMR), conforme Anexo III.

### 5.2 Reajuste

Os preços serão reajustados anualmente pelo índice **ICTI** (Índice de Custos de Tecnologia da Informação), conforme Art. 24 da IN SGD 94/2022, contado da data da proposta.

### 5.3 Dotação Orçamentária

| Campo | Valor |
|-------|-------|
| **Unidade Orçamentária** | {{unidade_orcamentaria}} |
| **Função Programática** | {{funcao_programatica}} |
| **Elemento de Despesa** | {{elemento_despesa}} |
| **Fonte de Recurso** | {{fonte_recurso}} |

## 6. Obrigações das Partes

### 6.1 Obrigações da Contratada

{{obrigacoes_contratada}}

### 6.2 Obrigações da Contratante

{{obrigacoes_contratante}}

## 7. Fiscalização e Gestão

| Função | Responsável | Matrícula/SIAPE |
|--------|-------------|-----------------|
| **Gestor do Contrato** | {{gestor}} | {{siape_gestor}} |
| **Fiscal Técnico** | {{fiscal_tecnico}} | {{siape_fiscal_tecnico}} |
| **Fiscal Administrativo** | {{fiscal_admin}} | {{siape_fiscal_admin}} |

## 8. Sanções Administrativas

O descumprimento das obrigações contratuais sujeitará a Contratada às sanções previstas nos Arts. 155 a 163 da Lei 14.133/2021, incluindo:

- Advertência
- Multa de até {{multa_percentual}}% sobre o valor do contrato
- Impedimento de licitar e contratar
- Declaração de inidoneidade

## 9. Rescisão

O contrato poderá ser rescindido nas hipóteses previstas no Art. 137 da Lei 14.133/2021.

## 10. Disposições Finais

### 10.1 Direitos de Propriedade Intelectual

{{propriedade_intelectual}}

### 10.2 Sigilo e Confidencialidade

A Contratada obriga-se a manter sigilo sobre todas as informações a que tiver acesso (Termo de Compromisso — Anexo IV).

### 10.3 Subcontratação

{{subcontratacao}}

### 10.4 Foro

Fica eleito o foro da Justiça Federal, Seção Judiciária de {{foro}}, para dirimir quaisquer questões decorrentes deste contrato.

## 11. Anexos

| Anexo | Documento |
|-------|-----------|
| I | Termo de Referência |
| II | Proposta da Contratada |
| III | Instrumento de Medição de Resultado (IMR) |
| IV | Termo de Compromisso de Manutenção do Sigilo |
| V | Termo de Ciência |

## 12. Assinaturas

| Pela Contratante | Pela Contratada |
|------------------|-----------------|
| {{nome_contratante}} | {{nome_contratada}} |
| {{cargo_contratante}} | {{cargo_contratada}} |
| **{{local}}, {{data}}** | |

**Testemunhas:**

1. Nome: {{testemunha_1}} — CPF: {{cpf_testemunha_1}}
2. Nome: {{testemunha_2}} — CPF: {{cpf_testemunha_2}}

---

> **Nota:** Modelo simplificado. Template oficial AGU disponível em:
> https://www.gov.br/agu/pt-br/composicao/cgu/cgu/modelos/licitacoesecontratos/14133
