# Edital de Pregão Eletrônico

> Modelo de documento para o edital de pregão eletrônico.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Preâmbulo

O(A) {{org_name}}, por meio do seu Departamento de Licitações, torna
público que será realizado **Pregão Eletrônico**, nos termos da Lei
14.133/2021, para contratação de serviços conforme descrito abaixo.

**Data da sessão:** {{session_date}}
**Horário da sessão:** {{session_time}}
**Local:** Eletrônico via {{bidding_portal_url}}

## 2. Objeto

{{object_description}}

## 3. Valor Estimado

O valor total estimado deste contrato é de **R$ {{estimated_value}}**
para um período de {{contract_duration_months}} meses.

## 4. Requisitos de Participação

Os fornecedores deverão apresentar:

- Comprovante de inscrição no CNPJ
- Certidões de regularidade fiscal (Federal, Estadual, Municipal)
- Certidão de regularidade do FGTS
- Certidão de débitos trabalhistas
- Comprovação de qualificação técnica (conforme Anexo I)

## 5. Envio de Propostas

As propostas deverão ser enviadas eletronicamente via {{bidding_portal_url}}
até **{{proposal_deadline}}**.

## 6. Critério de Julgamento

O contrato será adjudicado ao fornecedor que apresentar o **menor preço**,
desde que atenda a todos os requisitos de qualificação.

## 7. Procedimentos da Sessão

1. Abertura da sessão na data e horário previstos.
2. Recebimento das propostas eletrônicas.
3. Classificação e ordenação por menor preço.
4. Negociação com o fornecedor melhor classificado.
5. Verificação dos documentos de qualificação.
6. Declaração do vencedor.

## 8. Prazo para Recurso

Qualquer interessado poderá interpor recurso no prazo de **3 dias úteis**
após a declaração do vencedor, conforme Art. 165 da Lei 14.133/2021.

## 9. Vigência Contratual

O contrato terá vigência de {{contract_duration_months}} meses, a contar
da data de assinatura, prorrogável nos termos da lei.

## 10. Fundamentação Legal

- Lei 14.133/2021 — Lei de Licitações e Contratos Administrativos
- {{additional_regulations}}

---

*Gerado a partir do modelo de documento do Catálogo de Processos.*
