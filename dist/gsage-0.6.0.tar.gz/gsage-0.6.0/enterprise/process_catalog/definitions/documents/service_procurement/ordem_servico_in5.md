# Ordem de Serviço (OS)

> Modelo conforme Anexo V-A da IN SEGES 5/2017.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Identificação

| Campo | Valor |
|-------|-------|
| **Nº da Ordem de Serviço** | {{os_number}} |
| **Contrato nº** | {{contract_number}} |
| **Fornecedor** | {{supplier_name}} |
| **CNPJ** | {{supplier_cnpj}} |
| **Data de Emissão** | {{issue_date}} |
| **Prazo para Início** | {{start_deadline}} |
| **Prazo para Conclusão** | {{completion_deadline}} |

## 2. Definição e Especificação dos Serviços

### 2.1 Descrição

{{service_description}}

### 2.2 Volume de Serviços Demandados

{{service_volume}}

## 3. Metodologia de Avaliação da Qualidade

{{quality_evaluation_methodology}}

### 3.1 Indicadores

| Indicador | Meta | Método de Verificação |
|-----------|------|----------------------|
| {{indicator_1_name}} | {{indicator_1_target}} | {{indicator_1_method}} |
| {{indicator_2_name}} | {{indicator_2_target}} | {{indicator_2_method}} |

## 4. Responsáveis

| Função | Nome | Contato |
|--------|------|---------|
| **Solicitante** | {{requester_name}} | {{requester_contact}} |
| **Fiscal Técnico** | {{technical_supervisor}} | {{supervisor_contact}} |
| **Preposto da Contratada** | {{contractor_rep}} | {{contractor_contact}} |

## 5. Acompanhamento e Avaliação

A execução dos serviços será acompanhada conforme os seguintes marcos:

| Etapa | Descrição | Prazo | Critério de Aceitação |
|-------|-----------|-------|----------------------|
| {{stage_1_name}} | {{stage_1_desc}} | {{stage_1_deadline}} | {{stage_1_criteria}} |
| {{stage_2_name}} | {{stage_2_desc}} | {{stage_2_deadline}} | {{stage_2_criteria}} |

## 6. Atestação

Ao final da execução, o fiscal técnico emitirá o **Termo de Atestação**
confirmando a conclusão dos serviços conforme os critérios estabelecidos.

## 7. Aprovações

**Solicitante:** ________________________________ Data: {{date}}
{{requester_name}}

**Fiscal Técnico:** ________________________________ Data: {{date}}
{{technical_supervisor}}

---

*Modelo conforme Anexo V-A da IN SEGES 5/2017.*
