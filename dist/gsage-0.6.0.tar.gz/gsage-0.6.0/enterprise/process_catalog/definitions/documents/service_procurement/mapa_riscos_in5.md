# Mapa de Riscos

> Modelo conforme Anexo IV da IN SEGES 5/2017.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## Fase de Análise

☐ Planejamento da Contratação e Seleção do Fornecedor
☐ Gestão do Contrato

**Fase selecionada:** {{selected_phase}}

---

## RISCO {{risk_number}}

**Probabilidade:** ☐ Baixa  ☐ Média  ☐ Alta
**Impacto:** ☐ Baixa  ☐ Média  ☐ Alta

### Danos Identificados

| ID | Descrição do Dano |
|----|-------------------|
| 1  | {{damage_1}} |
| 2  | {{damage_2}} |

### Ações Preventivas

| ID | Ação Preventiva | Responsável |
|----|----------------|-------------|
| 1  | {{preventive_action_1}} | {{preventive_responsible_1}} |
| 2  | {{preventive_action_2}} | {{preventive_responsible_2}} |

### Ações de Contingência

| ID | Ação de Contingência | Responsável |
|----|---------------------|-------------|
| 1  | {{contingency_action_1}} | {{contingency_responsible_1}} |
| 2  | {{contingency_action_2}} | {{contingency_responsible_2}} |

---

## Aprovação

__________________________________________
{{responsible_name}}
Responsável pelos Riscos

**Data:** {{date}}

---

*Modelo conforme Anexo IV da IN SEGES 5/2017.*
