# Histórico de Gestão do Contrato

> Modelo baseado no template oficial da SGD (IN SGD/ME nº 94/2022).
> Fonte: https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/
> Preencha os marcadores `{{...}}` com os dados coletados durante a gestão contratual.

## Identificação do Contrato

| Campo | Valor |
|-------|-------|
| **Contrato nº** | {{contrato_numero}} |
| **Processo Administrativo** | {{processo_admin}} |
| **Contratada** | {{razao_social}} |
| **CNPJ** | {{cnpj}} |
| **Objeto** | {{objeto_contrato}} |
| **Vigência** | {{data_inicio}} a {{data_termino}} |
| **Gestor do Contrato** | {{gestor}} |

## 1. Eventos e Ocorrências

| Data | Tipo | Descrição | Responsável |
|------|------|-----------|-------------|
| {{data_1}} | {{tipo_1}} | {{descricao_1}} | {{responsavel_1}} |
| {{data_n}} | {{tipo_n}} | {{descricao_n}} | {{responsavel_n}} |

> **Tipos de evento:** Início da Execução | Reunião de Fiscalização | Notificação | Prorrogação | Aditivo | Repactuação/Reajuste | Sanção | Rescisão | Encerramento | Outros

## 2. Aditivos Contratuais

| Nº | Data | Tipo | Descrição | Valor (R$) |
|----|------|------|-----------|-----------|
| {{aditivo_num_1}} | {{data_aditivo_1}} | {{tipo_aditivo_1}} | {{desc_aditivo_1}} | {{valor_aditivo_1}} |

> **Tipos:** Prorrogação | Acréscimo | Supressão | Repactuação | Reajuste | Reequilíbrio

## 3. Fiscalização e Medição

### 3.1 Relatórios de Fiscalização

| Período | Indicadores | Conformidade | Glosas (R$) | Fiscal |
|---------|-------------|-------------|-------------|--------|
| {{periodo_1}} | {{indicadores_1}} | {{conformidade_1}}% | {{glosas_1}} | {{fiscal_1}} |

### 3.2 Pagamentos Realizados

| Mês/Ano | NF nº | Valor (R$) | Retenções (R$) | Valor Líquido (R$) |
|---------|-------|------------|----------------|-------------------|
| {{mes_1}} | {{nf_1}} | {{valor_bruto_1}} | {{retencoes_1}} | {{valor_liquido_1}} |

## 4. Ocorrências Trabalhistas (Dedicação Exclusiva)

| Data | Empregado | Ocorrência | Providência |
|------|-----------|------------|-------------|
| {{data_oc_1}} | {{empregado_1}} | {{ocorrencia_1}} | {{providencia_1}} |

## 5. Encerramento

| Campo | Valor |
|-------|-------|
| **Data de Encerramento** | {{data_encerramento}} |
| **Tipo** | {{tipo_encerramento}} *(Término normal / Rescisão)* |
| **Relatório Final** | {{relatorio_final}} |
| **Termo de Recebimento Definitivo** | {{data_trd}} |

## 6. Lições Aprendidas

{{licoes_aprendidas}}

---

> **Assinatura do Gestor do Contrato:**
> {{gestor}} — Matrícula/SIAPE: {{siape_gestor}}
> **{{local}}, {{data_atualizacao}}**

---

> **Nota:** Modelo simplificado. Template oficial SGD disponível em:
> https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/
