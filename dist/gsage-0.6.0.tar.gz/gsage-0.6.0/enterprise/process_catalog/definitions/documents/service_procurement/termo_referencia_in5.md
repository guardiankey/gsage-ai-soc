# Termo de Referência (TR)

> Modelo conforme Anexo V da IN SEGES 5/2017.
> Devem ser utilizados os modelos de minutas padronizados da AGU.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Objeto

{{object_description}}

## 2. Justificativa da Necessidade da Contratação

{{justification}}

## 3. Descrição da Solução como um Todo

{{solution_description}}

Considerando o ciclo de vida do objeto: {{lifecycle_description}}

## 4. Requisitos da Contratação

### 4.1 Requisitos de Sustentabilidade

{{sustainability_requirements}}

### 4.2 Requisitos Técnicos

{{technical_requirements}}

### 4.3 Requisitos de Qualificação Técnica

{{qualification_requirements}}

## 5. Modelo de Execução do Objeto

### 5.1 Descrição dos Serviços

{{service_description}}

### 5.2 Dinâmica do Contrato

{{contract_dynamics}}

### 5.3 Metodologia de Avaliação

{{evaluation_methodology}}

### 5.4 Ordem de Serviço

Definir o modelo de Ordem de Serviço que será utilizado nas etapas de
solicitação, acompanhamento, avaliação e atestação dos serviços, conforme
modelo previsto no Anexo V-A da IN 5/2017, contendo no mínimo:

- Definição e especificação dos serviços a serem realizados
- Volume de serviços demandados
- Metodologia de avaliação da qualidade
- Identificação do responsável pela solicitação
- Prazo para início e conclusão dos serviços

## 6. Modelo de Gestão do Contrato e Critérios de Medição e Pagamento

### 6.1 Fiscalização

{{supervision_description}}

### 6.2 Critérios de Medição

{{measurement_criteria}}

### 6.3 Critérios de Pagamento

{{payment_criteria}}

### 6.4 Sanções, Glosas e Condições para Rescisão

Definir as sanções, glosas e condições para rescisão contratual, utilizando
como referencial os modelos de minutas padronizados da AGU:

{{sanctions_description}}

## 7. Estimativa de Custos

### 7.1 Valor Estimado

**Valor total estimado:** R$ {{estimated_value}}
**Duração do contrato:** {{contract_duration_months}} meses

### 7.2 Planilha de Custos

Conforme modelo previsto no Anexo VII-D da IN 5/2017, adaptado às
especificidades do serviço.

## 8. Local e Prazo de Execução

**Local:** {{execution_location}}
**Prazo:** {{execution_deadline}}

## 9. Fundamentação Legal

- Lei 14.133/2021 — Lei de Licitações e Contratos Administrativos
- IN SEGES 5/2017 — Contratação de Serviços sob Regime de Execução Indireta
- {{additional_regulations}}

---

*Modelo conforme Anexo V da IN SEGES 5/2017.*
