# Documento de Formalização da Demanda (DFD)

> Modelo conforme Anexo II da IN SEGES 5/2017.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Identificação

| Campo | Valor |
|-------|-------|
| **Órgão** | {{org_name}} |
| **Setor Requisitante** | {{requesting_dept}} |
| **Responsável pela Demanda** | {{requester_name}} |
| **Matrícula/SIAPE** | {{requester_id}} |
| **E-mail** | {{requester_email}} |
| **Telefone** | {{requester_phone}} |

## 2. Justificativa da Necessidade

{{justification}}

Considerando o Planejamento Estratégico do órgão (quando houver): {{strategic_alignment}}

## 3. Quantidade de Serviço a Ser Contratada

{{service_quantity}}

## 4. Previsão de Início da Prestação dos Serviços

Data prevista: {{expected_start_date}}

## 5. Indicação da Equipe de Planejamento e Fiscalização

### Equipe de Planejamento da Contratação

| Nome | Matrícula/SIAPE |
|------|-----------------|
| {{planner_1_name}} | {{planner_1_id}} |
| {{planner_2_name}} | {{planner_2_id}} |

### Responsável pela Fiscalização (se necessário)

| Nome | Matrícula/SIAPE |
|------|-----------------|
| {{supervisor_name}} | {{supervisor_id}} |

## 6. Aprovação

**Local:** {{location}}
**Data:** {{date}}

__________________________________________
{{requester_name}}
Responsável pela Formalização da Demanda

---

*Modelo conforme Anexo II da IN SEGES 5/2017.*
