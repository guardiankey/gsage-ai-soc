# Minuta de Contrato de Serviço

> Modelo de documento para minuta de contrato de prestação de serviços.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Partes

**Contratante:** {{org_name}}, CNPJ {{org_cnpj}}
**Contratada:** {{supplier_name}}, CNPJ {{supplier_cnpj}}

## 2. Objeto

O presente contrato tem por objeto a prestação de serviços de {{object_description}},
conforme especificação técnica anexa.

## 3. Valor e Forma de Pagamento

**Valor total:** R$ {{contract_value}}
**Forma de pagamento:** {{payment_terms}}

## 4. Prazo e Vigência

**Prazo:** {{contract_duration_months}} meses, a partir de {{start_date}}.
**Vigência:** {{effective_date}} a {{expiry_date}}, podendo ser prorrogado
nos termos da Lei 14.133/2021.

## 5. Obrigações das Partes

### 5.1 Obrigações da Contratada

{{contractor_obligations}}

### 5.2 Obrigações da Contratante

{{contracting_obligations}}

## 6. Fiscalização

A execução do contrato será fiscalizada por {{supervisor_name}},
designado como fiscal do contrato nos termos do Art. 117 da Lei 14.133/2021.

## 7. Sanções

O descumprimento das obrigações sujeitará a contratada às sanções
previstas nos Arts. 155 a 163 da Lei 14.133/2021.

## 8. Rescisão

O contrato poderá ser rescindido nas hipóteses previstas no Art. 137
da Lei 14.133/2021.

## 9. Foro

Fica eleito o foro da comarca de {{jurisdiction}} para dirimir
quaisquer questões decorrentes deste contrato.

## 10. Fundamentação Legal

- Lei 14.133/2021 — Lei de Licitações e Contratos Administrativos
- {{additional_regulations}}

---

*Gerado a partir do modelo de documento do Catálogo de Processos.*
