# Draft Service Contract

## Contract Identification

- **Contract number:** [number]
- **Process number:** [administrative process number]
- **Date:** [date]

## Parties

### Contracting Authority

- **Name:** [agency name]
- **CNPJ:** [CNPJ]
- **Address:** [address]
- **Representative:** [name, role]

### Contractor

- **Company name:** [company name]
- **CNPJ:** [CNPJ]
- **Address:** [address]
- **Representative:** [name, role]

## 1. Object

[Describe the service object as defined in the technical specification]

## 2. Contract Value

- **Total value:** R$ [value]
- **Payment method:** [payment terms]
- **Price adjustment:** [adjustment rules, if any]

## 3. Duration

- **Start date:** [date]
- **End date:** [date]
- **Renewal:** [renewal conditions]

## 4. Obligations

### 4.1 Contractor Obligations

- [obligation 1]
- [obligation 2]
- [obligation 3]

### 4.2 Contracting Authority Obligations

- [obligation 1]
- [obligation 2]
- [obligation 3]

## 5. Payment

- **Payment schedule:** [schedule]
- **Invoice requirements:** [requirements]
- **Retention/guarantees:** [if applicable]

## 6. Monitoring and Acceptance

- **Contract supervisor:** [name/role]
- **Acceptance procedure:** [procedure]
- **Performance indicators:** [KPIs]

## 7. Penalties

- [penalty clause 1]
- [penalty clause 2]

## 8. Termination

- **Termination conditions:** [conditions]
- **Notice period:** [period]

## 9. Legal Basis

- **Law:** Law 14.133/2021
- **Procurement modality:** [modality]
- **Budget allocation:** [budget reference]

## 10. Signatures

_________________________
**Contracting Authority**

_________________________
**Contractor**

_________________________
**Witnesses**
