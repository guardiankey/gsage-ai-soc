# Termo de Referência de TIC

> Modelo conforme IN SGD/ME nº 94/2022, Art. 12.
> Utilizar o Modelo de TR da SGD (Art. 8º, §2º, IN 94/2022).
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## 1. Declaração do Objeto

### 1.1 Natureza do Objeto

{{natureza_objeto}}

### 1.2 Quantitativos

{{quantitativos}}

### 1.3 Prazo do Contrato

**Duração:** {{prazo_contrato}} meses
**Possibilidade de Prorrogação:** {{prorrogacao}}

### 1.4 Código CATMAT/CATSER

{{codigo_catmat}}

## 2. Fundamentação da Contratação

### 2.1 Justificativa

{{justificativa}}

### 2.2 Estudos Preliminares

Os Estudos Técnicos Preliminares (Anexo {{anexo_etp}}) integram este Termo de Referência, contendo a análise de viabilidade e os elementos essenciais que fundamentam esta contratação.

### 2.3 Alinhamento Estratégico

- **PDTIC:** {{alinhamento_pdtic}}
- **Estratégia de Governo Digital:** {{alinhamento_egd}}
- **Plano de Contratações Anual (PCA):** {{pca}}

## 3. Descrição da Solução como um Todo

{{descricao_solucao}}

> Extraída dos Estudos Preliminares, com eventuais atualizações.

## 4. Requisitos da Contratação

### 4.1 Requisitos de Negócio

1. {{req_negocio_1}}
2. {{req_negocio_n}}

### 4.2 Requisitos Técnicos

1. {{req_tecnico_1}}
2. {{req_tecnico_n}}

### 4.3 Requisitos de Segurança da Informação e Privacidade (SIP)

{{requisitos_sip}}

### 4.4 Requisitos de Sustentabilidade

{{requisitos_sustentabilidade}}

### 4.5 Enquadramento CBO

| Função | CBO | Quantidade |
|--------|-----|------------|
| {{funcao_1}} | {{cbo_1}} | {{qtd_1}} |

### 4.6 Obrigações da Contratante e da Contratada

#### Contratante

{{obrigacoes_contratante}}

#### Contratada

{{obrigacoes_contratada}}

## 5. Modelo de Execução do Objeto

### 5.1 Dinâmica do Contrato

{{dinamica_contrato}}

### 5.2 Prazo para Início da Execução

{{prazo_inicio}}

### 5.3 Rotinas de Execução

| Atividade | Frequência | Periodicidade | Local |
|-----------|------------|---------------|-------|
| {{atividade_1}} | {{frequencia_1}} | {{periodicidade_1}} | {{local_1}} |

### 5.4 Metodologia e Tecnologias

{{metodologia}}

### 5.5 Ordem de Serviço

Conforme modelo do Anexo V-A da IN 5/2017, contendo:
- Identificação do pedido e da contratada
- Definição e especificação dos serviços
- Quantidade de horas demandadas (se aplicável)
- Local de realização
- Recursos financeiros
- Critérios de avaliação
- Identificação dos responsáveis

### 5.6 Transição Contratual

{{transicao_contratual}}

### 5.7 Subcontratação e Consórcio

- **Subcontratação:** {{subcontratacao}}
- **Exclusividade ME/EPP:** {{me_epp}}
- **Consórcio:** {{consorcio}}

## 6. Modelo de Gestão do Contrato

### 6.1 Atores da Gestão

| Função | Responsável |
|--------|-------------|
| Gestor do Contrato | {{gestor}} |
| Fiscal Técnico | {{fiscal_tecnico}} |
| Fiscal Administrativo | {{fiscal_administrativo}} |
| Fiscal Setorial (se aplicável) | {{fiscal_setorial}} |

### 6.2 Mecanismos de Comunicação

{{mecanismos_comunicacao}}

### 6.3 Critérios de Medição

{{criterios_medicao}}

### 6.4 Critérios de Pagamento

{{criterios_pagamento}}

> Forma de pagamento definida em função dos resultados. Evitar remuneração por horas trabalhadas ou por postos de trabalho (excepcionalmente admitidos com justificativa).

### 6.5 Retenção e Glosas (Art. 19, III, IN 94/2022)

| Evento | Percentual de Glosa | Procedimento |
|--------|---------------------|--------------|
| {{evento_1}} | {{glosa_1}}% | {{procedimento_1}} |

### 6.6 Sanções Administrativas (Art. 19, IV, IN 94/2022)

{{sancoes}}

### 6.7 Instrumento de Medição de Resultado (IMR)

| Indicador | Meta | Método de Verificação | Periodicidade |
|-----------|------|----------------------|---------------|
| {{indicador_1}} | {{meta_1}} | {{metodo_1}} | {{period_1}} |

### 6.8 Garantia Contratual

{{garantia}}

> Para serviços com dedicação exclusiva: 5% do valor do contrato, com cobertura para encargos trabalhistas e previdenciários.

## 7. Forma de Seleção do Fornecedor

- **Classificação do serviço:** {{classificacao_servico}}
- **Forma de seleção:** {{forma_selecao}} *(licitação / inexigibilidade / dispensa)*
- **Modalidade:** {{modalidade}}
- **Tipo de licitação:** {{tipo_licitacao}} *(menor preço / técnica e preço)*

## 8. Critérios de Seleção do Fornecedor

### 8.1 Habilitação

{{habilitacao}}

### 8.2 Qualificação Técnica

{{qualificacao_tecnica}}

> Exigências devem ser específicas, objetivas e justificadas. Vedada pontuação progressiva por número de atestados de idêntico teor.

### 8.3 Qualificação Econômico-Financeira

{{qualificacao_economica}}

### 8.4 Critérios de Julgamento

{{criterios_julgamento}}

### 8.5 Margem de Preferência e Desempate

{{margem_preferencia}}

## 9. Estimativa de Preços

### 9.1 Valor Estimado

**Valor total estimado:** R$ {{valor_estimado}}

### 9.2 Planilha de Custos e Formação de Preços

Conforme Anexo VII-D da IN 5/2017 (para serviços com dedicação exclusiva) ou pesquisa de mercado conforme IN SEGES 65/2021.

### 9.3 Memória de Cálculo

{{memoria_calculo}}

## 10. Adequação Orçamentária

- **Dotação Orçamentária:** {{dotacao_orcamentaria}}
- **Compatibilidade LDO:** {{compatibilidade_ldo}}
- **PCA:** {{pca_verificacao}}

## 11. Disposições Finais

### 11.1 Reajuste de Preços

**Índice:** ICTI (Art. 24, IN 94/2022)
**Periodicidade:** Anual, contado da data da proposta.

### 11.2 Cláusula de Reajuste

{{clausula_reajuste}}

### 11.3 Vedações

- Vedada participação de cooperativas/consórcios? {{vedacao_cooperativas}}
- Observar vedações dos Arts. 3º, 4º e 5º da IN SGD 94/2022

## 12. Aprovação

| **Equipe de Planejamento** | **Autoridade Máxima da Área de TIC** |
|---------------------------|--------------------------------------|
| Integrante Técnico: {{nome_tecnico}} | {{nome_autoridade_tic}} |
| Integrante Requisitante: {{nome_requisitante}} | Matrícula/SIAPE: {{siape_autoridade}} |
| Integrante Administrativo: {{nome_admin}} | |
| {{local}}, {{data}} | {{local}}, {{data}} |

**Aprovação pela Autoridade Competente:**

__________________________________________
{{nome_autoridade_competente}}
{{local}}, {{data}}

---

> **Referências:** IN SGD/ME nº 94/2022, Arts. 8º, 12, 15, 16, 17, 18, 19, 24. IN SEGES 65/2021. Lei 14.133/2021. Modelos AGU.
