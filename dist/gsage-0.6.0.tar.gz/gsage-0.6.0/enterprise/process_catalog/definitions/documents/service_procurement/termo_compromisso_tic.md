# Termo de Compromisso de Manutenção do Sigilo — TIC

> Modelo baseado no template oficial da SGD.
> Fonte: https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/
> Anexo do Termo de Referência para serviços de TIC. Preencha os marcadores `{{...}}`.

## Identificação

**Contrato:** {{contrato_numero}}
**Processo Administrativo:** {{processo_admin}}
**Órgão Contratante:** {{org_name}}

## Compromisso

Pelo presente instrumento, {{nome_compromitente}}, {{nacionalidade}}, {{estado_civil}}, portador da Carteira de Identidade nº {{rg}}, inscrito no CPF sob o nº {{cpf}}, na qualidade de {{cargo}} da empresa **{{razao_social}}**, CNPJ nº **{{cnpj}}**, doravante denominada **CONTRATADA**, assume o compromisso de:

1. **Manter absoluto sigilo** sobre todas as informações, dados, documentos, materiais e conhecimentos a que tiver acesso em decorrência da execução do Contrato nº {{contrato_numero}}, celebrado com o **{{org_name}}**;

2. **Não divulgar, reproduzir ou utilizar**, sob qualquer forma ou pretexto, as informações sigilosas a que tiver acesso, salvo mediante autorização expressa da **CONTRATANTE**;

3. **Não realizar cópia** de documentos, arquivos, softwares ou quaisquer outros materiais pertencentes à **CONTRATANTE**, sem prévia autorização;

4. **Zelar pela segurança** das informações, adotando as medidas necessárias para evitar o acesso, a divulgação ou o uso indevido por terceiros não autorizados;

5. **Comunicar imediatamente** à **CONTRATANTE** qualquer incidente de segurança da informação que envolva dados sob sua responsabilidade;

6. **Responsabilizar-se** por todos os seus empregados, prepostos e subcontratados que tenham acesso às informações, estendendo a eles a obrigação de sigilo aqui pactuada;

7. **Devolver** à **CONTRATANTE**, ao término do contrato, todos os documentos, materiais e equipamentos que lhe tenham sido confiados, bem como eliminar eventuais cópias de arquivos digitais;

8. A obrigação de sigilo **permanecerá vigente** mesmo após o término do contrato, pelo prazo de {{prazo_sigilo}} anos, ou enquanto a informação não se tornar de domínio público por meio lícito.

## Penalidades

O descumprimento deste compromisso sujeitará o infrator às sanções civis, penais e administrativas previstas na Lei 14.133/2021, no Código Penal Brasileiro e na Lei Geral de Proteção de Dados (LGPD — Lei 13.709/2018).

## Assinatura

| Compromitente | Testemunha 1 | Testemunha 2 |
|---------------|-------------|-------------|
| Nome: {{nome_compromitente}} | Nome: {{testemunha_1}} | Nome: {{testemunha_2}} |
| CPF: {{cpf_compromitente}} | CPF: {{cpf_testemunha_1}} | CPF: {{cpf_testemunha_2}} |

**{{local}}, {{data}}**

---

> **Nota:** Modelo simplificado. Template oficial SGD disponível em: https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/
