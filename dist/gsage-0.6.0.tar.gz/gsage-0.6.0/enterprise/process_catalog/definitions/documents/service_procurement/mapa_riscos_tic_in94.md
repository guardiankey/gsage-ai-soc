# Mapa de Gerenciamento de Riscos — TIC

> Modelo baseado no template oficial da SGD (MGR v3).
> Fonte: https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.
> Referência: IN SGD/ME nº 94/2022; Lei 14.133/2021, Art. 18, §1º.

## Identificação

| Campo | Valor |
|-------|-------|
| **Processo Administrativo nº** | {{processo_admin}} |
| **Projeto / Solução** | {{nome_projeto}} |
| **Órgão** | {{org_name}} |
| **Data** | {{date}} |

## Histórico de Revisões

| Data | Versão | Descrição | Fase* | Autor |
|------|--------|-----------|-------|-------|
| {{data_1}} | 1.0 | Finalização da primeira versão | PCTIC | {{autor_1}} |
| {{data_n}} | {{versao_n}} | {{descricao_n}} | {{fase_n}} | {{autor_n}} |

> *Fases: **PCTIC** = Planejamento da Contratação; **SFTIC** = Seleção de Fornecedores; **GCTIC** = Gestão do Contrato.

## 1. Identificação dos Riscos

### Risco {{n_risco}}

| Atributo | Valor |
|----------|-------|
| **ID do Risco** | R{{n_risco}} |
| **Fase** | {{fase}} *(PCTIC / SFTIC / GCTIC)* |
| **Tipo** | {{tipo_risco}} |
| **Descrição** | {{descricao_risco}} |

### Probabilidade

- [ ] Baixa
- [ ] Média
- [ ] Alta

### Impacto

- [ ] Baixo
- [ ] Médio
- [ ] Alto

### Dano(s) Identificado(s)

1. {{dano_1}}
2. {{dano_2}}

## 2. Tratamento dos Riscos

### Ações Preventivas

| ID | Ação Preventiva | Responsável | Prazo |
|----|----------------|-------------|-------|
| {{ap_1}} | {{desc_ap_1}} | {{resp_ap_1}} | {{prazo_ap_1}} |

### Ações de Contingência

| ID | Ação de Contingência | Responsável | Gatilho |
|----|---------------------|-------------|---------|
| {{ac_1}} | {{desc_ac_1}} | {{resp_ac_1}} | {{gatilho_ac_1}} |

## 3. Monitoramento

| Indicador | Meta | Periodicidade | Responsável |
|-----------|------|---------------|-------------|
| {{indicador_1}} | {{meta_1}} | {{periodicidade_1}} | {{resp_mon_1}} |

## 4. Aprovação

> O Mapa de Riscos deve ser assinado por toda a Equipe de Planejamento da Contratação (Art. 11, IN SGD 94/2022).

| Integrante Técnico | Integrante Requisitante |
|--------------------|-------------------------|
| {{nome_tecnico}} | {{nome_requisitante}} |
| Matrícula/SIAPE: {{siape_tecnico}} | Matrícula/SIAPE: {{siape_requisitante}} |

**{{local}}, {{data_aprovacao}}**

---

> **Nota:** Este é um modelo simplificado. O template oficial completo está disponível em:
> https://www.gov.br/governodigital/pt-br/contratacoes-de-tic/orientacoes-e-apoio-especializado/templates-de-artefatos-para-contratacao-e-lista-de-verificacao
