# Modelo de Ofício

> Modelo de documento para ofícios administrativos.
> Preencha os marcadores `{{...}}` com os dados coletados antes da geração.

## Cabeçalho

**De:** {{sender_name}}, {{sender_role}}
**Para:** {{recipient_name}}, {{recipient_role}}
**Assunto:** {{subject}}
**Data:** {{date}}
**Nº:** {{document_number}}

## Corpo

{{body}}

## Despedida

Atenciosamente,

{{sender_name}}
{{sender_role}}
