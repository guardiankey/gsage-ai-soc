# Official Letter

**Reference:** [reference number]
**Date:** [date]

**From:**
[department/authority name]

**To:**
[recipient name/department]

**Subject:** [subject]

## Body

[letter content — state the purpose, provide context, and specify any
required action or response.]

## Attachments

- [attachment 1]
- [attachment 2]

## Signature

_________________________
**[name]**
[role]
