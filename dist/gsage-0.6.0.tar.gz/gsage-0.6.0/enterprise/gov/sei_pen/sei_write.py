"""gSage AI — SEI-PEN Write tool.

Performs write operations on the SEI (Sistema Eletrônico de Informações)
WSSEI REST API v2: acknowledge documents, create/update internal documents,
and create/update processes.

All operations require **human-in-the-loop approval** before execution.

Required permission: ``sei:write``
"""

from __future__ import annotations

import json as _json
import logging
import time
import uuid
from contextvars import ContextVar
from typing import ClassVar, Optional

import redis.asyncio as redis
from sqlalchemy.ext.asyncio import AsyncSession

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.shared.elasticsearch.client import ElasticsearchClient
from src.shared.security.context import AgentContext

from src.mcp_server.tools.enterprise.gov.sei_pen import _helpers
from src.mcp_server.tools.enterprise.gov.sei_pen._client import (
    SeiPenClient,
    SeiPenError,
    resolve_base_url,
    with_hint,
)
from src.mcp_server.tools.enterprise.gov.sei_pen._helpers import HelperError
from src.mcp_server.tools.enterprise.gov.sei_pen._operations import BuildError, WRITE_OPERATIONS, build_request

log = logging.getLogger(__name__)

# High-level helper operations (multi-call chains / name resolution). These are
# not single-call WSSEI routes, so they are dispatched before ``build_request``.
HELPER_OPS = (
    "processo.criar_facil",
    "documento.criar_com_conteudo",
    "documento.atualizar_conteudo",
    "processo.definir_prazo",
    "documento.enviar_externo",
    "documento.cadastrar_externo",  # routed through high-level helper (loads file)
    "documento.secao_alterar",      # routed through high-level helper for resilience
)

_WRITE_OP_IDS = sorted(WRITE_OPERATIONS.keys()) + sorted(HELPER_OPS)

# ── Per-coroutine session transport ───────────────────────────────────────────
# Bridges the DB session into execute() (which has no `session` param) so the
# cached reference-data loaders used by name-resolution helpers receive it.
_session_ctx: ContextVar[Optional[AsyncSession]] = ContextVar(
    "sei_pen_write_session", default=None
)


class SeiPenWriteTool(BaseTool):
    """Perform write operations on the SEI WSSEI REST API v2.

    All operations require human-in-the-loop approval before execution.

    **Available operations**

    | Operation                      | Description                                                    |
    |--------------------------------|----------------------------------------------------------------|
    | ``documento.dar_ciencia``      | Acknowledge a document                                         |
    | ``documento.cadastrar_interno``| Create a new internal document inside a process               |
    | ``documento.alterar_interno``  | Update metadata of an existing internal document              |
    | ``processo.criar``             | Create a new SEI process                                       |
    | ``processo.alterar``           | Update metadata of an existing process                         |
    | ``documento.atualizar_conteudo`` | High-level: rewrite editable section(s) of an existing doc in one batched call |
    | ``documento.enviar_externo``     | Upload a file from the conversation as an external document in a process |
    | ``documento.cadastrar_externo``   | Same as enviar_externo — upload a file as an external SEI document |

    **Markdown support** — ``conteudo_md`` parameter

    For ``documento.criar_com_conteudo`` and ``documento.atualizar_conteudo``,
    prefer **``conteudo_md``** (Markdown) over ``conteudo_html`` (raw HTML).
    Markdown is automatically converted to SEI-compatible HTML with the correct
    CSS classes (Texto_Justificado, Secao, Citacao, Paragrafo_Numerado_Nivel1,
    Marcador_Alinhado, etc.). Tables, fenced code blocks, and blockquotes are
    fully supported. If both are provided, ``conteudo_html`` takes precedence.

    **Required params per operation**

    *documento.dar_ciencia*: ``documento`` (document internal ID)

    *documento.cadastrar_interno*: ``procedimento``, ``idSerie``, ``observacao``, ``nivelAcesso``
    (``idUnidadeGeradoraProtocolo`` defaults to the session unit when omitted)

    *documento.alterar_externo*: ``documento``, ``idSerie``, ``dataElaboracao``, ``nivelAcesso``

    *documento.alterar_interno*: ``documento``, ``observacao``, ``nivelAcesso``

    *processo.criar*: ``tipoProcesso``, ``nivelAcesso``, ``assuntos``

    *processo.alterar*: ``protocolo``, ``idTipoProcesso``, ``nivelAcesso``, ``assuntos``

    *processo.atribuir*: ``numeroProcesso`` (formatted protocol), ``usuario`` (numeric ID only, not login string)

    *processo.enviar*: ``numeroProcesso`` (formatted protocol), ``unidadesDestino``

    *processo.concluir*: ``numeroProcesso`` (formatted protocol)

    *processo.sobrestar*: ``protocolo`` (path param — numeric or formatted ID of the process to suspend)

    *processo.cancelar_sobrestamento*: ``protocolo`` (path param — same as sobrestar)

    *processo.agendar_retorno*: ``unidade``, ``dtProgramada``

    *documento.criar_com_conteudo*: ``procedimento``, ``idSerie`` (or ``serie_nome``),
    ``conteudo_md`` (preferred) or ``conteudo_html``, ``nivelAcesso`` (default 0)

    *documento.atualizar_conteudo*: ``documento``, ``conteudo_md`` (preferred)
    or ``conteudo_html`` or ``secoes``

    *documento.enviar_externo*: ``procedimento``, ``idSerie`` (or ``serie_nome``), ``file_id``
    (``dataElaboracao`` defaults to today, ``nivelAcesso`` defaults to 0 = público)

    **⚠️ Parameter guidance — path param vs form param**

    - ``protocolo`` = **URL path parameter** (goes in the URL). Use numeric ID to avoid Apache ``%2F`` issues.
    - ``numeroProcesso`` = **form body parameter** (goes in POST body). Use formatted protocol like ``00000.000001/2026-01``.
    - **Do NOT confuse them.** ``sobrestar`` / ``cancelar_sobrestamento`` / ``alterar`` use ``protocolo`` (path).
      ``enviar`` / ``concluir`` / ``atribuir`` use ``numeroProcesso`` (form).

    **Access level values**: 0 = público, 1 = restrito, 2 = sigiloso

    **Rate limit**: 10 requests/minute. If ``RATE_LIMIT_EXCEEDED``, wait ~10 s and retry.

    Requires **human approval** before execution.

    Permission: ``sei:write``
    """

    name: ClassVar[str] = "sei_pen_write"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Create and update documents and processes in the SEI government "
        "document management system via the WSSEI REST API v2. "
        "Supports Markdown (conteudo_md) for document content — auto-converted "
        "to SEI-compatible HTML. Requires approval."
    )
    category: ClassVar[str] = "document"
    permissions: ClassVar[list[str]] = ["sei:write"]
    rate_limit_per_minute: ClassVar[int] = 10
    timeout_seconds: ClassVar[int] = 60
    use_circuit_breaker: ClassVar[bool] = True
    requires_approval: ClassVar[bool] = True
    supports_multiple_configs: ClassVar[bool] = False

    # Shared org-level configuration and user keychain entry across all
    # ``sei_pen_*`` tools.
    config_namespace: ClassVar[Optional[str]] = "sei_pen"
    requires_user_credentials: ClassVar[bool] = True
    credential_namespace: ClassVar[Optional[str]] = "sei_pen"
    credential_schema: ClassVar[Optional[dict]] = {
        "kind": "basic",
        "required": ["username", "password"],
        "optional": [],
        "extra_fields": {
            "required": ["orgao_id"],
            "optional": ["unidade_id"],
            "properties": {
                "orgao_id": (
                    "SEI organ/agency numeric ID (e.g. '0' for the default organ)."
                ),
                "unidade_id": (
                    "Default unit ID sent with every request to maintain "
                    "session context."
                ),
            },
        },
        "description": (
            "SEI-PEN username and password (login/sigla and senha). "
            "Add 'orgao_id' (required) and 'unidade_id' (optional) as extra "
            "fields of this credential."
        ),
    }

    audit_field_mapping: ClassVar[dict] = {"target_entities": "protocolo"}

    # ── Tool params ───────────────────────────────────────────────────────────

    params_schema: ClassVar[dict] = {
        "type": "object",
        "properties": {
            "operation": {
                "type": "string",
                "enum": _WRITE_OP_IDS,
                "description": (
                    "SEI-PEN write operation to perform. "
                    "See tool description for required params per operation."
                ),
            },
            # ── Identifiers ───────────────────────────────────────────────────
            "procedimento": {
                "type": "string",
                "description": (
                    "Process internal numeric ID. "
                    "Required for: documento.cadastrar_interno, "
                    "documento.criar_com_conteudo, processo.reabrir."
                ),
            },
            "documento": {
                "type": "string",
                "description": (
                    "Document internal numeric ID. "
                    "Required for: documento.dar_ciencia, documento.alterar_interno, "
                    "documento.atualizar_conteudo."
                ),
            },
            "protocolo": {
                "type": "string",
                "description": (
                    "Process internal ID (numeric) for path-based endpoints. "
                    "This is a **URL path parameter**, not a form field. "
                    "Use the numeric internal ID (e.g. '42') rather than the "
                    "formatted protocol (e.g. '00000.000001/2026-01') to avoid "
                    "URL encoding issues with Apache (%2F rejection). "
                    "Required for: processo.alterar, processo.remover_atribuicao, "
                    "processo.sobrestar, processo.cancelar_sobrestamento."
                ),
            },
            # ── Document creation / update ────────────────────────────────────
            "idSerie": {
                "type": "string",
                "description": (
                    "Document type (série) ID. "
                    "Use sei_pen_read(operation='unidade.pesquisar') to discover available types. "
                    "Required for: documento.cadastrar_interno, documento.enviar_externo."
                ),
            },
            "observacao": {
                "type": "string",
                "description": (
                    "Observation text attached to the document. "
                    "Required for: documento.cadastrar_interno, documento.alterar_interno."
                ),
            },
            "nivelAcesso": {
                "type": "integer",
                "minimum": 0,
                "maximum": 2,
                "description": (
                    "Access level: 0 = público, 1 = restrito, 2 = sigiloso. "
                    "Required for: documento.cadastrar_interno, documento.alterar_interno, "
                    "processo.criar, processo.alterar."
                ),
            },
            "assuntos": {
                "type": "string",
                "description": (
                    "Comma-separated subject IDs, e.g. '3,5' or '674'. "
                    "**Required** for: processo.criar, processo.alterar (the "
                    "SEI API rejects requests without subjects). "
                    "Optional for: documento.cadastrar_interno, documento.alterar_interno."
                ),
            },
            "interessados": {
                "type": "string",
                "description": (
                    "Comma-separated interested-party (contato) IDs. "
                    "Optional for: documento.cadastrar_interno, documento.alterar_interno, "
                    "processo.criar, processo.alterar."
                ),
            },
            "idHipoteseLegal": {
                "type": "string",
                "description": (
                    "Legal hypothesis ID (required when nivelAcesso > 0). "
                    "Optional for: documento.cadastrar_interno, documento.alterar_interno, "
                    "processo.alterar."
                ),
            },
            "protocoloDocumentoModelo": {
                "type": "string",
                "description": (
                    "Formatted protocol of the model document to use as template. "
                    "Optional for: documento.cadastrar_interno."
                ),
            },
            "descricao": {
                "type": "string",
                "description": (
                    "Free-text description for the document. "
                    "Optional for: documento.cadastrar_interno, documento.alterar_interno."
                ),
            },
            "destinatarios": {
                "type": "string",
                "description": (
                    "Comma-separated recipient (contato) IDs. "
                    "Optional for: documento.cadastrar_interno, documento.alterar_interno."
                ),
            },
            "idUnidadeGeradoraProtocolo": {
                "type": "string",
                "description": (
                    "Generating/responsible unit ID for the document. "
                    "When omitted, defaults to the session unit ('unidade_id' from the "
                    "credential, or the 'unidade' override). The WSSEI module requires "
                    "this field to register the document. "
                    "Optional for: documento.cadastrar_interno, documento.alterar_interno."
                ),
            },
            # ── Process creation / update ─────────────────────────────────────
            "tipoProcesso": {
                "type": "string",
                "description": (
                    "Process type ID. "
                    "Use sei_pen_read(operation='processo.pesquisar_assunto') to discover. "
                    "Required for: processo.criar."
                ),
            },
            "hipoteseLegal": {
                "type": "string",
                "description": (
                    "Legal hypothesis value for the process. "
                    "Required for: processo.criar."
                ),
            },
            "grauSigilo": {
                "type": "string",
                "description": (
                    "Secrecy degree. Only relevant for sigiloso processes "
                    "(nivelAcesso=2). Omit or pass empty string ('') for public "
                    "or restricted processes. "
                    "Optional for: processo.criar, processo.alterar."
                ),
            },
            "especificacao": {
                "type": "string",
                "description": (
                    "Process subject/specification text. "
                    "Optional for: processo.criar, processo.alterar."
                ),
            },
            "observacoes": {
                "type": "string",
                "description": (
                    "Free-text observations for the process. "
                    "Optional for: processo.criar."
                ),
            },
            "idTipoProcesso": {
                "type": "string",
                "description": (
                    "Process type ID to update. "
                    "Required for: processo.alterar."
                ),
            },
            # ── Document section content ──────────────────────────────────────
            "versao": {
                "type": "string",
                "description": (
                    "Document version number to edit. "
                    "Required for: documento.secao_alterar. "
                    "Get it from sei_pen_read(operation='documento.secao_listar')."
                ),
            },
            "secoes": {
                "description": (
                    "Sections to update. "
                    "PREFER 'documento.atualizar_conteudo' over 'documento.secao_alterar' "
                    "— the high-level helper auto-resolves the version, fills all "
                    "required sections, and handles HTML entity unescaping. "
                    "Only use 'documento.secao_alterar' directly if you need "
                    "precise control and have already listed the full section "
                    "payload via sei_pen_read(operation='documento.secao_listar'). "
                    "For documento.secao_alterar: a JSON-encoded string of "
                    '[{"id", "idSecaoModelo", "conteudo"}] with ALL sections. '
                    "For documento.atualizar_conteudo: a JSON array (object[]) "
                    "of {id|idSecaoModelo, conteudo} — only the sections you want to change. "
                    "Required for: documento.secao_alterar; "
                    "alternative to 'conteudo_html' for documento.atualizar_conteudo."
                ),
            },
            # ── Process tramitation / lifecycle ───────────────────────────────
            "numeroProcesso": {
                "type": "string",
                "description": (
                    "Formatted process number/protocol (e.g. "
                    "'000123.000017/2026-12'), NOT the internal numeric ID. "
                    "This is a **form body parameter**, not a URL path param. "
                    "Use the 'ProtocoloFormatado' value from processo.criar or "
                    "processo.consultar. "
                    "Required for: processo.enviar, processo.concluir, processo.atribuir."
                ),
            },
            "unidadesDestino": {
                "type": "string",
                "description": (
                    "Comma-separated destination unit IDs, e.g. '110000965,110000966'. "
                    "Required for: processo.enviar."
                ),
            },
            "usuario": {
                "type": "string",
                "description": (
                    "**Numeric user ID only** (e.g. '100000693'), NOT a login "
                    "string (e.g. 'heles.junior'). The SEI WSSEI API accepts "
                    "only the internal numeric ID for assignments. "
                    "Use sei_pen_read(operation='usuario.pesquisar', palavrachave='...') "
                    "to discover the numeric ID from a login name. "
                    "Required for: processo.atribuir. "
                    "Optional for: processo.agendar_retorno, processo.definir_prazo."
                ),
            },
            "dtProgramada": {
                "type": "string",
                "description": (
                    "Programmed return date in dd/MM/yyyy. "
                    "Required for: processo.agendar_retorno."
                ),
            },
            "atividadeEnvio": {
                "type": "string",
                "description": (
                    "Sending activity ID associated with the scheduled return. "
                    "Optional for: processo.agendar_retorno, processo.definir_prazo."
                ),
            },
            "protocoloDestino": {
                "type": "string",
                "description": (
                    "Related process protocol when suspending. "
                    "Optional for: processo.sobrestar."
                ),
            },
            "motivo": {
                "type": "string",
                "description": (
                    "Reason text. Optional for: processo.sobrestar."
                ),
            },
            "sinManterAbertoUnidade": {
                "type": "string",
                "description": (
                    "'S'/'N' — keep the process open in the current unit. "
                    "Optional for: processo.enviar."
                ),
            },
            "sinRemoverAnotacao": {
                "type": "string",
                "description": "'S'/'N'. Optional for: processo.enviar.",
            },
            "sinEnviarEmailNotificacao": {
                "type": "string",
                "description": "'S'/'N'. Optional for: processo.enviar.",
            },
            "dataRetornoProgramado": {
                "type": "string",
                "description": (
                    "dd/MM/yyyy return date on send. Optional for: processo.enviar."
                ),
            },
            "diasRetornoProgramado": {
                "type": "string",
                "description": (
                    "Number of days for return on send. Optional for: processo.enviar."
                ),
            },
            "sinDiasUteisRetornoProgramado": {
                "type": "string",
                "description": "'S'/'N'. Optional for: processo.enviar.",
            },
            "sinReabrir": {
                "type": "string",
                "description": "'S'/'N'. Optional for: processo.enviar.",
            },
            # ── High-level helper inputs (friendly, name-based) ───────────────
            "tipo_processo_nome": {
                "type": "string",
                "description": (
                    "Process type *name* to resolve automatically. "
                    "Used by: processo.criar_facil (alternative to tipoProcesso)."
                ),
            },
            "serie_nome": {
                "type": "string",
                "description": (
                    "Document type (série) *name* to resolve automatically. "
                    "Used by: documento.criar_com_conteudo, documento.enviar_externo "
                    "(alternative to idSerie)."
                ),
            },
            "hipotese_nome": {
                "type": "string",
                "description": (
                    "Legal-hypothesis *name* to resolve automatically. "
                    "Used by: processo.criar_facil (alternative to hipoteseLegal)."
                ),
            },
            "conteudo_html": {
                "type": "string",
                "description": (
                    "HTML body content to write into the document. "
                    "Required for: documento.criar_com_conteudo. "
                    "Quick-mode alternative to 'secoes' for documento.atualizar_conteudo "
                    "(overwrites the editable principal section). "
                    "When both 'conteudo_md' and 'conteudo_html' are provided, "
                    "'conteudo_html' takes precedence."
                ),
            },
            "conteudo_md": {
                "type": "string",
                "description": (
                    "⭐ PREFERRED — Markdown body content. Automatically converted "
                    "to SEI-compatible HTML with correct CSS classes: headings → "
                    "Secao/Texto_Justificado_Maiusculas, paragraphs → Texto_Justificado, "
                    "ordered lists → Paragrafo_Numerado_Nivel1, unordered → Marcador_Alinhado, "
                    "blockquotes → Citacao, tables → Tabela_Texto_Centralizado. "
                    "Supports fenced code blocks and TOC. "
                    "Used by: documento.criar_com_conteudo, documento.atualizar_conteudo "
                    "(alternative to conteudo_html)."
                ),
            },
            "file_id": {
                "type": "string",
                "description": (
                    "GSage file ID (UUID) of the uploaded attachment to send. "
                    "To discover available files and their UUIDs, call "
                    "list_recent_artifacts(scope='session', category='attachment') "
                    "— this returns file_id, filename, content_type, and size "
                    "for each file uploaded in the current conversation. "
                    "You can also find the UUID in the [ATTACHED_FILES] block "
                    "at the top of the conversation context (the 'id:' field). "
                    "Do NOT call read_file to inspect the file — just pass the "
                    "UUID directly here. "
                    "Required for: documento.enviar_externo, documento.cadastrar_externo."
                ),
            },
            "dataElaboracao": {
                "type": "string",
                "description": (
                    "Document date in DD/MM/YYYY format. Defaults to today's date "
                    "when omitted. Used by: documento.enviar_externo."
                ),
            },
            "descricao": {
                "type": "string",
                "description": (
                    "Free-text description for the document. "
                    "Optional for: documento.enviar_externo, documento.cadastrar_externo, "
                    "documento.cadastrar_interno, documento.alterar_interno."
                ),
            },
            "nome_arvore": {
                "type": "string",
                "description": (
                    "Display name for the document in the SEI process tree. "
                    "When omitted the file name is used. "
                    "Optional for: documento.enviar_externo, documento.cadastrar_externo."
                ),
            },
            "numero": {
                "type": "string",
                "description": (
                    "Tree identifier for external documents. Same concept as "
                    "'nome_arvore' — this is the raw WSSEI field name used by "
                    "documento.alterar_externo. Optional for: documento.alterar_externo."
                ),
            },
            "remetente": {
                "type": "string",
                "description": (
                    "Sender (remetente) contact ID for external documents. "
                    "Optional for: documento.enviar_externo, documento.cadastrar_externo."
                ),
            },
            "dias": {
                "type": "integer",
                "minimum": 0,
                "description": (
                    "Days ahead to compute the deadline date. "
                    "Used by: processo.definir_prazo (alternative to dtProgramada)."
                ),
            },
            "data": {
                "type": "string",
                "description": (
                    "Explicit deadline date in dd/MM/yyyy. "
                    "Used by: processo.definir_prazo (alternative to dias)."
                ),
            },
            # ── Session unit override ─────────────────────────────────────────
            "unidade": {
                "type": "string",
                "description": (
                    "Unit ID (numeric) to override the default session unit context "
                    "for this request. "
                    "Required for: processo.agendar_retorno, processo.definir_prazo."
                ),
            },
        },
        "required": ["operation"],
        "additionalProperties": False,
    }

    # ── Tool config (stored encrypted in DB) ─────────────────────────────────

    config_schema: ClassVar[Optional[dict]] = {
        "type": "object",
        "properties": {
            "ambiente": {
                "type": "string",
                "enum": [
                    "producao_orgao1", "producao_orgao2", "producao_orgao3",
                    "producao_orgao4", "producao_orgao5",
                    "homologacao_orgao1", "homologacao_orgao2", "homologacao_orgao3",
                    "homologacao_orgao4", "homologacao_orgao5",
                ],
                "description": (
                    "SEI-PEN environment preset. Maps to the standard WSSEI v2 URL. "
                    "Use 'base_url' for non-standard installations."
                ),
            },
            "base_url": {
                "type": "string",
                "description": (
                    "Custom WSSEI v2 base URL. Overrides 'ambiente' when set. "
                    "Example: http://sei.myorg.gov.br/sei/modulos/wssei/controlador_ws.php/api/v2"
                ),
            },
        },
        "required": [],
        "additionalProperties": False,
    }
    config_defaults: ClassVar[dict] = {}

    # ── No persistent state needed ────────────────────────────────────────────

    state_schema: ClassVar[Optional[dict]] = None
    state_defaults: ClassVar[dict] = {}
    reset_policy: ClassVar[str] = "never"

    # ── Session transport ─────────────────────────────────────────────────────
    async def run(
        self,
        agent_context: AgentContext,
        params: dict,
        session: AsyncSession,
        redis_client: redis.Redis,
        es_client: ElasticsearchClient,
        gsage_session_id: Optional[uuid.UUID] = None,
        tool_call_id: Optional[uuid.UUID] = None,
    ) -> ToolResult:
        """Override to make the DB session available inside execute().

        The cached SEI reference-data loaders (used by name-resolution helpers)
        require a ``session`` to read/write the result cache.
        """
        token = _session_ctx.set(session)
        try:
            return await super().run(
                agent_context,
                params,
                session,
                redis_client,
                es_client,
                gsage_session_id,
            )
        finally:
            _session_ctx.reset(token)

    # ── Execute ───────────────────────────────────────────────────────────────

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        t0 = time.perf_counter()
        operation: str = params["operation"]

        # ── Resolve base URL ──────────────────────────────────────────────────
        try:
            base_url = resolve_base_url(
                config.get("ambiente"),
                config.get("base_url"),
            )
        except SeiPenError as exc:
            return self._failure("CONFIG_ERROR", str(exc))

        # ── Resolve credentials (user keychain shared by all sei_pen_* tools) ──
        user_creds = agent_context.user_credentials.get("sei_pen") or {}
        usuario: str = (user_creds.get("username") or "").strip()
        senha: str = (user_creds.get("password") or "").strip()
        extra: dict = user_creds.get("extra_fields") or {}
        orgao_id: str = str(extra.get("orgao_id", "") or "").strip()
        unidade_id: Optional[str] = str(extra.get("unidade_id", "") or "").strip() or None
        if not usuario or not senha:
            return self._failure(
                "CREDENTIAL_MISSING",
                "SEI-PEN requires a personal credential. Configure your "
                "'sei_pen' credential in Settings → Credentials and link "
                "it as active for this tool.",
            )
        if not orgao_id:
            return self._failure(
                "CREDENTIAL_MISSING",
                "SEI-PEN credential must include an 'orgao_id' extra field. "
                "Edit your 'sei_pen' credential in Settings → Credentials and "
                "add 'orgao_id' (and optionally 'unidade_id') as extra fields.",
            )

        # ── Build request ─────────────────────────────────────────────────────
        # Default idUnidadeGeradoraProtocolo to the session unit for document
        # operations when the caller does not provide it. The WSSEI module
        # sets the document's generating/responsible unit from this field;
        # omitting it makes the underlying SEI component reject the request
        # with "Atributo [IdUnidadeResponsavel] não recebeu valor."
        default_unit = params.get("unidade") or unidade_id

        if operation in ("documento.cadastrar_interno", "documento.alterar_interno"):
            if not params.get("idUnidadeGeradoraProtocolo") and default_unit:
                params = {**params, "idUnidadeGeradoraProtocolo": default_unit}

        # ── Normalise documento.alterar_externo: accept ``nome_arvore`` as ───
        # an alias for ``numero`` (tree identifier in SEI).
        if operation == "documento.alterar_externo":
            nome_arvore = params.get("nome_arvore")
            if nome_arvore and not params.get("numero"):
                params["numero"] = nome_arvore

        # ── Build the REST client ─────────────────────────────────────────────
        client = SeiPenClient(
            base_url=base_url,
            usuario=usuario,
            senha=senha,
            orgao_id=orgao_id,
            unidade_id=unidade_id,
            timeout=float(self.timeout_seconds),
        )
        unidade_override: Optional[str] = params.get("unidade")

        # ── Normalise processo.atribuir: accept ``procedimento`` as an ──────
        # alternative to ``numeroProcesso`` (the formatted protocol).
        if operation == "processo.atribuir":
            proc = params.get("procedimento")
            if proc and not params.get("numeroProcesso"):
                params["numeroProcesso"] = str(proc)

        # ── Normalise secoes: SEI EncodingMiddleware transcodes form body ───
        # to ISO-8859-1.  Non-ASCII UTF-8 bytes get corrupted and break
        # json_decode on the PHP side.  Re-encode with ensure_ascii=True so
        # every non-ASCII char becomes a \\uXXXX escape (pure ASCII that
        # survives the ISO-8859-1 round-trip).
        if operation == "documento.secao_alterar":
            raw = params.get("secoes")
            if raw is not None:
                if isinstance(raw, list):
                    params["secoes"] = _json.dumps(raw, ensure_ascii=True)
                elif isinstance(raw, str):
                    try:
                        parsed = _json.loads(raw)
                        if isinstance(parsed, list):
                            params["secoes"] = _json.dumps(parsed, ensure_ascii=True)
                    except (_json.JSONDecodeError, TypeError):
                        pass

        # ── High-level helper chains (name resolution / multi-call) ───────────
        if operation in HELPER_OPS:
            session = _session_ctx.get()
            org_id = getattr(agent_context, "org_id", None)
            try:
                helper_result = await self._run_helper(
                    operation=operation,
                    params=params,
                    client=client,
                    base_url=base_url,
                    orgao_id=orgao_id,
                    org_id=org_id,
                    session=session,
                    unidade_override=unidade_override,
                    default_unit=unidade_override or unidade_id,
                    agent_context=agent_context,
                )
            except HelperError as exc:
                msg = str(exc)
                if exc.candidates:
                    msg += "\n\nCandidates (use one of these ids):\n" + _json.dumps(
                        exc.candidates, ensure_ascii=False, indent=2
                    )
                return self._failure(
                    "INVALID_PARAMS",
                    msg,
                    execution_time_ms=round((time.perf_counter() - t0) * 1000),
                )
            except SeiPenError as exc:
                log.warning(
                    "sei_pen_write: helper=%s error=%s", operation, exc, exc_info=True
                )
                retryable = (
                    exc.status_code in (429, 500, 502, 503, 504)
                    if exc.status_code
                    else False
                )
                return self._failure(
                    "SEI_API_ERROR",
                    with_hint(str(exc), exc.status_code, operation),
                    retryable=retryable,
                )

            elapsed_ms = round((time.perf_counter() - t0) * 1000)
            log.info(
                "sei_pen_write: helper=%s status=success elapsed_ms=%d",
                operation,
                elapsed_ms,
            )
            return self._success(
                {"operation": operation, "result": helper_result},
                execution_time_ms=elapsed_ms,
            )

        # ── Single-call WSSEI route ───────────────────────────────────────────
        try:
            method, path, query, form = build_request(operation, params, is_write=True)
        except BuildError as exc:
            return self._failure("INVALID_PARAMS", str(exc))

        try:
            response = await client.request(
                method,
                path,
                params=query or None,
                data=form or None,
                unidade_override=unidade_override,
            )
        except SeiPenError as exc:
            log.warning(
                "sei_pen_write: operation=%s error=%s", operation, exc, exc_info=True
            )
            retryable = exc.status_code in (429, 500, 502, 503, 504) if exc.status_code else False
            return self._failure(
                "SEI_API_ERROR",
                with_hint(str(exc), exc.status_code, operation),
                retryable=retryable,
            )

        elapsed_ms = round((time.perf_counter() - t0) * 1000)
        log.info(
            "sei_pen_write: operation=%s status=success elapsed_ms=%d",
            operation,
            elapsed_ms,
        )

        return self._success(
            {
                "operation": operation,
                "result": response.get("data"),
                "mensagem": response.get("mensagem"),
                "sucesso": response.get("sucesso"),
            }
        )

    # ── Helper dispatch ───────────────────────────────────────────────────────

    async def _run_helper(
        self,
        *,
        operation: str,
        params: dict,
        client: SeiPenClient,
        base_url: str,
        orgao_id: str,
        org_id: Optional[uuid.UUID],
        session: Optional[AsyncSession],
        unidade_override: Optional[str],
        default_unit: Optional[str],
        agent_context: AgentContext,
    ) -> dict:
        """Dispatch a high-level helper chain by operation name."""
        # ── MD → HTML conversion ─────────────────────────────────────────
        # When the caller provides Markdown (conteudo_md) instead of raw HTML,
        # convert it automatically using the SEI CSS class mapper.
        # conteudo_html always wins if both are set.
        conteudo_md = params.get("conteudo_md")
        if conteudo_md and not params.get("conteudo_html"):
            from src.mcp_server.tools.enterprise.gov.sei_pen._sei_md import md_to_sei_html
            params["conteudo_html"] = md_to_sei_html(str(conteudo_md))

        # ── ISO-8859-1 sanitisation for raw HTML ─────────────────────────
        # md_to_sei_html() already sanitises its output, but when the caller
        # passes raw conteudo_html directly we must still scrub characters
        # outside the Latin-1 repertoire (em dash, smart quotes, etc.) or
        # SEI's mb_convert_encoding(…, 'ISO-8859-1') will corrupt the content.
        raw_html = params.get("conteudo_html")
        if raw_html:
            from src.mcp_server.tools.enterprise.gov.sei_pen._sei_md import sanitize_for_sei
            params["conteudo_html"] = sanitize_for_sei(str(raw_html))

        if operation == "processo.criar_facil":
            return await _helpers.criar_processo_facil(
                client=client,
                base_url=base_url,
                orgao_id=orgao_id,
                org_id=org_id,
                session=session,
                unidade_override=unidade_override,
                tipo_processo_nome=params.get("tipo_processo_nome"),
                tipo_processo_id=params.get("tipoProcesso"),
                nivel_acesso=int(params.get("nivelAcesso", 0) or 0),
                hipotese_nome=params.get("hipotese_nome"),
                hipotese_id=params.get("hipoteseLegal"),
                grau_sigilo=params.get("grauSigilo", "") or "",
                especificacao=params.get("especificacao"),
                interessados=params.get("interessados"),
                assuntos=params.get("assuntos"),
                observacoes=params.get("observacoes"),
            )

        if operation == "documento.criar_com_conteudo":
            procedimento = params.get("procedimento")
            if not procedimento:
                raise HelperError(
                    "'procedimento' (process internal ID) is required for "
                    "documento.criar_com_conteudo."
                )
            conteudo = params.get("conteudo_html")
            if not conteudo:
                raise HelperError(
                    "'conteudo_html' (or 'conteudo_md') is required for "
                    "documento.criar_com_conteudo."
                )
            return await _helpers.criar_documento_com_conteudo(
                client=client,
                base_url=base_url,
                orgao_id=orgao_id,
                org_id=org_id,
                session=session,
                unidade_override=unidade_override,
                procedimento=str(procedimento),
                serie_nome=params.get("serie_nome"),
                id_serie=params.get("idSerie"),
                nivel_acesso=int(params.get("nivelAcesso", 0) or 0),
                observacao=params.get("observacao", "") or "",
                conteudo_html=str(conteudo),
                id_unidade_geradora=params.get("idUnidadeGeradoraProtocolo")
                or default_unit,
                id_hipotese_legal=params.get("idHipoteseLegal"),
            )

        if operation == "processo.definir_prazo":
            dias_raw = params.get("dias")
            return await _helpers.definir_prazo(
                client=client,
                unidade_override=unidade_override,
                unidade=params.get("unidade"),
                dias=int(dias_raw) if dias_raw not in (None, "") else None,
                data=params.get("data") or params.get("dtProgramada"),
                usuario=params.get("usuario"),
                atividade_envio=params.get("atividadeEnvio"),
            )

        if operation == "documento.atualizar_conteudo":
            documento = params.get("documento")
            if not documento:
                raise HelperError(
                    "'documento' (internal document ID) is required for "
                    "documento.atualizar_conteudo."
                )
            raw_secoes = params.get("secoes")
            secoes_arg: Optional[list[dict]] = None
            if raw_secoes:
                if isinstance(raw_secoes, list):
                    secoes_arg = raw_secoes
                elif isinstance(raw_secoes, str):
                    try:
                        parsed = _json.loads(raw_secoes)
                    except _json.JSONDecodeError as exc:
                        raise HelperError(
                            f"'secoes' is not valid JSON: {exc}"
                        ) from exc
                    if not isinstance(parsed, list):
                        raise HelperError(
                            "'secoes' must decode to a JSON array of section objects."
                        )
                    secoes_arg = parsed
                else:
                    raise HelperError(
                        "'secoes' must be a list of section objects or a JSON-encoded "
                        "string of that list."
                    )
            return await _helpers.atualizar_documento_conteudo(
                client=client,
                unidade_override=unidade_override,
                documento=str(documento),
                conteudo_html=params.get("conteudo_html"),
                secoes=secoes_arg,
            )

        if operation in ("documento.enviar_externo", "documento.cadastrar_externo"):
            procedimento = params.get("procedimento")
            if not procedimento:
                raise HelperError(
                    f"'procedimento' (process internal ID) is required for "
                    f"{operation}."
                )
            file_id = params.get("file_id")
            if not file_id:
                raise HelperError(
                    f"'file_id' (GSage file UUID) is required for "
                    f"{operation}. The file must be uploaded to "
                    "the conversation first."
                )
            # Load the file from MinIO with access control.
            # Use _load_file_with_reason so we can surface the exact
            # failure cause (NOT_FOUND, ACCESS_DENIED, PURGED, …) instead
            # of a generic "file not found" message.
            org_id_str = str(agent_context.org_id) if agent_context.org_id else ""
            _max_file_bytes = 50 * 1024 * 1024  # 50 MB cap for SEI uploads
            load_result, reason = await self._load_file_with_reason(
                file_id=str(file_id),
                org_id=org_id_str,
                user_id=str(agent_context.user_id) if agent_context.user_id else None,
                dept_id=str(agent_context.dept_id) if agent_context.dept_id else None,
                max_bytes=_max_file_bytes,
            )
            if load_result is None:
                reason_msg = {
                    "NOT_FOUND": (
                        f"File '{file_id}' does not exist in the database. "
                        "The UUID may be incorrect."
                    ),
                    "PURGED": (
                        f"File '{file_id}' has been purged and is no longer "
                        "available."
                    ),
                    "ACCESS_DENIED": (
                        f"Access denied to file '{file_id}'. The file may "
                        "belong to a different user or department, or the "
                        "org_id may not match."
                    ),
                    "LOAD_FAILED": (
                        f"File '{file_id}' exists but could not be read from "
                        "storage (MinIO error)."
                    ),
                }.get(reason or "", f"File '{file_id}' not found or access denied (reason: {reason}).")
                raise HelperError(
                    f"{reason_msg} Call list_recent_artifacts("
                    f"scope='session', category='all') to verify available "
                    f"files and their current UUIDs."
                )
            file_bytes: bytes = load_result.get("data") or b""
            file_name: str = load_result.get("filename") or "documento.pdf"
            file_mime: str = load_result.get("content_type") or "application/octet-stream"

            return await _helpers.enviar_documento_externo(
                client=client,
                base_url=base_url,
                orgao_id=orgao_id,
                org_id=org_id,
                session=session,
                unidade_override=unidade_override,
                procedimento=str(procedimento),
                serie_nome=params.get("serie_nome"),
                id_serie=params.get("idSerie"),
                file_name=file_name,
                file_content=file_bytes,
                file_mime=file_mime,
                data_elaboracao=params.get("dataElaboracao"),
                nivel_acesso=int(params.get("nivelAcesso", 0) or 0),
                numero=params.get("numero"),
                observacao=params.get("observacao", "") or "",
                assuntos=params.get("assuntos"),
                interessados=params.get("interessados"),
                id_hipotese_legal=params.get("idHipoteseLegal"),
                id_unidade_geradora=params.get("idUnidadeGeradoraProtocolo")
                or default_unit,
                descricao=params.get("descricao"),
                nome_arvore=params.get("nome_arvore"),
                remetente=params.get("remetente"),
            )

        if operation == "documento.secao_alterar":
            # Route the low-level operation through the high-level helper
            # so sections are auto-listed, version is auto-resolved, and
            # the full payload (all sections) is sent to SEI.
            documento = params.get("documento")
            if not documento:
                raise HelperError(
                    "'documento' (internal document ID) is required for "
                    "documento.secao_alterar."
                )
            raw_secoes = params.get("secoes")
            secoes_arg: Optional[list[dict]] = None
            if raw_secoes:
                if isinstance(raw_secoes, list):
                    secoes_arg = raw_secoes
                elif isinstance(raw_secoes, str):
                    try:
                        parsed = _json.loads(raw_secoes)
                    except _json.JSONDecodeError as exc:
                        raise HelperError(
                            f"'secoes' is not valid JSON: {exc}"
                        ) from exc
                    if not isinstance(parsed, list):
                        raise HelperError(
                            "'secoes' must decode to a JSON array of section objects."
                        )
                    secoes_arg = parsed
                else:
                    raise HelperError(
                        "'secoes' must be a list of section objects or a JSON-encoded string."
                    )
            return await _helpers.atualizar_documento_conteudo(
                client=client,
                unidade_override=unidade_override,
                documento=str(documento),
                conteudo_html=params.get("conteudo_html"),
                secoes=secoes_arg,
            )

        raise HelperError(f"Unknown helper operation: {operation}")
