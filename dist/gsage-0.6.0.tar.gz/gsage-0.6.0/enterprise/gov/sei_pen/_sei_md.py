"""SEI-PEN Markdown → HTML converter with SEI CSS class mapping.

Converts Markdown to SEI-compatible HTML, mapping standard Markdown elements
to the CSS classes used by SEI's document editor (``<p class="...">`` elements).

The SEI document model uses exclusively ``<p>`` tags for block content — all
styling (headings, lists, indentation, numbering) is driven by CSS classes.
This module maps Markdown semantics to the standard SEI CSS class set.

Usage::

    from src.mcp_server.tools.enterprise.gov.sei_pen._sei_md import md_to_sei_html

    html = md_to_sei_html(markdown_text)

Classes mapped (standard SEI document CSS):

| Markdown                     | SEI CSS class                       |
|------------------------------|-------------------------------------|
| ``# Heading``                | ``Secao`` (bold, centered)          |
| ``## Heading``               | ``Texto_Justificado_Maiusculas``    |
| ``### Heading``              | ``Texto_Justificado`` (configurable via ``SEI_PARAGRAPH_CLASS``) |
| Regular paragraph            | ``Texto_Justificado`` (configurable) |
| ``> blockquote``             | ``Citacao``                         |
| ``1. ordered list``          | ``Paragrafo_Numerado_Nivel1``       |
| ``- unordered list``         | ``Marcador_Alinhado``               |
| ``**bold**``                 | ``<strong>``                        |
| ``*italic*``                 | ``<em>``                            |
| Table                        | ``<td>`` cells (no ``<th>``) with ``<p>`` wrappers, |
|                              | header ``background-color: #ddd``, ``border``, ``cellpadding`` |
| ``---`` (hr)                 | ``Espaco_linha``                    |

To use the SEI rich-text editor's paragraph class instead of the default::

    from src.mcp_server.tools.enterprise.gov.sei_pen import _sei_md
    _sei_md.SEI_PARAGRAPH_CLASS = "Texto_Alinhado_Esquerda_Espacamento_Simples"

All output is sanitised for ISO-8859-1 (Latin-1) storage — characters
outside the Latin-1 repertoire are replaced with safe ASCII equivalents.  """

from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Optional

import markdown
from markdown.extensions import Extension
from markdown.treeprocessors import Treeprocessor

# ── SEI CSS class mapping ───────────────────────────────────────────────────

# Paragraph class used for regular paragraphs and table cell content.
# SEI installations may use different class sets depending on the document
# template.  Known values:
#   - "Texto_Justificado" (older / generic templates)
#   - "Texto_Alinhado_Esquerda_Espacamento_Simples" (newer templates, seen in
#     documents produced by the SEI rich-text editor)
# Change this constant if your SEI templates use a different paragraph class.
SEI_PARAGRAPH_CLASS: str = "Texto_Justificado"

_HEADING_CLASS: dict[int, str] = {
    1: "Secao",
    2: "Texto_Justificado_Maiusculas",
    3: SEI_PARAGRAPH_CLASS,
}

_TAG_CLASS: dict[str, str] = {
    "h1": "Secao",
    "h2": "Texto_Justificado_Maiusculas",
    "h3": SEI_PARAGRAPH_CLASS,
    "p": SEI_PARAGRAPH_CLASS,
}

# Table attributes matching the SEI rich-text editor output.
# The SEI editor uses <td> (never <th>), wraps cell content in <p> elements,
# and applies a grey background to header cells.
_TABLE_ATTRS: dict[str, str] = {
    "border": "1",
    "cellpadding": "4",
    "style": (
        "border-collapse:collapse; border-color:#646464;"
        "margin-left:auto; margin-right:auto; width:100%;"
    ),
}

_HEADER_CELL_STYLE: str = "background-color: rgb(221, 221, 221);"


# ── Module-level helpers ────────────────────────────────────────────────────

def _append_text(target: ET.Element, text: str) -> None:
    """Append *text* to *target*, merging with existing tail if present."""
    if not text:
        return
    children = list(target)
    if children:
        last = children[-1]
        last.tail = (last.tail or "") + text
    else:
        target.text = (target.text or "") + text


# ── Treeprocessor ───────────────────────────────────────────────────────────

class _SEITreeprocessor(Treeprocessor):
    """Transform the markdown ElementTree into SEI-classed <p> elements."""

    def run(self, root: ET.Element) -> None:
        self._transform_children(root)

    # ── Tree walk ───────────────────────────────────────────────────────

    def _transform_children(self, parent: ET.Element) -> None:
        children = list(parent)
        for child in children:
            self._transform_element(child, parent)

    def _transform_element(self, elem: ET.Element, parent: ET.Element) -> None:
        tag = elem.tag

        if tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            level = int(tag[1])
            cls = _HEADING_CLASS.get(level, "Texto_Justificado")
            self._replace_with_p(elem, parent, cls, bold=(level <= 2))
            return

        if tag == "blockquote":
            self._flatten_blockquote(elem, parent)
            return

        if tag == "ol":
            self._transform_list(elem, parent, ordered=True)
            return

        if tag == "ul":
            self._transform_list(elem, parent, ordered=False)
            return

        if tag == "li":
            return  # handled by parent ol/ul

        if tag == "hr":
            self._replace_with_p(elem, parent, "Espaco_linha", text="&nbsp;")
            return

        if tag == "table":
            self._transform_table(elem)
            return

        if tag in ("pre", "code"):
            return  # pass-through

        if tag == "p":
            cls = _TAG_CLASS.get("p", "Texto_Justificado")
            elem.set("class", cls)
            self._transform_children(elem)
            return

        self._transform_children(elem)

    # ── Element transformations ─────────────────────────────────────────

    def _replace_with_p(
        self,
        elem: ET.Element,
        parent: ET.Element,
        cls: str,
        bold: bool = False,
        text: Optional[str] = None,
    ) -> None:
        """Replace *elem* with a <p class="cls"> element."""
        p = ET.Element("p")
        p.set("class", cls)

        if text is not None:
            p.text = text
        elif bold:
            strong = ET.SubElement(p, "strong")
            strong.text = elem.text
            strong.tail = elem.tail
            for child in list(elem):
                strong.append(child)
        else:
            p.text = elem.text
            p.tail = elem.tail
            for child in list(elem):
                p.append(child)

        idx = list(parent).index(elem)
        parent.remove(elem)
        parent.insert(idx, p)
        self._transform_children(p)

    def _flatten_blockquote(self, elem: ET.Element, parent: ET.Element) -> None:
        """Flatten <blockquote> into <p class="Citacao"> (no nested <p>)."""
        p = ET.Element("p")
        p.set("class", "Citacao")
        self._collect_inline(elem, p)
        idx = list(parent).index(elem)
        parent.remove(elem)
        parent.insert(idx, p)

    def _collect_inline(self, elem: ET.Element, target_p: ET.Element) -> None:
        """Recursively collect inline content into *target_p*.

        Strips block-level wrappers (<p>, <div>) and preserves inline
        formatting elements (<strong>, <em>, <a>, <code>, <br>).
        """
        if elem.tag in ("p", "div", "blockquote"):
            if elem.text:
                _append_text(target_p, elem.text)
            for child in list(elem):
                self._collect_inline(child, target_p)
            return

        if elem.tag in ("strong", "em", "a", "code", "br", "span", "sub", "sup"):
            new_elem = ET.SubElement(target_p, elem.tag)
            new_elem.text = elem.text
            new_elem.tail = elem.tail
            for key, val in elem.attrib.items():
                new_elem.set(key, val)
            for child in list(elem):
                new_elem.append(child)
            return

        if elem.text:
            _append_text(target_p, elem.text)
        for child in list(elem):
            self._collect_inline(child, target_p)

    def _transform_list(
        self, elem: ET.Element, parent: ET.Element, ordered: bool
    ) -> None:
        """Transform <ol>/<ul> — keep list structure, apply SEI CSS classes.

        Preserves the <ol>/<ul> wrapper so the SEI editor renders proper
        numbered lists, while applying Paragrafo_Numerado_Nivel1 / Marcador_Alinhado
        to each <li> element.
        """
        cls = "Paragrafo_Numerado_Nivel1" if ordered else "Marcador_Alinhado"

        for li in list(elem):
            if li.tag != "li":
                continue
            # Wrap the <li> text content in a <p> with the SEI class
            inner_p = ET.Element("p")
            inner_p.set("class", cls)
            inner_p.text = (li.text or "").strip()
            # Move children from <li> into the inner <p>
            for child in list(li):
                inner_p.append(child)
            if list(li):
                list(li)[-1].tail = (list(li)[-1].tail or "").strip()
            # Clear <li> and insert the wrapped <p>
            li.text = None
            li[:] = [inner_p]
            self._transform_children(inner_p)

    def _transform_table(self, table: ET.Element) -> None:
        """Transform a Markdown <table> into SEI-editor-compatible HTML.

        The SEI rich-text editor uses a specific table format:

        * ``<td>`` for **all** cells (never ``<th>``).
        * Header cells get ``role="columnheader"`` (or ``"rowheader"``),
          ``style="background-color: rgb(221, 221, 221);"``, and bold text.
        * Cell text content is wrapped in ``<p class="…">`` elements.
        * The ``<table>`` element carries ``border``, ``cellpadding``, and
          inline ``style`` attributes matching the editor output.
        """
        # ── Table-level attributes ───────────────────────────────────────
        for attr, val in _TABLE_ATTRS.items():
            table.set(attr, val)

        # ── Convert <th> → <td> with header styling ─────────────────────
        for thead in table.iter("thead"):
            for tr in thead.iter("tr"):
                for th in list(tr.iter("th")):
                    td = self._th_to_td(th, role="columnheader")
                    # Insert before the old <th>, then remove <th>
                    tr.insert(list(tr).index(th), td)
                    tr.remove(th)

        for tbody in table.iter("tbody"):
            for tr in tbody.iter("tr"):
                for th in list(tr.iter("th")):
                    td = self._th_to_td(th, role="rowheader")
                    tr.insert(list(tr).index(th), td)
                    tr.remove(th)

        # ── Wrap bare text in <td> with <p> elements ────────────────────
        for td in table.iter("td"):
            self._wrap_td_content(td)

        # ── Apply cell class to every <td> ──────────────────────────────
        for td in table.iter("td"):
            if not td.get("class"):
                td.set("class", "Tabela_Texto_Centralizado")

    @staticmethod
    def _th_to_td(th: ET.Element, role: str) -> ET.Element:
        """Convert a ``<th>`` element to a ``<td>`` with SEI header styling."""
        td = ET.Element("td")
        td.set("role", role)
        existing_style = th.get("style", "")
        td.set("style", f"{_HEADER_CELL_STYLE} {existing_style}".strip())
        # Copy text and children
        td.text = th.text
        td.tail = th.tail
        for child in list(th):
            td.append(child)
        # Wrap header text in <strong> if not already present
        if not _has_tag(td, "strong"):
            _wrap_content_in_tag(td, "strong")
        return td

    def _wrap_td_content(self, td: ET.Element) -> None:
        """Wrap bare text content of a ``<td>`` in ``<p class="…">`` elements.

        If the cell already contains ``<p>`` elements they are kept as-is
        (only their class is normalised).  Bare text nodes and inline
        elements (``<strong>``, ``<em>``, ``<br>``) are collected into a
        new ``<p>``.
        """
        # Check if the cell already has block-level wrappers.
        has_block = any(
            child.tag in ("p", "div") for child in td if isinstance(child, ET.Element)  # type: ignore[union-attr]
        )
        if has_block:
            # Normalise class on existing <p> elements.
            for p in td.iter("p"):
                if not p.get("class"):
                    p.set("class", SEI_PARAGRAPH_CLASS)
            return

        # Collect inline content into a single <p>.
        p = ET.Element("p")
        p.set("class", SEI_PARAGRAPH_CLASS)
        p.text = td.text
        td.text = None
        # IMPORTANT: ElementTree's append() does NOT auto-remove the element
        # from its previous parent (unlike the DOM API).  We must explicitly
        # remove children from <td> after moving them to <p>, otherwise they
        # appear in both places and produce duplicated content.
        children_to_move = list(td)
        for child in children_to_move:
            p.append(child)
            # Move tail text into the paragraph as well
            if child.tail:
                if not p.text and len(p) == 0:
                    p.text = child.tail
                else:
                    last_child = list(p)[-1] if list(p) else p
                    last_child.tail = (last_child.tail or "") + child.tail
                child.tail = None
        # Remove the now-duplicated children from <td>.
        for child in children_to_move:
            td.remove(child)
        td.insert(0, p)


# ── Inline helpers (module-level — used by _SEITreeprocessor and _th_to_td) ──

def _has_tag(parent: ET.Element, tag: str) -> bool:
    """Return True if *parent* contains a descendant with *tag*."""
    return any(child.tag == tag for child in parent.iter())


def _wrap_content_in_tag(parent: ET.Element, tag: str) -> None:
    """Wrap the text content of *parent* in a new ``<tag>`` element.

    Only applied when *parent* has direct text content (``parent.text``)
    and no existing ``<tag>`` child.  Existing children are moved into
    the new wrapper.

    Note: ElementTree's ``append()`` does NOT auto-remove from the old
    parent (unlike the DOM API), so children must be explicitly removed
    from *parent* after being appended to *wrapper*.
    """
    if _has_tag(parent, tag):
        return
    wrapper = ET.Element(tag)
    wrapper.text = parent.text
    parent.text = None
    children_to_move = list(parent)
    for child in children_to_move:
        wrapper.append(child)
    for child in children_to_move:
        parent.remove(child)
    parent.append(wrapper)


# ── Extension ───────────────────────────────────────────────────────────────

class _SEIExtension(Extension):
    """Markdown extension that applies SEI CSS class mapping."""

    def extendMarkdown(self, md):
        md.treeprocessors.register(_SEITreeprocessor(md), "sei_classes", 20)


# ── Public API ──────────────────────────────────────────────────────────────

def md_to_sei_html(md_text: str) -> str:
    """Convert Markdown text to SEI-compatible HTML.

    Returns HTML body content suitable for SEI document sections
    (``<p class="...">`` elements only — no ``<html>``, ``<head>``,
    or ``<body>`` wrappers).

    YAML frontmatter (``---`` delimited block at the start) is silently
    stripped — the ``markdown`` library does not support it natively and
    would produce broken HTML.

    The output is sanitised for SEI's ISO-8859-1 storage: characters
    outside the Latin-1 repertoire (e.g. em dash ``—`` U+2014, euro sign
    ``€`` U+20AC) are replaced with safe ASCII equivalents so the PHP
    ``mb_convert_encoding(…, 'ISO-8859-1')`` step does not corrupt or
    truncate the content.
    """
    # Strip YAML frontmatter if present (common in LLM-generated documents).
    stripped = _strip_frontmatter(md_text)
    html = markdown.markdown(
        stripped,
        extensions=["tables", "fenced_code", "toc", _SEIExtension()],
        output_format="html",
    )
    return _sanitize_for_iso8859_1(html)


# ── ISO-8859-1 sanitisation ────────────────────────────────────────────────

# Characters not representable in ISO-8859-1 that commonly appear in
# Portuguese-language markdown (LLM-generated or human-written).
# Replaced with safe ASCII equivalents so the SEI's PHP
# ``mb_convert_encoding(…, 'ISO-8859-1')`` does not truncate the content.
_ISO8859_1_REPLACEMENTS: dict[str, str] = {
    "\u2014": "--",    # em dash —
    "\u2013": "-",     # en dash –
    "\u2018": "'",     # left single quotation mark '
    "\u2019": "'",     # right single quotation mark '
    "\u201c": '"',     # left double quotation mark "
    "\u201d": '"',     # right double quotation mark "
    "\u2026": "...",   # horizontal ellipsis …
    "\u20ac": "EUR ",  # euro sign €
    "\u2122": "(TM)",  # trade mark sign ™
    "\u0160": "S",     # Latin capital letter S with caron Š
    "\u0161": "s",     # Latin small letter s with caron š
    "\u017d": "Z",     # Latin capital letter Z with caron Ž
    "\u017e": "z",     # Latin small letter z with caron ž
    "\u0152": "OE",    # Latin capital ligature OE Œ
    "\u0153": "oe",    # Latin small ligature oe œ
    "\u0178": "Y",     # Latin capital letter Y with diaeresis Ÿ
}


def _sanitize_for_iso8859_1(text: str) -> str:
    """Replace characters outside the ISO-8859-1 repertoire with safe ASCII.

    SEI stores document content as ISO-8859-1 (Latin-1).  Although the
    JSON payload is protected during HTTP transport by ``ensure_ascii=True``
    (every non-ASCII byte is ``\\uXXXX``-escaped), PHP's ``json_decode``
    restores the original Unicode characters and then
    ``mb_convert_encoding(…, 'ISO-8859-1')`` is applied for storage.
    Characters that cannot be mapped to Latin-1 (em dash, euro sign,
    smart quotes, etc.) are either replaced with ``?`` or — when
    ``mbstring.substitute_character`` is unset — cause the **entire
    string** to be dropped, resulting in an empty section.

    This function performs the replacement **before** the content reaches
    SEI, so the stored HTML only contains ISO-8859-1-safe characters.
    """
    # Fast path: text is already pure ASCII
    if text.isascii():
        return text

    # Apply known replacements
    for char, replacement in _ISO8859_1_REPLACEMENTS.items():
        if char in text:
            text = text.replace(char, replacement)

    # Fallback: strip any remaining non-ISO-8859-1 characters.
    # We iterate character by character; this is O(n) but n is typically
    # < 50 KB, so the overhead is negligible.
    result: list[str] = []
    for ch in text:
        try:
            ch.encode("iso-8859-1")
            result.append(ch)
        except UnicodeEncodeError:
            result.append("?")
    return "".join(result)


def sanitize_for_sei(html_text: str) -> str:
    """Public entry point: sanitise HTML content for SEI ISO-8859-1 storage.

    Use this when raw HTML (not converted from Markdown) needs to be sent
    to SEI, e.g. via ``conteudo_html`` in ``atualizar_conteudo`` or
    ``secao_alterar``.

    ``md_to_sei_html()`` already calls this internally, so Markdown users
    are covered automatically.
    """
    return _sanitize_for_iso8859_1(html_text)


def _strip_frontmatter(text: str) -> str:
    """Remove YAML frontmatter (``---`` delimited block) from *text*.

    Returns *text* unchanged if no frontmatter is found.
    """
    if not text.startswith("---"):
        return text
    # Find the closing --- (must be at start of line, after the first line).
    lines = text.splitlines()
    if len(lines) < 2:
        return text
    # lines[0] is the opening ---
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            # Return everything after the closing ---
            remaining = lines[i + 1:]
            return "\n".join(remaining).lstrip("\n")
    # No closing --- found — return as-is (don't eat the whole document).
    return text
