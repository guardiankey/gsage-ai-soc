"""gSage AI — SIORG API client.

Async HTTP client for the public SIORG (Sistema de Organização e Inovação
Institucional) API.  No authentication required.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional
from urllib.parse import urlparse

import httpx

log = logging.getLogger(__name__)

BASE_URL = "https://estruturaorganizacional.dados.gov.br/doc"
DEFAULT_TIMEOUT = 30.0
MAX_RETRIES = 3
RETRY_DELAY = 5.0  # seconds to wait when rate-limited

# Error codes returned inside servico.codigoErro (HTTP 200 body)
_ERR_NOT_FOUND = 102
_ERR_INVALID_VERSION = 103
_ERR_NOT_ORGAO_ENTIDADE = 104


class SiorgError(Exception):
    """Raised when the SIORG API returns ``servico.codigoErro != 0``."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


def parse_id(uri: object) -> Optional[int]:
    """Extract the numeric id from a SIORG URI.

    ``"https://.../id/unidade-organizacional/26"`` → ``26``.
    Returns ``None`` if the URI cannot be parsed.
    """
    if not isinstance(uri, str) or not uri.strip():
        return None
    try:
        path = urlparse(uri).path
        parts = path.rstrip("/").rsplit("/", 1)
        return int(parts[-1])
    except (ValueError, IndexError):
        return None


def parse_label(uri: object) -> Optional[str]:
    """Extract the human-readable label from a SIORG URI.

    ``"https://.../id/tipo-unidade/orgao"`` → ``"orgao"``.
    ``"https://.../id/natureza-juridica/administracao-direta"`` → ``"administracao-direta"``.
    Returns ``None`` if the URI cannot be parsed.
    """
    if not isinstance(uri, str) or not uri.strip():
        return None
    try:
        path = urlparse(uri).path
        return path.rstrip("/").rsplit("/", 1)[-1]
    except (ValueError, IndexError):
        return None


class SiorgClient:
    """Async HTTP client for the public SIORG API."""

    def __init__(self, timeout: float = DEFAULT_TIMEOUT) -> None:
        self._timeout = timeout

    # ── Low-level GET ────────────────────────────────────────────────────

    async def _get(self, path: str, **params: str) -> dict:
        """Perform a GET request with retry on rate-limit errors."""
        url = f"{BASE_URL}{path}"
        last_exc: Optional[Exception] = None

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                async with httpx.AsyncClient(
                    timeout=self._timeout, follow_redirects=True,
                ) as client:
                    resp = await client.get(url, params=params)
                    resp.raise_for_status()
                    data: dict = resp.json()

                servico = data.get("servico", {})
                code = servico.get("codigoErro", 0)
                msg = servico.get("mensagem", "")

                # Rate-limit: wait and retry
                if code != 0 and ("aguarde" in msg.lower() or "andamento" in msg.lower()):
                    if attempt < MAX_RETRIES:
                        log.warning("SIORG rate-limited, retrying in %.1fs (attempt %d/%d)", RETRY_DELAY, attempt, MAX_RETRIES)
                        await asyncio.sleep(RETRY_DELAY)
                        continue
                    raise SiorgError(code, msg)

                if code != 0:
                    raise SiorgError(code, msg)

                return data

            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                last_exc = exc
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(RETRY_DELAY)
                    continue
                raise SiorgError(500, str(exc)) from exc

        raise SiorgError(500, str(last_exc)) from last_exc

    # ── Public endpoints ─────────────────────────────────────────────────

    async def get_orgaos_resumido(self) -> list[dict]:
        """A3: ``GET /orgao-entidade/resumida`` — all orgs/entities."""
        data = await self._get(
            "/orgao-entidade/resumida",
            codigoPoder="1",
            codigoEsfera="1",
        )
        return data.get("unidades", [])

    async def get_unidade_resumida(self, codigo: int) -> dict:
        """A5: ``GET /unidade-organizacional/{codigo}``."""
        data = await self._get(f"/unidade-organizacional/{codigo}")
        return data.get("unidade", {})

    async def get_estrutura(self, codigo: int) -> dict:
        """A9: ``GET /unidade-organizacional/{codigo}/estrutura``.

        Returns the nested tree::

            {"codigoUnidade": 26, "estrutura": [...]}
        """
        data = await self._get(f"/unidade-organizacional/{codigo}/estrutura")
        return data.get("estrutura", {})

    async def get_contato(self, codigo: int) -> dict:
        """A7: ``GET /unidade-organizacional/{codigo}/endereco-contato``.

        Returns the full response dict with ``endereco`` (list) and
        ``contato`` (list) keys — the caller extracts the first item.
        """
        return await self._get(
            f"/unidade-organizacional/{codigo}/endereco-contato"
        )

    async def get_cargos_totais(self, codigo: int) -> dict:
        """D3: ``GET /cargo-funcao/total-alocados-tipo``."""
        data = await self._get(
            "/cargo-funcao/total-alocados-tipo",
            codigoUnidade=str(codigo),
        )
        return data

    async def get_ocupantes(self, codigo: int) -> list[dict]:
        """D4: ``GET /instancias/consulta-unidade``.

        Returns a flat list of occupant dicts extracted from the nested
        ``unidade.cargos[].instancias[]`` structure.
        """
        data = await self._get(
            "/instancias/consulta-unidade",
            codigoUnidade=str(codigo),
        )
        unidade = data.get("unidade", {})
        cargos = unidade.get("cargos", [])
        ocupantes: list[dict] = []
        for cargo in cargos:
            denominacao = cargo.get("denominacao", "")
            funcao = cargo.get("funcao", "")
            for inst in cargo.get("instancias", []):
                # nomeTitular/cpfTitular are always null in SIORG
                # (personnel data lives in external systems)
                ocupantes.append({
                    "cargo": denominacao,
                    "funcao": funcao,
                    "codigo_instancia": inst.get("codigoInstancia"),
                    "nome_titular": inst.get("nomeTitular"),
                    "cpf_titular": inst.get("cpfTitular"),
                })
        return ocupantes
