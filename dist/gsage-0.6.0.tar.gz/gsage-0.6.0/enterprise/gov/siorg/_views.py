"""gSage AI — Slim views and Mermaid generator for SIORG.

Normalises raw SIORG API responses into compact, agent-friendly dicts and
produces Mermaid ``graph TD`` diagrams from organisational hierarchy trees.
"""

from __future__ import annotations

from typing import Optional

from src.mcp_server.tools.enterprise.gov.siorg._client import (
    parse_id,
    parse_label,
)

# ── Constants ────────────────────────────────────────────────────────────────
_MERMAID_MAX_NIVEIS = 4
_MERMAID_MAX_NOS = 100  # keep diagrams compact for agent context windows
_NAME_MAX_LEN = 30

# Well-known IBGE municipio codes for federal-government addresses.
# Most SIORG addresses are in Brasília or Rio de Janeiro.
_CIDADE_IBGE: dict[int, str] = {
    5300108: "Brasília",
    3304557: "Rio de Janeiro",
    3550308: "São Paulo",
    3106200: "Belo Horizonte",
    4106902: "Curitiba",
    4314902: "Porto Alegre",
    2611606: "Recife",
    2927408: "Salvador",
    2304400: "Fortaleza",
    1501402: "Belém",
    1302603: "Manaus",
}


# ── Slim views ───────────────────────────────────────────────────────────────


def slim_orgao(raw: dict) -> dict:
    """Slim a single org/entity from A3 or A5."""
    return {
        "codigo": parse_id(raw.get("codigoUnidade")),
        "sigla": raw.get("sigla") or "",
        "nome": raw.get("nome") or "",
        "tipo": parse_label(raw.get("codigoTipoUnidade")),
        "natureza_juridica": parse_label(raw.get("codigoNaturezaJuridica")),
        "codigo_pai": parse_id(raw.get("codigoUnidadePai")),
        "data_inicio": (raw.get("dataInicialVersaoConsulta") or ""),
        "competencia": (raw.get("competencia") or "")[:500] if raw.get("competencia") else None,
        "nivel_normatizacao": raw.get("nivelNormatizacao"),
    }


def slim_contato(raw: dict) -> dict:
    """Slim the contact/address response from A7.

    The API returns ``{"endereco": [...], "contato": [...]}`` — both lists.
    We extract the first item of each.
    """
    end_list = raw.get("endereco", [])
    con_list = raw.get("contato", [])
    end = end_list[0] if isinstance(end_list, list) and end_list else {}
    con = con_list[0] if isinstance(con_list, list) and con_list else {}

    telefones = con.get("telefone", [])
    emails = con.get("email", [])
    sites = con.get("site", [])

    # Extract IBGE municipio code from URI
    municipio_uri = end.get("municipio", "")
    municipio_codigo = parse_id(municipio_uri) if isinstance(municipio_uri, str) and municipio_uri else None
    cidade = _CIDADE_IBGE.get(municipio_codigo) if municipio_codigo else None

    return {
        "endereco": end.get("logradouro"),
        "numero": end.get("numero") if end.get("numero") != 0 else None,
        "complemento": end.get("complemento"),
        "bairro": end.get("bairro"),
        "cidade": cidade,
        "municipio_codigo_ibge": municipio_codigo,
        "uf": end.get("uf"),
        "cep": str(end.get("cep", "")) if end.get("cep") else None,
        "telefone": telefones[0] if telefones else None,
        "email": emails[0] if emails else None,
        "site": sites[0].get("site") if sites else None,
        "horario_funcionamento": end.get("horarioDeFuncionamento"),
    }


def slim_cargos(raw: dict) -> dict:
    """Slim the allocated-position totals from D3.

    The D3 response structure varies — try multiple possible keys.
    """
    total = 0
    por_tipo: dict[str, int] = {}
    # Try known key variants for the items list
    items = (
        raw.get("cargos")
        or raw.get("lista")
        or raw.get("resultado")
        or []
    )
    for item in items:
        tipo = parse_label(item.get("codigoTipoCargo")) or item.get("tipo") or item.get("denominacao") or "outros"
        qtd = int(item.get("quantidade") or item.get("total") or 0)
        por_tipo[tipo] = por_tipo.get(tipo, 0) + qtd
        total += qtd
    return {"total": total, "por_tipo": por_tipo}


def slim_ocupante(raw: dict) -> dict:
    """Slim an occupant record from D4.

    SIORG tracks organisational structure, not personnel data —
    ``nomeTitular`` and ``cpfTitular`` are always null and not exposed.
    """
    return {
        "cargo": raw.get("cargo"),
        "funcao": raw.get("funcao"),
        "codigo_instancia": raw.get("codigo_instancia"),
    }


def slim_estrutura_item(raw: dict) -> dict:
    """Slim a single structure node from A9."""
    return {
        "codigo": raw.get("codigoUnidade") if isinstance(raw.get("codigoUnidade"), int) else parse_id(raw.get("codigoUnidade")),
        "filhas": [slim_estrutura_item(c) for c in raw.get("estrutura", [])],
    }


# ── Org lookup (from A3 cache) ──────────────────────────────────────────────


def build_org_lookup(orgaos: list[dict]) -> dict[int, dict]:
    """Build ``{codigo: {sigla, nome}}`` from a list of slimmed orgs."""
    lookup: dict[int, dict] = {}
    for o in orgaos:
        cod = o.get("codigo")
        if cod is not None:
            lookup[cod] = {"sigla": o.get("sigla", ""), "nome": o.get("nome", "")}
    return lookup


# ── Mermaid generator ───────────────────────────────────────────────────────


def build_mermaid_tree(
    raiz: dict,
    arvore: dict,
    lookup: dict[int, dict],
    max_niveis: int = _MERMAID_MAX_NIVEIS,
    max_nos: int = _MERMAID_MAX_NOS,
) -> dict:
    """Build a Mermaid ``graph TD`` from a SIORG hierarchy tree.

    Parameters
    ----------
    raiz:
        Dict with ``codigo``, ``sigla``, ``nome`` for the root node.
    arvore:
        Nested tree from A9: ``{"codigoUnidade": N, "estrutura": [...]}``.
    lookup:
        ``{codigo: {sigla, nome}}`` built from A3 cache.
    max_niveis:
        Maximum depth to render (default 4).
    max_nos:
        Hard cap on total nodes rendered.

    Returns
    -------
    dict
        ``{"mermaid": str, "nodes_shown": int, "nodes_total": int,
        "truncated": bool}``.
    """
    lines: list[str] = ["graph TD"]
    node_count = 0
    nodes_total = 0  # counted even beyond limit

    def _safe_id(codigo: object) -> str:
        """Mermaid-safe node id."""
        return f"N{parse_id(codigo) or codigo}"

    def _label(codigo: object) -> str:
        info = lookup.get(parse_id(codigo) or 0, {})
        sigla = info.get("sigla", "")
        nome = info.get("nome", "")
        if sigla and nome:
            return f"{sigla}\\n{nome[:_NAME_MAX_LEN]}"
        if nome:
            return nome[:_NAME_MAX_LEN]
        if sigla:
            return sigla
        return f"Unid. {codigo}"

    def _walk(node: dict, depth: int) -> Optional[str]:
        nonlocal node_count, nodes_total
        nodes_total += 1

        if depth > max_niveis:
            return None

        cod = node.get("codigoUnidade")
        if isinstance(cod, int):
            cod_int = cod
        else:
            cod_int = parse_id(cod)

        if cod_int is None:
            return None

        nid = _safe_id(cod_int)
        label = _label(cod_int)
        filhos = node.get("estrutura", [])

        if node_count >= max_nos:
            return None

        if filhos:
            lines.append(f'    {nid}("{label}")')
            node_count += 1

            children_shown = 0
            for child in filhos:
                if node_count >= max_nos:
                    break
                child_id = _walk(child, depth + 1)
                if child_id:
                    lines.append(f"    {nid} --> {child_id}")
                    children_shown += 1

            # If there are more children not shown, add ellipsis
            remaining = len(filhos) - children_shown - sum(
                1 for c in filhos[children_shown:] if c.get("estrutura")
            )
            if children_shown < len(filhos) or node_count >= max_nos:
                ellipsis_id = f"{nid}_more"
                lines.append(f'    {ellipsis_id}["..."]')
                lines.append(f"    {nid} --> {ellipsis_id}")
        else:
            lines.append(f'    {nid}["{label}"]')
            node_count += 1
        return nid

    # Build root node
    root_id = _safe_id(raiz.get("codigo", "root"))
    root_label = _label(raiz.get("codigo", ""))
    lines.append(f'    {root_id}("{root_label}")')
    node_count += 1
    nodes_total += 1

    for child in arvore.get("estrutura", []):
        if node_count >= max_nos:
            break
        child_id = _walk(child, depth=1)
        if child_id:
            lines.append(f"    {root_id} --> {child_id}")

    truncated = node_count < nodes_total or node_count >= max_nos
    return {
        "mermaid": "\n".join(lines),
        "nodes_shown": node_count,
        "nodes_total": nodes_total,
        "truncated": truncated,
    }
