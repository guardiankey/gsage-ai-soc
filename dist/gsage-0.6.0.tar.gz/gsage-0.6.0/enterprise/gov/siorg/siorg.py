"""gSage AI — SIORG organisational structure tool.

Query the Brazilian federal government's official organisational structure
database (SIORG).  Provides org listing, hierarchy with Mermaid diagrams,
contact details, and position/occupant information.

Permission: ``gov:siorg:read``.
"""

from __future__ import annotations

import asyncio
import logging
import time
import unicodedata
from typing import ClassVar, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.mcp_server.tools.enterprise.gov.siorg._client import (
    SiorgClient,
    SiorgError,
)
from src.mcp_server.tools.enterprise.gov.siorg._views import (
    build_mermaid_tree,
    build_org_lookup,
    slim_cargos,
    slim_contato,
    slim_ocupante,
    slim_orgao,
    slim_estrutura_item,
)
from src.mcp_server.tools.result_export import (
    AGENT_PREVIEW_ROWS,
    build_agent_payload,
)
from src.shared.cache.decorator import cached
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────
_CACHE_TTL_ESTRUTURA = 6 * 3600     # 6 hours
_CACHE_TTL_CARGOS = 1 * 3600         # 1 hour
_DEFAULT_MAX_RESULTS = 50

_ACTIONS = frozenset({
    "list_orgaos",
    "search_orgaos",
    "get_orgao",
    "get_estrutura",
    "get_ocupantes",
    "get_contato",
})


# ── Cached helpers ───────────────────────────────────────────────────────────


@cached(
    ttl=_CACHE_TTL_ESTRUTURA,
    scope="global",
    key_fn=lambda *_args, **_kwargs: "siorg:orgaos:v1",
    logical_name="siorg",
)
async def _get_orgaos_cache(
    *, session: AsyncSession,  # noqa: ARG001
) -> list[dict]:
    """Fetch and cache the full org list (A3)."""
    client = SiorgClient()
    raw = await client.get_orgaos_resumido()
    return [slim_orgao(r) for r in raw]


# ── Tool ─────────────────────────────────────────────────────────────────────


class SiorgTool(BaseTool):
    """Query the Brazilian federal government organisational structure (SIORG).

    Actions
    -------
    - ``list_orgaos`` — list all federal executive orgs/entities.
    - ``search_orgaos`` — search orgs by name or code.
    - ``get_orgao`` — full dossier: identity + hierarchy + contact + positions.
    - ``get_estrutura`` — hierarchy tree with Mermaid diagram (4 levels).
    - ``get_ocupantes`` — positions and their occupants.
    - ``get_contato`` — address and contact details.

    Permission: ``gov:siorg:read``.
    """

    name: ClassVar[str] = "siorg"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Query the Brazilian federal government organisational structure "
        "(SIORG): org listing, hierarchy with Mermaid diagrams, contacts, "
        "positions and occupants."
    )
    description: ClassVar[str] = (
        "**get_orgao** returns a composite dossier:\n"
        "- `orgao`: identity (nome, sigla, tipo, natureza_juridica)\n"
        "- `contato`: address, phone, email, site, hours\n"
        "- `estrutura`: total_unidades + Mermaid diagram\n"
        "- `cargos_alocados`: allocated positions by type (D3 endpoint)\n"
        "\n"
        "Use `get_ocupantes` for actual named occupants (D4 endpoint)."
    )
    category: ClassVar[str] = "gov"
    permissions: ClassVar[list[str]] = ["gov:siorg:read"]
    rate_limit_per_minute: ClassVar[int] = 20
    timeout_seconds: ClassVar[int] = 120
    use_circuit_breaker: ClassVar[bool] = False
    requires_approval: ClassVar[bool] = False
    supports_multiple_configs: ClassVar[bool] = False
    requires_config: ClassVar[bool] = False

    params_schema: ClassVar[dict] = {
        "type": "object",
        "required": ["action"],
        "properties": {
            "action": {
                "type": "string",
                "enum": sorted(_ACTIONS),
                "description": "Which SIORG query to perform.",
            },
            "codigo_unidade": {
                "type": "integer",
                "description": (
                    "Numeric unit code (extracted from the SIORG URI). "
                    "Required for get_orgao, get_estrutura, get_ocupantes, "
                    "get_contato.  Example: 26 = Presidência da República."
                ),
            },
            "nome": {
                "type": "string",
                "description": (
                    "[search_orgaos] Search term — case-insensitive match "
                    "against org name and abbreviation."
                ),
            },
            "max_results": {
                "type": "integer",
                "minimum": 1,
                "maximum": 500,
                "description": (
                    f"Maximum results to return (default {_DEFAULT_MAX_RESULTS})."
                ),
            },
            "max_depth": {
                "type": "integer",
                "minimum": 1,
                "maximum": 10,
                "default": 3,
                "description": (
                    "[get_estrutura] Maximum depth levels to return. "
                    "Default 3. Reduce if the output is too large."
                ),
            },
            "resolve_depth": {
                "type": "integer",
                "minimum": 0,
                "maximum": 5,
                "default": 2,
                "description": (
                    "[get_estrutura] How many levels to resolve names for "
                    "via parallel API calls. 0 = fast (codes only). "
                    "Default 2 resolves immediate children. "
                    "Higher values are slower but give more names."
                ),
            },
            "force_refresh": {
                "type": "boolean",
                "description": "Bypass cache for this call.",
            },
            "export_csv": {
                "type": "boolean",
                "description": (
                    "Force CSV artifact even for small results. CSV is "
                    f"generated automatically over {AGENT_PREVIEW_ROWS} rows."
                ),
            },
            "export_json": {
                "type": "boolean",
                "description": "Persist full result as a JSON artifact.",
            },
            "tipo": {
                "type": "string",
                "description": (
                    "[list_orgaos] Filter by unit type. "
                    "Common values: 'orgao', 'entidade', 'autarquia', "
                    "'fundacao', 'empresa-publica', 'sociedade-economia-mista'. "
                    "Omit for all types."
                ),
            },
        },
        "additionalProperties": False,
    }

    config_schema: ClassVar[Optional[dict]] = None
    config_defaults: ClassVar[dict] = {}
    state_schema: ClassVar[Optional[dict]] = None
    state_defaults: ClassVar[dict] = {}
    reset_policy: ClassVar[str] = "never"

    # ── Execute ───────────────────────────────────────────────────────────

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        t0 = time.monotonic()
        action = (params.get("action") or "").strip()
        if action not in _ACTIONS:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "INVALID_PARAMS",
                f"action must be one of {sorted(_ACTIONS)}; got {action!r}.",
                execution_time_ms=elapsed,
            )

        try:
            data = await self._dispatch(action, params, agent_context)
        except SiorgError as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                f"SIORG_ERROR_{exc.code}", exc.message,
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            log.exception("siorg(%s): unexpected error", action)
            elapsed = int((time.monotonic() - t0) * 1000)
            msg = str(exc) or type(exc).__name__
            return self._failure(
                "INTERNAL_ERROR", msg, execution_time_ms=elapsed,
            )

        elapsed = int((time.monotonic() - t0) * 1000)
        return self._success(data={"action": action, **data}, execution_time_ms=elapsed)

    # ── Dispatch ──────────────────────────────────────────────────────────

    async def _dispatch(
        self, action: str, params: dict, ctx: AgentContext,
    ) -> dict:
        client = SiorgClient()

        if action == "list_orgaos":
            return await self._do_list_orgaos(ctx, params)
        elif action == "search_orgaos":
            return await self._do_search_orgaos(ctx, params)
        elif action == "get_orgao":
            return await self._do_get_orgao(client, params)
        elif action == "get_estrutura":
            return await self._do_get_estrutura(client, ctx, params)
        elif action == "get_ocupantes":
            return await self._do_get_ocupantes(client, params, ctx)
        elif action == "get_contato":
            return await self._do_get_contato(client, params)
        else:
            raise ValueError(f"Unknown action: {action}")

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _unaccent(text: str) -> str:
        """Remove accents/diacritics, keeping base characters only.

        ``"Presidência"`` → ``"Presidencia"``.
        """
        nfkd = unicodedata.normalize("NFKD", text)
        return "".join(c for c in nfkd if not unicodedata.combining(c))

    def _require_codigo(self, params: dict) -> int:
        cod = params.get("codigo_unidade")
        if cod is None:
            raise SiorgError(400, "'codigo_unidade' is required for this action.")
        return int(cod)

    def _max_results(self, params: dict) -> int:
        return min(int(params.get("max_results") or _DEFAULT_MAX_RESULTS), 500)

    async def _tabular(
        self,
        ctx: AgentContext,
        action: str,
        rows: list[dict],
        params: dict,
    ) -> dict:
        """Build agent payload with auto-CSV for large result sets.

        Follows the same pattern as Trellix EDR and Proxmox tools: inline
        preview capped at ``AGENT_PREVIEW_ROWS`` rows, CSV artifact
        generated automatically when the full set exceeds the cap.
        """
        payload = await build_agent_payload(
            tool=self,
            rows=rows,
            export_csv=bool(params.get("export_csv", False)),
            export_json=bool(params.get("export_json", False)),
            filename_prefix=f"{self.name}_{action}",
            agent_context=ctx,
        )
        return {
            "rows_total": payload["rows_total"],
            "rows_overflow": payload["rows_overflow"],
            "rows_preview_limit": AGENT_PREVIEW_ROWS,
            "artifacts": payload["artifacts"],
            "agent_hint": payload["agent_hint"],
            "rows": payload["rows_preview"],
        }

    # ── Actions ───────────────────────────────────────────────────────────

    async def _do_list_orgaos(self, ctx: AgentContext, params: dict) -> dict:
        """A3: List all federal executive orgs (cached), optionally filtered by type."""
        from src.mcp_server.tools.base import _tool_session_ctx
        session = _tool_session_ctx.get()
        if session is None:
            raise RuntimeError("No DB session available")
        orgaos = await _get_orgaos_cache(session=session)

        # Filter by type if requested
        tipo_filter = (params.get("tipo") or "").strip().lower()
        if tipo_filter:
            orgaos = [o for o in orgaos if (o.get("tipo") or "").lower() == tipo_filter]

        return await self._tabular(ctx, "list_orgaos", orgaos, params)

    async def _do_search_orgaos(
        self, ctx: AgentContext, params: dict,
    ) -> dict:
        """Search orgs by name/code (client-side filter on cached A3)."""
        nome = (params.get("nome") or "").strip()
        if not nome:
            raise SiorgError(400, "'nome' is required for search_orgaos.")

        from src.mcp_server.tools.base import _tool_session_ctx
        session = _tool_session_ctx.get()
        if session is None:
            raise RuntimeError("No DB session available")
        all_orgs = await _get_orgaos_cache(session=session)
        max_results = self._max_results(params)

        term_lower = self._unaccent(nome.lower())
        results: list[dict] = []
        for o in all_orgs:
            nome_org = self._unaccent((o.get("nome") or "").lower())
            sigla_org = self._unaccent((o.get("sigla") or "").lower())
            if term_lower in nome_org or term_lower in sigla_org:
                results.append(o)
            # Also search by code if term is numeric
            elif term_lower.isdigit() and int(term_lower) == o.get("codigo"):
                results.append(o)

        return {
            "orgaos": results[:max_results],
            "total": len(results),
            "termo": nome,
        }

    async def _do_get_orgao(
        self, client: SiorgClient, params: dict,
    ) -> dict:
        """Full dossier: identity + structure + contact + positions."""
        codigo = self._require_codigo(params)
        from src.mcp_server.tools.base import _tool_session_ctx as base_ctx
        session = base_ctx.get()

        # Fetch all 4 endpoints in parallel with partial-failure tolerance
        results = await asyncio.gather(
            client.get_unidade_resumida(codigo),
            client.get_estrutura(codigo),
            client.get_contato(codigo),
            client.get_cargos_totais(codigo),
            return_exceptions=True,
        )
        a5_raw, a9_raw, a7_raw, d3_raw = results

        errors: list[str] = []

        # Process identity (A5)
        orgao: dict = {}
        if isinstance(a5_raw, Exception):
            errors.append(f"Identidade: {a5_raw}")
        elif isinstance(a5_raw, dict):
            orgao = slim_orgao(a5_raw)

        # Process contact (A7)
        contato: Optional[dict] = None
        if isinstance(a7_raw, Exception):
            errors.append(f"Contato: {a7_raw}")
        elif isinstance(a7_raw, dict):
            contato = slim_contato(a7_raw)

        # Process structure (A9) + Mermaid
        estrutura_info: dict = {"total_unidades": 0, "niveis": 0, "mermaid": None}
        if isinstance(a9_raw, Exception):
            errors.append(f"Estrutura: {a9_raw}")
        elif isinstance(a9_raw, dict):
            arvore = a9_raw
            # Count total units by flattening the nested tree
            def _count(n: dict) -> int:
                return 1 + sum(_count(c) for c in n.get("estrutura", []))
            if arvore.get("codigoUnidade") is not None:
                estrutura_info["total_unidades"] = _count(arvore) - 1  # exclude root

                # Build Mermaid — need org lookup for names
                if session is not None:
                    try:
                        cached_orgs = await _get_orgaos_cache(session=session)
                        lookup = build_org_lookup(cached_orgs)
                        mermaid_result = build_mermaid_tree(
                            orgao if orgao else {"codigo": codigo, "sigla": "", "nome": ""},
                            arvore,
                            lookup,
                        )
                        estrutura_info["mermaid"] = mermaid_result["mermaid"]
                        estrutura_info["nodes_shown"] = mermaid_result["nodes_shown"]
                        estrutura_info["nodes_total"] = mermaid_result["nodes_total"]
                        estrutura_info["truncated"] = mermaid_result["truncated"]
                    except Exception as exc:
                        errors.append(f"Mermaid: {exc}")

        # Process allocated positions (D3) — NOT occupants (D4)
        cargos_alocados: dict = {}
        if isinstance(d3_raw, Exception):
            errors.append(f"Cargos alocados: {d3_raw}")
        elif isinstance(d3_raw, dict):
            cargos_alocados = slim_cargos(d3_raw)

        return {
            "orgao": orgao,
            "contato": contato,
            "estrutura": estrutura_info,
            "cargos_alocados": cargos_alocados,
            "agent_hint": (
                "'cargos_alocados' counts allocated positions (D3 endpoint). "
                "Use get_ocupantes for actual named occupants (D4 endpoint). "
                "Counts may differ because some positions are vacant."
            ),
            "errors": errors or None,
        }

    async def _do_get_estrutura(
        self, client: SiorgClient, ctx: AgentContext, params: dict,
    ) -> dict:
        """A9: Hierarchy tree + Mermaid diagram.

        Resolves sub-unit names via parallel A5 calls up to
        *resolve_depth* levels (default 2).  Set ``resolve_depth=0``
        for fast mode (sub-units shown as codes only).
        """
        codigo = self._require_codigo(params)
        max_depth = int(params.get("max_depth") or 3)
        resolve_depth = int(params.get("resolve_depth") or 2)
        from src.mcp_server.tools.base import _tool_session_ctx
        session = _tool_session_ctx.get()
        if session is None:
            raise RuntimeError("No DB session available")

        raw = await client.get_estrutura(codigo)

        # Flatten tree — A9 only returns codigoUnidade (no sigla/nome in children)
        def _flatten(node: dict, depth: int = 0, parent: int = 0) -> list[dict]:
            cod = node.get("codigoUnidade")
            if isinstance(cod, int):
                cid = cod
            else:
                cid = node.get("codigoUnidade") or 0
            rows = [{"codigo": cid, "nivel": depth, "codigo_pai": parent}]
            if depth < max_depth:
                for child in node.get("estrutura", []):
                    rows.extend(_flatten(child, depth + 1, cid))
            return rows

        flat_rows = _flatten(raw) if raw else []

        # Names come from A3 cache (top-level orgs only).  Sub-units
        # need individual A5 calls — use get_orgao(codigo_unidade=N)
        # to resolve names for specific codes.
        # Start with A3 cache (top-level orgs)
        cached_orgs = await _get_orgaos_cache(session=session)
        lookup = build_org_lookup(cached_orgs)

        # ── Resolve missing names via parallel A5 calls ─────────────────
        resolved_count = 0
        if resolve_depth > 0:
            missing_codes: list[int] = []
            for row in flat_rows:
                if row["nivel"] <= resolve_depth and row["codigo"] not in lookup:
                    missing_codes.append(row["codigo"])
            missing_codes = list(dict.fromkeys(missing_codes))  # dedup

            if missing_codes:
                sem = asyncio.Semaphore(15)
                async def _resolve_one(code: int) -> tuple[int, dict]:
                    async with sem:
                        try:
                            unit = await client.get_unidade_resumida(code)
                            return code, {
                                "sigla": unit.get("sigla") or "",
                                "nome": unit.get("nome") or "",
                            }
                        except Exception:
                            return code, {"sigla": "", "nome": ""}

                results = await asyncio.gather(*[
                    _resolve_one(c) for c in missing_codes
                ])
                for code, info in results:
                    if info["sigla"] or info["nome"]:
                        lookup[code] = info
                        resolved_count += 1

        unit_info = lookup.get(codigo, {"sigla": "", "nome": f"Unidade {codigo}"})

        # Enrich rows with names from lookup
        for row in flat_rows:
            info = lookup.get(row["codigo"], {})
            row["sigla"] = info.get("sigla", "")
            row["nome"] = info.get("nome", "")

        mermaid_result = build_mermaid_tree(
            {"codigo": codigo, "sigla": unit_info["sigla"], "nome": unit_info["nome"]},
            raw if raw else {},
            lookup,
            max_niveis=max_depth,
        )

        # Use tabular helper for auto-CSV
        tabular = await self._tabular(ctx, "estrutura", flat_rows, params)

        return {
            "unidade": {
                "codigo": codigo,
                "sigla": unit_info["sigla"],
                "nome": unit_info["nome"],
            },
            "total_unidades": len(flat_rows),
            "niveis_maximos": max_depth,
            "mermaid": mermaid_result["mermaid"],
            "mermaid_nodes_shown": mermaid_result["nodes_shown"],
            "mermaid_nodes_total": mermaid_result["nodes_total"],
            "mermaid_truncated": mermaid_result["truncated"],
            "nomes_resolvidos_a5": resolved_count,
            "agent_hint": (
                f"Resolved {resolved_count} sub-unit names via A5 "
                f"(resolve_depth={resolve_depth}). "
                "Increase resolve_depth for more names (slower). "
                "Set resolve_depth=0 for fast mode (codes only). "
                "The CSV includes all rows; Mermaid capped at 100 nodes."
            ),
            **tabular,
        }

    async def _do_get_ocupantes(
        self, client: SiorgClient, params: dict, ctx: AgentContext,
    ) -> dict:
        """D4: Positions and occupants."""
        codigo = self._require_codigo(params)
        raw = await client.get_ocupantes(codigo)
        ocupantes = [slim_ocupante(r) for r in raw]

        # Aggregate by type
        por_tipo: dict[str, int] = {}
        for o in ocupantes:
            cargo = o.get("cargo", "outros")
            tipo = cargo.split()[0] if cargo else "outros"
            por_tipo[tipo] = por_tipo.get(tipo, 0) + 1

        tabular = await self._tabular(ctx, "ocupantes", ocupantes, params)
        return {
            "unidade": {"codigo": codigo},
            **tabular,
            "por_tipo": por_tipo,
            "agent_hint": (
                "SIORG tracks positions (cargo/funcao), not person names. "
                "Occupant identities live in external personnel systems "
                "(SIAPE, Sigepe). Use 'codigo_instancia' to cross-reference."
            ),
        }

    async def _do_get_contato(
        self, client: SiorgClient, params: dict,
    ) -> dict:
        """A7: Address and contact."""
        codigo = self._require_codigo(params)
        raw = await client.get_contato(codigo)
        return {
            "unidade": {"codigo": codigo},
            "contato": slim_contato(raw),
        }
