# Government-sector tool families (SEI-PEN, etc.).
# Auto-discovered by the MCP server registry at startup.
