"""gSage AI — Senado Federal + Normas.leg.br HTTP clients.

Async HTTP clients for the public Senado Federal Dados Abertos API and the
Normas.leg.br API.  No authentication required for either.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional
from urllib.parse import urlencode

import httpx

from src.mcp_server.tools.enterprise.gov.senado._constants import (
    BASE_URL_NORMAS,
    BASE_URL_SENADO,
    DEFAULT_TIMEOUT,
    DEFAULT_VERSION,
    MAX_RETRIES,
    RETRY_DELAY,
)

log = logging.getLogger(__name__)


# ── Errors ───────────────────────────────────────────────────────────────────


class SenadoError(Exception):
    """Raised when the Senado API returns an unexpected response."""

    def __init__(self, status: int, message: str) -> None:
        self.status = status
        self.message = message
        super().__init__(f"[{status}] {message}")


class NormasLegError(Exception):
    """Raised when the Normas.leg.br API returns an unexpected response."""

    def __init__(self, status: int, message: str) -> None:
        self.status = status
        self.message = message
        super().__init__(f"[{status}] {message}")


# ── Helpers ──────────────────────────────────────────────────────────────────


def _extract_urn(url: str) -> str:
    """Extract the URN from a normas.leg.br URL.

    ``"https://normas.leg.br/?urn=urn:lex:br:federal:lei:2021-04-01;14133"``
    → ``"urn:lex:br:federal:lei:2021-04-01;14133"``.
    """
    if "urn=" in url:
        return url.split("urn=", 1)[1].split("&")[0]
    return url


# ── SenadoClient ─────────────────────────────────────────────────────────────


class SenadoClient:
    """Async HTTP client for the Senado Federal Dados Abertos API.

    Public API — no authentication needed.
    Rate limit: max ~10 req/s. Use 2s delay between requests.
    """

    def __init__(self, timeout: float = DEFAULT_TIMEOUT) -> None:
        self._timeout = timeout

    async def _get_json(self, url: str) -> dict:
        """GET *url*, follow redirects, parse JSON with retry on 429."""
        last_exc: Optional[Exception] = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                async with httpx.AsyncClient(
                    timeout=self._timeout,
                    follow_redirects=True,
                ) as client:
                    resp = await client.get(url, headers={"Accept": "application/json"})
                    if resp.status_code == 429:
                        retry_after = RETRY_DELAY * attempt
                        log.warning(
                            "Senado API rate-limited (429). "
                            "Retrying in %.1fs (attempt %d/%d).",
                            retry_after, attempt, MAX_RETRIES,
                        )
                        await asyncio.sleep(retry_after)
                        continue
                    if resp.status_code >= 400:
                        raise SenadoError(
                            resp.status_code,
                            f"Senado API error: {resp.text[:500]}",
                        )
                    return resp.json()
            except httpx.TimeoutException as exc:
                last_exc = SenadoError(408, f"Timeout after {self._timeout}s: {exc}")
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(RETRY_DELAY * attempt)
            except httpx.HTTPStatusError as exc:
                raise SenadoError(exc.response.status_code, str(exc)) from exc
            except SenadoError:
                raise
        raise last_exc  # type: ignore[misc]

    # ── API methods ───────────────────────────────────────────────────────

    async def buscar(
        self,
        tipo: Optional[str] = None,
        numero: Optional[int] = None,
        ano: Optional[int] = None,
        data: Optional[str] = None,
    ) -> list[dict]:
        """Search legislation via ``GET /legislacao/lista``.

        Args:
            tipo: Sigla do tipo (e.g. ``"LEI"``, ``"DEC"``).
            numero: Número da norma.
            ano: Ano da norma.
            data: Data de assinatura no formato ``AAAAMMDD``.

        Returns:
            List of matching legislation items (raw API documents).
        """
        params: dict[str, str] = {"v": str(DEFAULT_VERSION)}
        if tipo:
            params["tipo"] = tipo
        if numero is not None:
            params["numero"] = str(numero)
        if ano is not None:
            params["ano"] = str(ano)
        if data:
            params["data"] = data

        qs = urlencode(params)
        url = f"{BASE_URL_SENADO}/legislacao/lista.json?{qs}"
        result = await self._get_json(url)

        docs = result.get("ListaDocumento", {})
        documentos = docs.get("documentos", {})
        return documentos.get("documento", [])

    async def buscar_por_termo(
        self,
        termo: str,
        tipo_termo: Optional[int] = None,
    ) -> dict:
        """Search legislation catalog terms via ``GET /legislacao/termos``.

        Args:
            termo: Keyword or phrase to search.
            tipo_termo: Optional term type code (e.g. 9 = assunto).

        Returns:
            Raw API response dict. The response shape may differ from
            ``/legislacao/lista``; callers should handle via slim views.
        """
        params: dict[str, str] = {
            "termo": termo,
            "v": str(DEFAULT_VERSION),
        }
        if tipo_termo is not None:
            params["tipo"] = str(tipo_termo)

        qs = urlencode(params)
        url = f"{BASE_URL_SENADO}/legislacao/termos.json?{qs}"
        result = await self._get_json(url)
        return result  # The response shape may differ; return raw for views to handle.

    async def detalhes(self, codigo: int) -> dict:
        """Get legislation details via ``GET /legislacao/{codigo}``.

        Args:
            codigo: Internal legislation code from ``buscar`` results.

        Returns:
            Raw API response containing the ``DetalheDocumento`` wrapper.
        """
        url = f"{BASE_URL_SENADO}/legislacao/{codigo}.json?v={DEFAULT_VERSION}"
        return await self._get_json(url)

    async def tipos_norma(self) -> dict:
        """List all normative types via ``GET /legislacao/tiposNorma``.

        Returns:
            Raw API response dict (or list, depending on redirect target).
        """
        url = f"{BASE_URL_SENADO}/legislacao/tiposNorma.json"
        return await self._get_json(url)


# ── NormasLegClient ──────────────────────────────────────────────────────────


class NormasLegClient:
    """Async HTTP client for the Normas.leg.br public API.

    Used to download the full consolidated text of legislation.
    Public API — no authentication needed.
    """

    def __init__(self, timeout: float = DEFAULT_TIMEOUT) -> None:
        self._timeout = timeout

    async def _get_json(self, url: str) -> dict:
        """GET *url*, parse JSON."""
        async with httpx.AsyncClient(
            timeout=self._timeout,
            follow_redirects=True,
        ) as client:
            resp = await client.get(url, headers={"Accept": "application/json"})
            if resp.status_code == 429:
                raise NormasLegError(429, "Normas.leg.br rate-limited (429). Retry later.")
            if resp.status_code >= 400:
                raise NormasLegError(
                    resp.status_code,
                    f"Normas.leg.br error: {resp.text[:500]}",
                )
            return resp.json()

    async def _get_text(self, url: str) -> str:
        """GET *url*, return raw text (HTML)."""
        async with httpx.AsyncClient(
            timeout=self._timeout,
            follow_redirects=True,
        ) as client:
            resp = await client.get(url)
            if resp.status_code == 429:
                raise NormasLegError(429, "Normas.leg.br rate-limited (429). Retry later.")
            if resp.status_code >= 400:
                raise NormasLegError(
                    resp.status_code,
                    f"Normas.leg.br error: {resp.text[:500]}",
                )
            return resp.text

    # ── API methods ───────────────────────────────────────────────────────

    async def get_documento_maior_detalhe(self, urn: str) -> dict:
        """Get the full document metadata from normas.leg.br.

        Calls ``GET /normas?urn={urn}&&tipo_documento=maior-detalhe``.

        Args:
            urn: LexML URN (e.g. ``"urn:lex:br:federal:lei:2021-04-01;14133"``).

        Returns:
            Full JSON-LD response with ``encoding[]`` containing text URLs.
        """
        qs = urlencode({"urn": urn, "tipo_documento": "maior-detalhe"})
        url = f"{BASE_URL_NORMAS}/normas?{qs}"
        return await self._get_json(url)

    def find_texto_compilado_url(self, doc: dict) -> Optional[str]:
        """Find the compiled text URL in a normas.leg.br document response.

        Looks for ``encoding[]`` entry with
        ``additionalType == "CompilacaoMonoVigenteNaCD"``.

        Returns the corrected URL (with ``/public/`` inserted), or ``None``
        if no compiled text is available.
        """
        for enc in doc.get("encoding", []):
            if enc.get("additionalType") == "CompilacaoMonoVigenteNaCD":
                content_url = enc.get("contentUrl", "")
                if not content_url:
                    continue
                # Fix: /api/binario/{uuid}/texto → /api/public/binario/{uuid}/texto
                return content_url.replace("/api/binario/", "/api/public/binario/")

        # Fallback: try PublicacaoOriginal
        for enc in doc.get("encoding", []):
            if enc.get("additionalType") == "PublicacaoOriginal":
                content_url = enc.get("contentUrl", "")
                if content_url:
                    return content_url.replace("/api/binario/", "/api/public/binario/")

        return None

    async def get_texto_html(self, content_url: str) -> str:
        """Download the full HTML text of a law.

        Args:
            content_url: Corrected URL from :meth:`find_texto_compilado_url`.

        Returns:
            Raw HTML string.
        """
        return await self._get_text(content_url)
