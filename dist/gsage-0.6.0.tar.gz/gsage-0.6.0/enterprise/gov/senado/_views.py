"""gSage AI — Slim views for Senado legislation API responses.

Normalises raw Senado Federal and Normas.leg.br API responses into compact,
agent-friendly dicts.
"""

from __future__ import annotations

from typing import Optional

from src.mcp_server.tools.enterprise.gov.senado._constants import _TIPO_COMMON


# ── Slim views ───────────────────────────────────────────────────────────────


def slim_norma(raw: dict) -> dict:
    """Slim a single search result from ``/legislacao/lista``."""
    return {
        "codigo": int(raw.get("id", 0)),
        "tipo": raw.get("descricao") or raw.get("tipo", ""),
        "numero": int(raw.get("numero", 0)),
        "ano": int(raw.get("anoassinatura", 0)),
        "ementa": raw.get("ementa", ""),
        "data": raw.get("dataassinatura", ""),
        "norma_nome": raw.get("normaNome", ""),
        "apelido": raw.get("apelido", ""),
    }


def slim_norma_detalhe(raw: dict) -> dict:
    """Slim a single detailed result from ``/legislacao/{codigo}``.

    Extracts the first ``documento`` from the nested ``DetalheDocumento``
    wrapper.
    """
    doc = raw.get("DetalheDocumento", {})
    documentos = doc.get("documentos", {})
    docs_list = documentos.get("documento", [])
    if not docs_list:
        return _empty_detalhe()
    d = docs_list[0]

    ident = d.get("identificacao", {})
    if not isinstance(ident, dict):
        ident = {}

    # Extract URN from urlDocumento
    url_doc = ident.get("urlDocumento", "")
    urn = _extract_urn_from_url(url_doc)

    # Publications
    pubs_raw = _safe_get_list(d, "publicacoes", "publicacao")
    publicacoes = [_slim_publicacao(p) for p in pubs_raw]

    # Article structure (disps)
    disps_raw = _safe_get_list(d, "disps", "disp")
    estrutura = [disp.get("nomeDispositivo", "") for disp in disps_raw]

    # Related legislation (vides = norms that alter this one)
    vides_raw = _safe_get_list(d, "vides", "vide")
    normas_correlatas = [_slim_vide(v) for v in vides_raw]

    # Altered legislation (edivs = norms this one alters)
    edivs_raw = _safe_get_list(d, "edivs", "ediv")
    normas_alteradas = [_slim_ediv(e) for e in edivs_raw]

    # Classification
    classes_raw = d.get("classes", {})
    if isinstance(classes_raw, dict):
        classificacao = classes_raw.get("classe", "")
    elif isinstance(classes_raw, str):
        classificacao = classes_raw
    else:
        classificacao = ""

    # Indexing keywords
    indexacao_raw = d.get("indexacao", {})
    if isinstance(indexacao_raw, dict):
        indexacao = indexacao_raw.get("frase", [])
        if not isinstance(indexacao, list):
            indexacao = []
    else:
        indexacao = []

    # Extract year from the URN date part (more reliable than URL parsing)
    # urn:lex:br:federal:lei:2021-04-01;14133 → 2021
    ano = _extract_ano_from_urn(urn) or _extract_ano_from_data(
        ident.get("dataassinatura", "")
    )

    return {
        "codigo": int(d.get("id", 0)),
        "tipo": ident.get("descricao") or ident.get("tipo", ""),
        "numero": int(ident.get("numero", 0)),
        "ano": ano,
        "ementa": d.get("ementa", ""),
        "data_assinatura": ident.get("dataassinatura", ""),
        "situacao": ident.get("situacao", ""),
        "nome_completo": ident.get("normaNome", ""),
        "apelido": ident.get("apelido", ""),
        "link_texto": url_doc,
        "urn": urn,
        "publicacoes": publicacoes,
        "estrutura": estrutura,
        "normas_correlatas": normas_correlatas,
        "normas_alteradas": normas_alteradas,
        "classificacao": classificacao,
        "indexacao": indexacao,
    }


def slim_tipo_norma(raw: dict) -> dict:
    """Slim a single tipo entry from ``/legislacao/tiposNorma``.

    The raw format varies; handles both list-of-dicts and nested wrappers.
    """
    # Try common known structures
    if isinstance(raw, dict):
        sigla = raw.get("sigla") or raw.get("codigo") or raw.get("tipo", "")
        desc = raw.get("descricao") or raw.get("nome") or raw.get("nomeTipoNorma", "")
        if sigla:
            return {"sigla": str(sigla).strip(), "descricao": str(desc).strip()}
    if isinstance(raw, str):
        return {"sigla": raw.strip(), "descricao": ""}
    return {"sigla": "", "descricao": str(raw)}


def slim_tipos_norma_list(raw: object) -> list[dict]:
    """Parse the ``tiposNorma`` response into a list of ``{sigla, descricao}``.

    The Senado API returns this as a redirect to a JSON file which may be a
    flat list, a dict with a list, or a nested ``ListaTiposNorma`` wrapper.
    """
    items: list = []

    if isinstance(raw, list):
        items = raw
    elif isinstance(raw, dict):
        # Try common wrapper keys
        for key in ("ListaTiposNorma", "TiposNorma", "tiposNorma", "resultado"):
            if key in raw:
                val = raw[key]
                if isinstance(val, list):
                    items = val
                    break
                if isinstance(val, dict):
                    for inner_key in ("tipoNorma", "tipos", "item"):
                        if inner_key in val:
                            items = val[inner_key] if isinstance(val[inner_key], list) else [val[inner_key]]
                            break
                    if items:
                        break
        # If no wrapper found, treat the dict itself as a single entry or
        # look for any list value
        if not items:
            for v in raw.values():
                if isinstance(v, list):
                    items = v
                    break
            if not items:
                items = [raw]

    return [slim_tipo_norma(item) for item in items if item]


def format_tipo_display(tipo_sigla: str) -> str:
    """Return a human-readable display for a tipo sigla.

    Uses the static mapping for common types; falls back to the raw sigla.
    """
    return _TIPO_COMMON.get(tipo_sigla.upper(), tipo_sigla)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _extract_urn_from_url(url: str) -> str:
    """Extract the URN from a normas.leg.br URL."""
    if "urn=" in url:
        return url.split("urn=", 1)[1].split("&")[0]
    return ""


def _slim_publicacao(pub: dict) -> dict:
    return {
        "fonte": pub.get("fonte", ""),
        "sigla_fonte": pub.get("siglaFonte", ""),
        "data": pub.get("data", ""),
        "pagina": pub.get("pagina", ""),
        "coluna": pub.get("coluna", ""),
        "tem_texto": pub.get("temTexto", "N") == "S",
    }


def _slim_vide(vide: dict) -> dict:
    return {
        "norma": vide.get("nomeNormaPosterior", ""),
        "comentario": vide.get("comentario", ""),
        "data": vide.get("datAssinatura", ""),
        "publicacao": vide.get("nomePub", ""),
        "pagina": vide.get("pagina", ""),
    }


def _slim_ediv(ediv: dict) -> dict:
    itens_raw = ediv.get("itens", {}).get("item", []) if isinstance(ediv.get("itens"), dict) else []
    dispositivos = [item.get("dispositivo", "") for item in itens_raw] if isinstance(itens_raw, list) else []
    return {
        "norma": ediv.get("nomeNormaAnterior", ""),
        "comentario": ediv.get("comentario", ""),
        "data": ediv.get("datAssinatura", ""),
        "dispositivos_alterados": dispositivos,
    }


def _empty_detalhe() -> dict:
    return {
        "codigo": 0,
        "tipo": "",
        "numero": 0,
        "ano": 0,
        "ementa": "",
        "data_assinatura": "",
        "situacao": "",
        "nome_completo": "",
        "apelido": "",
        "link_texto": "",
        "urn": "",
        "publicacoes": [],
        "estrutura": [],
        "normas_correlatas": [],
        "normas_alteradas": [],
        "classificacao": "",
        "indexacao": [],
    }


def _safe_get_list(doc: dict, parent_key: str, child_key: str) -> list:
    """Safely extract a list from a nested dict that may be an empty string.

    The Senado API sometimes returns ``""`` instead of ``{}`` for empty
    sections like ``disps``, ``vides``, ``edivs``.
    """
    parent = doc.get(parent_key, {})
    if not isinstance(parent, dict):
        return []
    child = parent.get(child_key, [])
    if not isinstance(child, list):
        return []
    return child


def _extract_ano_from_urn(urn: str) -> int:
    """Extract the year from a LexML URN date part.

    ``urn:lex:br:federal:lei:2021-04-01;14133`` → ``2021``.
    """
    import re
    parts = urn.replace(":", " ").replace(";", " ").split()
    date_pat = re.compile(r"^(\d{4})-\d{2}-\d{2}$")
    for p in parts:
        m = date_pat.match(p)
        if m:
            return int(m.group(1))
    return 0


def _extract_ano_from_data(data_str: str) -> int:
    """Extract the year from a Brazilian date string.

    ``"01/04/2021"`` → ``2021``.
    """
    parts = data_str.split("/")
    if len(parts) == 3 and parts[2].isdigit():
        return int(parts[2])
    return 0
