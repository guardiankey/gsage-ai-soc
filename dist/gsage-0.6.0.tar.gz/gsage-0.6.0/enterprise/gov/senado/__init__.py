"""gSage AI — Brazilian federal legislation tools (Senado Federal)."""
