"""gSage AI — Constants for the Senado legislation tool."""

from __future__ import annotations

BASE_URL_SENADO = "https://legis.senado.leg.br/dadosabertos"
BASE_URL_NORMAS = "https://normas.leg.br/api/public"
DEFAULT_TIMEOUT = 30.0
DEFAULT_VERSION = 3
MAX_RETRIES = 3
RETRY_DELAY = 2.0  # seconds to wait when rate-limited

# Cache TTLs
_CACHE_TTL_ESTRUTURA = 24 * 3600   # 24 hours — tipos_norma (static)
_CACHE_TTL_BUSCA = 24 * 3600       # 24 hours — buscar
_CACHE_TTL_DETALHE = 24 * 3600     # 24 hours — detalhes
_CACHE_TTL_TEXTO = 24 * 3600       # 24 hours — baixar_texto

# Actions
_ACTIONS = frozenset({
    "buscar",
    "buscar_por_termo",
    "detalhes",
    "baixar_texto",
    "tipos_norma",
})

# Common tipo abbreviations baked into the schema description.
# Keep in sync with the 'tipo' parameter description in legislacao.py.
_TIPO_COMMON: dict[str, str] = {
    "LEI": "Lei Ordinária",
    "LCP": "Lei Complementar",
    "DEC": "Decreto",
    "MPV": "Medida Provisória",
    "EMC": "Emenda Constitucional",
    "DLG": "Decreto Legislativo",
    "RSF": "Resolução do Senado Federal",
}
