"""gSage AI — HTML → Markdown conversion for normas.leg.br content."""

from __future__ import annotations

import re

from bs4 import BeautifulSoup
import markdownify

__all__ = ["html_to_markdown"]


def html_to_markdown(html: str) -> str:
    """Convert normas.leg.br HTML to clean Markdown.

    Removes ``<style>``, ``<script>``, ``<img>``, ``<meta>``, ``<link>`` tags,
    then converts to Markdown with ATX-style headings.

    Args:
        html: Raw HTML from normas.leg.br/api/public/binario/{uuid}/texto.

    Returns:
        Clean Markdown string.
    """
    soup = BeautifulSoup(html, "html.parser")

    # Strip non-content tags
    for tag in soup.find_all(["style", "script", "img", "meta", "link"]):
        tag.decompose()

    md = markdownify.markdownify(str(soup), heading_style="ATX")
    # Normalise excessive blank lines (3+ → 2)
    md = re.sub(r"\n{3,}", "\n\n", md)
    return md.strip()
