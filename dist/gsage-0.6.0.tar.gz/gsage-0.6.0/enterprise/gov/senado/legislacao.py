"""gSage AI — Brazilian federal legislation search and retrieval tool.

Query the Senado Federal Dados Abertos API for legislation metadata, and
download full consolidated texts from Normas.leg.br as Markdown artifacts.

Actions
-------
- ``buscar`` — search legislation by type, number, and year.
- ``buscar_por_termo`` — keyword search in the legislation catalog.
- ``detalhes`` — rich metadata: summary, article structure, related legislation.
- ``baixar_texto`` — download full text as a Markdown artifact.
- ``tipos_norma`` — list all normative type abbreviations (rare types).

Permission: ``gov:senado:legislacao:read``.
"""

from __future__ import annotations

import logging
import re
import time
from typing import ClassVar, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.mcp_server.tools.enterprise.gov.senado._client import (
    NormasLegClient,
    NormasLegError,
    SenadoClient,
    SenadoError,
    _extract_urn,
)
from src.mcp_server.tools.enterprise.gov.senado._constants import (
    _ACTIONS,
    _CACHE_TTL_BUSCA,
    _CACHE_TTL_DETALHE,
    _CACHE_TTL_ESTRUTURA,
    _CACHE_TTL_TEXTO,
    _TIPO_COMMON,
)
from src.mcp_server.tools.enterprise.gov.senado._converter import html_to_markdown
from src.mcp_server.tools.enterprise.gov.senado._views import (
    format_tipo_display,
    slim_norma,
    slim_norma_detalhe,
    slim_tipos_norma_list,
)
from src.shared.cache.decorator import cached
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

# ── Cached helpers ───────────────────────────────────────────────────────────


@cached(
    ttl=_CACHE_TTL_ESTRUTURA,
    scope="global",
    key_fn=lambda *_args, **_kwargs: "senado:tipos_norma:v1",
    logical_name="senado_tipos_norma",
)
async def _get_tipos_norma_cache(
    *, session: AsyncSession,  # noqa: ARG001
) -> list[dict]:
    """Fetch and cache the list of normative types."""
    client = SenadoClient()
    raw = await client.tipos_norma()
    return slim_tipos_norma_list(raw)


@cached(
    ttl=_CACHE_TTL_BUSCA,
    scope="global",
    key_fn=lambda tipo, numero, ano, data, **_kwargs: (
        f"senado:busca:{tipo or '_'}:{numero or '_'}:{ano or '_'}:{data or '_'}"
    ),
    logical_name="senado_busca",
)
async def _buscar_normas_cache(
    tipo: Optional[str],
    numero: Optional[int],
    ano: Optional[int],
    data: Optional[str],
    *,
    session: AsyncSession,  # noqa: ARG001
) -> list[dict]:
    """Fetch and cache legislation search results."""
    client = SenadoClient()
    raw = await client.buscar(tipo=tipo, numero=numero, ano=ano, data=data)
    return [slim_norma(r) for r in raw]


@cached(
    ttl=_CACHE_TTL_DETALHE,
    scope="global",
    key_fn=lambda codigo, **_kwargs: f"senado:norma:{codigo}",
    logical_name="senado_detalhe",
)
async def _detalhes_norma_cache(
    codigo: int,
    *,
    session: AsyncSession,  # noqa: ARG001
) -> dict:
    """Fetch and cache legislation detail metadata."""
    client = SenadoClient()
    raw = await client.detalhes(codigo)
    return slim_norma_detalhe(raw)


@cached(
    ttl=_CACHE_TTL_TEXTO,
    scope="global",
    key_fn=lambda urn, **_kwargs: f"senado:texto:{urn}",
    logical_name="senado_texto",
)
async def _baixar_texto_html_cache(
    urn: str,
    *,
    session: AsyncSession,  # noqa: ARG001
) -> str:
    """Fetch, convert, and cache the full Markdown text of a law.

    Returns the raw Markdown string (cached to avoid re-download + conversion).
    """
    normas_client = NormasLegClient()

    # Step 1: Get document metadata
    doc = await normas_client.get_documento_maior_detalhe(urn)

    # Step 2: Find compiled text URL
    content_url = normas_client.find_texto_compilado_url(doc)
    if not content_url:
        raise NormasLegError(
            404,
            f"No compiled text (CompilacaoMonoVigenteNaCD or "
            f"PublicacaoOriginal) found for URN {urn}.",
        )

    # Step 3: Download HTML
    html = await normas_client.get_texto_html(content_url)

    # Return HTML — conversion to MD is done at call site so we can also
    # return HTML-only if requested.
    return html


# ── Helpers ──────────────────────────────────────────────────────────────────


def _build_filename_from_urn(urn: str, extension: str) -> str:
    """Build a human-readable filename from a LexML URN.

    ``urn:lex:br:federal:lei:2021-04-01;14133`` → ``lei_14133_2021.md``.
    """
    # Normalise: replace delimiters with spaces, split
    parts = urn.replace(":", " ").replace(";", " ").split()

    # Map URN tipo names (full Portuguese words) → short siglas for filenames
    _TIPO_URN_MAP: dict[str, str] = {
        "lei": "lei",
        "leicomplementar": "lcp",
        "decreto": "dec",
        "decretolei": "dec",
        "decreto-lei": "dec",
        "medidaprovisonia": "mpv",
        "emendaconstitucional": "emc",
        "decretolegislativo": "dlg",
        "resolucao": "rsf",
        "resolução": "rsf",
    }
    # Also add the abbreviations themselves
    for short, _long in _TIPO_COMMON.items():
        _TIPO_URN_MAP.setdefault(short.lower(), short.lower())

    # 1. Find tipo (case-insensitive, also try joining multi-word types)
    tipo_str = "norma"
    tipo_idx = -1
    # First try: exact match on individual parts
    for i, p in enumerate(parts):
        key = p.lower()
        if key in _TIPO_URN_MAP:
            tipo_str = _TIPO_URN_MAP[key]
            tipo_idx = i
            break
    # Second try: if not found, look for the longest matching phrase by
    # joining consecutive parts (e.g. "decreto" "lei" → "decretolei")
    if tipo_str == "norma":
        for start in range(len(parts)):
            for end in range(start + 2, min(start + 4, len(parts) + 1)):
                joined = "".join(p.lower() for p in parts[start:end])
                if joined in _TIPO_URN_MAP:
                    tipo_str = _TIPO_URN_MAP[joined]
                    tipo_idx = end - 1
                    break
            if tipo_str != "norma":
                break

    # 2. Find date part (YYYY-MM-DD pattern) → extract year
    ano_str = "0000"
    date_pat = re.compile(r"^(\d{4})-\d{2}-\d{2}$")
    for p in parts:
        m = date_pat.match(p)
        if m:
            ano_str = m.group(1)
            break

    # 3. Find number (pure digits, at least 1 digit, after the tipo if found)
    num_str = "0000"
    search_start = tipo_idx + 1 if tipo_idx >= 0 else 0
    for p in parts[search_start:]:
        if re.match(r"^\d+$", p) and date_pat.match(p) is None:
            num_str = p
            break

    return f"{tipo_str}_{num_str}_{ano_str}.{extension}"


def _build_planalto_url(tipo: str, numero: int, ano: int) -> Optional[str]:
    """Build a link to the full text on Planalto.gov.br.

    The Planalto site hosts the official text of most federal legislation,
    especially decretos (which are NOT compiled on normas.leg.br).  This
    provides a best-effort fallback when ``baixar_texto`` fails.

    Pattern: ``https://www.planalto.gov.br/ccivil_03/_ato{PERIODO}/{ANO}/{PASTA}/{PREFIXO}{NUMERO}.htm``

    Args:
        tipo: Sigla do tipo (e.g. ``"LEI"``, ``"DEC"``, ``"MPV"``).
        numero: Número da norma.
        ano: Ano da norma.

    Returns:
        Planalto URL string, or ``None`` if the tipo is not supported.
    """
    # Calculate 4-year presidential term period
    # Terms since 1995 (FHC): 1995, 1999, 2003, 2007, 2011, 2015, 2019, 2023
    # _ato prefix used from 2015 onwards; earlier periods have different structure
    if ano >= 2015:
        start = ano - ((ano - 2015) % 4)
        periodo = f"_ato{start}-{start + 3}"
        dir_ano = str(ano)
    elif ano >= 1995:
        start = ano - ((ano - 1995) % 4)
        periodo = f"_ato{start}-{start + 3}"
        dir_ano = str(ano)
    else:
        # Pre-1995: older site structure — fallback to basic pattern
        periodo = ""
        dir_ano = str(ano)

    # Map tipo sigla → Planalto path components
    _PLANALTO_TIPO_MAP: dict[str, tuple[str, str]] = {
        "LEI": ("lei", "L"),
        "DEC": ("decreto", "D"),
        "LCP": ("lcp", "Lcp"),
        "MPV": ("mpv", "MPV"),
        "EMC": ("emc", "EC"),
        "DLG": ("dlg", "DLG"),
    }

    tipo_upper = tipo.upper()
    entry = _PLANALTO_TIPO_MAP.get(tipo_upper)
    if not entry:
        return None

    pasta, prefixo = entry

    if periodo:
        url = (
            f"https://www.planalto.gov.br/ccivil_03/{periodo}"
            f"/{dir_ano}/{pasta}/{prefixo}{numero}.htm"
        )
    else:
        url = (
            f"https://www.planalto.gov.br/ccivil_03"
            f"/{pasta}/{prefixo}{numero}.htm"
        )

    return url


def _parse_tipo_numero_ano_from_urn(urn: str) -> tuple[Optional[str], int, int]:
    """Extract tipo, numero, ano from a LexML URN.

    ``urn:lex:br:federal:lei:2021-04-01;14133`` → ``("LEI", 14133, 2021)``.
    """
    parts = urn.replace(":", " ").replace(";", " ").split()

    # Map URN names → siglas
    _TIPO_FROM_URN: dict[str, str] = {
        "lei": "LEI", "leicomplementar": "LCP", "decreto": "DEC",
        "decretolei": "DEC", "medidaprovisoria": "MPV",
        "medidaprovisonia": "MPV", "emendaconstitucional": "EMC",
        "decretolegislativo": "DLG", "resolucao": "RSF",
    }
    for short in _TIPO_COMMON:
        _TIPO_FROM_URN.setdefault(short.lower(), short)

    # Find tipo
    tipo: Optional[str] = None
    for p in parts:
        key = p.lower()
        if key in _TIPO_FROM_URN:
            tipo = _TIPO_FROM_URN[key]
            break

    # Find date → year
    ano = 0
    date_pat = re.compile(r"^(\d{4})-\d{2}-\d{2}$")
    for p in parts:
        m = date_pat.match(p)
        if m:
            ano = int(m.group(1))
            break

    # Find number (pure digits, not the date)
    numero = 0
    for p in parts:
        if re.match(r"^\d+$", p) and date_pat.match(p) is None:
            numero = int(p)
            break

    return tipo, numero, ano


# ── Tool ─────────────────────────────────────────────────────────────────────


class LegislacaoFederalTool(BaseTool):
    """Search and retrieve Brazilian federal legislation (laws, decrees, etc.).

    Actions
    -------
    - ``buscar`` — search by type + number + year.
    - ``buscar_por_termo`` — keyword/concept search.
    - ``detalhes`` — rich metadata: summary, article structure, related norms.
    - ``baixar_texto`` — download full text as Markdown artifact.
    - ``tipos_norma`` — list all normative type abbreviations.

    Permission: ``gov:senado:legislacao:read``.
    """

    name: ClassVar[str] = "legislacao_federal"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Search and retrieve Brazilian federal legislation (laws, decrees, "
        "provisional measures, constitutional amendments). Find by type+number+year "
        "or keyword; get rich metadata (article structure, related legislation, "
        "DOU publication info); download full consolidated text as Markdown."
    )
    description: ClassVar[str] = (
        "**buscar** finds legislation by tipo+numero+ano.\n"
        "  Common tipos: LEI (Lei Ordinária), LCP (Lei Complementar),\n"
        "  DEC (Decreto), MPV (Medida Provisória), EMC (Emenda Constitucional).\n"
        "  No need to call 'tipos_norma' for these — they're in the param description.\n"
        "\n"
        "**detalhes** returns rich metadata for a specific law:\n"
        "- ementa (summary), article structure (names only, no text),\n"
        "- publicações no DOU (fonte, data, página),\n"
        "- normas_correlatas (norms that alter/revoke this one),\n"
        "- normas_alteradas (norms this one alters),\n"
        "- classificação temática, indexação.\n"
        "\n"
        "**baixar_texto** downloads the full consolidated text as a Markdown\n"
        "artifact saved in the conversation context. Use after 'detalhes'.\n"
        "\n"
        "**IMPORTANT:** This API does NOT return article bodies — only\n"
        "article numbers. Use 'baixar_texto' for full text."
    )
    category: ClassVar[str] = "government"
    permissions: ClassVar[list[str]] = ["gov:senado:legislacao:read"]
    rate_limit_per_minute: ClassVar[int] = 30
    timeout_seconds: ClassVar[int] = 60
    use_circuit_breaker: ClassVar[bool] = False
    requires_approval: ClassVar[bool] = False
    supports_multiple_configs: ClassVar[bool] = False
    requires_config: ClassVar[bool] = False

    params_schema: ClassVar[dict] = {
        "type": "object",
        "required": ["action"],
        "properties": {
            "action": {
                "type": "string",
                "enum": sorted(_ACTIONS),
                "description": "Which legislation operation to perform.",
            },
            "tipo": {
                "type": "string",
                "description": (
                    "Sigla do tipo da norma. Use uma das siglas abaixo:\n"
                    + "\n".join(
                        f"  {k}  = {v}" for k, v in _TIPO_COMMON.items()
                    )
                    + "\nOutras siglas: use 'tipos_norma' para a lista completa."
                ),
            },
            "numero": {
                "type": "integer",
                "description": (
                    "Número da norma (ex: 8112 for Lei 8.112/1990). "
                    "Use alone or with 'ano'."
                ),
            },
            "ano": {
                "type": "integer",
                "description": "Ano da norma (ex: 2013). Use with 'numero' for precise lookup.",
            },
            "data": {
                "type": "string",
                "description": (
                    "Data de assinatura no formato AAAAMMDD "
                    "(ex: 19901211 for 11/12/1990). "
                    "Use to find normas from a specific date."
                ),
            },
            "termo": {
                "type": "string",
                "description": (
                    "Keyword or phrase to search in the legislation catalog "
                    "(ex: 'licitação', 'proteção de dados', 'improbidade'). "
                    "Required for 'buscar_por_termo'."
                ),
            },
            "tipo_termo": {
                "type": "integer",
                "description": "Optional term type code. 9 = assunto (subject).",
            },
            "codigo": {
                "type": "integer",
                "description": (
                    "Internal legislation code for 'detalhes'. "
                    "Obtained from 'buscar' or 'buscar_por_termo' results."
                ),
            },
            "urn": {
                "type": "string",
                "description": (
                    "LexML URN for 'baixar_texto'. "
                    "Extracted from 'detalhes' → 'link_texto' field. "
                    "Ex: 'urn:lex:br:federal:lei:2021-04-01;14133'."
                ),
            },
            "formato": {
                "type": "string",
                "enum": ["markdown", "html"],
                "default": "markdown",
                "description": "Output format for 'baixar_texto'. 'markdown' (default) converts HTML→MD. 'html' returns raw HTML.",
            },
            "force_refresh": {
                "type": "boolean",
                "description": "Bypass cache for this call.",
            },
        },
    }

    config_schema: ClassVar[Optional[dict]] = None
    config_defaults: ClassVar[dict] = {}
    state_schema: ClassVar[Optional[dict]] = None
    state_defaults: ClassVar[dict] = {}
    reset_policy: ClassVar[str] = "never"

    # ── Execute ───────────────────────────────────────────────────────────

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        t0 = time.monotonic()
        action = (params.get("action") or "").strip()
        if action not in _ACTIONS:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "INVALID_PARAMS",
                f"action must be one of {sorted(_ACTIONS)}; got {action!r}.",
                execution_time_ms=elapsed,
            )

        try:
            data = await self._dispatch(action, params, agent_context)
        except (SenadoError, NormasLegError) as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                f"SENADO_ERROR_{exc.status}" if isinstance(exc, SenadoError)
                else f"NORMASLEG_ERROR_{exc.status}",
                exc.message,
                execution_time_ms=elapsed,
            )
        except Exception:
            log.exception("legislacao_federal(%s): unexpected error", action)
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "INTERNAL_ERROR",
                f"Unexpected error in {action}. See logs for details.",
                execution_time_ms=elapsed,
            )

        elapsed = int((time.monotonic() - t0) * 1000)
        return self._success(data={"action": action, **data}, execution_time_ms=elapsed)

    # ── Dispatch ──────────────────────────────────────────────────────────

    async def _dispatch(
        self, action: str, params: dict, ctx: AgentContext,
    ) -> dict:
        from src.mcp_server.tools.base import _tool_session_ctx
        session = _tool_session_ctx.get()
        if session is None:
            raise RuntimeError("No DB session available")

        force_refresh = bool(params.get("force_refresh", False))

        if action == "buscar":
            return await self._do_buscar(params, session, force_refresh)
        elif action == "buscar_por_termo":
            return await self._do_buscar_por_termo(params)
        elif action == "detalhes":
            return await self._do_detalhes(params, session, force_refresh)
        elif action == "baixar_texto":
            return await self._do_baixar_texto(params, ctx, session, force_refresh)
        elif action == "tipos_norma":
            return await self._do_tipos_norma(params, session, force_refresh)
        else:
            raise ValueError(f"Unknown action: {action}")

    # ── Actions ───────────────────────────────────────────────────────────

    async def _do_buscar(
        self,
        params: dict,
        session: AsyncSession,
        force_refresh: bool,
    ) -> dict:
        """Search legislation by type + number + year."""
        tipo = (params.get("tipo") or "").strip().upper() or None
        numero = params.get("numero")
        if numero is not None:
            numero = int(numero)
        ano = params.get("ano")
        if ano is not None:
            ano = int(ano)
        data = (params.get("data") or "").strip() or None

        # Require at least one search parameter
        if not any([tipo, numero is not None, ano is not None, data]):
            raise SenadoError(
                400,
                "At least one search parameter is required: "
                "'tipo', 'numero', 'ano', or 'data'.",
            )

        if force_refresh:
            client = SenadoClient()
            raw = await client.buscar(tipo=tipo, numero=numero, ano=ano, data=data)
            rows = [slim_norma(r) for r in raw]
        else:
            rows = await _buscar_normas_cache(
                tipo=tipo, numero=numero, ano=ano, data=data, session=session,
            )

        tipo_display = format_tipo_display(tipo) if tipo else ""
        agent_hint = (
            f"Found {len(rows)} {tipo_display} normas. "
            "Use 'detalhes' with a 'codigo' from the results for full metadata, "
            "or 'baixar_texto' with a 'urn' to download the full text."
        )

        return {
            "rows_total": len(rows),
            "rows": rows,
            "agent_hint": agent_hint,
        }

    async def _do_buscar_por_termo(self, params: dict) -> dict:
        """Search legislation by keyword."""
        termo = (params.get("termo") or "").strip()
        if not termo:
            raise SenadoError(400, "'termo' is required for 'buscar_por_termo'.")

        tipo_termo = params.get("tipo_termo")
        if tipo_termo is not None:
            tipo_termo = int(tipo_termo)

        client = SenadoClient()
        raw = await client.buscar_por_termo(termo=termo, tipo_termo=tipo_termo)

        # The termos endpoint response shape may differ; try to extract documents
        rows: list[dict] = []
        if isinstance(raw, list):
            rows = [slim_norma(r) for r in raw]
        elif isinstance(raw, dict):
            # Try common nesting patterns
            docs: object = raw.get("ListaDocumento", raw)
            if isinstance(docs, dict):
                documentos: object = docs.get("documentos", {})
                if isinstance(documentos, dict):
                    docs_list: object = documentos.get("documento", [])
                    if isinstance(docs_list, list):
                        rows = [slim_norma(r) for r in docs_list]
            else:
                rows = []

        agent_hint = (
            f"Keyword search for '{termo}' returned {len(rows)} results. "
            "Use 'detalhes' with a 'codigo' to explore a specific norma."
        )

        return {
            "termo": termo,
            "rows_total": len(rows),
            "rows": rows,
            "agent_hint": agent_hint,
        }

    async def _do_detalhes(
        self,
        params: dict,
        session: AsyncSession,
        force_refresh: bool,
    ) -> dict:
        """Get rich metadata for a specific law."""
        codigo = params.get("codigo")
        if codigo is None:
            raise SenadoError(400, "'codigo' is required for 'detalhes'.")
        codigo = int(codigo)

        if force_refresh:
            client = SenadoClient()
            raw = await client.detalhes(codigo)
            detalhe = slim_norma_detalhe(raw)
        else:
            detalhe = await _detalhes_norma_cache(codigo=codigo, session=session)

        if not detalhe.get("codigo"):
            raise SenadoError(404, f"No legislation found for code {codigo}.")

        agent_hint = (
            "This API returns only metadata and article structure — NOT the "
            "article text bodies. To read the full law text, use "
            "'baixar_texto' with the 'urn' field from this result."
        )

        return {
            **detalhe,
            "agent_hint": agent_hint,
        }

    async def _do_baixar_texto(
        self,
        params: dict,
        ctx: AgentContext,
        session: AsyncSession,
        force_refresh: bool,
    ) -> dict:
        """Download full text, convert to Markdown, store as artifact.

        Tries normas.leg.br first.  Falls back to a Planalto.gov.br link for
        legislation types that are not compiled on normas.leg.br (decretos,
        medidas provisórias, etc.).
        """
        urn = (params.get("urn") or "").strip()
        if not urn:
            raise SenadoError(400, "'urn' is required for 'baixar_texto'.")

        # Ensure it's a real URN, not a full URL
        if "http" in urn:
            urn = _extract_urn(urn)
        if not urn.startswith("urn:lex:"):
            raise SenadoError(
                400,
                f"'urn' must be a LexML URN (e.g. 'urn:lex:br:federal:lei:...'). "
                f"Got: {urn!r}. Extract the URN from 'detalhes' → 'link_texto'.",
            )

        formato = (params.get("formato") or "markdown").strip().lower()

        # ── Try normas.leg.br ────────────────────────────────────────────
        try:
            if force_refresh:
                normas_client = NormasLegClient()
                doc = await normas_client.get_documento_maior_detalhe(urn)
                content_url = normas_client.find_texto_compilado_url(doc)
                if not content_url:
                    raise NormasLegError(
                        404,
                        f"No compiled text found for URN {urn}.",
                    )
                html = await normas_client.get_texto_html(content_url)
            else:
                html = await _baixar_texto_html_cache(urn=urn, session=session)

            # Success — produce artifact
            if formato == "html":
                output_bytes = html.encode("utf-8")
                content_type = "text/html"
                extension = "html"
            else:
                md_text = html_to_markdown(html)
                output_bytes = md_text.encode("utf-8")
                content_type = "text/markdown"
                extension = "md"

            filename = _build_filename_from_urn(urn, extension)

            file_info = await self._store_file(
                data=output_bytes,
                filename=filename,
                content_type=content_type,
                agent_context=ctx,
                session=session,
                description=f"Texto integral ({formato}) — URN: {urn}",
                scope="user",
            )

            preview = (
                html[:500]
                if formato == "html"
                else html_to_markdown(html)[:500]
            )

            agent_hint = (
                f"Full text downloaded as {formato.upper()} artifact. "
                f"file_id={file_info.get('file_id') if file_info else 'unknown'}. "
                "The text is now available in the conversation context — you can "
                "answer specific questions about any article."
            )

            return {
                "urn": urn,
                "formato": formato,
                "tamanho_chars": len(output_bytes),
                "artefato": file_info,
                "preview": preview,
                "agent_hint": agent_hint,
            }

        except NormasLegError as exc:
            # ── Fallback: Planalto.gov.br ───────────────────────────────
            tipo, numero, ano = _parse_tipo_numero_ano_from_urn(urn)
            planalto_url = _build_planalto_url(tipo or "", numero, ano)

            if planalto_url:
                log.info(
                    "baixar_texto: normas.leg.br failed (%s), "
                    "falling back to Planalto URL %s",
                    exc.message, planalto_url,
                )
                agent_hint = (
                    f"No compiled text available on normas.leg.br for this "
                    f"norma ({exc.message}). The official text is available on "
                    f"Planalto.gov.br: {planalto_url}. "
                    "Direct the user to open this link in a browser to read "
                    "the full text."
                )
                return {
                    "urn": urn,
                    "tipo": tipo,
                    "numero": numero,
                    "ano": ano,
                    "erro_normas_leg": exc.message,
                    "planalto_url": planalto_url,
                    "artefato": None,
                    "agent_hint": agent_hint,
                }
            else:
                # No fallback available — re-raise original error
                raise

    async def _do_tipos_norma(
        self,
        params: dict,
        session: AsyncSession,
        force_refresh: bool,
    ) -> dict:
        """List all normative type abbreviations."""
        if force_refresh:
            client = SenadoClient()
            raw = await client.tipos_norma()
            tipos = slim_tipos_norma_list(raw)
        else:
            tipos = await _get_tipos_norma_cache(session=session)

        agent_hint = (
            f"Found {len(tipos)} normative types. "
            "The 7 most common (LEI, LCP, DEC, MPV, EMC, DLG, RSF) are already "
            "listed in the 'buscar' action's 'tipo' parameter — no need to "
            "call 'tipos_norma' just for those. Use this list to discover "
            "rare types (portarias, instruções normativas, etc.)."
        )

        return {
            "tipos": tipos,
            "total": len(tipos),
            "agent_hint": agent_hint,
        }
