"""gSage AI — Slim views and Mermaid generator for Compras.gov.br.

Normalises raw API responses into compact, agent-friendly dicts and
produces Mermaid diagrams for procurement flows.
"""

from __future__ import annotations

from typing import Optional

from src.mcp_server.tools.enterprise.gov.compras._client import parse_id, parse_label

# ── Slim views ───────────────────────────────────────────────────────────────


def slim_uasg(raw: dict) -> dict:
    """Slim a UASG record."""
    return {
        "codigo_uasg": raw.get("codigoUasg"),
        "nome": raw.get("nomeUasg"),
        "cnpj": raw.get("cnpjCpfUasg"),
        "codigo_orgao": raw.get("codigoOrgao"),
        "cnpj_orgao": raw.get("cnpjCpfOrgao"),
        "codigo_siorg": raw.get("codigoSiorg"),
        "uf": raw.get("siglaUf"),
        "municipio": raw.get("nomeMunicipioIbge"),
        "status": raw.get("statusUasg"),
    }


def slim_contrato(raw: dict) -> dict:
    """Slim a contract record from C1.

    Field names match the actual Compras.gov.br API response
    (camelCase Portuguese, confirmed via live API testing).
    """
    _g = lambda *keys: next((raw.get(k) for k in keys if raw.get(k) is not None), None)
    # Primary identifier — idCompra is the real key
    codigo = raw.get("idCompra") or raw.get("codigo") or raw.get("codigoContrato")
    tipo = raw.get("tipo") or "idCompra"
    numero = raw.get("numeroContrato") or raw.get("numero") or raw.get("numeroCompra")
    return {
        "id": f"{tipo}:{codigo}" if codigo else (f"numero:{numero}" if numero else None),
        "numero": numero,
        "tipo": tipo if codigo else None,
        "codigo_compra": codigo or None,
        "pncp": raw.get("numeroControlePncpContrato") or None,
        "objeto": raw.get("objeto"),
        "fornecedor": _g("nomeRazaoSocialFornecedor", "nomeFornecedor", "razaoSocialFornecedor"),
        "cnpj_fornecedor": _g("niFornecedor", "cnpjFornecedor", "cpfCnpjFornecedor"),
        "valor": _to_float(_g("valorGlobal", "valor", "valorTotal", "valorContrato")),
        "data_inicio": _g("dataVigenciaInicial", "dataInicioVigencia", "dataVigenciaInicio"),
        "data_fim": _g("dataVigenciaFinal", "dataFimVigencia", "dataVigenciaFim"),
        "situacao": _g("nomeTipo", "situacao", "status", "situacaoContrato"),
        "orgao_codigo": raw.get("codigoOrgao"),
        "orgao_nome": raw.get("nomeOrgao"),
        "uasg_codigo": _g("codigoUnidadeGestora", "codigoUasg"),
        "uasg_nome": _g("nomeUnidadeGestora", "nomeUasg"),
        "modalidade": raw.get("nomeModalidadeCompra"),
        "categoria": raw.get("nomeCategoria"),
    }


def slim_contrato_detalhe(raw: dict) -> dict:
    """Slim a detailed contract from C2.

    Returns ``{"not_found": True}`` when the API response is empty
    (contract does not exist or id is invalid).
    """
    # C2 returns 'idCompra', not 'codigo'
    has_id = raw.get("idCompra") or raw.get("codigo") or raw.get("codigoContrato")
    if not raw or not has_id:
        return {"not_found": True, "id": None}
    return {
        "id": f"{raw.get('tipo', 'idCompra')}:{raw.get('idCompra') or raw.get('codigo', '')}",
        "numero": raw.get("numeroContrato") or raw.get("numero"),
        "objeto": raw.get("objeto"),
        "valor_total": _to_float(raw.get("valorGlobal") or raw.get("valor")),
        "data_assinatura": raw.get("dataAssinatura"),
        "data_inicio": raw.get("dataVigenciaInicial"),
        "data_fim": raw.get("dataVigenciaFinal"),
        "fornecedor": {
            "cnpj": raw.get("niFornecedor") or raw.get("cnpjFornecedor"),
            "razao_social": raw.get("nomeRazaoSocialFornecedor") or raw.get("nomeFornecedor"),
        },
        "orgao": {
            "codigo": raw.get("codigoOrgao"),
            "nome": raw.get("nomeOrgao"),
        },
        "uasg": {
            "codigo": raw.get("codigoUnidadeGestora"),
            "nome": raw.get("nomeUnidadeGestora"),
        },
        "modalidade": raw.get("nomeModalidadeCompra"),
        "categoria": raw.get("nomeCategoria"),
        "processo": raw.get("processo"),
        "pncp_compra": raw.get("numeroControlePncpCompra"),
        "pncp_contrato": raw.get("numeroControlePncpContrato"),
        "valor_acumulado": _to_float(raw.get("valorAcumulado")),
        "valor_parcela": _to_float(raw.get("valorParcela")),
    }


def slim_fornecedor(raw: dict) -> dict:
    """Slim a supplier record from F1."""
    return {
        "cnpj": raw.get("cnpj"),
        "cpf": raw.get("cpf"),
        "razao_social": raw.get("nomeRazaoSocialFornecedor") or raw.get("razaoSocial"),
        "nome_fantasia": raw.get("nomeFantasia"),
        "porte": raw.get("porteEmpresaNome") or raw.get("porte"),
        "natureza_juridica": {
            "id": raw.get("naturezaJuridicaId"),
            "descricao": raw.get("naturezaJuridicaNome") or raw.get("naturezaJuridicaDescricao"),
        },
        "municipio": raw.get("nomeMunicipio"),
        "uf": raw.get("ufSigla"),
        "cnae": raw.get("nomeCnae"),
        "habilitado_licitar": raw.get("habilitadoLicitar"),
    }


def slim_preco(raw: dict) -> dict:
    """Slim a price record from pesquisa-preco."""
    return {
        "data": raw.get("dataCompra") or raw.get("dataResultado"),
        "orgao": raw.get("nomeOrgao"),
        "uasg": raw.get("nomeUasg"),
        "codigo_uasg": raw.get("codigoUasg"),
        "fornecedor": raw.get("nomeFornecedor"),
        "cnpj_fornecedor": raw.get("niFornecedor"),
        "descricao": raw.get("descricaoItem"),
        "quantidade": _to_float(raw.get("quantidade")),
        "preco_unitario": _to_float(raw.get("precoUnitario")),
        "valor_total": _to_float(raw.get("valorTotal") or 0),
        "estado": raw.get("estado"),
        "municipio": raw.get("municipio"),
    }


def slim_arp(raw: dict) -> dict:
    """Slim a price registration act from A1."""
    return {
        "numero": raw.get("numeroAtaRegistroPreco") or raw.get("numeroAta"),
        "objeto": raw.get("objeto"),
        "data_inicio": raw.get("dataVigenciaInicial"),
        "data_fim": raw.get("dataVigenciaFinal"),
        "orgao_gerenciador": raw.get("nomeUnidadeGerenciadora"),
        "codigo_orgao": raw.get("codigoUnidadeGerenciadora"),
        "codigo_uasg": raw.get("codigoUnidadeGestora"),
        "modalidade": raw.get("nomeModalidadeCompra"),
        "pncp": raw.get("numeroControlePncpAta"),
    }


# ── Helpers ──────────────────────────────────────────────────────────────────


def _to_float(val: object) -> Optional[float]:
    """Safe float conversion."""
    if val is None:
        return None
    try:
        return round(float(str(val)), 2)
    except (TypeError, ValueError):
        return None


# ── Contratos.gov.br views ───────────────────────────────────────────────────


def slim_contrato_ug(raw: dict) -> dict:
    """Slim a Contratos.gov.br contract (from /ug/ endpoint — nested format).

    Handles both the flat format (/id/) and nested format (/ug/).
    """
    # Flat format fields
    orgao_codigo = raw.get("orgao_codigo")
    orgao_nome = raw.get("orgao_nome")
    unidade_codigo = raw.get("unidade_codigo")
    unidade_nome = raw.get("unidade_nome")
    fornecedor_nome = raw.get("fornecedor_nome")
    fornecedor_cnpj = raw.get("fonecedor_cnpj_cpf_idgener") or raw.get("fornecedor_cnpj_cpf")

    # Nested format (from /ug/)
    contratante = raw.get("contratante")
    if isinstance(contratante, dict):
        orgao = contratante.get("orgao", {})
        if orgao:
            orgao_codigo = orgao_codigo or orgao.get("codigo")
            orgao_nome = orgao_nome or orgao.get("nome")
            ug = orgao.get("unidade_gestora", {})
            if ug:
                unidade_codigo = unidade_codigo or ug.get("codigo")
                unidade_nome = unidade_nome or ug.get("nome")

    fornecedor = raw.get("fornecedor")
    if isinstance(fornecedor, dict):
        fornecedor_nome = fornecedor_nome or fornecedor.get("nome")
        fornecedor_cnpj = fornecedor_cnpj or fornecedor.get("cnpj_cpf_idgener")

    return {
        "id": raw.get("id"),
        "numero": raw.get("numero"),
        "objeto": raw.get("objeto"),
        "orgao_codigo": orgao_codigo,
        "orgao_nome": orgao_nome,
        "unidade_codigo": unidade_codigo,
        "unidade_nome": unidade_nome,
        "fornecedor": fornecedor_nome,
        "cnpj_fornecedor": fornecedor_cnpj,
        "tipo": raw.get("tipo"),
        "categoria": raw.get("categoria"),
        "modalidade": raw.get("modalidade"),
        "data_assinatura": raw.get("data_assinatura"),
        "vigencia_inicio": raw.get("vigencia_inicio"),
        "vigencia_fim": raw.get("vigencia_fim"),
        "valor_global": raw.get("valor_global"),
        "valor_parcela": raw.get("valor_parcela"),
        "valor_acumulado": raw.get("valor_acumulado"),
        "situacao": raw.get("situacao"),
        "receita_despesa": raw.get("receita_despesa"),
    }


def slim_empenho(raw: dict) -> dict:
    """Slim an empenho record."""
    return {
        "id": raw.get("id"),
        "numero": raw.get("numero"),
        "credor": raw.get("credor"),
        "fonte_recurso": raw.get("fonte_recurso"),
        "programa_trabalho": raw.get("programa_trabalho"),
        "natureza_despesa": raw.get("naturezadespesa"),
        "empenhado": raw.get("empenhado"),
        "liquidado": raw.get("liquidado"),
        "pago": raw.get("pago"),
    }


def slim_fatura(raw: dict) -> dict:
    """Slim a fatura record."""
    return {
        "id": raw.get("id"),
        "numero": raw.get("numero"),
        "emissao": raw.get("emissao"),
        "vencimento": raw.get("vencimento"),
        "valor": raw.get("valor"),
        "juros": raw.get("juros"),
        "multa": raw.get("multa"),
        "glosa": raw.get("glosa"),
        "valor_liquido": raw.get("valorliquido"),
        "situacao": raw.get("situacao"),
    }


def slim_historico_contrato(raw: dict) -> dict:
    """Slim a contract history (aditivo/apostilamento) record."""
    forn = raw.get("fornecedor")
    fornecedor_nome = forn.get("nome") if isinstance(forn, dict) else forn
    return {
        "id": raw.get("id"),
        "tipo": raw.get("tipo"),
        "numero": raw.get("numero"),
        "fornecedor": fornecedor_nome,
        "data_assinatura": raw.get("data_assinatura"),
        "vigencia_inicio": raw.get("vigencia_inicio"),
        "vigencia_fim": raw.get("vigencia_fim"),
        "valor_global": raw.get("valor_global"),
        "situacao_contrato": raw.get("situacao_contrato"),
    }


def slim_item_contrato(raw: dict) -> dict:
    """Slim a contract item record."""
    return {
        "tipo_item": raw.get("tipo_item"),
        "codigo_item": raw.get("codigo_item"),
        "descricao": raw.get("descricao_item"),
        "unidade": raw.get("unidade"),
        "quantidade": raw.get("quantidade"),
        "valor_unitario": raw.get("valor_unitario"),
        "valor_total": raw.get("valor_total"),
    }


def slim_terceirizado(raw: dict) -> dict:
    """Slim a terceirizado record."""
    return {
        "id": raw.get("id"),
        "funcao": raw.get("funcao"),
        "jornada": raw.get("jornada"),
        "salario": raw.get("salario"),
        "custo": raw.get("custo"),
        "escolaridade": raw.get("escolaridade"),
        "situacao": raw.get("situacao"),
    }


# ── Contratos.gov.br — new views (Fase 1) ──────────────────────────────────


def slim_garantia(raw: dict) -> dict:
    """Slim a guarantee record."""
    return {
        "id": raw.get("id"),
        "tipo": raw.get("tipo"),
        "valor": raw.get("valor"),
        "data_inicio": raw.get("data_inicio"),
        "data_fim": raw.get("data_fim"),
        "fornecedor": raw.get("fornecedor"),
        "situacao": raw.get("situacao"),
    }


def slim_cronograma(raw: dict) -> dict:
    """Slim a schedule/event record."""
    return {
        "id": raw.get("id"),
        "data": raw.get("data"),
        "descricao": raw.get("descricao"),
        "previsao": raw.get("previsao"),
        "realizado": raw.get("realizado"),
    }


def slim_ocorrencia(raw: dict) -> dict:
    """Slim an occurrence record."""
    return {
        "id": raw.get("id"),
        "tipo": raw.get("tipo"),
        "descricao": raw.get("descricao"),
        "data": raw.get("data"),
        "situacao": raw.get("situacao"),
    }


def slim_publicacao(raw: dict) -> dict:
    """Slim a publication record."""
    return {
        "id": raw.get("id"),
        "veiculo": raw.get("veiculo"),
        "data": raw.get("data"),
        "resumo": raw.get("resumo"),
        "link": raw.get("link"),
    }


def slim_responsavel(raw: dict) -> dict:
    """Slim a responsable record."""
    return {
        "id": raw.get("id"),
        "nome": raw.get("nome"),
        "tipo": raw.get("tipo"),
        "cargo": raw.get("cargo"),
        "data_inicio": raw.get("data_inicio"),
        "data_fim": raw.get("data_fim"),
    }


def slim_preposto(raw: dict) -> dict:
    """Slim a supplier representative record."""
    return {
        "id": raw.get("id"),
        "nome": raw.get("nome"),
        "cpf": raw.get("cpf"),
        "email": raw.get("email"),
        "telefone": raw.get("telefone"),
    }


def slim_despesa_acessoria(raw: dict) -> dict:
    """Slim an ancillary expense record."""
    return {
        "id": raw.get("id"),
        "descricao": raw.get("descricao"),
        "valor": raw.get("valor"),
        "data": raw.get("data"),
    }


def slim_arquivo_contrato(raw: dict) -> dict:
    """Slim a contract file/attachment record."""
    return {
        "id": raw.get("id"),
        "nome": raw.get("nome"),
        "tipo": raw.get("tipo"),
        "data": raw.get("data"),
        "tamanho": raw.get("tamanho"),
    }


def slim_domicilio_bancario(raw: dict) -> dict:
    """Slim bank account details."""
    return {
        "banco": raw.get("banco"),
        "agencia": raw.get("agencia"),
        "conta": raw.get("conta"),
        "tipo": raw.get("tipo"),
    }


# ── Dados Abertos — additional views ─────────────────────────────────────────


def slim_licitacao(raw: dict) -> dict:
    """Slim a legacy licitação record (SIASG, law 8.666)."""
    return {
        "id_compra": raw.get("id_compra"),
        "identificador": raw.get("identificador"),
        "numero_processo": raw.get("numero_processo"),
        "uasg": raw.get("uasg"),
        "modalidade": raw.get("nome_modalidade"),
        "numero_aviso": raw.get("numero_aviso"),
        "situacao": raw.get("situacao_aviso"),
        "objeto": raw.get("objeto"),
        "valor_estimado": _to_float(raw.get("valor_estimado_total")),
        "valor_homologado": _to_float(raw.get("valor_homologado_total")),
        "numero_itens": raw.get("numero_itens"),
        "data_publicacao": raw.get("data_publicacao"),
        "data_abertura": raw.get("data_abertura_proposta"),
        "responsavel": raw.get("nome_responsavel"),
        "funcao_responsavel": raw.get("funcao_responsavel"),
    }


def _strip_nulls(d: dict) -> dict:
    """Remove keys with None, 0-as-null, empty-string, or false-status values.

    CNBS returns ``codigoClasse: 0``, ``nomeSubclasse: null``, etc. for
    unused hierarchy levels.  Stripping them keeps agent output clean.
    """
    # Sentinel values that mean "not applicable / no data"
    _NULL_SENTINELS: set[object] = {None, "", False}
    return {
        k: v for k, v in d.items()
        if v not in _NULL_SENTINELS
        and not (isinstance(v, int) and v == 0 and k.startswith("codigo_"))
    }


def slim_servico(raw: dict, *, fonte: str = "CATSER") -> dict:
    """Slim a CATSER service record from CATSER API or CNBS.

    CNBS ``/servico/v1/palavra`` returns full hierarchy with names
    (``nomeSessao``, ``nomeDivisao``, ``nomeGrupo``, ``nomeClasse``)
    while the CATSER API only returns codes.
    """
    if fonte == "CNBS":
        # CNBS field names (camelCase, richer — includes hierarchy names)
        svc: dict = {
            "codigo": raw.get("codigoServico") or raw.get("codigo"),
            "nome": raw.get("nomeServicoAcentuado") or raw.get("descricaoServicoAcentuado") or raw.get("nome"),
            "descricao": raw.get("descricaoServicoAcentuado"),
            "codigo_secao": raw.get("codigoSessao"),
            "nome_secao": raw.get("nomeSessao"),
            "codigo_divisao": raw.get("codigoDivisao"),
            "nome_divisao": raw.get("nomeDivisao"),
            "codigo_grupo": raw.get("codigoGrupo"),
            "nome_grupo": raw.get("nomeGrupo"),
            "codigo_classe": raw.get("codigoClasse"),
            "nome_classe": raw.get("nomeClasse"),
            "status": raw.get("statusServico") or raw.get("status"),
            "fonte": "CNBS",
        }
    else:
        # CATSER Dados Abertos API (codes only)
        svc = {
            "codigo": raw.get("codigoServico"),
            "nome": raw.get("nomeServico"),
            "codigo_secao": raw.get("codigoSecao"),
            "codigo_divisao": raw.get("codigoDivisao"),
            "codigo_grupo": raw.get("codigoGrupo"),
            "codigo_classe": raw.get("codigoClasse"),
            "status": raw.get("statusServico"),
        }
    return _strip_nulls(svc)


# ── Mermaid ──────────────────────────────────────────────────────────────────


def build_mermaid_dashboard(
    orgao_nome: str,
    total_contratos: int,
    total_atas: int,
    total_fornecedores: int,
    valor_total: Optional[float],
    top_fornecedores: list[dict],
    max_suppliers: int = 8,
) -> str:
    """Build a Mermaid diagram for the dashboard overview."""
    valor_str = f"R$ {valor_total:,.0f}" if valor_total else "N/D"
    lines = [
        "graph TD",
        f'    Orgao("{orgao_nome}")',
        f'    Contratos["Contratos: {total_contratos}"]',
        f'    Atas["Atas: {total_atas}"]',
        f'    Valor["Valor Total: {valor_str}"]',
        f"    Orgao --> Contratos",
        f"    Orgao --> Atas",
        f"    Contratos --> Valor",
    ]
    for i, f in enumerate(top_fornecedores[:max_suppliers]):
        nome = (f.get("nome") or f.get("razao_social") or "?")[:25]
        lines.append(f'    F{i}["{nome}"]')
        lines.append(f"    Contratos --> F{i}")
    return "\n".join(lines)


def build_mermaid_contrato(
    orgao_nome: str,
    fornecedor_nome: str,
    itens: list[dict],
    valor_total: Optional[float],
) -> str:
    """Build a Mermaid diagram for a single contract."""
    valor_str = f"R$ {valor_total:,.0f}" if valor_total else ""
    fornecedor_label = f"{fornecedor_nome[:30]}"
    lines = [
        "graph LR",
        f'    Orgao("{orgao_nome}")',
        f'    Fornecedor("{fornecedor_label}")',
        f'    Valor["{valor_str}"]',
        f"    Orgao -->|contrata| Fornecedor",
        f"    Fornecedor -->|valor| Valor",
    ]
    for i, item in enumerate(itens[:5]):
        desc = (item.get("descricao") or item.get("nome") or "?")[:20]
        qtd = int(item.get("quantidade") or 0)
        lines.append(f'    Item{i}["{desc} x{qtd}"]')
        lines.append(f"    Fornecedor -->|entrega| Item{i}")
    return "\n".join(lines)
