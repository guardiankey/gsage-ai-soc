"""gSage AI — Compras.gov.br + Contratos.gov.br procurement tool.

Query Brazilian federal procurement data from Dados Abertos Compras.gov.br
and Contratos.gov.br: contracts, bids, price registration acts, suppliers,
material catalog, price research, empenhos, faturas, and contract history.
Includes an aggregated dashboard view for quick situational awareness.

For PNCP (Lei 14.133/2021) native queries, see ``pncp_contratos.py``.

Permission: ``gov:compras:comprasgovbr:read``.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from datetime import date
from statistics import median, stdev
from typing import ClassVar, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.mcp_server.tools.enterprise.gov.compras._client import (
    CNBSClient,
    ComprasClient,
    ComprasError,
)
from src.mcp_server.tools.enterprise.gov.compras._client_contratosgovbr import (
    ContratosGovbrClient,
    ContratosGovbrError,
)
from src.mcp_server.tools.enterprise.gov.compras._constants import (
    _CACHE_TTL_CATMAT,
    _CACHE_TTL_CATSER,
    _CACHE_TTL_CONTRATOS,
    _CACHE_TTL_DETALHE,
    _CACHE_TTL_ESTRUTURA,
    _CACHE_TTL_TRANSPARENCIA,
    _CSV_THRESHOLD,
    _DEFAULT_MAX_RESULTS,
)
from src.mcp_server.tools.enterprise.gov.compras._dashboard import build_dashboard
from src.mcp_server.tools.enterprise.gov.compras._views import (
    build_mermaid_contrato,
    slim_arp,
    slim_arquivo_contrato,
    slim_contrato,
    slim_contrato_detalhe,
    slim_contrato_ug,
    slim_cronograma,
    slim_despesa_acessoria,
    slim_domicilio_bancario,
    slim_empenho,
    slim_fatura,
    slim_fornecedor,
    slim_garantia,
    slim_historico_contrato,
    slim_item_contrato,
    slim_licitacao,
    slim_ocorrencia,
    slim_preco,
    slim_preposto,
    slim_publicacao,
    slim_responsavel,
    slim_servico,
    slim_terceirizado,
    slim_uasg,
)
from src.mcp_server.tools.result_export import (
    AGENT_PREVIEW_ROWS,
    build_agent_payload,
    export_to_csv,
    store_export_artifact,
)
from src.shared.cache.decorator import cached
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

# Maximum rows per section inlined in detalhar_contrato_completo.
# Sections larger than this are exported as CSV with a preview.
_PREVIEW_LIMIT: int = 20

# ── Actions ──────────────────────────────────────────────────────────────────

_ACTIONS = frozenset({
    # Dados Abertos — existing
    "dashboard",
    "buscar_orgao",
    "buscar_materiais",
    "listar_materiais_por_pdm",
    "listar_contratos",
    "detalhar_contrato",
    "listar_contratacoes",
    "listar_fornecedores",
    "listar_atas",
    "pesquisar_precos",
    "listar_pgc",
    # Dados Abertos — new (legacy SIASG, CATSER)
    "listar_licitacoes",
    "listar_pregoes",
    "listar_dispensas",
    "buscar_servicos",
    "listar_servicos_por_grupo",
    # Contratos.gov.br — existing
    "listar_contratos_ug",
    "detalhar_contrato_id",
    "listar_empenhos",
    "listar_itens_contrato",
    "listar_faturas",
    "listar_historico_contrato",
    "listar_terceirizados",
    # Contratos.gov.br — novos (Fase 1)
    "listar_garantias_contrato",
    "listar_cronograma_contrato",
    "listar_ocorrencias_contrato",
    "listar_publicacoes_contrato",
    "listar_responsaveis_contrato",
    "listar_prepostos_contrato",
    "listar_despesas_acessorias",
    "listar_arquivos_contrato",
    "listar_domicilio_bancario",
    "listar_contratos_inativos_ug",
    "buscar_contrato_ug_origem",
    # Contratos.gov.br — helper consolidado
    "detalhar_contrato_completo",
    # Dados Abertos — busca por fornecedor
    "buscar_contratos_fornecedor",
})


# ── Cached helpers ───────────────────────────────────────────────────────────


@cached(
    ttl=_CACHE_TTL_ESTRUTURA,
    scope="global",
    key_fn=lambda *_args, **_kwargs: "compras:uasg:list:v1",
    logical_name="compras",
)
async def _get_uasg_cache(
    *, session: AsyncSession,  # noqa: ARG001
) -> list[dict]:
    """Fetch and cache the full UASG list."""
    client = ComprasClient()
    raw = await client.get_uasg()
    return [slim_uasg(r) for r in raw]


@cached(
    ttl=_CACHE_TTL_TRANSPARENCIA,
    scope="global",
    key_fn=lambda cpf_cnpj, max_results=500, **_: (
        f"transparencia:contratos:{cpf_cnpj}:v2:mr{max_results}"
    ),
    logical_name="compras_contratos_fornecedor",
)
async def _fetch_contratos_fornecedor_cached(
    *, cpf_cnpj: str, max_results: int = 500, config_json: str, session: AsyncSession,
) -> dict:
    """Fetch contracts for a supplier CPF/CNPJ, cached for 6 hours.

    The Portal da Transparência API returns 15 items per page with no
    pagination envelope.  This helper fetches up to *max_results* and
    caches the raw rows + pagination metadata.

    Returns ``{"rows": [...], "meta": {...}}``.
    """
    from src.mcp_server.tools.enterprise.gov.compras._client_transparencia import (  # noqa: PLC0415
        TransparenciaClient,
    )

    config = json.loads(config_json)
    client = TransparenciaClient(config)
    rows, meta = await client.buscar_contratos_por_fornecedor(
        cpf_cnpj, max_results=max_results,
    )
    return {"rows": rows, "meta": meta}


@cached(
    ttl=_CACHE_TTL_CATSER,
    scope="global",
    key_fn=lambda query_hash="", max_results=50, **_: (
        f"compras:catser:search:v1:{query_hash}:mr{max_results}"
    ),
    logical_name="compras_catser",
)
async def _fetch_servicos_cached(
    *,
    query_hash: str,
    query: dict,
    max_results: int,
    session: AsyncSession,  # noqa: ARG001
) -> list[dict]:
    """Fetch CATSER service items from Compras.gov.br, cached for 24 h."""
    client = ComprasClient()
    raw = await client.get_itens_servico(max_results=max_results, **query)
    return [slim_servico(r) for r in raw]


# ── Tool ─────────────────────────────────────────────────────────────────────


class ComprasGovbrTool(BaseTool):
    """Query Brazilian federal procurement data (Compras.gov.br + Contratos.gov.br).

    Actions
    -------
    - ``dashboard`` — aggregated view of an org's procurement.
    - ``buscar_orgao`` — locate a UASG/org by code or SIORG id.
    - ``buscar_materiais`` — search CATMAT material **groups** (PDM codes) by name.
      Returns PDM codes. Use with ``listar_materiais_por_pdm`` to find specific items.
      ⚠️ CATMAT groups are broad — verify the description before using.
      Example: "notebook" may return unrelated items; try "microcomputador" (PDM 6661) instead.
    - ``listar_materiais_por_pdm`` — list **all CATMAT items** within a PDM group.
      Use the ``codigo`` from ``buscar_materiais`` as ``codigo_pdm``.
      Returns item codes (``codigo_item``) for use in ``pesquisar_precos``.
    - ``listar_contratos`` — list contracts for an org (C1).
    - ``detalhar_contrato`` — full contract details with items and supplier (C2+C4).
    - ``listar_contratacoes`` — list PNCP contratações (Compras.gov.br module).
    - ``listar_fornecedores`` — supplier lookup by CNPJ/CPF.
    - ``listar_atas`` — list price registration acts (ARP).
    - ``pesquisar_precos`` — price research for a **CATMAT or CATSER item code**.
      Use ``codigo_item`` from ``listar_materiais_por_pdm`` (CATMAT) or
      ``codigo`` from ``buscar_servicos`` (CATSER).
      NOT the PDM group code (PDM returns 0 results).
      Results show actual purchase prices — check ``descricaoItem`` to confirm.
    - ``listar_pgc`` — procurement planning for an org/year.
    - ``listar_licitacoes`` — legacy SIASG bids (law 8.666, up to 2020).
    - ``listar_pregoes`` — electronic auctions (Pregão).
    - ``listar_dispensas`` — direct awards / exemptions.
    - ``buscar_servicos`` — search CATSER service codes by name or code.
      Text search uses CNBS (Serpro) dedicated service endpoint first —
      reliable server-side matching. Falls back to CATSER API with
      client-side filtering. Code search uses CATSER API directly.
      CATSER has a 4-level hierarchy: Seção → Divisão → Grupo → Classe → Serviço.
      Results include hierarchy fields for browsing related services.
    - ``listar_servicos_por_grupo`` — list **all CATSER services** within a
      hierarchy level. Provide at least one of: ``codigo_secao``,
      ``codigo_divisao``, ``codigo_grupo``, ``codigo_classe``.
      Use optional ``palavra`` for client-side name filtering (substring,
      case-insensitive) — more reliable than ``buscar_servicos`` for
      text search because the API does not filter by name server-side.
      Use codes from ``buscar_servicos`` results to browse the catalogue
      at any depth (Seção → Divisão → Grupo → Classe).
      Returns service codes (``codigo``) for use in ``pesquisar_precos``.
    - ``listar_contratos_ug`` — active contracts by UG (Contratos.gov.br).
    - ``detalhar_contrato_id`` — contract detail by numeric ID (Contratos.gov.br).
    - ``listar_empenhos`` — budget commitments for a contract (Contratos.gov.br).
    - ``listar_itens_contrato`` — contract items (Contratos.gov.br).
    - ``listar_faturas`` — invoices for a contract (Contratos.gov.br).
    - ``listar_historico_contrato`` — amendments/addendums (Contratos.gov.br).
    - ``listar_terceirizados`` — outsourced workers (Contratos.gov.br).
    - ``listar_garantias_contrato`` — guarantees/warranties (Contratos.gov.br).
    - ``listar_cronograma_contrato`` — execution schedule (Contratos.gov.br).
    - ``listar_ocorrencias_contrato`` — occurrences/delays (Contratos.gov.br).
    - ``listar_publicacoes_contrato`` — DOU publications (Contratos.gov.br).
    - ``listar_responsaveis_contrato`` — responsables (Contratos.gov.br).
    - ``listar_prepostos_contrato`` — supplier representatives (Contratos.gov.br).
    - ``listar_despesas_acessorias`` — ancillary expenses (Contratos.gov.br).
    - ``listar_arquivos_contrato`` — attached documents (Contratos.gov.br).
    - ``listar_domicilio_bancario`` — bank account details (Contratos.gov.br).
    - ``listar_contratos_inativos_ug`` — inactive contracts by UG (Contratos.gov.br).
    - ``buscar_contrato_ug_origem`` — find contract by UASG + number/year (Contratos.gov.br).
    - ``detalhar_contrato_completo`` — **all** sub-resources in a single call (Contratos.gov.br).
    - ``buscar_contratos_fornecedor`` — search contracts by supplier CPF/CNPJ (Dados Abertos).

    Permission: ``gov:compras:comprasgovbr:read``.
    """

    name: ClassVar[str] = "comprasgovbr"
    version: ClassVar[str] = "2.0.0"
    summary: ClassVar[str] = (
        "Query Brazilian federal procurement data via Compras.gov.br and "
        "Contratos.gov.br: contracts, bids, price registration, suppliers, "
        "material catalog, price research, empenhos, faturas, and aggregated dashboard."
    )
    category: ClassVar[str] = "gov"
    permissions: ClassVar[list[str]] = ["gov:compras:comprasgovbr:read"]
    rate_limit_per_minute: ClassVar[int] = 30
    timeout_seconds: ClassVar[int] = 180
    use_circuit_breaker: ClassVar[bool] = False
    requires_approval: ClassVar[bool] = False
    supports_multiple_configs: ClassVar[bool] = False
    requires_config: ClassVar[bool] = False

    params_schema: ClassVar[dict] = {
        "type": "object",
        "required": ["action"],
        "properties": {
            "action": {
                "type": "string",
                "enum": sorted(_ACTIONS),
                "description": "Which procurement query to perform.",
            },
            "codigo_orgao": {
                "type": "integer",
                "description": (
                    "Compras gov org code. Required for listar_contratos. "
                    "For dashboard and listar_atas, use codigo_uasg instead "
                    "or the tool will auto-resolve. "
                    "Use buscar_orgao(codigo_uasg=...) to discover. "
                    "Example: 20101 = Presidência da República."
                ),
            },
            "codigo_uasg": {
                "type": "string",
                "description": (
                    "[buscar_orgao, listar_contratos, dashboard, listar_atas, "
                    "listar_contratacoes] UASG code. Resolves to org code "
                    "automatically. Example: '110001'."
                ),
            },
            "codigo_unidade_gestora": {
                "type": "string",
                "description": (
                    "[listar_contratos] Unidade Gestora code (optional, "
                    "narrows results to a specific unit within the org). "
                    "Example: '110161'."
                ),
            },
            "codigo_siorg": {
                "type": "string",
                "description": (
                    "[buscar_orgao] SIORG org code to look up the "
                    "corresponding Compras/UASG code. Example: '334'."
                ),
            },
            "cnpj": {
                "type": "string",
                "description": "CNPJ for listar_fornecedores. Example: '00394411000109'.",
            },
            "cpf_cnpj": {
                "type": "string",
                "description": (
                    "[buscar_contratos_fornecedor] CPF (11 digits) or CNPJ "
                    "(14 digits) do fornecedor. Aceita formatado ou só dígitos. "
                    "Exemplos: '00394411000109', '21545863000114'."
                ),
            },
            "id_contrato": {
                "type": "string",
                "description": (
                    "Contract ID for detalhar_contrato. "
                    "Format: 'tipo:codigo' (e.g. 'idCompra:123456')."
                ),
            },
            "palavra": {
                "type": "string",
                "description": (
                    "[buscar_materiais, buscar_servicos, listar_servicos_por_grupo] "
                    "Search term. "
                    "For buscar_materiais: CATMAT searches product "
                    "GROUP names (PDM), not individual items. Try generic terms: "
                    "'microcomputador' (PDM 6661), 'veiculo', 'mesa', 'cadeira', "
                    "'notebook', 'ar condicionado', 'servidor'. If results seem "
                    "unrelated to your search term, the PDM name matched loosely; "
                    "try a different word. ⚠️ buscar_materiais returns a SAMPLE "
                    "of up to 5 items per PDM. To see ALL CATMAT items in a "
                    "group, use listar_materiais_por_pdm(codigo_pdm=X). After "
                    "finding item codes, use pesquisar_precos(codigo_item=...). "
                    "For buscar_servicos: search CATSER services by name. Try terms "
                    "like 'manutenção predial', 'limpeza', 'vigilância', "
                    "'suporte técnico', 'consultoria'. "
                    "For listar_servicos_por_grupo: optional client-side name "
                    "filter within a hierarchy level (e.g. "
                    "listar_servicos_por_grupo(codigo_secao=1, palavra='cloud'))."
                ),
            },
            "codigo_item": {
                "type": "integer",
                "description": (
                    "CATMAT or CATSER item code for pesquisar_precos. "
                    "Obtain via listar_materiais_por_pdm (CATMAT) or "
                    "buscar_servicos (CATSER) — use the 'codigo_item' "
                    "or 'codigo' field from results. "
                    "⚠️ NOT the PDM group code (that returns "
                    "0 results). Example: 469150 for a specific microcomputer "
                    "model within PDM 6661. "
                    "For services, use the CATSER 'codigo' field directly."
                ),
            },
            "codigo_pdm": {
                "type": "integer",
                "description": (
                    "PDM code from buscar_materiais to list all CATMAT items "
                    "in that group. Use listar_materiais_por_pdm to browse "
                    "the full catalog before picking a material for "
                    "pesquisar_precos. Example: 6661 for microcomputadores."
                ),
            },
            "uf": {
                "type": "string",
                "description": "State abbreviation for pesquisar_precos. Example: 'RJ'.",
            },
            "ano": {
                "type": "integer",
                "description": "Year for listar_pgc. Example: 2025.",
            },
            "ano_aviso": {
                "type": "integer",
                "description": "[listar_dispensas] Year of the aviso de dispensa. Example: 2020.",
            },
            "codigo_modalidade": {
                "type": "integer",
                "minimum": 1,
                "maximum": 9,
                "description": (
                    "[listar_contratacoes, listar_atas] Modalidade: "
                    "1=Concorrência, 2=Concurso, 3=Leilão, 5=Pregão (default), "
                    "6=Diálogo Competitivo, 8=Dispensa, 9=Inexigibilidade. "
                    "Nota: 4 (Tomada de Preços) e 7 (Convite) são da lei "
                    "8.666 e não funcionam nestes endpoints (14.133/2021)."
                ),
            },
            "vigencia_min": {
                "type": "string",
                "description": "Start date filter (YYYY-MM-DD). Also accepts YYYYMMDD and DD/MM/YYYY.",
            },
            "vigencia_max": {
                "type": "string",
                "description": "End date filter (YYYY-MM-DD). Also accepts YYYYMMDD and DD/MM/YYYY.",
            },
            "data_publicacao_inicial": {
                "type": "string",
                "description": "[listar_licitacoes, listar_pregoes] Start publication date (YYYY-MM-DD, YYYYMMDD, or DD/MM/YYYY).",
            },
            "data_publicacao_final": {
                "type": "string",
                "description": "[listar_licitacoes, listar_pregoes] End publication date (YYYY-MM-DD, YYYYMMDD, or DD/MM/YYYY).",
            },
            "unidade_codigo": {
                "type": "integer",
                "description": "[listar_contratos_ug, listar_contratos_inativos_ug] Unidade Gestora (UG) code. Example: 110161.",
            },
            "contrato_id": {
                "type": "integer",
                "description": (
                    "[detalhar_contrato_id, listar_empenhos, listar_itens_contrato, "
                    "listar_faturas, listar_historico_contrato, listar_terceirizados, "
                    "listar_garantias_contrato, listar_cronograma_contrato, "
                    "listar_ocorrencias_contrato, listar_publicacoes_contrato, "
                    "listar_responsaveis_contrato, listar_prepostos_contrato, "
                    "listar_despesas_acessorias, listar_arquivos_contrato, "
                    "listar_domicilio_bancario, detalhar_contrato_completo] "
                    "Numeric contract ID from Contratos.gov.br. Example: 2957."
                ),
            },
            "codigo_uasg": {
                "type": "integer",
                "description": (
                    "[buscar_contrato_ug_origem] UASG origin code. "
                    "Example: 110001."
                ),
            },
            "numero_contrato": {
                "type": "string",
                "description": (
                    "[buscar_contrato_ug_origem] Contract number/year "
                    "format. Example: '00022/2025'."
                ),
            },
            "codigo_servico": {
                "type": "integer",
                "description": "[buscar_servicos] CATSER service code. Example: 1.",
            },
            "codigo_secao": {
                "type": "integer",
                "description": (
                    "[listar_servicos_por_grupo] CATSER section code "
                    "(level 1 of hierarchy: Seção). Example: 1."
                ),
            },
            "codigo_divisao": {
                "type": "integer",
                "description": (
                    "[listar_servicos_por_grupo] CATSER division code "
                    "(level 2: Divisão). Use with codigo_secao to narrow."
                ),
            },
            "codigo_grupo": {
                "type": "integer",
                "description": (
                    "[listar_servicos_por_grupo] CATSER group code "
                    "(level 3: Grupo). Use with codigo_secao and/or"
                    " codigo_divisao to narrow."
                ),
            },
            "codigo_classe": {
                "type": "integer",
                "description": (
                    "[listar_servicos_por_grupo] CATSER class code "
                    "(level 4: Classe). Most specific level before "
                    "individual services."
                ),
            },
            "max_results": {
                "type": "integer",
                "minimum": 1,
                "maximum": 500,
                "default": 100,
                "description": (
                    f"Max results to return (default 50). "
                    "Results exceeding the inline preview limit (30) are "
                    "auto-exported to CSV."
                ),
            },
            "force_refresh": {
                "type": "boolean",
                "description": "Bypass cache.",
            },
            "export_csv": {
                "type": "boolean",
                "default": False,
                "description": (
                    "Force CSV export even without overflow. "
                    "CSV is auto-generated when result exceeds the inline preview limit."
                ),
            },
            "vigencia_min": {
                "type": "string",
                "description": (
                    "[buscar_contratos_fornecedor] Filter contracts with "
                    "start date >= this value (YYYY-MM-DD, YYYYMMDD, or DD/MM/YYYY). "
                    "Client-side filter applied after fetching all pages."
                ),
            },
            "vigencia_max": {
                "type": "string",
                "description": (
                    "[buscar_contratos_fornecedor] Filter contracts with "
                    "end date <= this value (YYYY-MM-DD, YYYYMMDD, or DD/MM/YYYY). "
                    "Client-side filter applied after fetching all pages."
                ),
            },
            "filtro_orgao": {
                "type": "string",
                "description": (
                    "[buscar_contratos_fornecedor] Filter by contracting "
                    "agency name (case-insensitive substring match). "
                    "Client-side filter."
                ),
            },
            "filtro_objeto": {
                "type": "string",
                "description": (
                    "[buscar_contratos_fornecedor] Filter by term in the "
                    "contract object/description (case-insensitive substring match). "
                    "Client-side filter."
                ),
            },
        },
        "additionalProperties": False,
    }

    config_schema: ClassVar[Optional[dict]] = {
        "type": "object",
        "properties": {
            "api_key": {
                "type": "string",
                "description": (
                    "API key for Portal da Transparência (sanções CEIS/CNEP/CEPIM/CEAF). "
                    "Obtain at https://portaldatransparencia.gov.br/api-de-dados"
                ),
            },
        },
    }
    config_defaults: ClassVar[dict] = {}
    state_schema: ClassVar[Optional[dict]] = None
    state_defaults: ClassVar[dict] = {}
    reset_policy: ClassVar[str] = "never"

    # ── Execute ───────────────────────────────────────────────────────────

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        t0 = time.monotonic()
        action = (params.get("action") or "").strip()
        if action not in _ACTIONS:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "INVALID_PARAMS",
                f"action must be one of {sorted(_ACTIONS)}; got {action!r}.",
                execution_time_ms=elapsed,
            )

        try:
            data = await self._dispatch(action, params, agent_context, config)
        except ComprasError as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                f"API_ERROR_{exc.code}", exc.message,
                execution_time_ms=elapsed,
            )
        except ContratosGovbrError as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                f"CONTRATOSGOVBR_ERROR_{exc.code}", exc.message,
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            log.exception("compras(%s): unexpected error", action)
            elapsed = int((time.monotonic() - t0) * 1000)
            msg = str(exc) or type(exc).__name__
            return self._failure(
                "INTERNAL_ERROR", msg, execution_time_ms=elapsed,
            )

        elapsed = int((time.monotonic() - t0) * 1000)
        return self._success(data={"action": action, **data}, execution_time_ms=elapsed)

    # ── Dispatch ──────────────────────────────────────────────────────────

    async def _dispatch(
        self, action: str, params: dict, ctx: AgentContext, config: dict,
    ) -> dict:
        client = ComprasClient()

        if action == "dashboard":
            return await self._do_dashboard(client, ctx, params)
        elif action == "buscar_orgao":
            return await self._do_buscar_orgao(ctx, params)
        elif action == "buscar_contratos_fornecedor":
            return await self._do_buscar_contratos_fornecedor(ctx, params, config)
        elif action == "buscar_materiais":
            return await self._do_buscar_materiais(ctx, params)
        elif action == "listar_materiais_por_pdm":
            return await self._do_listar_materiais_por_pdm(ctx, params)
        elif action == "listar_contratos":
            return await self._do_listar_contratos(client, ctx, params)
        elif action == "detalhar_contrato":
            return await self._do_detalhar_contrato(client, params)
        elif action == "listar_contratacoes":
            return await self._do_listar_contratacoes(client, params)
        elif action == "listar_fornecedores":
            return await self._do_listar_fornecedores(client, params)
        elif action == "listar_atas":
            return await self._do_listar_atas(client, params)
        elif action == "pesquisar_precos":
            return await self._do_pesquisar_precos(client, params)
        elif action == "listar_pgc":
            return await self._do_listar_pgc(client, params)
        # ── New Dados Abertos actions ─────────────────────────────────────
        elif action == "listar_licitacoes":
            return await self._do_listar_licitacoes(client, params)
        elif action == "listar_pregoes":
            return await self._do_listar_pregoes(client, params)
        elif action == "listar_dispensas":
            return await self._do_listar_dispensas(client, params)
        elif action == "buscar_servicos":
            return await self._do_buscar_servicos(client, params)
        elif action == "listar_servicos_por_grupo":
            return await self._do_listar_servicos_por_grupo(client, params)
        # ── Contratos.gov.br actions ──────────────────────────────────────
        elif action == "listar_contratos_ug":
            return await self._do_listar_contratos_ug(params)
        elif action == "detalhar_contrato_id":
            return await self._do_detalhar_contrato_id(params)
        elif action == "listar_empenhos":
            return await self._do_listar_empenhos(params)
        elif action == "listar_itens_contrato":
            return await self._do_listar_itens_contrato(params)
        elif action == "listar_faturas":
            return await self._do_listar_faturas(params)
        elif action == "listar_historico_contrato":
            return await self._do_listar_historico_contrato(params)
        elif action == "listar_terceirizados":
            return await self._do_listar_terceirizados(params)
        elif action in (
            "listar_garantias_contrato", "listar_cronograma_contrato",
            "listar_ocorrencias_contrato", "listar_publicacoes_contrato",
            "listar_responsaveis_contrato", "listar_prepostos_contrato",
            "listar_despesas_acessorias", "listar_arquivos_contrato",
            "listar_domicilio_bancario",
        ):
            return await self._do_listar_detalhe_contrato_simples(action, params)
        elif action == "listar_contratos_inativos_ug":
            return await self._do_listar_contratos_inativos_ug(params)
        elif action == "buscar_contrato_ug_origem":
            return await self._do_buscar_contrato_ug_origem(params)
        elif action == "detalhar_contrato_completo":
            return await self._do_detalhar_contrato_completo(params, ctx)
        else:
            raise ValueError(f"Unknown action: {action}")

    # ── Helpers ───────────────────────────────────────────────────────────

    def _require(self, params: dict, field: str) -> int:
        val = params.get(field)
        if val is None:
            raise ComprasError(400, f"'{field}' is required for this action.")
        return int(val)

    def _max_results(self, params: dict) -> int:
        return min(int(params.get("max_results") or _DEFAULT_MAX_RESULTS), 500)

    @staticmethod
    def _siorg_hint(codigo_orgao: object) -> Optional[str]:
        """Warn when *codigo_orgao* looks like a SIORG code, not Compras."""
        try:
            c = int(str(codigo_orgao))
        except (ValueError, TypeError):
            return None
        if c < 1000:
            return (
                f"Code {c} looks like a SIORG code (org structure), "
                "not a Compras code (procurement). SIORG codes < 1000. "
                "Use buscar_orgao(codigo_uasg=...) to find the correct "
                "Compras code, or buscar_orgao(codigo_siorg=...) to "
                "look up by SIORG code."
            )
        return None

    async def _maybe_csv(
        self, rows: list[dict], prefix: str, params: dict, ctx: AgentContext,
    ) -> dict:
        """Generate CSV artifact if row count exceeds threshold."""
        if len(rows) <= _CSV_THRESHOLD and not params.get("export_csv"):
            return {}
        from src.mcp_server.tools.result_export import build_agent_payload
        payload = await build_agent_payload(
            tool=self, rows=rows,
            export_csv=True,
            export_json=bool(params.get("export_json")),
            filename_prefix=f"compras_{prefix}",
            agent_context=ctx,
        )
        return {"artifacts": payload.get("artifacts"), "agent_hint": payload.get("agent_hint")}

    # ── Actions ───────────────────────────────────────────────────────────

    async def _do_dashboard(
        self, client: ComprasClient, ctx: AgentContext, params: dict,
    ) -> dict:
        """Aggregated procurement dashboard. Accepts codigo_orgao or codigo_uasg."""
        codigo_uasg = params.get("codigo_uasg")
        codigo_orgao = params.get("codigo_orgao")

        # Resolve UASG → org code if needed
        use_uasg: Optional[str] = None
        if codigo_uasg and not codigo_orgao:
            raw = await client.get_uasg(codigoUasg=str(codigo_uasg))
            if raw:
                codigo_orgao = int(raw[0].get("codigoOrgao", 0))
                use_uasg = str(codigo_uasg)
            if not codigo_orgao:
                raise ComprasError(400, f"Could not resolve UASG '{codigo_uasg}' to an org code.")
        if not codigo_orgao:
            raise ComprasError(400, "'codigo_orgao' or 'codigo_uasg' is required for dashboard.")

        data = await build_dashboard(client, int(codigo_orgao), codigo_uasg=use_uasg)

        # When filtering by UASG, also fetch active contracts from
        # Contratos.gov.br (more complete data than Dados Abertos).
        if use_uasg:
            try:
                cg = ContratosGovbrClient()
                cg_raw = await cg.listar_contratos_ug(int(use_uasg))
                if cg_raw:
                    data["contratos_ug"] = [slim_contrato_ug(r) for r in cg_raw]
                    data["total_contratos_ug"] = len(cg_raw)
            except Exception as exc:
                data["errors"] = data.get("errors") or []
                data["errors"].append(f"Contratos.gov.br: {exc}")

        # Add CSV for large result sets
        if len(data.get("contratos_recentes", [])) > _CSV_THRESHOLD:
            csv_info = await self._maybe_csv(
                data.get("contratos_recentes", []),
                "dashboard_contratos", params,
                ctx,
            )
            data.update(csv_info)
        # Add helpful agent hint
        siorg_hint = self._siorg_hint(codigo_orgao)
        data["siorg_hint"] = siorg_hint
        if not data.get("errors"):
            data["agent_hint"] = (
                "Use listar_contratos(codigo_orgao=...) para ver todos os contratos. "
                "Use detalhar_contrato(id='...') para ver itens de um contrato específico."
            )
        return data

    async def _do_buscar_orgao(
        self, ctx: AgentContext, params: dict,
    ) -> dict:
        """Locate org/UASG by code, CNPJ, SIORG, or name. Results are cached."""
        from src.mcp_server.tools.base import _tool_session_ctx
        session = _tool_session_ctx.get()

        codigo_uasg = str(params.get("codigo_uasg") or "").strip()
        codigo_siorg = str(params.get("codigo_siorg") or "").strip()
        cnpj = str(params.get("cnpj") or "").strip()
        nome = str(params.get("nome") or "").strip()

        results: list[dict] = []

        # 1) UASG lookup — Dados Abertos (fast, single-call)
        if codigo_uasg:
            client = ComprasClient()
            raw = await client.get_uasg(codigoUasg=codigo_uasg)
            results = [slim_uasg(r) for r in raw]

        # 2) CNPJ lookup — Contratos.gov.br /orgaos
        elif cnpj:
            cg_client = ContratosGovbrClient()
            orgaos = await cg_client.listar_orgaos()
            results = [
                {"cnpj": o.get("cnpj"), "nome": o.get("orgao"),
                 "uasg": None, "codigo_orgao": o.get("codigo"),
                 "fonte": "Contratos.gov.br"}
                for o in orgaos if o.get("cnpj") == cnpj
            ]

        # 3) SIORG lookup — Dados Abertos cache
        elif codigo_siorg and session is not None:
            all_orgs = await _get_uasg_cache(session=session)
            results = [
                o for o in all_orgs
                if str(o.get("codigo_siorg", "")) == codigo_siorg
            ]

        # 4) Name/razão social — Contratos.gov.br /unidades (fallback /orgaos)
        elif nome:
            cg_client = ContratosGovbrClient()
            orgaos, unidades = await asyncio.gather(
                cg_client.listar_orgaos(),
                cg_client.listar_unidades(),
                return_exceptions=True,
            )
            nome_lower = nome.lower()
            if isinstance(orgaos, list):
                for o in orgaos:
                    if nome_lower in (o.get("orgao") or "").lower():
                        results.append({
                            "cnpj": o.get("cnpj"),
                            "nome": o.get("orgao"),
                            "uasg": None,
                            "codigo_orgao": o.get("codigo"),
                            "fonte": "Contratos.gov.br",
                        })
            if isinstance(unidades, list):
                for u in unidades:
                    if nome_lower in (u.get("unidade") or "").lower():
                        results.append({
                            "uasg": u.get("codigo"),
                            "nome": u.get("unidade"),
                            "orgao": u.get("orgao"),
                            "cnpj": None,
                            "fonte": "Contratos.gov.br/unidades",
                        })
        else:
            raise ComprasError(400, "Provide 'codigo_uasg', 'cnpj', 'codigo_siorg', or 'nome'.")

        return {
            "orgaos": results[: self._max_results(params)],
            "total": len(results),
            "agent_hint": (
                "Use listar_contratos(codigo_orgao=...) or "
                "dashboard(codigo_orgao=...) with the returned codigo_orgao."
            ) if results else "No results found.",
        }

    # ── buscar_contratos_fornecedor ──────────────────────────────────────

    async def _do_buscar_contratos_fornecedor(
        self, ctx: AgentContext, params: dict, config: dict,
    ) -> dict:
        """Search contracts by supplier CPF/CNPJ — paginated, cached, filtered.

        Uses the **Portal da Transparência** API (via ``TransparenciaClient``)
        which natively supports supplier-CPF/CNPJ lookup.  Also searches
        sanctions (CEIS, CNEP, CEPIM, CEAF).

        Contracts are cached for 6 hours (PostgreSQL, global scope) via the
        ``@cached`` decorator.  Use ``force_refresh=true`` to bypass.

        Client-side filters (``vigencia_min``, ``vigencia_max``,
        ``filtro_orgao``, ``filtro_objeto``) are applied **after** fetching
        all pages so the agent can refine results without new API calls.

        Requires ``api_key`` in tool config (obtain at
        https://portaldatransparencia.gov.br/api-de-dados).
        """
        raw = (params.get("cpf_cnpj") or "").strip()
        if not raw:
            raise ComprasError(400, "'cpf_cnpj' is required.")
        cpf_cnpj = re.sub(r"\D", "", raw)
        if len(cpf_cnpj) not in (11, 14):
            raise ComprasError(
                400,
                f"CPF/CNPJ inválido: '{raw}' — expected 11 (CPF) or 14 (CNPJ) digits after cleaning, got {len(cpf_cnpj)}.",
            )

        from src.mcp_server.tools.enterprise.gov.compras._client_transparencia import (  # noqa: PLC0415
            TransparenciaClient,
        )
        from src.mcp_server.tools.enterprise.gov.compras._views_transparencia import (  # noqa: PLC0415
            slim_contrato_fornecedor,
            slim_sancao,
        )

        t_client = TransparenciaClient(config)
        if not t_client.has_api_key:
            raise ComprasError(
                401,
                "API key do Portal da Transparência não configurada. "
                "Configure TOOL_COMPRASGOVBR__API_KEY no .env "
                "(https://portaldatransparencia.gov.br/api-de-dados).",
            )

        max_results = self._max_results(params)
        force_refresh = bool(params.get("force_refresh", False))
        cache_hit = False

        # ── Fetch contracts (cached or fresh) ──────────────────────────
        contratos_raw: list[dict] = []
        contratos_meta: dict = {"paginas_consumidas": 0, "truncado": False}

        # Cache fetch: use at least 100 results for reasonable cache coverage
        # (7 pages × ~2s delay ≈ 14s), but not 500 which can timeout for
        # suppliers with thousands of contracts (34 pages × ~2s ≈ 68s+).
        _cache_fetch = max(max_results, 100)

        if not force_refresh:
            try:
                from src.shared.database import _get_session_maker  # noqa: PLC0415
                async with _get_session_maker()() as session:
                    cached = await _fetch_contratos_fornecedor_cached(
                        cpf_cnpj=cpf_cnpj,
                        max_results=_cache_fetch,
                        config_json=json.dumps(config),
                        session=session,
                    )
                    if isinstance(cached, dict) and "rows" in cached:
                        contratos_raw = cached["rows"]
                        contratos_meta = cached.get("meta", contratos_meta)
                        cache_hit = True
            except Exception as exc:
                log.warning(
                    "buscar_contratos_fornecedor: cache fetch failed (%s), "
                    "falling back to live API", exc,
                )

        if not contratos_raw:
            try:
                contratos_raw, contratos_meta = await t_client.buscar_contratos_por_fornecedor(
                    cpf_cnpj, max_results=_cache_fetch,
                )
            except Exception as exc:
                log.warning("buscar_contratos_fornecedor: live API failed: %s", exc)
                contratos_raw = []
                contratos_meta = {"paginas_consumidas": 0, "truncado": False}

        # Slice to requested max_results (cache stores up to 500)
        if len(contratos_raw) > max_results:
            contratos_raw = contratos_raw[:max_results]
            contratos_meta["truncado"] = True

        # ── Fetch sanctions (always live; rarely large) ─────────────────
        sancoes_raw: list[dict] = []
        sancoes_meta: dict = {"paginas_consumidas": 0, "truncado": False}
        try:
            sancoes_raw, sancoes_meta = await t_client.buscar_sancoes(
                cpf_cnpj, max_results=max_results,
            )
        except Exception as exc:
            log.warning("buscar_contratos_fornecedor: sanctions lookup failed: %s", exc)

        # ── Slim + apply client-side filters ────────────────────────────
        contratos = [slim_contrato_fornecedor(r) for r in contratos_raw]
        sancoes = [slim_sancao(r) for r in sancoes_raw]

        filtros: dict[str, str] = {}
        contratos = self._aplicar_filtros_contratos(contratos, params, filtros)

        # ── Build agent payload (preview + CSV) ─────────────────────────
        _PREVIEW = 30  # keep inline preview small so the agent doesn't get lost

        agent_payload = await build_agent_payload(
            self,
            rows=contratos,
            export_csv=bool(params.get("export_csv", False)),
            export_json=False,
            filename_prefix=f"comprasgovbr_contratos_fornecedor_{cpf_cnpj}",
            agent_context=ctx,
            preview_rows=_PREVIEW,
        )

        # ── Sanctions agent payload (separate CSV if overflow) ──────────
        sanctions_payload = await build_agent_payload(
            self,
            rows=sancoes,
            export_csv=bool(params.get("export_csv", False)),
            export_json=False,
            filename_prefix=f"comprasgovbr_sancoes_{cpf_cnpj}",
            agent_context=ctx,
            preview_rows=_PREVIEW,
        )

        # ── Build agent_hint ────────────────────────────────────────────
        hint_parts: list[str] = []
        total_contratos = len(contratos)
        paginas = contratos_meta.get("paginas_consumidas", 0)
        truncado = contratos_meta.get("truncado", False)

        if total_contratos:
            hint_parts.append(
                f"{total_contratos} contratos encontrados para o "
                f"{'CNPJ' if len(cpf_cnpj) == 14 else 'CPF'} {cpf_cnpj} "
                f"({paginas} página(s) da API consumida(s))."
            )
            if truncado:
                hint_parts.append(
                    f"⚠️ Resultado truncado pelo limite max_results={max_results} — "
                    "há potencialmente mais contratos. Aumente max_results (máx. 500) "
                    "ou use filtros (vigencia_min, vigencia_max, filtro_orgao, "
                    "filtro_objeto) para refinar a busca."
                )
            else:
                hint_parts.append(
                    "Todos os contratos disponíveis foram recuperados (sem truncamento)."
                )
        else:
            hint_parts.append(
                f"Nenhum contrato encontrado no Portal da Transparência para "
                f"{'CNPJ' if len(cpf_cnpj) == 14 else 'CPF'} {cpf_cnpj}."
            )

        if filtros:
            filtro_desc = ", ".join(f"{k}={v}" for k, v in filtros.items())
            hint_parts.append(f"Filtros aplicados: {filtro_desc}.")

        if agent_payload["rows_overflow"]:
            csv_info = agent_payload.get("artifacts", {}).get("csv_file") or {}
            hint_parts.append(
                f"CSV com todos os {total_contratos} contratos disponível para download."
            )
            if csv_info.get("download_path"):
                hint_parts.append(f"Download: {csv_info['download_path']}")

        if sancoes:
            total_sanc = len(sancoes)
            hint_parts.append(
                f"{total_sanc} sanção(ões) encontrada(s) nas bases CEIS/CNEP/CEPIM/CEAF."
            )
        else:
            hint_parts.append("Nenhuma sanção encontrada nas bases federais.")

        if cache_hit:
            hint_parts.append("(Dados do cache — use force_refresh=true para atualizar.)")

        # ── ID incompatibility warning (Portal da Transparência ≠ Contratos.gov.br) ─
        hint_parts.append(
            "⚠️ Os 'id' retornados são do Portal da Transparência e NÃO funcionam "
            "em detalhar_contrato_completo / detalhar_contrato_id (Contratos.gov.br). "
            "Use buscar_contrato_ug_origem(codigo_uasg=<uasg>, numero_contrato='<numero>') "
            "para obter o ID numérico do Contratos.gov.br, ou use "
            "listar_contratos_ug(unidade_codigo=<uasg>) para listar contratos da UG."
        )

        # ── Assemble result ─────────────────────────────────────────────
        result: dict = {
            "action": "buscar_contratos_fornecedor",
            "cpf_cnpj": cpf_cnpj,
            "tipo": "CNPJ" if len(cpf_cnpj) == 14 else "CPF",
            "contratos": agent_payload["rows_preview"],
            "total_contratos_retornados": total_contratos,
            "paginas_consumidas": paginas,
            "truncado": truncado,
            "filtros_aplicados": filtros if filtros else None,
            "rows_total": agent_payload["rows_total"],
            "rows_overflow": agent_payload["rows_overflow"],
            "rows_preview_limit": _PREVIEW,
            "artifacts": agent_payload["artifacts"],
            "agent_hint": " ".join(hint_parts),
        }

        if sancoes:
            result["sancoes"] = sanctions_payload["rows_preview"]
            result["total_sancoes"] = len(sancoes)
            if sanctions_payload.get("artifacts"):
                result["sancoes_artifacts"] = sanctions_payload["artifacts"]
        else:
            result["sancoes"] = []
            result["total_sancoes"] = 0

        return result

    # ── Client-side filter helpers ──────────────────────────────────────

    @staticmethod
    def _aplicar_filtros_contratos(
        contratos: list[dict], params: dict, filtros_out: dict,
    ) -> list[dict]:
        """Apply client-side filters to contract records.

        Modifies *filtros_out* in-place with the filters that were actually
        applied (normalised values).
        """
        vigencia_min = (params.get("vigencia_min") or "").strip()
        vigencia_max = (params.get("vigencia_max") or "").strip()
        filtro_orgao = (params.get("filtro_orgao") or "").strip().lower()
        filtro_objeto = (params.get("filtro_objeto") or "").strip().lower()

        if vigencia_min:
            try:
                from src.mcp_server.tools.enterprise.gov.compras._client import (  # noqa: PLC0415
                    normalizar_data,
                )
                vigencia_min = normalizar_data(vigencia_min)
                filtros_out["vigencia_min"] = vigencia_min
            except (ValueError, ImportError):
                log.warning("Invalid vigencia_min: %s — ignoring filter", vigencia_min)
                vigencia_min = ""

        if vigencia_max:
            try:
                from src.mcp_server.tools.enterprise.gov.compras._client import (  # noqa: PLC0415
                    normalizar_data,
                )
                vigencia_max = normalizar_data(vigencia_max)
                filtros_out["vigencia_max"] = vigencia_max
            except (ValueError, ImportError):
                log.warning("Invalid vigencia_max: %s — ignoring filter", vigencia_max)
                vigencia_max = ""

        if filtro_orgao:
            filtros_out["filtro_orgao"] = params.get("filtro_orgao", "").strip()

        if filtro_objeto:
            filtros_out["filtro_objeto"] = params.get("filtro_objeto", "").strip()

        if not (vigencia_min or vigencia_max or filtro_orgao or filtro_objeto):
            return contratos

        filtered: list[dict] = []
        for c in contratos:
            if vigencia_min and (c.get("data_inicio") or "—") < vigencia_min:
                continue
            if vigencia_max and (c.get("data_fim") or "—") > vigencia_max:
                continue
            if filtro_orgao:
                orgao = (c.get("orgao") or "").lower()
                if filtro_orgao not in orgao:
                    continue
            if filtro_objeto:
                objeto = (c.get("objeto") or "").lower()
                if filtro_objeto not in objeto:
                    continue
            filtered.append(c)

        return filtered

    async def _do_buscar_materiais(self, ctx: AgentContext, params: dict) -> dict:
        """Search materials by name — CATMAT primary, CNBS fallback.

        Returns PDM codes (product groups).  Inline preview capped at 10;
        full results auto-exported as CSV when exceeding the cap.
        """
        palavra = (params.get("palavra") or "").strip()
        if not palavra:
            raise ComprasError(400, "'palavra' is required for buscar_materiais.")
        max_results = self._max_results(params)

        results: list[dict] = []
        errors: list[str] = []

        # 1. Try CATMAT (Compras.gov.br) first
        try:
            client = ComprasClient()
            catmat_raw = await client.get_item_material(
                max_results=max_results,
                descricaoItem=palavra,
            )
            for item in catmat_raw:
                codigo_pdm = item.get("codigoPdm")
                results.append({
                    "codigo": int(codigo_pdm) if codigo_pdm and str(codigo_pdm).isdigit() else (codigo_pdm or None),
                    "nome": item.get("descricaoItem", ""),
                    "tipo": "M",
                    "fonte": "CATMAT",
                    "codigo_item": item.get("codigoItem"),
                })
        except Exception as exc:
            errors.append(f"CATMAT: {exc}")

        # 2. Fallback to CNBS (Serpro) if CATMAT returned nothing or failed
        if not results:
            try:
                cnbs = CNBSClient()
                pdms = await cnbs.hint(palavra)
                svc_count = 0
                for pdm in pdms[:max_results]:
                    codigo_pdm = str(pdm.get("codigo", ""))
                    nome_pdm = pdm.get("nome", "")
                    tipo = pdm.get("tipo", "M")
                    # Services (tipo S): include with source marker, skip material-only caracteristicas
                    if tipo == "S":
                        svc_count += 1
                        results.append({
                            "codigo": int(codigo_pdm) if codigo_pdm.isdigit() else codigo_pdm,
                            "nome": nome_pdm,
                            "tipo": "S",
                            "fonte": "CNBS",
                            "itens": [],  # CNBS caracteristicas is material-only
                        })
                        continue
                    # Materials (tipo M): enrich with sample items
                    itens: list[dict] = []
                    if codigo_pdm:
                        try:
                            chars = await cnbs.caracteristicas(codigo_pdm)
                            for c in chars[:5]:
                                ci = c.get("codigoItem")
                                if ci:
                                    itens.append({"codigo_item": ci})
                        except Exception:
                            pass
                    results.append({
                        "codigo": int(codigo_pdm) if codigo_pdm.isdigit() else codigo_pdm,
                        "nome": nome_pdm,
                        "tipo": tipo,
                        "fonte": "CNBS",
                        "itens": itens,
                    })
            except Exception as exc:
                errors.append(f"CNBS: {exc}")

        if not results:
            return {
                "termo": palavra,
                "resultados": [],
                "total": 0,
                "erros": errors or None,
                "agent_hint": "No materials found.",
            }

        # ── Build agent payload — inline preview capped at 10 ───────────
        _PREVIEW_MATERIAIS = 10
        payload = await build_agent_payload(
            self,
            rows=results,
            export_csv=bool(params.get("export_csv", False)),
            export_json=False,
            filename_prefix=f"compras_materiais_{palavra[:30]}",
            agent_context=ctx,
            preview_rows=_PREVIEW_MATERIAIS,
        )

        hint = (
            f"🔹 STEP 1/3: Found {len(results)} PDM group(s) "
            f"matching '{palavra}'.\n"
        )
        if payload.get("rows_overflow"):
            csv_info = payload.get("artifacts", {}).get("csv_file") or {}
            download_path = csv_info.get("download_path", "")
            file_id = csv_info.get("file_id", "")
            hint += (
                f"Only {_PREVIEW_MATERIAIS} results shown inline. "
                f"Full list ({len(results)} items) saved as CSV"
            )
            if download_path:
                hint += f" — {download_path}"
            elif file_id:
                hint += f" — file_id={file_id}"
            hint += ".\n"
        hint += (
            "🔹 STEP 2/3: Pick a PDM and run "
            "listar_materiais_por_pdm(codigo_pdm=<codigo>) "
            "to list all CATMAT items in that group.\n"
            "🔹 STEP 3/3: Use the 'codigo_item' from step 2 in "
            "pesquisar_precos(codigo_item=<codigo_item>).\n"
            "⚠️ Do NOT use the PDM 'codigo' directly in "
            "pesquisar_precos — it expects a CATMAT item code, "
            "not a group code. PDM codes return 0 results.\n"
            "⚠️ CATMAT names can be misleading — some items "
            "named 'Notebook' in CATMAT are tools (pé de cabra), "
            "but MANY are actual laptop computers. ALWAYS run "
            "listar_materiais_por_pdm(codigo_pdm=X) to check "
            "the real descrição of each item before discarding "
            "a PDM. For computers also try 'microcomputador' "
            "(PDM 6661)."
        )
        # Cross-ref: if CNBS returned services, tell agent about buscar_servicos
        svc_results = [r for r in results if r.get("tipo") == "S"]
        if svc_results:
            hint += (
                f"\n💡 Also found {len(svc_results)} service(s) (tipo S) via CNBS. "
                f"Use buscar_servicos(palavra='{palavra}') to explore CATSER service "
                f"codes with full hierarchy (Seção/Divisão/Grupo/Classe)."
            )

        return {
            "termo": palavra,
            "resultados": payload["rows_preview"],
            "total": payload["rows_total"],
            "rows_overflow": payload["rows_overflow"],
            "artifacts": payload["artifacts"],
            "erros": errors or None,
            "agent_hint": hint,
        }

    async def _do_listar_materiais_por_pdm(self, ctx: AgentContext, params: dict) -> dict:
        """List all CATMAT items within a PDM group. Auto-CSV if > 20 items."""
        codigo_pdm = params.get("codigo_pdm")
        if not codigo_pdm:
            raise ComprasError(400, "'codigo_pdm' is required. Get it from buscar_materiais.")
        max_results = self._max_results(params)
        client = ComprasClient()
        raw = await client.get_item_material(
            max_results=max_results,
            codigoPdm=str(codigo_pdm),
        )
        itens = [
            {
                "codigo_item": item.get("codigoItem"),
                "nome": item.get("descricaoItem", ""),
                "codigo_pdm": item.get("codigoPdm"),
            }
            for item in raw
        ]

        result: dict = {
            "codigo_pdm": int(codigo_pdm) if str(codigo_pdm).isdigit() else codigo_pdm,
            "total": len(itens),
        }

        if len(itens) > 20:
            # Generate CSV artifact (too many items for inline display)
            csv_info = await self._maybe_csv(
                itens, f"catmat_pdm{codigo_pdm}", params,
                ctx,
            )
            result["artifacts"] = csv_info.get("artifacts")
            result["itens_csv"] = True
            agent_hint = (
                f"{len(itens)} items in PDM {codigo_pdm} — "
                f"lista muito grande para exibição inline. "
            )
            if csv_info.get("artifacts", {}).get("csv_file"):
                agent_hint += (
                    "Arquivo CSV salvo com a lista completa. "
                    f"file_id={csv_info['artifacts']['csv_file']['file_id']}. "
                )
            agent_hint += (
                "Use pesquisar_precos(codigo_item=...) with one of the "
                "'codigo_item' values from the CSV to find prices. "
                "⚠️ Use 'codigo_item' (CATMAT), NOT 'codigo_pdm' (group)."
            )
        else:
            result["itens"] = itens
            agent_hint = (
                f"Found {len(itens)} CATMAT items in PDM {codigo_pdm}. "
                "To get prices, use pesquisar_precos(codigo_item=<codigo_item>) "
                "with one of the 'codigo_item' values above. "
                "⚠️ Use 'codigo_item' (CATMAT), NOT 'codigo_pdm' (group)."
            )

        result["agent_hint"] = agent_hint
        return result

    async def _do_listar_contratos(
        self, client: ComprasClient, ctx: AgentContext, params: dict,
    ) -> dict:
        """List contracts.  Accepts codigo_orgao or codigo_uasg."""
        codigo_uasg = params.get("codigo_uasg")
        codigo_orgao = params.get("codigo_orgao")

        # Resolve UASG → org code if needed
        if codigo_uasg and not codigo_orgao:
            raw_uasg = await client.get_uasg(codigoUasg=str(codigo_uasg))
            if raw_uasg:
                codigo_orgao = int(raw_uasg[0].get("codigoOrgao", 0))
            if not codigo_orgao:
                raise ComprasError(400, f"Could not resolve UASG '{codigo_uasg}' to an org code.")
        if not codigo_orgao:
            raise ComprasError(400, "'codigo_orgao' or 'codigo_uasg' is required.")

        codigo = int(codigo_orgao)
        max_results = self._max_results(params)
        siorg_hint = self._siorg_hint(codigo)

        # C1 requires a date range ≤ 365 days.  Default to the last year.
        hoje = date.today()
        vig_min = params.get("vigencia_min") or (hoje.replace(year=hoje.year - 1)).isoformat()
        vig_max = params.get("vigencia_max") or hoje.isoformat()

        query: dict[str, str] = {
            "codigoOrgao": str(codigo),
            "dataVigenciaInicialMin": str(vig_min),
            "dataVigenciaInicialMax": str(vig_max),
        }
        # codigo_unidade_gestora narrows to a specific unit within the org
        ug = params.get("codigo_unidade_gestora")
        if ug:
            query["codigoUnidadeGestora"] = str(ug)
        raw = await client.get_contratos(max_results=max_results, **query)
        contratos = [slim_contrato(r) for r in raw]

        # Auto-CSV for large result sets
        csv_info = await self._maybe_csv(
            contratos, "contratos", params,
            ctx,
        )

        return {
            "orgao": {"codigo": codigo},
            "contratos": contratos,
            "total": len(contratos),
            "siorg_hint": siorg_hint,
            **csv_info,
            "agent_hint": (
                "Use detalhar_contrato(id_contrato='...') to see items, "
                "values, and supplier details for a specific contract. "
                "Pass codigo_orgao for itens (C4) lookup. "
                "The API limits date range to 365 days — use vigencia_min/max "
                "to narrow the window."
            ) if contratos else (
                "No contracts found. The API limits date range to 365 days "
                "(default: last year). Try codigo_unidade_gestora for a "
                "specific unit within the org, or adjust vigencia_min/max."
            ),
        }
        contratos = [slim_contrato(r) for r in raw]
        return {
            "orgao": {"codigo": codigo},
            "contratos": contratos,
            "total": len(contratos),
            "siorg_hint": siorg_hint,
            "agent_hint": (
                "Use detalhar_contrato(id_contrato='...', codigo_orgao=...) "
                "to see items, values, and supplier details. "
                "If 'id' starts with 'numero:', pass codigo_orgao so the "
                "tool can resolve the real contract identifier. "
                "The API limits date range to 365 days — use 'vigencia_min' "
                "and 'vigencia_max' to narrow the window. "
                "Use 'codigo_unidade_gestora' to filter by unit."
            ) if contratos else (
                "No contracts found. The API limits date range to 365 days "
                "(default: last year). Try codigo_unidade_gestora for a "
                "specific unit within the org, or adjust vigencia_min/max."
            ),
        }

    async def _do_detalhar_contrato(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """Full contract detail — resolves ``numero:`` ids via the listing."""
        id_str = (params.get("id_contrato") or "").strip()
        if not id_str or ":" not in id_str:
            raise ComprasError(400, "'id_contrato' must be 'tipo:codigo' (e.g. 'idCompra:123456').")
        tipo, codigo = id_str.split(":", 1)
        if not tipo or not codigo:
            raise ComprasError(400, "'id_contrato' must be 'tipo:codigo' with non-empty values.")

        # ── Resolve "numero:" prefix ──────────────────────────────────
        if tipo == "numero":
            codigo_orgao = params.get("codigo_orgao") or ""
            if not codigo_orgao:
                raise ComprasError(
                    400,
                    "'codigo_orgao' is required when id_contrato uses "
                    "'numero:' format. Example: detalhar_contrato("
                    "id_contrato='numero:00011/2012', codigo_orgao=20101)",
                )
            # Search listing for the contract with this numero
            raw_list = await client.get_contratos(
                max_results=300, codigoOrgao=str(codigo_orgao),
            )
            # Try multiple field names for the contract number
            _NUMERO_KEYS = (
                "numero", "numeroContrato", "nuContrato",
                "nrContrato", "numeroProcesso",
            )
            found: dict | None = None
            for c in raw_list:
                for nk in _NUMERO_KEYS:
                    c_numero = c.get(nk)
                    if c_numero and str(c_numero).strip() == codigo:
                        found = c
                        break
                if found:
                    break
            if found is None:
                # Diagnostic: show a few available numeros from the listing
                sample_numeros: list[str] = []
                for c in raw_list[:5]:
                    for nk in _NUMERO_KEYS:
                        v = c.get(nk)
                        if v:
                            sample_numeros.append(f"{nk}={v}")
                            break
                return {
                    "contrato": {"not_found": True},
                    "not_found": True,
                    "total_scanned": len(raw_list),
                    "sample_numeros": sample_numeros,
                    "agent_hint": (
                        f"Contract 'numero:{codigo}' not found among "
                        f"{len(raw_list)} contracts for codigo_orgao={codigo_orgao}. "
                        "Sample numeros: " + ", ".join(sample_numeros[:5]) + ". "
                        "Use listar_contratos(codigo_orgao=...) to browse all ids."
                    ) if sample_numeros else (
                        f"Listing returned {len(raw_list)} contracts but none "
                        f"had a 'numero' field. The API may expose identifiers "
                        "under different keys."
                    ),
                }
            # Extract real identifiers from the raw listing item
            tipo = found.get("tipo") or "idCompra"
            codigo = (
                found.get("idCompra")
                or found.get("codigo")
                or found.get("codigoContrato")
                or found.get("codigoCompra")
                or ""
            )
            if not codigo:
                # Last resort: try PNCP identifier
                pncp = found.get("numeroControlePncpContrato")
                if pncp:
                    tipo = "numeroControlePncpContrato"
                    codigo = pncp
            if not codigo:
                # Return slimmed listing data so user at least sees something
                return {
                    "contrato": slim_contrato_detalhe(found) if found else {},
                    "not_found": False,
                    "raw_keys": sorted(found.keys()) if found else [],
                    "agent_hint": (
                        "Contract found in listing but has no typed 'codigo' "
                        "(idCompra, PNCP, codigoContrato). The C2 detail "
                        "endpoint cannot be called without a typed identifier. "
                        "Listing data is shown in 'contrato'. Raw API keys: "
                        + ", ".join(sorted(found.keys())[:20])
                    ),
                }

        # Fetch contract detail. Try to extract codigo_orgao from the
        # detail response if not in params, so items can also be fetched.
        codigo_orgao = params.get("codigo_orgao") or ""
        detalhe_raw: object = None
        itens_raw: object = []
        if codigo_orgao:
            detalhe_raw, itens_raw = await asyncio.gather(
                client.get_contrato_by_id(tipo, codigo),
                client.get_contratos_itens(
                    codigoOrgao=str(codigo_orgao), max_results=50,
                ),
                return_exceptions=True,
            )
        else:
            detalhe_raw = await client.get_contrato_by_id(tipo, codigo)
            # Try to extract codigo_orgao from the response so items can
            # also be fetched. Non-fatal if it fails.
            if isinstance(detalhe_raw, dict) and detalhe_raw.get("codigoOrgao"):
                try:
                    codigo_orgao = str(detalhe_raw["codigoOrgao"])
                    itens_raw = await client.get_contratos_itens(
                        codigoOrgao=str(codigo_orgao), max_results=50,
                    )
                except Exception as exc:
                    itens_raw = exc

        errors: list[str] = []
        contrato: dict = {}

        errors: list[str] = []
        contrato: dict = {}
        if isinstance(detalhe_raw, Exception):
            errors.append(f"Detalhe: {detalhe_raw}")
        elif isinstance(detalhe_raw, dict):
            contrato = slim_contrato_detalhe(detalhe_raw)

        itens: list[dict] = []
        if isinstance(itens_raw, Exception):
            errors.append(f"Itens: {itens_raw}")
        elif isinstance(itens_raw, list):
            itens = [
                {"descricao": i.get("descricao"), "quantidade": i.get("quantidade"),
                 "valor_unitario": i.get("valorUnitario"), "valor_total": i.get("valorTotal")}
                for i in itens_raw[:20]
            ]

        # Build Mermaid
        mermaid: Optional[str] = None
        try:
            orgao_nome = contrato.get("orgao", {}).get("nome", "Órgão")
            fornecedor_nome = contrato.get("fornecedor", {}).get("razao_social", "Fornecedor")
            valor = contrato.get("valor_total")
            mermaid = build_mermaid_contrato(orgao_nome, fornecedor_nome, itens, valor)
        except Exception:
            pass

        return {
            "contrato": contrato,
            "itens": itens,
            "mermaid": mermaid,
            "errors": errors or None,
            "not_found": contrato.get("not_found", False),
            "agent_hint": (
                "Contract not found — the id may be invalid or the contract "
                "does not exist in the Compras.gov.br database. "
                "Use listar_contratos(codigo_orgao=...) to discover valid ids."
            ) if contrato.get("not_found") else (
                "Use listar_contratos(codigo_orgao=...) to discover more contracts. "
                "Use detalhar_contrato_completo(contrato_id=...) or "
                "detalhar_contrato_completo(id_contrato='...') to fetch ALL "
                "sub-resources (itens, empenhos, faturas, garantias, cronograma, "
                "historico, ocorrencias, responsaveis, prepostos, publicacoes, "
                "arquivos, domicilio bancario, terceirizados) in a single call."
            ),
        }

    async def _do_listar_contratacoes(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """List contratações PNCP (new law 14.133/2021)."""
        codigo_orgao = params.get("codigo_orgao")
        # Default to Pregão (5) — the most common modality
        codigo_modalidade = params.get("codigo_modalidade") or 5
        max_results = self._max_results(params)

        hoje = date.today()
        query: dict[str, str] = {
            "dataPublicacaoPncpInicial": str(params.get("vigencia_min") or hoje.replace(year=hoje.year - 1).isoformat()),
            "dataPublicacaoPncpFinal": str(params.get("vigencia_max") or hoje.isoformat()),
        }
        if codigo_orgao:
            query["codigoOrgao"] = str(codigo_orgao)
        if codigo_modalidade:
            query["codigoModalidade"] = str(codigo_modalidade).zfill(2)
        # PNCP endpoint uses unidadeOrgaoCodigoUnidade for UASG filter
        uasg = params.get("codigo_uasg")
        if uasg:
            query["unidadeOrgaoCodigoUnidade"] = str(uasg)

        raw = await client.get_contratacoes(max_results=max_results, **query)
        return {
            "contratacoes": raw,
            "total": len(raw),
            "filtros": {
                "codigo_orgao": codigo_orgao,
                "codigo_modalidade": codigo_modalidade,
            },
            "agent_hint": (
                "Use codigo_modalidade to filter: 5=Pregão (most common), "
                "1=Concorrência, 8=Dispensa, 9=Inexigibilidade. "
                "Date range max 365 days (lei 14.133/2021)."
            ) if raw else (
                "No contratações found. Try codigo_modalidade=5 (Pregão) "
                "or adjust the date range (max 365 days)."
            ),
        }

    async def _do_listar_fornecedores(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """Supplier lookup."""
        cnpj = (params.get("cnpj") or "").strip()
        if not cnpj:
            raise ComprasError(400, "'cnpj' is required for listar_fornecedores.")
        raw = await client.get_fornecedor(cnpj=cnpj)
        fornecedores = [slim_fornecedor(r) for r in raw]
        return {
            "fornecedor": fornecedores[0] if fornecedores else {},
            "total": len(fornecedores),
        }

    async def _do_listar_atas(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """List price registration acts.  Auto-resolves org code → UASG."""
        codigo_uasg = params.get("codigo_uasg")
        codigo_orgao = params.get("codigo_orgao")
        codigo_modalidade = params.get("codigo_modalidade")

        # Auto-resolve: U1 doesn't filter by codigoOrgao reliably.
        # User should use codigo_uasg directly.
        if not codigo_uasg:
            # Try as-is (might be a UASG code)
            codigo_uasg = str(codigo_orgao) if codigo_orgao else None

        hoje = date.today()
        query: dict[str, str] = {
            "dataVigenciaInicialMin": str(params.get("vigencia_min") or hoje.replace(year=hoje.year - 1).isoformat()),
            "dataVigenciaInicialMax": str(params.get("vigencia_max") or hoje.isoformat()),
        }
        if codigo_uasg:
            query["codigoUnidadeGerenciadora"] = str(codigo_uasg)
        if codigo_modalidade:
            query["codigoModalidadeCompra"] = str(codigo_modalidade).zfill(2)
        raw = await client.get_arp(
            max_results=self._max_results(params),
            **query,
        )
        atas = [slim_arp(r) for r in raw]
        return {
            "atas": atas,
            "total": len(atas),
            "filtro_uasg": codigo_uasg or None,
            "agent_hint": (
                "Use codigo_uasg='110001' to filter by unit. "
                "Use codigo_modalidade=5 for Pregão (most common). "
                "Without filters, results are global. "
                "Date range max 365 days."
            ) if not atas else None,
        }

    async def _do_pesquisar_precos(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """Price research for a CATMAT or CATSER item code.

        Tries the material endpoint first; falls back to the dedicated
        service endpoint (``/modulo-pesquisa-preco/3_consultarServico``)
        if no material prices are found.
        """
        codigo = self._require(params, "codigo_item")
        uf = (params.get("uf") or "").strip()

        kwargs: dict = {}
        if uf:
            kwargs["estado"] = uf

        max_results = self._max_results(params)
        precos: list[dict] = []
        fonte: str = "CATMAT"

        # 1. Try material endpoint first
        raw_mat = await client.get_precos(
            max_results=max_results,
            codigoItemCatalogo=str(codigo),
            **kwargs,
        )
        precos = [slim_preco(r) for r in raw_mat]

        # 2. If no results, try the dedicated service endpoint
        if not precos:
            raw_svc = await client.get_precos_servico(
                max_results=max_results,
                codigoItemCatalogo=str(codigo),
                **kwargs,
            )
            precos = [slim_preco(r) for r in raw_svc]
            if precos:
                fonte = "CATSER"

        # Compute statistics
        valores = [p["preco_unitario"] for p in precos if p.get("preco_unitario")]
        stats: dict = {"total_compras": len(precos)}
        if valores:
            stats["preco_medio"] = round(sum(valores) / len(valores), 2)
            stats["preco_mediano"] = round(median(valores), 2)
            stats["preco_minimo"] = round(min(valores), 2)
            stats["preco_maximo"] = round(max(valores), 2)
            if len(valores) > 1:
                try:
                    stats["desvio_padrao"] = round(stdev(valores), 2)
                except Exception:
                    pass

        result: dict = {
            "codigo": codigo,
            "fonte": fonte,
            "estatisticas": stats,
            "compras": precos,
            "total": len(precos),
        }

        if precos:
            result["agent_hint"] = (
                f"{len(precos)} price records for {fonte} item {codigo}. "
                + (f"Avg price: R$ {stats.get('preco_medio', 0):,.2f}. "
                   if stats.get("preco_medio") else "")
                + "Check 'descricaoItem' in each record to confirm "
                  "they match what you expect."
            )
        else:
            result["sugestao"] = (
                f"No prices found for code {codigo} "
                f"(tried both CATMAT and CATSER endpoints). "
                "Possible causes:\n"
                "  1. This may be a PDM group code — PDM codes "
                "return 0 results. Use listar_materiais_por_pdm "
                "first to find CATMAT item codes.\n"
                "  2. This may be a CATSER service code with no "
                "purchase history in either endpoint.\n"
                "  3. Try a different item code from the same group.\n"
                "  4. Try without UF filter for nationwide results.\n"
                "  5. Try broader search terms in buscar_materiais "
                "or buscar_servicos."
            )
            result["agent_hint"] = result["sugestao"]

        return result

    async def _do_listar_pgc(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """Procurement planning."""
        codigo = self._require(params, "codigo_orgao")
        ano = params.get("ano") or date.today().year
        raw = await client.get_pgc(
            max_results=self._max_results(params),
            orgao=str(codigo),
            anoPcaProjetoCompra=str(ano),
        )
        return {
            "orgao": {"codigo": codigo},
            "ano": int(ano),
            "planejamento": raw,
            "total": len(raw),
            "siorg_hint": self._siorg_hint(codigo),
        }

    # ── New Dados Abertos actions ───────────────────────────────────────────

    async def _do_listar_licitacoes(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """List legacy SIASG bids (law 8.666, up to 2020)."""
        from src.mcp_server.tools.enterprise.gov.compras._client import (
            _default_data_inicial,
            _default_data_final,
            normalizar_data,
        )
        d_ini = normalizar_data(params.get("data_publicacao_inicial") or _default_data_inicial())
        d_fim = normalizar_data(params.get("data_publicacao_final") or _default_data_final())

        query: dict[str, str] = {
            "dataPublicacaoInicial": d_ini,
            "dataPublicacaoFinal": d_fim,
        }
        uasg = params.get("codigo_uasg")
        if uasg:
            query["coUasg"] = str(uasg)
        modalidade = params.get("codigo_modalidade")
        if modalidade:
            query["modalidade"] = str(modalidade)

        raw = await client.get_licitacoes(max_results=self._max_results(params), **query)
        licitacoes = [slim_licitacao(r) for r in raw]
        return {
            "licitacoes": licitacoes,
            "total": len(licitacoes),
            "periodo": {"inicial": d_ini, "final": d_fim},
            "agent_hint": (
                "These are legacy SIASG bids (law 8.666). "
                "For newer bids use listar_contratacoes (law 14.133/2021) "
                "or the pncp_contratos tool for native PNCP access."
            ),
        }

    async def _do_listar_pregoes(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """List electronic auctions (Pregão).

        Reuses the licitações endpoint with modalidade=5 (Pregão).
        """
        from src.mcp_server.tools.enterprise.gov.compras._client import (
            _default_data_inicial,
            _default_data_final,
            normalizar_data,
        )
        d_ini = normalizar_data(params.get("data_publicacao_inicial") or _default_data_inicial())
        d_fim = normalizar_data(params.get("data_publicacao_final") or _default_data_final())

        query: dict[str, str] = {
            "dataPublicacaoInicial": d_ini,
            "dataPublicacaoFinal": d_fim,
            "modalidade": "5",  # Pregão
        }
        uasg = params.get("codigo_uasg")
        if uasg:
            query["coUasg"] = str(uasg)

        raw = await client.get_licitacoes(max_results=self._max_results(params), **query)
        pregoes = [slim_licitacao(r) for r in raw]
        return {
            "pregoes": pregoes,
            "total": len(pregoes),
            "periodo": {"inicial": d_ini, "final": d_fim},
        }

    async def _do_listar_dispensas(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """List direct awards / exemptions (dispensas e inexigibilidades)."""
        ano = self._require(params, "ano_aviso")

        query: dict[str, str] = {"anoAviso": str(ano)}
        uasg = params.get("codigo_uasg")
        if uasg:
            query["coUasg"] = str(uasg)

        # Compras.gov.br legado: compras sem licitação
        raw = await client.get_licitacoes(
            max_results=self._max_results(params),
            dataPublicacaoInicial=f"{ano}-01-01",
            dataPublicacaoFinal=f"{ano}-12-31",
            **query,
        )
        dispensas = [slim_licitacao(r) for r in raw]
        return {
            "dispensas": dispensas,
            "total": len(dispensas),
            "ano": ano,
            "agent_hint": (
                "Results include all compras sem licitação for the year. "
                "Filter by modalidade name to distinguish dispensa vs inexigibilidade."
            ),
        }

    async def _do_buscar_servicos(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """Search CATSER service codes — CNBS primary, CATSER fallback.

        Text search (``palavra``): CNBS ``/servico/v1/palavra`` first —
        reliable server-side text matching.  Falls back to CATSER API with
        client-side filtering because the CATSER API returns a default set
        when no results match.

        Code search (``codigo_servico``): CATSER API directly.
        """
        from src.mcp_server.tools.base import _tool_session_ctx

        codigo = params.get("codigo_servico")
        nome = (params.get("palavra") or "").strip()

        if not codigo and not nome:
            raise ComprasError(400, "Provide 'codigo_servico' or 'palavra' for buscar_servicos.")

        max_results = self._max_results(params)
        servicos: list[dict] = []
        erros: list[str] = []

        # ── Text search: CNBS primary, CATSER fallback ──────────────────
        if nome:
            # 1. CNBS dedicated service search (reliable text matching)
            try:
                cnbs = CNBSClient()
                cnbs_raw = await cnbs.buscar_servicos(nome)
                if cnbs_raw:
                    servicos = [
                        slim_servico(item, fonte="CNBS")
                        for item in cnbs_raw[:max_results]
                    ]
            except Exception as exc:
                erros.append(f"CNBS: {exc}")

            # 2. Fallback to CATSER API with client-side filtering
            if not servicos:
                import hashlib
                import json

                query: dict[str, str] = {"nomeServico": nome}
                query_hash = hashlib.md5(
                    json.dumps(query, sort_keys=True).encode()
                ).hexdigest()
                raw_all: list[dict] = []
                try:
                    session = _tool_session_ctx.get()
                    if session is not None and not params.get("force_refresh"):
                        raw_all = await _fetch_servicos_cached(
                            query_hash=query_hash, query=query,
                            max_results=max_results, session=session,
                        )
                    else:
                        raw = await client.get_itens_servico(
                            max_results=max_results, nomeServico=nome,
                        )
                        raw_all = [slim_servico(r) for r in raw]
                except Exception as exc:
                    erros.append(f"CATSER: {exc}")

                # Client-side filter: CATSER API returns fallback set
                if raw_all:
                    nome_lower = nome.lower()
                    servicos = [
                        s for s in raw_all
                        if s.get("nome") and nome_lower in s["nome"].lower()
                    ]
                    if servicos:
                        for s in servicos:
                            s["fonte"] = "CATSER"

        # ── Code search: CATSER API only ────────────────────────────────
        elif codigo:
            query_dict: dict[str, str] = {"codigoServico": str(codigo)}
            try:
                session = _tool_session_ctx.get()
                if session is not None and not params.get("force_refresh"):
                    import hashlib
                    import json
                    qh = hashlib.md5(
                        json.dumps(query_dict, sort_keys=True).encode()
                    ).hexdigest()
                    servicos = await _fetch_servicos_cached(
                        query_hash=qh, query=query_dict,
                        max_results=max_results, session=session,
                    )
                else:
                    raw = await client.get_itens_servico(
                        max_results=max_results, codigoServico=str(codigo),
                    )
                    servicos = [slim_servico(r) for r in raw]
            except Exception as exc:
                erros.append(f"CATSER: {exc}")

        # ── Empty-result diagnostics ────────────────────────────────────
        if not servicos and nome:
            return {
                "servicos": [],
                "total": 0,
                "termo": nome,
                "erros": erros or None,
                "agent_hint": (
                    f"No CATSER services found for '{nome}' — "
                    f"both CNBS and CATSER API returned no matches. "
                    f"Try browsing by hierarchy with "
                    f"listar_servicos_por_grupo(codigo_secao=N, palavra='{nome}') "
                    f"to search within a section. "
                    f"Or try buscar_materiais(palavra='{nome}') if you're "
                    f"looking for materials instead of services."
                ),
            }

        if not servicos and codigo:
            return {
                "servicos": [],
                "total": 0,
                "termo": str(codigo),
                "erros": erros or None,
                "agent_hint": (
                    f"No CATSER service found with code {codigo}. "
                    f"The code may not exist or may be inactive. "
                    f"Use listar_servicos_por_grupo(codigo_secao=N) to browse "
                    f"valid service codes by section. Known-good codes from "
                    f"testing: 15750 (locação equipamentos TI), "
                    f"30255 (outsourcing fiscal), 12556 (locação audiovisual)."
                ),
            }

        if not servicos:
            return {
                "servicos": [],
                "total": 0,
                "termo": nome or str(codigo),
                "erros": erros or None,
                "agent_hint": (
                    "No services found. Try a different search term, or use "
                    "buscar_materiais(palavra='...') if you're looking for "
                    "materials/products instead of services."
                ),
            }

        # ── Agent hint ───────────────────────────────────────────────────
        fontes = {s.get("fonte", "CATSER") for s in servicos}
        hint = (
            f"Found {len(servicos)} CATSER service(s)"
        )
        if nome:
            hint += f" matching '{nome}'"
        hint += f" (sources: {', '.join(sorted(fontes))}).\n"

        # Educational: explain CATSER vs CATMAT/PDM
        hint += (
            "📋 CATSER = Catálogo de Serviços (services catalogue). "
            "Each result is an individual service with a unique code "
            "(use directly in pesquisar_precos).\n"
            "🔄 Unlike CATMAT where PDM codes are GROUP codes that "
            "need listar_materiais_por_pdm to find individual items, "
            "CATSER codes ARE the individual items.\n"
        )

        # Hierarchy guidance (with names if CNBS source)
        has_names = any(s.get("nome_secao") for s in servicos)
        if has_names:
            hint += (
                "🏗️ Hierarchy (Seção → Divisão → Grupo → Classe → Serviço):\n"
            )
            # Show unique hierarchy paths (deduplicated)
            seen: set[tuple] = set()
            for s in servicos[:5]:
                path = (
                    s.get("nome_secao", ""),
                    s.get("nome_divisao", ""),
                    s.get("nome_grupo", ""),
                    s.get("nome_classe", ""),
                )
                if path not in seen and any(path):
                    seen.add(path)
                    parts = " > ".join(p for p in path if p)
                    hint += f"  • {parts}\n"
            if len(servicos) > 5:
                hint += f"  … and {len(servicos) - 5} more\n"
        else:
            hint += (
                "🏗️ CATSER hierarchy: Seção → Divisão → Grupo → Classe → Serviço. "
                "Use codigo_secao/divisao/grupo/classe fields to browse with "
                "listar_servicos_por_grupo(codigo_secao=N, ...).\n"
            )
        hint += (
            "💡 Use pesquisar_precos(codigo_item=<codigo>) to find "
            "purchase prices for any service code."
        )
        # Truncation warning: if we hit the max_results limit, there
        # may be more results.  CNBS returns the full set; CATSER API
        # paginates.  Both are sliced to max_results.
        if len(servicos) >= max_results:
            hint += (
                f"\n⚠️ Result truncated at max_results={max_results}. "
                f"There may be more services matching this search. "
                f"Increase max_results (up to 500) to see more, or use "
                f"listar_servicos_por_grupo to browse by hierarchy section."
            )

        return {
            "servicos": servicos,
            "total": len(servicos),
            "termo": nome or str(codigo),
            "erros": erros or None,
            "agent_hint": hint,
        }

    async def _do_listar_servicos_por_grupo(
        self, client: ComprasClient, params: dict,
    ) -> dict:
        """List all CATSER services within a hierarchy level (Seção→Divisão→Grupo→Classe).

        At least one of ``codigo_secao``, ``codigo_divisao``, ``codigo_grupo``,
        ``codigo_classe`` must be provided.  The API filters by the most specific
        level given.
        """
        query: dict[str, str] = {}
        for param_name, api_name in (
            ("codigo_secao", "codigoSecao"),
            ("codigo_divisao", "codigoDivisao"),
            ("codigo_grupo", "codigoGrupo"),
            ("codigo_classe", "codigoClasse"),
        ):
            val = params.get(param_name)
            if val is not None:
                query[api_name] = str(int(val))

        if not query:
            raise ComprasError(
                400,
                "Provide at least one of: 'codigo_secao', 'codigo_divisao', "
                "'codigo_grupo', 'codigo_classe' for listar_servicos_por_grupo.",
            )

        max_results = self._max_results(params)
        raw = await client.get_itens_servico(max_results=max_results, **query)
        servicos = [slim_servico(r) for r in raw]

        # Client-side name filter (optional, case-insensitive substring).
        # The CATSER API does not reliably filter by name server-side, so
        # ``palavra`` provides a reliable client-side alternative.
        palavra = (params.get("palavra") or "").strip()
        filtered_before = 0
        if palavra:
            palavra_lower = palavra.lower()
            filtered_before = len(servicos)
            servicos = [
                s for s in servicos
                if s.get("nome") and palavra_lower in s["nome"].lower()
            ]

        # Describe which level was used
        niveis: list[str] = []
        for pn, _an in (
            ("codigo_secao", "codigoSecao"),
            ("codigo_divisao", "codigoDivisao"),
            ("codigo_grupo", "codigoGrupo"),
            ("codigo_classe", "codigoClasse"),
        ):
            if params.get(pn) is not None:
                niveis.append(pn.replace("codigo_", ""))

        filtro_info = f" + palavra='{palavra}'" if palavra else ""
        hint = (
            f"Found {len(servicos)} CATSER service(s) at level(s): "
            f"{' > '.join(niveis)}{filtro_info}.\n"
        )
        if palavra and filtered_before:
            hint += (
                f"(Client-side filtered from {filtered_before} to {len(servicos)} "
                f"by '{palavra}')\n"
            )
        hint += (
            "Use the returned 'codigo' in pesquisar_precos(codigo_item=...) "
            "to find prices. To go deeper in the hierarchy, use a more "
            "specific level (e.g. add codigo_classe to narrow from grupo). "
            "To go up, use a less specific level (e.g. only codigo_secao)."
        )
        if len(servicos) >= max_results:
            hint += (
                f"\n⚠️ Result truncated at max_results={max_results}. "
                f"There may be more services at this hierarchy level. "
                f"Increase max_results (up to 500) or add a more specific "
                f"level filter to narrow results."
            )

        return {
            "servicos": servicos,
            "total": len(servicos),
            "niveis": niveis,
            "agent_hint": hint,
        }

    # ── Contratos.gov.br actions ────────────────────────────────────────────

    async def _do_listar_contratos_ug(self, params: dict) -> dict:
        """List active contracts by UG (Contratos.gov.br)."""
        codigo = self._require(params, "unidade_codigo")
        cg_client = ContratosGovbrClient()
        raw = await cg_client.listar_contratos_ug(codigo)
        contratos = [slim_contrato_ug(r) for r in raw]
        return {
            "unidade_codigo": codigo,
            "contratos": contratos,
            "total": len(contratos),
            "agent_hint": (
                "Use detalhar_contrato_id(contrato_id=...) to see full details. "
                "Use listar_empenhos(contrato_id=...) to see budget commitments."
            ) if contratos else (
                f"No active contracts found for UG {codigo}. "
                "Try another UG code."
            ),
        }

    async def _do_detalhar_contrato_id(self, params: dict) -> dict:
        """Get contract detail by numeric ID (Contratos.gov.br)."""
        contrato_id = self._require(params, "contrato_id")
        cg_client = ContratosGovbrClient()
        raw = await cg_client.consultar_contrato(contrato_id)
        if not raw:
            return {
                "contrato": {"not_found": True},
                "contrato_id": contrato_id,
                "agent_hint": f"Contract {contrato_id} not found in Contratos.gov.br.",
            }
        contrato = slim_contrato_ug(raw)
        return {
            "contrato": contrato,
            "contrato_id": contrato_id,
            "agent_hint": (
                "Use listar_empenhos(contrato_id=...) to see budget commitments. "
                "Use listar_itens_contrato(contrato_id=...) to see items. "
                "Use listar_historico_contrato(contrato_id=...) to see amendments."
            ),
        }

    async def _resolve_contrato_id(
        self, params: dict,
    ) -> int:
        """Resolve ``contrato_id`` (numeric) from *params*.

        Accepts either:
        - ``contrato_id`` (int) — used directly with Contratos.gov.br.
        - ``id_contrato`` (str, e.g. ``idCompra:...``) — tries Dados Abertos
          lookup; if the response contains a ``codigoContrato`` field it is
          used as the Contratos.gov.br numeric ID.

        Raises :class:`ComprasError` when neither is provided or resolution
        fails.
        """
        contrato_id = params.get("contrato_id")
        if contrato_id is not None:
            return int(contrato_id)

        id_contrato = (params.get("id_contrato") or "").strip()
        if not id_contrato:
            raise ComprasError(
                400,
                "Requires 'contrato_id' (numeric, from Contratos.gov.br) "
                "or 'id_contrato' (string, from Dados Abertos, e.g. "
                "'idCompra:...'). Use listar_contratos_ug(unidade_codigo=...) "
                "to discover numeric contrato_ids first.",
            )

        # Try Dados Abertos lookup
        if ":" not in id_contrato:
            raise ComprasError(400, "id_contrato must be 'tipo:codigo' (e.g. 'idCompra:123456').")
        tipo, codigo = id_contrato.split(":", 1)
        try:
            da_client = ComprasClient()
            raw = await da_client.get_contrato_by_id(tipo, codigo)
        except Exception as exc:
            raise ComprasError(502, f"Dados Abertos lookup failed: {exc}") from exc

        # Check if the Dados Abertos response has a Contratos.gov.br ID
        cg_id = raw.get("codigoContrato") or raw.get("codigo")
        if cg_id:
            try:
                return int(cg_id)
            except (TypeError, ValueError):
                pass

        raise ComprasError(
            400,
            f"Could not resolve '{id_contrato}' to a Contratos.gov.br "
            f"numeric ID. The Dados Abertos response does not contain a "
            f"mappable 'codigoContrato'. "
            f"Use listar_contratos_ug(unidade_codigo=...) first to obtain "
            f"the numeric contrato_id.",
        )

    async def _do_listar_empenhos(self, params: dict) -> dict:
        """List empenhos for a contract (Contratos.gov.br)."""
        contrato_id = await self._resolve_contrato_id(params)
        cg_client = ContratosGovbrClient()
        raw = await cg_client.listar_empenhos(contrato_id)
        empenhos = [slim_empenho(r) for r in raw]
        return {
            "contrato_id": contrato_id,
            "empenhos": empenhos,
            "total": len(empenhos),
            "agent_hint": (
                "Valores em formato brasileiro (ex: '42.290,89'). "
                "Use listar_faturas(contrato_id=...) para ver as faturas."
            ) if empenhos else None,
        }

    async def _do_listar_itens_contrato(self, params: dict) -> dict:
        """List items for a contract (Contratos.gov.br)."""
        contrato_id = await self._resolve_contrato_id(params)
        cg_client = ContratosGovbrClient()
        raw = await cg_client.listar_itens(contrato_id)
        itens = [slim_item_contrato(r) for r in raw]
        return {
            "contrato_id": contrato_id,
            "itens": itens,
            "total": len(itens),
        }

    async def _do_listar_faturas(self, params: dict) -> dict:
        """List faturas for a contract (Contratos.gov.br)."""
        contrato_id = await self._resolve_contrato_id(params)
        cg_client = ContratosGovbrClient()
        raw = await cg_client.listar_faturas(contrato_id)
        faturas = [slim_fatura(r) for r in raw]
        return {
            "contrato_id": contrato_id,
            "faturas": faturas,
            "total": len(faturas),
        }

    async def _do_listar_historico_contrato(self, params: dict) -> dict:
        """List amendments for a contract (Contratos.gov.br)."""
        contrato_id = await self._resolve_contrato_id(params)
        cg_client = ContratosGovbrClient()
        raw = await cg_client.listar_historico(contrato_id)
        historico = [slim_historico_contrato(r) for r in raw]
        return {
            "contrato_id": contrato_id,
            "historico": historico,
            "total": len(historico),
        }

    async def _do_listar_terceirizados(self, params: dict) -> dict:
        """List outsourced workers for a contract (Contratos.gov.br)."""
        contrato_id = self._require(params, "contrato_id")
        cg_client = ContratosGovbrClient()
        raw = await cg_client.listar_terceirizados(contrato_id)
        terceirizados = [slim_terceirizado(r) for r in raw]
        return {
            "contrato_id": contrato_id,
            "terceirizados": terceirizados,
            "total": len(terceirizados),
        }

    # ── Fase 1: Novos endpoints Contratos.gov.br ────────────────────────────

    _CG_DETALHE_MAP = {
        "listar_garantias_contrato": ("garantias", slim_garantia),
        "listar_cronograma_contrato": ("cronograma", slim_cronograma),
        "listar_ocorrencias_contrato": ("ocorrencias", slim_ocorrencia),
        "listar_publicacoes_contrato": ("publicacoes", slim_publicacao),
        "listar_responsaveis_contrato": ("responsaveis", slim_responsavel),
        "listar_prepostos_contrato": ("prepostos", slim_preposto),
        "listar_despesas_acessorias": ("despesas_acessorias", slim_despesa_acessoria),
        "listar_arquivos_contrato": ("arquivos", slim_arquivo_contrato),
        "listar_domicilio_bancario": ("domicilio_bancario", slim_domicilio_bancario),
    }

    async def _do_listar_detalhe_contrato_simples(self, action: str, params: dict) -> dict:
        """Generic handler for single-endpoint contract detail actions."""
        contrato_id = await self._resolve_contrato_id(params)
        endpoint, slim_fn = self._CG_DETALHE_MAP[action]
        cg_client = ContratosGovbrClient()
        raw = await getattr(cg_client, f"listar_{endpoint.replace('-', '_')}")(contrato_id)
        if isinstance(raw, list):
            items = [slim_fn(r) for r in raw]
        elif isinstance(raw, dict):
            items = slim_fn(raw)
        else:
            items = []
        return {
            "contrato_id": contrato_id,
            "itens": items if isinstance(items, list) else [items],
            "total": len(items) if isinstance(items, list) else 1,
        }

    async def _do_listar_contratos_inativos_ug(self, params: dict) -> dict:
        """List inactive contracts for a UG (Contratos.gov.br)."""
        unidade_codigo = int(self._require(params, "unidade_codigo"))
        cg_client = ContratosGovbrClient()
        raw = await cg_client.listar_contratos_inativos_ug(unidade_codigo)
        contratos = [slim_contrato_ug(r) for r in raw]
        return {
            "unidade_codigo": unidade_codigo,
            "contratos": contratos,
            "total": len(contratos),
        }

    async def _do_buscar_contrato_ug_origem(self, params: dict) -> dict:
        """Find contract by UASG origin + number/year."""
        codigo_uasg = int(self._require(params, "codigo_uasg"))
        numero_contrato = str(params.get("numero_contrato", "") or "").strip()
        if not numero_contrato:
            raise ComprasError(400, "'numero_contrato' is required (e.g. '00022/2025').")
        cg_client = ContratosGovbrClient()
        raw = await cg_client.buscar_contrato_ug_origem(codigo_uasg, numero_contrato)  # type: ignore[arg-type]
        if not raw:
            return {"not_found": True, "codigo_uasg": codigo_uasg, "numero_contrato": numero_contrato}
        contrato = slim_contrato_ug(raw)
        return {"contrato": contrato, "not_found": False}

    # ── Fase 2: detalhar_contrato_completo ────────────────────────────────

    async def _do_detalhar_contrato_completo(
        self, params: dict, agent_context: AgentContext,
    ) -> dict:
        """Full contract detail — fetches ALL sub-resources in parallel.

        Sections with more than ``_PREVIEW_LIMIT`` (20) rows are exported
        as CSV artifacts and only a preview is inlined in the response.
        """
        contrato_id = await self._resolve_contrato_id(params)
        cg = ContratosGovbrClient()

        # All possible detail endpoints
        raw = await asyncio.gather(
            cg.consultar_contrato(contrato_id),
            cg.listar_itens(contrato_id),
            cg.listar_empenhos(contrato_id),
            cg.listar_faturas(contrato_id),
            cg.listar_garantias(contrato_id),
            cg.listar_cronograma(contrato_id),
            cg.listar_historico(contrato_id),
            cg.listar_ocorrencias(contrato_id),
            cg.listar_responsaveis(contrato_id),
            cg.listar_prepostos(contrato_id),
            cg.listar_despesas_acessorias(contrato_id),
            cg.listar_publicacoes(contrato_id),
            cg.listar_arquivos(contrato_id),
            cg.listar_domicilio_bancario(contrato_id),
            cg.listar_terceirizados(contrato_id),
            return_exceptions=True,
        )
        (
            contrato_raw, itens_raw, empenhos_raw, faturas_raw,
            garantias_raw, cronograma_raw, historico_raw, ocorrencias_raw,
            responsaveis_raw, prepostos_raw, despesas_raw, publicacoes_raw,
            arquivos_raw, domicilio_raw, terceirizados_raw,
        ) = raw

        result: dict = {"contrato_id": contrato_id}

        if isinstance(contrato_raw, dict) and contrato_raw.get("id"):
            result["contrato"] = slim_contrato_ug(contrato_raw)

        sections_with_csv: list[str] = []
        sections_inline: list[str] = []

        for key, raw_data, slim_fn in (
            ("itens", itens_raw, slim_item_contrato),
            ("empenhos", empenhos_raw, slim_empenho),
            ("faturas", faturas_raw, slim_fatura),
            ("garantias", garantias_raw, slim_garantia),
            ("cronograma", cronograma_raw, slim_cronograma),
            ("historico", historico_raw, slim_historico_contrato),
            ("ocorrencias", ocorrencias_raw, slim_ocorrencia),
            ("responsaveis", responsaveis_raw, slim_responsavel),
            ("prepostos", prepostos_raw, slim_preposto),
            ("despesas_acessorias", despesas_raw, slim_despesa_acessoria),
            ("publicacoes", publicacoes_raw, slim_publicacao),
            ("arquivos", arquivos_raw, slim_arquivo_contrato),
            ("terceirizados", terceirizados_raw, slim_terceirizado),
        ):
            if not (isinstance(raw_data, list) and raw_data):
                continue
            items = [slim_fn(r) for r in raw_data]
            total = len(items)

            if total > _PREVIEW_LIMIT:
                # Export full data as CSV; inline only a preview
                csv_data = export_to_csv(items)
                stored = await store_export_artifact(
                    tool=self,
                    agent_context=agent_context,
                    data=csv_data,
                    filename=f"{key}_{contrato_id}.csv",
                    content_type="text/csv",
                )
                result[key] = {
                    "preview": items[:_PREVIEW_LIMIT],
                    "total": total,
                    "truncated": True,
                }
                if stored:
                    result[key]["csv_file_id"] = stored["file_id"]
                    result[key]["csv_download_path"] = stored["download_path"]
                sections_with_csv.append(key)
            else:
                result[key] = items
                sections_inline.append(key)

        if isinstance(domicilio_raw, dict):
            result["domicilio_bancario"] = slim_domicilio_bancario(domicilio_raw)
            sections_inline.append("domicilio_bancario")

        # Build agent_hint
        hint_parts: list[str] = [f"Contrato {contrato_id}:"]
        if sections_inline:
            hint_parts.append(
                f"seções inline: {', '.join(sections_inline)}."
            )
        if sections_with_csv:
            hint_parts.append(
                f"seções com CSV (>{_PREVIEW_LIMIT} registros): "
                f"{', '.join(sections_with_csv)}. "
                f"Apresente os links de download ao usuário."
            )
        result["agent_hint"] = " ".join(hint_parts)

        sections = sections_inline + [f"{s} (CSV)" for s in sections_with_csv]
        result["secoes_carregadas"] = sections
        return result
