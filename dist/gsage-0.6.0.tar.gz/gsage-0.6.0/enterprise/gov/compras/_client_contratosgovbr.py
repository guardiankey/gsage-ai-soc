"""gSage AI — Contratos.gov.br API client.

Async HTTP client for the public Contratos.gov.br API (federal contracts post-2021).
No authentication required — the API is fully public.

Key implementation notes (validated 2026-06-25):
- ``GET /id/{id}`` returns a **list** (take first element).
- Sub-resources use **plural**: empenhos, faturas, itens, terceirizados
- ``historico`` uses **singular**.
- Responses are plain JSON arrays/objects — no SIORG envelope, no pagination wrapper.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

import httpx

from src.mcp_server.tools.enterprise.gov.compras._constants import (
    CONTRATOSGOVBR_BASE,
    CONTRATOSGOVBR_TIMEOUT,
    _PAGE_DELAY,
)

log = logging.getLogger(__name__)


class ContratosGovbrError(Exception):
    """Raised on Contratos.gov.br API errors."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


class ContratosGovbrClient:
    """Async HTTP client for the public Contratos.gov.br API."""

    def __init__(self, timeout: float = CONTRATOSGOVBR_TIMEOUT) -> None:
        self._timeout = timeout
        self._last_call = 0.0
        self._lock = asyncio.Lock()

    async def _rate_limit(self) -> None:
        """Ensure minimum delay between calls — serialised via async lock."""
        async with self._lock:
            now = asyncio.get_event_loop().time()
            elapsed = now - self._last_call
            if elapsed < _PAGE_DELAY:
                await asyncio.sleep(_PAGE_DELAY - elapsed)
            self._last_call = asyncio.get_event_loop().time()

    async def _get(self, path: str) -> Any:
        """GET with rate-limiting.

        Returns parsed JSON (list or dict).  Raises ContratosGovbrError on
        HTTP errors.  Returns ``[]`` on 404 (resource not found).
        """
        await self._rate_limit()
        url = f"{CONTRATOSGOVBR_BASE}{path}"
        async with httpx.AsyncClient(
            timeout=self._timeout, follow_redirects=True,
        ) as client:
            resp = await client.get(url)
            if resp.status_code == 404:
                log.warning("Contratos.gov.br 404: %s", path)
                return []
            if resp.status_code >= 400:
                raise ContratosGovbrError(
                    resp.status_code,
                    f"Contratos.gov.br error: {resp.status_code} {path}",
                )
            return resp.json()

    # ── Endpoints ──────────────────────────────────────────────────────────

    async def listar_contratos_ug(self, unidade_codigo: int) -> list[dict[str, Any]]:
        """List active contracts for a UG (Unidade Gestora).

        Returns raw API list — callers should slim via ``_views.slim_contrato_ug()``.
        """
        data: Any = await self._get(f"/ug/{unidade_codigo}")
        return data if isinstance(data, list) else []

    async def consultar_contrato(self, contrato_id: int) -> Optional[dict[str, Any]]:
        """Get a single contract by numeric ID.

        API returns a list; we take the first element.
        Returns ``None`` when not found.
        """
        data: Any = await self._get(f"/id/{contrato_id}")
        if isinstance(data, list):
            return data[0] if data else None
        if isinstance(data, dict):
            return None if "error" in data else data
        return None

    async def listar_empenhos(self, contrato_id: int) -> list[dict[str, Any]]:
        """List empenhos (budget commitments) for a contract."""
        data: Any = await self._get(f"/{contrato_id}/empenhos")
        return data if isinstance(data, list) else []

    async def listar_faturas(self, contrato_id: int) -> list[dict[str, Any]]:
        """List faturas (invoices) for a contract."""
        data: Any = await self._get(f"/{contrato_id}/faturas")
        return data if isinstance(data, list) else []

    async def listar_itens(self, contrato_id: int) -> list[dict[str, Any]]:
        """List items for a contract."""
        data: Any = await self._get(f"/{contrato_id}/itens")
        return data if isinstance(data, list) else []

    async def listar_historico(self, contrato_id: int) -> list[dict[str, Any]]:
        """List history (amendments/addendums) for a contract."""
        data: Any = await self._get(f"/{contrato_id}/historico")
        return data if isinstance(data, list) else []

    async def listar_terceirizados(self, contrato_id: int) -> list[dict[str, Any]]:
        """List outsourced workers for a contract."""
        data: Any = await self._get(f"/{contrato_id}/terceirizados")
        return data if isinstance(data, list) else []

    async def listar_orgaos(self) -> list[dict[str, Any]]:
        """List all orgaos with active contracts."""
        data: Any = await self._get("/orgaos")
        return data if isinstance(data, list) else []

    async def listar_unidades(self) -> list[dict[str, Any]]:
        """List all unidades with active contracts."""
        data: Any = await self._get("/unidades")
        return data if isinstance(data, list) else []

    # ── Novos endpoints (Fase 1) ─────────────────────────────────────────

    async def listar_garantias(self, contrato_id: int) -> list[dict[str, Any]]:
        """List guarantees for a contract."""
        data: Any = await self._get(f"/{contrato_id}/garantias")
        return data if isinstance(data, list) else []

    async def listar_cronograma(self, contrato_id: int) -> list[dict[str, Any]]:
        """List execution schedule for a contract."""
        data: Any = await self._get(f"/{contrato_id}/cronograma")
        return data if isinstance(data, list) else []

    async def listar_ocorrencias(self, contrato_id: int) -> list[dict[str, Any]]:
        """List occurrences/delays for a contract."""
        data: Any = await self._get(f"/{contrato_id}/ocorrencias")
        return data if isinstance(data, list) else []

    async def listar_publicacoes(self, contrato_id: int) -> list[dict[str, Any]]:
        """List publications (DOU) for a contract."""
        data: Any = await self._get(f"/{contrato_id}/publicacoes")
        return data if isinstance(data, list) else []

    async def listar_responsaveis(self, contrato_id: int) -> list[dict[str, Any]]:
        """List responsables for a contract."""
        data: Any = await self._get(f"/{contrato_id}/responsaveis")
        return data if isinstance(data, list) else []

    async def listar_prepostos(self, contrato_id: int) -> list[dict[str, Any]]:
        """List supplier representatives for a contract."""
        data: Any = await self._get(f"/{contrato_id}/prepostos")
        return data if isinstance(data, list) else []

    async def listar_despesas_acessorias(self, contrato_id: int) -> list[dict[str, Any]]:
        """List ancillary expenses for a contract."""
        data: Any = await self._get(f"/{contrato_id}/despesas_acessorias")
        return data if isinstance(data, list) else []

    async def listar_arquivos(self, contrato_id: int) -> list[dict[str, Any]]:
        """List attached documents for a contract."""
        data: Any = await self._get(f"/{contrato_id}/arquivos")
        return data if isinstance(data, list) else []

    async def listar_domicilio_bancario(self, contrato_id: int) -> Optional[dict[str, Any]]:
        """Get bank account details for a contract."""
        data: Any = await self._get(f"/{contrato_id}/domiciliobancario")
        return data if isinstance(data, dict) and "error" not in data else None

    async def listar_contratos_inativos_ug(self, unidade_codigo: int) -> list[dict[str, Any]]:
        """List inactive contracts for a UG."""
        data: Any = await self._get(f"/inativo/ug/{unidade_codigo}")
        return data if isinstance(data, list) else []

    async def buscar_contrato_ug_origem(self, codigo_uasg: int, numero_contrato: str) -> Optional[dict[str, Any]]:
        """Find a contract by UASG origin + number/year (e.g. '00022/2025')."""
        data: Any = await self._get(f"/ugorigem/{codigo_uasg}/numeroano/{numero_contrato}")
        if isinstance(data, list):
            return data[0] if data else None
        if isinstance(data, dict):
            return None if "error" in data else data
        return None
