"""gSage AI — PNCP procurement tool (Lei 14.133/2021).

Query the Portal Nacional de Contratações Públicas (PNCP) native API.
Covers federal, state, and municipal procurement.

Permission: ``gov:compras:pncp_contratos:read``.

Important:
- The PNCP API has NO server-side text search. The ``texto`` parameter
  filters results client-side via ``_filtrar_por_texto()``.
- Date format: YYYYMMDD (also accepts YYYY-MM-DD and DD/MM/YYYY).
- Max date range: 365 days.
"""

from __future__ import annotations

import logging
import time
from datetime import date
from typing import ClassVar, Optional

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.mcp_server.tools.enterprise.gov.compras._client import (
    ComprasError,
    PNCPClient,
    _default_data_inicial,
    _filtrar_por_texto,
    normalizar_data_pncp,
    validar_periodo,
)
from src.mcp_server.tools.enterprise.gov.compras._constants import (
    MAX_DATE_RANGE_DAYS,
    MODALIDADES_PNCP,
    MODOS_DISPUTA,
    _DEFAULT_MAX_RESULTS,
    _MAX_PAGE_SIZE_CONTRATACOES,
)
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

_ACTIONS = frozenset({
    "listar_contratacoes",
    "listar_contratos",
    "listar_atas",
    "detalhar_contratacao",
    "listar_contratacoes_abertas",
    "listar_pca",
    "listar_contratacoes_atualizadas",
    "listar_contratos_atualizados",
    "listar_atas_atualizadas",
    "listar_instrumentos_cobranca",
})


class PncpContratosTool(BaseTool):
    """Query the PNCP (Portal Nacional de Contratações Públicas) native API.

    Actions
    -------
    - ``listar_contratacoes`` — search contratações by period + modalidade + texto.
    - ``listar_contratos`` — search contratos by period + texto.
    - ``listar_atas`` — search atas de registro de preço by period + texto.
    - ``detalhar_contratacao`` — detail of a specific contratação.
    - ``listar_contratacoes_abertas`` — contratações with open proposals.
    - ``listar_pca`` — Plano de Contratações Anual.
    - ``listar_contratacoes_atualizadas`` — recently updated contratações (feed).
    - ``listar_contratos_atualizados`` — recently updated contratos (feed).
    - ``listar_atas_atualizadas`` — recently updated atas (feed).
    - ``listar_instrumentos_cobranca`` — instrumentos de cobrança / NF.

    **Hint:** For supplier/org lookup by CNPJ/CPF, use the
    ``comprasgovbr`` tool (actions ``buscar_fornecedores`` /
    ``buscar_orgao``) instead — the PNCP API does not expose
    dedicated supplier or org endpoints.

    Permission: ``gov:compras:pncp_contratos:read``.
    """

    name: ClassVar[str] = "pncp_contratos"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Query the PNCP (Portal Nacional de Contratações Públicas) native API: "
        "contratações, contratos, atas, PCA, and feeds. "
        "Covers Lei 14.133/2021 with 19 modalidades."
    )
    category: ClassVar[str] = "gov"
    permissions: ClassVar[list[str]] = ["gov:compras:pncp_contratos:read"]
    rate_limit_per_minute: ClassVar[int] = 30
    timeout_seconds: ClassVar[int] = 180
    use_circuit_breaker: ClassVar[bool] = False
    requires_approval: ClassVar[bool] = False
    supports_multiple_configs: ClassVar[bool] = False
    requires_config: ClassVar[bool] = False

    params_schema: ClassVar[dict] = {
        "type": "object",
        "required": ["action"],
        "properties": {
            "action": {
                "type": "string",
                "enum": sorted(_ACTIONS),
                "description": "Which PNCP query to perform.",
            },
            "data_inicial": {
                "type": "string",
                "description": (
                    "Start date. Format: YYYYMMDD (e.g. 20250101). "
                    "Also accepts YYYY-MM-DD or DD/MM/YYYY. "
                    "Default: 30 days ago."
                ),
            },
            "data_final": {
                "type": "string",
                "description": (
                    "End date. Format: YYYYMMDD (e.g. 20250331). "
                    "Also accepts YYYY-MM-DD or DD/MM/YYYY. "
                    f"Max {MAX_DATE_RANGE_DAYS} days from data_inicial. "
                    "Default: today."
                ),
            },
            "modalidade": {
                "type": "integer",
                "minimum": 1,
                "maximum": 19,
                "description": (
                    "[listar_contratacoes, listar_contratacoes_abertas, "
                    "listar_contratacoes_atualizadas] "
                    "Modalidade code. 6=Pregão Eletrônico (most common). "
                    "See MODALIDADES_PNCP in constants for full list."
                ),
            },
            "texto": {
                "type": "string",
                "description": (
                    "Client-side text filter. Searches objeto, órgão, and "
                    "fornecedor fields. IMPORTANT: PNCP API has no text search — "
                    "filtering happens locally after fetching."
                ),
            },
            "uf": {
                "type": "string",
                "description": "State abbreviation filter (e.g. SP, RJ, DF).",
            },
            "cnpj_orgao": {
                "type": "string",
                "description": "CNPJ of the contracting org (14 digits).",
            },
            "cnpj": {
                "type": "string",
                "description": "[consultar_fornecedor, consultar_orgao] CNPJ (14 digits).",
            },
            "cpf": {
                "type": "string",
                "description": "[consultar_fornecedor] CPF (11 digits).",
            },
            "modo_disputa": {
                "type": "integer",
                "minimum": 1,
                "maximum": 5,
                "description": (
                    "[listar_contratacoes] Modo de disputa: "
                    "1=Aberto, 2=Fechado, 3=Aberto-Fechado, "
                    "4=Dispensa Com Disputa, 5=Não se aplica."
                ),
            },
            "ano": {
                "type": "integer",
                "description": "[listar_pca, detalhar_contratacao] Year. Example: 2025.",
            },
            "sequencial_compra": {
                "type": "integer",
                "minimum": 1,
                "description": (
                    "[detalhar_contratacao] Sequencial number of the contratação. "
                    "Obtained from listar_contratacoes results (campo sequencialCompra). "
                    "Example: 89."
                ),
            },
            "pagina": {
                "type": "integer",
                "minimum": 1,
                "description": "Page number for paginated results (default 1).",
            },
            "max_results": {
                "type": "integer",
                "minimum": 1,
                "maximum": 500,
                "description": (
                    f"Max results per page (default {_DEFAULT_MAX_RESULTS})."
                ),
            },
            "force_refresh": {
                "type": "boolean",
                "description": "Bypass cache.",
            },
        },
        "additionalProperties": False,
    }

    config_schema: ClassVar[Optional[dict]] = None
    config_defaults: ClassVar[dict] = {}
    state_schema: ClassVar[Optional[dict]] = None
    state_defaults: ClassVar[dict] = {}
    reset_policy: ClassVar[str] = "never"

    # ── Execute ───────────────────────────────────────────────────────────

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        t0 = time.monotonic()
        action = (params.get("action") or "").strip()
        if action not in _ACTIONS:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "INVALID_PARAMS",
                f"action must be one of {sorted(_ACTIONS)}; got {action!r}.",
                execution_time_ms=elapsed,
            )

        try:
            data = await self._dispatch(action, params)
        except ComprasError as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                f"API_ERROR_{exc.code}", exc.message,
                execution_time_ms=elapsed,
            )
        except ValueError as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "VALIDATION_ERROR", str(exc),
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            log.exception("pncp_contratos(%s): unexpected error", action)
            elapsed = int((time.monotonic() - t0) * 1000)
            msg = str(exc) or type(exc).__name__
            return self._failure(
                "INTERNAL_ERROR", msg, execution_time_ms=elapsed,
            )

        elapsed = int((time.monotonic() - t0) * 1000)
        return self._success(data={"action": action, **data}, execution_time_ms=elapsed)

    # ── Dispatch ──────────────────────────────────────────────────────────

    async def _dispatch(self, action: str, params: dict) -> dict:
        client = PNCPClient()

        if action == "listar_contratacoes":
            return await self._do_listar_contratacoes(client, params)
        elif action == "listar_contratos":
            return await self._do_listar_contratos(client, params)
        elif action == "listar_atas":
            return await self._do_listar_atas(client, params)

        elif action == "detalhar_contratacao":
            return await self._do_detalhar_contratacao(client, params)
        elif action == "listar_contratacoes_abertas":
            return await self._do_listar_contratacoes_abertas(client, params)
        elif action == "listar_pca":
            return await self._do_listar_pca(client, params)
        elif action == "listar_contratacoes_atualizadas":
            return await self._do_listar_contratacoes_atualizadas(client, params)
        elif action == "listar_contratos_atualizados":
            return await self._do_listar_contratos_atualizados(client, params)
        elif action == "listar_atas_atualizadas":
            return await self._do_listar_atas_atualizadas(client, params)
        elif action == "listar_instrumentos_cobranca":
            return await self._do_listar_instrumentos_cobranca(client, params)
        else:
            raise ValueError(f"Unknown action: {action}")

    # ── Helpers ───────────────────────────────────────────────────────────

    def _require(self, params: dict, field: str) -> str:
        val = params.get(field)
        if val is None or str(val).strip() == "":
            raise ComprasError(400, f"'{field}' is required for this action.")
        return str(val).strip()

    def _max_results(self, params: dict) -> int:
        return min(int(params.get("max_results") or _DEFAULT_MAX_RESULTS), 500)

    def _resolve_dates(self, params: dict) -> tuple[str, str]:
        """Resolve and validate date range. Returns (data_inicial, data_final) in YYYYMMDD."""
        d_ini = normalizar_data_pncp(
            params.get("data_inicial") or _default_data_inicial()
        )
        d_fim = normalizar_data_pncp(
            params.get("data_final") or date.today().strftime("%Y-%m-%d")
        )
        # Validate period
        from datetime import datetime
        dt_ini = datetime.strptime(d_ini, "%Y%m%d")
        dt_fim = datetime.strptime(d_fim, "%Y%m%d")
        if dt_fim < dt_ini:
            raise ValueError(
                f"data_final ({d_fim}) é anterior a data_inicial ({d_ini})."
            )
        if (dt_fim - dt_ini).days > MAX_DATE_RANGE_DAYS:
            raise ValueError(
                f"Período excede o máximo de {MAX_DATE_RANGE_DAYS} dias."
            )
        return d_ini, d_fim

    # ── Listar contratações ───────────────────────────────────────────────

    async def _do_listar_contratacoes(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Search contratações by period + modalidade + optional text filter."""
        modalidade = params.get("modalidade")
        if not modalidade:
            raise ComprasError(400, "'modalidade' is required for listar_contratacoes.")
        modalidade = int(modalidade)
        mod_nome = MODALIDADES_PNCP.get(modalidade, f"Código {modalidade}")

        d_ini, d_fim = self._resolve_dates(params)
        max_results = self._max_results(params)
        texto = (params.get("texto") or "").strip() or None

        query: dict[str, str] = {
            "dataInicial": d_ini,
            "dataFinal": d_fim,
            "codigoModalidadeContratacao": str(modalidade),
        }
        uf = params.get("uf")
        if uf:
            query["uf"] = str(uf)
        cnpj_orgao = params.get("cnpj_orgao")
        if cnpj_orgao:
            query["cnpjOrgao"] = str(cnpj_orgao)
        modo_disputa = params.get("modo_disputa")
        if modo_disputa:
            query["modoDisputa"] = str(modo_disputa)

        raw = await client.get_contratacoes(max_results=max_results, **query)

        # Client-side text filter
        if texto:
            raw = _filtrar_por_texto(raw, texto)

        # Slim results
        resultados = []
        for r in raw:
            orgao = r.get("orgaoEntidade", {}) or {}
            valor_est = r.get("valorEstimado")
            valor_hom = r.get("valorHomologado")
            resultados.append({
                "objeto": r.get("objetoCompra"),
                "orgao_nome": orgao.get("razaoSocial"),
                "orgao_cnpj": orgao.get("cnpj"),
                "modalidade": mod_nome,
                "modalidade_id": r.get("modalidadeId"),
                "situacao": r.get("situacaoCompraNome"),
                "valor_estimado": round(float(valor_est), 2) if valor_est else None,
                "valor_homologado": round(float(valor_hom), 2) if valor_hom else None,
                "data_publicacao": r.get("dataPublicacaoPncp"),
                "uf": r.get("uf"),
                "municipio": r.get("municipio"),
                "link_pncp": r.get("linkPncp"),
            })

        return {
            "contratacoes": resultados,
            "total": len(resultados),
            "modalidade": {"codigo": modalidade, "nome": mod_nome},
            "periodo": {"inicial": d_ini, "final": d_fim},
            "filtro_texto": texto,
            "agent_hint": (
                f"{len(resultados)} contratações found for {mod_nome}. "
                "Use modalidade=6 for Pregão Eletrônico (most common). "
                "The 'texto' filter is applied client-side."
            ),
        }

    # ── Listar contratos ──────────────────────────────────────────────────

    async def _do_listar_contratos(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Search contratos by period + optional text filter."""
        d_ini, d_fim = self._resolve_dates(params)
        max_results = self._max_results(params)
        texto = (params.get("texto") or "").strip() or None

        query: dict[str, str] = {
            "dataInicial": d_ini,
            "dataFinal": d_fim,
        }
        cnpj_orgao = params.get("cnpj_orgao")
        if cnpj_orgao:
            query["cnpjOrgao"] = str(cnpj_orgao)

        raw = await client.get_contratos(max_results=max_results, **query)
        if texto:
            raw = _filtrar_por_texto(raw, texto)

        resultados = []
        for r in raw:
            forn = r.get("fornecedor", {}) or {}
            valor = r.get("valorFinal") or r.get("valorInicial")
            resultados.append({
                "objeto": r.get("objetoContrato"),
                "orgao_nome": (r.get("orgaoEntidade", {}) or {}).get("razaoSocial"),
                "fornecedor_nome": forn.get("razaoSocial") or forn.get("nomeRazaoSocial"),
                "fornecedor_cnpj": forn.get("cnpj"),
                "numero_contrato": r.get("numeroContrato"),
                "valor": round(float(valor), 2) if valor else None,
                "vigencia_inicio": r.get("vigenciaInicio"),
                "vigencia_fim": r.get("vigenciaFim"),
                "situacao": r.get("situacaoContrato"),
            })

        return {
            "contratos": resultados,
            "total": len(resultados),
            "periodo": {"inicial": d_ini, "final": d_fim},
            "filtro_texto": texto,
        }

    # ── Listar atas ───────────────────────────────────────────────────────

    async def _do_listar_atas(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Search atas de registro de preço by period + optional text."""
        d_ini, d_fim = self._resolve_dates(params)
        max_results = self._max_results(params)
        texto = (params.get("texto") or "").strip() or None

        query: dict[str, str] = {
            "dataInicial": d_ini,
            "dataFinal": d_fim,
        }
        cnpj_orgao = params.get("cnpj_orgao")
        if cnpj_orgao:
            query["cnpjOrgao"] = str(cnpj_orgao)

        raw = await client.get_atas(max_results=max_results, **query)
        if texto:
            raw = _filtrar_por_texto(raw, texto)

        resultados = []
        for r in raw:
            forn = r.get("fornecedor", {}) or {}
            resultados.append({
                "objeto": r.get("objetoAta"),
                "orgao_nome": (r.get("orgaoEntidade", {}) or {}).get("razaoSocial"),
                "fornecedor_nome": forn.get("razaoSocial") or forn.get("nomeRazaoSocial"),
                "fornecedor_cnpj": forn.get("cnpj"),
                "numero_ata": r.get("numeroAta"),
                "valor_total": round(float(r["valorTotal"]), 2) if r.get("valorTotal") else None,
                "vigencia_inicio": r.get("vigenciaInicio"),
                "vigencia_fim": r.get("vigenciaFim"),
                "situacao": r.get("situacaoAta"),
            })

        return {
            "atas": resultados,
            "total": len(resultados),
            "periodo": {"inicial": d_ini, "final": d_fim},
            "filtro_texto": texto,
        }

    # ── Consultas ─────────────────────────────────────────────────────────

    async def _do_detalhar_contratacao(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Get detail of a specific contratação."""
        cnpj = self._require(params, "cnpj_orgao")
        ano = int(self._require(params, "ano"))
        sequencial = int(self._require(params, "sequencial_compra"))

        raw = await client.get_contratacao_detalhe(cnpj, ano, sequencial)
        if not raw:
            return {
                "not_found": True,
                "cnpj": cnpj,
                "ano": ano,
                "sequencial": sequencial,
            }

        orgao = raw.get("orgaoEntidade", {}) or {}
        return {
            "contratacao": {
                "objeto": raw.get("objetoCompra"),
                "orgao_nome": orgao.get("razaoSocial"),
                "orgao_cnpj": orgao.get("cnpj"),
                "ano": raw.get("anoCompra"),
                "sequencial": raw.get("sequencialCompra"),
                "modalidade": raw.get("modalidadeNome"),
                "situacao": raw.get("situacaoCompraNome"),
                "valor_estimado": raw.get("valorEstimado"),
                "valor_homologado": raw.get("valorHomologado"),
                "data_publicacao": raw.get("dataPublicacaoPncp"),
                "data_abertura": raw.get("dataAberturaProposta"),
            },
        }

    # ── Abertas / Feeds ───────────────────────────────────────────────────

    async def _do_listar_contratacoes_abertas(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Contratações with open proposals."""
        modalidade = int(params.get("modalidade") or 6)
        d_ini, d_fim = self._resolve_dates(params)

        # PNCP /contratacoes/proposta requires dataFinal >= today
        from datetime import datetime
        hoje = datetime.now().strftime("%Y%m%d")
        if d_fim < hoje:
            raise ValueError(
                f"data_final ({d_fim}) deve ser maior ou igual à data atual "
                f"({hoje}) para contratações abertas. "
                "A API PNCP exige data final futura para este endpoint."
            )

        max_results = self._max_results(params)

        query: dict[str, str] = {
            "dataInicial": d_ini,
            "dataFinal": d_fim,
            "codigoModalidadeContratacao": str(modalidade),
        }
        raw = await client.get_contratacoes_proposta(max_results=max_results, **query)
        return {
            "contratacoes_abertas": raw,
            "total": len(raw),
            "modalidade": MODALIDADES_PNCP.get(modalidade, str(modalidade)),
        }

    async def _do_listar_pca(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Plano de Contratações Anual."""
        ano = int(params.get("ano") or date.today().year)
        max_results = self._max_results(params)
        raw = await client.get_pca(max_results=max_results, ano=str(ano))
        return {
            "pca": raw,
            "total": len(raw),
            "ano": ano,
        }

    async def _do_listar_contratacoes_atualizadas(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Feed of recently updated contratações."""
        modalidade = params.get("modalidade")
        if not modalidade:
            mod_list = "\n".join(
                f"  {k}: {v}" for k, v in MODALIDADES_PNCP.items()
            )
            raise ComprasError(
                400,
                f"'modalidade' é obrigatório para listar_contratacoes_atualizadas. "
                f"Opções disponíveis:\n{mod_list}",
            )
        modalidade = int(modalidade)
        d_ini, d_fim = self._resolve_dates(params)
        max_results = self._max_results(params)
        raw = await client.get_contratacoes_atualizacao(
            max_results=max_results,
            dataInicial=d_ini,
            dataFinal=d_fim,
            codigoModalidadeContratacao=str(modalidade),
        )
        return {
            "contratacoes_atualizadas": raw,
            "total": len(raw),
            "modalidade": MODALIDADES_PNCP.get(modalidade, str(modalidade)),
        }

    async def _do_listar_contratos_atualizados(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Feed of recently updated contratos."""
        d_ini, d_fim = self._resolve_dates(params)
        max_results = self._max_results(params)
        raw = await client.get_contratos_atualizacao(
            max_results=max_results,
            dataInicial=d_ini,
            dataFinal=d_fim,
        )
        return {"contratos_atualizados": raw, "total": len(raw)}

    async def _do_listar_atas_atualizadas(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Feed of recently updated atas."""
        d_ini, d_fim = self._resolve_dates(params)
        max_results = self._max_results(params)
        raw = await client.get_atas_atualizacao(
            max_results=max_results,
            dataInicial=d_ini,
            dataFinal=d_fim,
        )
        return {"atas_atualizadas": raw, "total": len(raw)}

    async def _do_listar_instrumentos_cobranca(
        self, client: PNCPClient, params: dict,
    ) -> dict:
        """Instrumentos de cobrança (notas fiscais)."""
        d_ini, d_fim = self._resolve_dates(params)

        # PNCP /instrumentoscobranca/inclusao enforces 30-day max (not 365)
        from datetime import datetime
        dt_ini = datetime.strptime(d_ini, "%Y%m%d")
        dt_fim = datetime.strptime(d_fim, "%Y%m%d")
        days = (dt_fim - dt_ini).days
        if days > 30:
            raise ValueError(
                f"Período de {days} dias excede o máximo de 30 dias "
                f"permitido pela API PNCP para instrumentos de cobrança. "
                f"Reduza o intervalo entre data_inicial ({d_ini}) e "
                f"data_final ({d_fim})."
            )

        max_results = self._max_results(params)
        raw = await client.get_instrumentos_cobranca(
            max_results=max_results,
            dataInicial=d_ini,
            dataFinal=d_fim,
        )
        return {"instrumentos_cobranca": raw, "total": len(raw)}
