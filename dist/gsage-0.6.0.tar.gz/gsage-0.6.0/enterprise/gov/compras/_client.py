"""gSage AI — Compras.gov.br + CNBS API clients.

Async HTTP clients for the public Brazilian federal procurement APIs.
No authentication required — both APIs are fully public.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timedelta
from typing import Any, Optional
from urllib.parse import urlparse

import httpx

from src.mcp_server.tools.enterprise.gov.compras._constants import (
    CNBS_BASE,
    CNBS_TIMEOUT,
    COMPRAS_BASE,
    COMPRAS_TIMEOUT,
    MAX_DATE_RANGE_DAYS,
    PNCP_API_BASE,
    PNCP_ATAS,
    PNCP_ATAS_ATUALIZACAO,
    PNCP_CONTRATACOES,
    PNCP_CONTRATACOES_ATUALIZACAO,
    PNCP_CONTRATACOES_PROPOSTA,
    PNCP_CONTRATOS,
    PNCP_CONTRATOS_ATUALIZACAO,
    PNCP_INSTRUMENTOS_COBRANCA,
    PNCP_PCA,
    PNCP_TIMEOUT,
    _PAGE_DELAY,
    _UASG_PAGE_SIZE,
)

log = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# Shared helpers — date normalisation, period validation, text filtering
# ═══════════════════════════════════════════════════════════════════════════════

_DATE_RE = re.compile(r"^\d{8}$")


def normalizar_data(data: str) -> str:
    """Normalize a date string to YYYY-MM-DD format (ISO).

    Accepts: YYYYMMDD, YYYY-MM-DD, DD/MM/YYYY.
    Raises ValueError for invalid formats.

    >>> normalizar_data("20250101")
    '2025-01-01'
    >>> normalizar_data("2025-01-01")
    '2025-01-01'
    >>> normalizar_data("01/01/2025")
    '2025-01-01'
    """
    cleaned = data.strip()

    # Already YYYYMMDD → convert to ISO
    if _DATE_RE.match(cleaned):
        dt = datetime.strptime(cleaned, "%Y%m%d")
        return dt.strftime("%Y-%m-%d")

    # YYYY-MM-DD → already ISO
    if len(cleaned) == 10 and cleaned[4] == "-":
        datetime.strptime(cleaned, "%Y-%m-%d")  # validate
        return cleaned

    # DD/MM/YYYY → convert to ISO
    if len(cleaned) == 10 and cleaned[2] == "/":
        dt = datetime.strptime(cleaned, "%d/%m/%Y")
        return dt.strftime("%Y-%m-%d")

    msg = f"Formato de data inválido: '{data}'. Use YYYYMMDD, YYYY-MM-DD ou DD/MM/YYYY."
    raise ValueError(msg)


def normalizar_data_pncp(data: str) -> str:
    """Normalize a date string to YYYYMMDD format (PNCP API requirement).

    Accepts: YYYYMMDD, YYYY-MM-DD, DD/MM/YYYY.
    """
    cleaned = data.strip()

    if _DATE_RE.match(cleaned):
        datetime.strptime(cleaned, "%Y%m%d")  # validate
        return cleaned

    if len(cleaned) == 10 and cleaned[4] == "-":
        dt = datetime.strptime(cleaned, "%Y-%m-%d")
        return dt.strftime("%Y%m%d")

    if len(cleaned) == 10 and cleaned[2] == "/":
        dt = datetime.strptime(cleaned, "%d/%m/%Y")
        return dt.strftime("%Y%m%d")

    msg = f"Formato de data inválido: '{data}'. Use YYYYMMDD, YYYY-MM-DD ou DD/MM/YYYY."
    raise ValueError(msg)


def validar_periodo(data_inicial: str, data_final: str) -> None:
    """Validate that the date range does not exceed MAX_DATE_RANGE_DAYS.

    Accepts dates already normalised to ISO (YYYY-MM-DD).
    Raises ValueError if data_final < data_inicial or range > limit.
    """
    dt_ini = datetime.strptime(data_inicial, "%Y-%m-%d")
    dt_fim = datetime.strptime(data_final, "%Y-%m-%d")
    if dt_fim < dt_ini:
        msg = f"data_final ({data_final}) é anterior a data_inicial ({data_inicial})."
        raise ValueError(msg)
    diff = (dt_fim - dt_ini).days
    if diff > MAX_DATE_RANGE_DAYS:
        msg = (
            f"Período de {diff} dias excede o máximo de {MAX_DATE_RANGE_DAYS} dias. "
            "Reduza o intervalo entre data_inicial e data_final."
        )
        raise ValueError(msg)


def _default_data_inicial(dias_atras: int = 30) -> str:
    """Return *dias_atras* days ago in ISO format (sensible default for queries)."""
    return (datetime.now() - timedelta(days=dias_atras)).strftime("%Y-%m-%d")


def _default_data_final() -> str:
    """Return today in ISO format."""
    return datetime.now().strftime("%Y-%m-%d")


def _filtrar_por_texto(
    items: list[dict[str, Any]], texto: str | None,
    campos: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Filter API results client-side by text match on relevant fields.

    Used for APIs that lack server-side text search (e.g. PNCP).
    Default searchable fields cover common procurement response shapes.
    """
    if not texto:
        return items

    termo = texto.lower()
    if campos is None:
        campos = [
            "objeto", "objetoCompra", "objetoContrato", "objetoContratacao",
            "objetoAta", "descricao", "descricaoItem",
            "nomeRazaoSocialFornecedor", "nomeFornecedor",
            "razaoSocialFornecedor", "nomeOrgao", "nomeUasg",
            "nomeUnidadeGestora",
        ]

    filtered: list[dict[str, Any]] = []
    for item in items:
        # Build a single searchable string from all candidate fields
        fragments: list[str] = []
        for campo in campos:
            val = item.get(campo)
            if val and isinstance(val, str):
                fragments.append(val.lower())

        # Also search in nested dicts common in PNCP/Contratos.gov.br
        for nested_key in ("orgaoEntidade", "fornecedor", "contratante", "orgao"):
            nested = item.get(nested_key)
            if isinstance(nested, dict):
                for v in nested.values():
                    if v and isinstance(v, str):
                        fragments.append(v.lower())

        if termo in " ".join(fragments):
            filtered.append(item)

    return filtered


# ═══════════════════════════════════════════════════════════════════════════════
# Exceptions
# ═══════════════════════════════════════════════════════════════════════════════


class ComprasError(Exception):
    """Raised on API errors (including SIORG-style envelope errors)."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


# ── URI helpers ─────────────────────────────────────────────────────────────


def parse_id(uri: object) -> Optional[int]:
    """Extract numeric id from a SIORG-style URI."""
    if not isinstance(uri, str) or not uri.strip():
        return None
    try:
        path = urlparse(uri).path
        parts = path.rstrip("/").rsplit("/", 1)
        return int(parts[-1])
    except (ValueError, IndexError):
        return None


def parse_label(uri: object) -> Optional[str]:
    """Extract human-readable label from a SIORG-style URI."""
    if not isinstance(uri, str) or not uri.strip():
        return None
    try:
        path = urlparse(uri).path
        return path.rstrip("/").rsplit("/", 1)[-1]
    except (ValueError, IndexError):
        return None


# ── Compras.gov.br client ────────────────────────────────────────────────────


class ComprasClient:
    """Async HTTP client for the public Compras.gov.br API."""

    def __init__(self, timeout: float = COMPRAS_TIMEOUT) -> None:
        self._timeout = timeout
        self._last_call = 0.0
        self._lock = asyncio.Lock()

    async def _rate_limit(self) -> None:
        """Ensure minimum delay between calls — serialised via async lock."""
        async with self._lock:
            now = asyncio.get_event_loop().time()
            elapsed = now - self._last_call
            if elapsed < _PAGE_DELAY:
                await asyncio.sleep(_PAGE_DELAY - elapsed)
            self._last_call = asyncio.get_event_loop().time()

    async def _get(self, path: str, **params: Any) -> dict:
        """GET with rate-limiting and error handling.

        Returns ``{"resultado": [], "totalRegistros": 0}`` on 404 so
        callers can proceed without crashing.
        """
        await self._rate_limit()
        url = f"{COMPRAS_BASE}{path}"
        async with httpx.AsyncClient(
            timeout=self._timeout, follow_redirects=True,
        ) as client:
            resp = await client.get(url, params=params)
            # 404 → empty result (endpoint or resource not found)
            if resp.status_code == 404:
                log.warning("Compras API 404: %s params=%s", path, params)
                return {"resultado": [], "totalRegistros": 0}
            resp.raise_for_status()
            data: dict = resp.json()

        # Check for API-level errors (some endpoints return 200 with error message)
        if isinstance(data, dict) and "statusCode" in data:
            code = data.get("statusCode", 0)
            if code != 200:
                msg = data.get("message", "Unknown error")
                raise ComprasError(code, msg)
        return data

    async def _get_paginated(
        self, path: str, max_results: int = 50, page_size: int = 0, **params: Any,
    ) -> list[dict]:
        """Fetch up to *max_results* items, handling pagination automatically.

        If *page_size* is 0 (default), it is auto-calculated from
        ``max(10, min(500, max_results))``.  Some endpoints (e.g. UASG)
        reject sizes > 10 — pass ``page_size=10`` for those.
        """
        if page_size <= 0:
            page_size = min(500, max(10, max_results))
        collected: list[dict] = []
        page = 1

        while len(collected) < max_results:
            resp = await self._get(
                path, pagina=str(page), tamanhoPagina=str(page_size), **params,
            )
            items = resp.get("resultado", [])
            if not items:
                break
            collected.extend(items)
            total_pages = int(resp.get("totalPaginas", 1))
            if page >= total_pages:
                break
            page += 1
        return collected[:max_results]

    async def _fetch_with_date_split(
        self,
        path: str,
        max_results: int,
        params: dict[str, Any],
        date_min_key: str,
        date_max_key: str,
    ) -> list[dict]:
        """Fetch with auto-split when date range > 365 days.

        Extracts *date_min_key* and *date_max_key* from *params*,
        splits into ≤365-day chunks if needed, and merges results.
        Falls back to a single ``_get_paginated`` call when no date
        range is present or it is already ≤365 days.
        """
        d_min_str = params.pop(date_min_key, None)
        d_max_str = params.pop(date_max_key, None)
        if not d_min_str or not d_max_str:
            return await self._get_paginated(path, max_results=max_results, **params)

        from datetime import datetime, timedelta
        try:
            d_min = datetime.fromisoformat(str(d_min_str))
            d_max = datetime.fromisoformat(str(d_max_str))
        except ValueError:
            return await self._get_paginated(path, max_results=max_results, **params)

        if d_min > d_max:
            d_min, d_max = d_max, d_min
        if (d_max - d_min).days <= 365:
            # Restore and do single call
            params[date_min_key] = str(d_min_str)
            params[date_max_key] = str(d_max_str)
            return await self._get_paginated(path, max_results=max_results, **params)

        # Split into 365-day chunks
        collected: list[dict] = []
        chunk_start = d_min
        while chunk_start < d_max and len(collected) < max_results:
            chunk_end = min(chunk_start + timedelta(days=365), d_max)
            chunk_params: dict[str, Any] = {
                date_min_key: chunk_start.date().isoformat(),
                date_max_key: chunk_end.date().isoformat(),
                **params,
            }
            chunk = await self._get_paginated(
                path, max_results=max_results - len(collected), **chunk_params,
            )
            collected.extend(chunk)
            chunk_start = chunk_end + timedelta(days=1)

        return collected[:max_results]
    # ── Endpoints ────────────────────────────────────────────────────────

    async def get_uasg(self, **params: Any) -> list[dict]:
        """U1: Search UASGs.  Requires ``statusUasg=1`` for results."""
        # statusUasg=1 is required — the endpoint silently returns [] without it
        if "statusUasg" not in params:
            params["statusUasg"] = "1"
        return await self._get_paginated(
            "/modulo-uasg/1_consultarUasg", max_results=50,
            page_size=_UASG_PAGE_SIZE, **params,
        )

    async def get_orgaos_uasg(self, **params: Any) -> list[dict]:
        """U3: Search orgs by CNPJ/code.  Uses ``statusOrgao=true`` (NOT statusUasg)."""
        if "statusOrgao" not in params:
            params["statusOrgao"] = "true"
        return await self._get_paginated(
            "/modulo-uasg/2_consultarOrgao", max_results=50,
            page_size=_UASG_PAGE_SIZE, **params,
        )

    async def get_contratos(self, max_results: int = 50, **params: Any) -> list[dict]:
        """C1: List contracts.  Auto-splits date range > 365 days."""
        return await self._fetch_with_date_split(
            "/modulo-contratos/1_consultarContratos",
            max_results, params,
            "dataVigenciaInicialMin", "dataVigenciaInicialMax",
        )

    async def get_contrato_by_id(self, tipo: str, codigo: str) -> dict:
        """C2: Get contract details by ID."""
        resp = await self._get(
            "/modulo-contratos/1.1_consultarContratos_Id",
            tipo=tipo, codigo=codigo,
        )
        items = resp.get("resultado", [])
        return items[0] if items else {}

    async def get_contratos_itens(self, max_results: int = 50, **params: Any) -> list[dict]:
        """C4: List contract items."""
        return await self._get_paginated(
            "/modulo-contratos/2_consultarContratosItem",
            max_results=max_results, **params,
        )

    async def get_licitacoes(self, max_results: int = 50, **params: Any) -> list[dict]:
        """L1: List bids (legacy law 8.666 — DEPRECATED, use get_contratacoes)."""
        return await self._get_paginated(
            "/modulo-legado/1_consultarLicitacao",
            max_results=max_results, **params,
        )

    async def get_contratacoes(self, max_results: int = 50, **params: Any) -> list[dict]:
        """T1: List contratações PNCP.  Auto-splits date range."""
        return await self._fetch_with_date_split(
            "/modulo-contratacoes/1_consultarContratacoes_PNCP_14133",
            max_results, params,
            "dataPublicacaoPncpInicial", "dataPublicacaoPncpFinal",
        )

    async def get_contratacao_by_id(self, tipo: str, codigo: str) -> dict:
        """T2: Get contratação detail by ID."""
        resp = await self._get(
            "/modulo-contratacoes/1.1_consultarContratacoes_PNCP_14133_Id",
            tipo=tipo, codigo=codigo,
        )
        items = resp.get("resultado", [])
        return items[0] if items else {}

    async def get_contratacoes_itens(self, max_results: int = 50, **params: Any) -> list[dict]:
        """T3: List contratação items."""
        return await self._get_paginated(
            "/modulo-contratacoes/2_consultarItensContratacoes_PNCP_14133",
            max_results=max_results, **params,
        )

    async def get_contratacoes_resultados(self, max_results: int = 50, **params: Any) -> list[dict]:
        """T5: List contratação results (fornecedor, valor)."""
        return await self._get_paginated(
            "/modulo-contratacoes/3_consultarResultadoItensContratacoes_PNCP_14133",
            max_results=max_results, **params,
        )

    async def get_fornecedor(self, **params: Any) -> list[dict]:
        """F1: Search suppliers.  Requires ``ativo=True`` for results."""
        if "ativo" not in params:
            params["ativo"] = "True"
        return await self._get_paginated(
            "/modulo-fornecedor/1_consultarFornecedor", max_results=10, **params,
        )

    async def get_arp(self, max_results: int = 50, **params: Any) -> list[dict]:
        """A1: List price registration acts.  Auto-splits date range."""
        return await self._fetch_with_date_split(
            "/modulo-arp/1_consultarARP",
            max_results, params,
            "dataVigenciaInicialMin", "dataVigenciaInicialMax",
        )

    async def get_precos(self, max_results: int = 100, **params: Any) -> list[dict]:
        """03: Search prices for a CATMAT material."""
        return await self._get_paginated(
            "/modulo-pesquisa-preco/1_consultarMaterial",
            max_results=max_results, **params,
        )

    async def get_precos_servico(self, max_results: int = 100, **params: Any) -> list[dict]:
        """03: Search prices for a CATSER service.

        Uses the dedicated service price endpoint
        ``/modulo-pesquisa-preco/3_consultarServico``.
        """
        return await self._get_paginated(
            "/modulo-pesquisa-preco/3_consultarServico",
            max_results=max_results, **params,
        )

    async def get_pgc(self, max_results: int = 50, **params: Any) -> list[dict]:
        """04: Procurement planning."""
        return await self._get_paginated(
            "/modulo-pgc/1_consultarPgcDetalhe",
            max_results=max_results, **params,
        )

    async def get_item_material(self, max_results: int = 50, **params: Any) -> list[dict]:
        """M1: Search CATMAT material items by description or code."""
        return await self._get_paginated(
            "/modulo-material/4_consultarItemMaterial",
            max_results=max_results, **params,
        )

    async def get_itens_servico(self, max_results: int = 50, **params: Any) -> list[dict]:
        """S1: Search CATSER service items by code or name."""
        return await self._get_paginated(
            "/modulo-servico/6_consultarItemServico",
            max_results=max_results, **params,
        )


# ── PNCP client ──────────────────────────────────────────────────────────────


class PNCPClient:
    """Async HTTP client for the PNCP API (Portal Nacional de Contratações Públicas).

    Base URL: ``https://pncp.gov.br/api/consulta/v1``
    API docs: https://pncp.gov.br/api/consulta/swagger-ui/index.html

    Key characteristics:
    - No server-side text search — use ``_filtrar_por_texto()`` client-side.
    - Date format: YYYYMMDD (use ``normalizar_data_pncp()``).
    - Max date range: 365 days.
    - Pagination: pagina / tamanhoPagina query params.
    """

    def __init__(self, timeout: float = PNCP_TIMEOUT) -> None:
        self._timeout = timeout
        self._last_call = 0.0
        self._lock = asyncio.Lock()

    async def _rate_limit(self) -> None:
        async with self._lock:
            now = asyncio.get_event_loop().time()
            elapsed = now - self._last_call
            if elapsed < _PAGE_DELAY:
                await asyncio.sleep(_PAGE_DELAY - elapsed)
            self._last_call = asyncio.get_event_loop().time()

    async def _get(self, path: str, **params: Any) -> dict:
        """GET with rate-limiting. Returns parsed JSON dict."""
        await self._rate_limit()
        url = f"{PNCP_API_BASE}{path}"
        try:
            async with httpx.AsyncClient(
                timeout=self._timeout, follow_redirects=True,
            ) as client:
                resp = await client.get(url, params=params)
                if resp.status_code == 404:
                    log.warning("PNCP API 404: %s params=%s", path, params)
                    return {"totalRegistros": 0, "resultado": []}
                if resp.status_code >= 400:
                    body = (resp.text or "<empty>")[:500]
                    log.error(
                        "PNCP API %s: %s params=%s body=%s",
                        resp.status_code, path, params, body,
                    )
                    raise ComprasError(
                        resp.status_code,
                        f"PNCP API {resp.status_code}: {resp.reason_phrase} "
                        f"| body: {body}",
                    )
                try:
                    data: dict = resp.json()
                except ValueError as exc:
                    body = (resp.text or "<empty>")[:200]
                    msg = f"Resposta inválida PNCP ({path}): {exc} | body: {body}"
                    log.error(msg)
                    raise ComprasError(500, msg) from exc
                return data
        except httpx.TimeoutException:
            raise ComprasError(
                504, f"PNCP API timeout ({self._timeout}s): {path}"
            )
        except httpx.ConnectError as exc:
            raise ComprasError(
                503, f"PNCP API connection refused: {path} | {exc}"
            )
        except httpx.ReadError as exc:
            raise ComprasError(
                502, f"PNCP API connection reset / read error: {path} | {exc}"
            )
        except httpx.RemoteProtocolError as exc:
            raise ComprasError(
                502, f"PNCP API protocol error: {path} | {exc}"
            )

    async def _get_paginated(
        self, path: str, max_results: int = 50, page_size: int = 10, **params: Any,
    ) -> list[dict]:
        """Fetch up to *max_results* items with pagination."""
        if page_size <= 0:
            page_size = min(500, max(10, max_results))
        collected: list[dict] = []
        page = 1

        while len(collected) < max_results:
            resp = await self._get(
                path, pagina=str(page), tamanhoPagina=str(page_size), **params,
            )
            items = resp.get("resultado", [])
            if not items:
                break
            collected.extend(items)
            total_pages = int(resp.get("totalPaginas", 1))
            if page >= total_pages:
                break
            page += 1
        return collected[:max_results]

    # ── PNCP endpoints ───────────────────────────────────────────────────

    async def get_contratacoes(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search contratações by period + modalidade."""
        return await self._get_paginated(
            PNCP_CONTRATACOES, max_results=max_results, **params,
        )

    async def get_contratacoes_proposta(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search contratações with open proposals."""
        return await self._get_paginated(
            PNCP_CONTRATACOES_PROPOSTA, max_results=max_results, **params,
        )

    async def get_contratacoes_atualizacao(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search recently updated contratações."""
        return await self._get_paginated(
            PNCP_CONTRATACOES_ATUALIZACAO, max_results=max_results, **params,
        )

    async def get_contratos(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search contratos by period."""
        return await self._get_paginated(
            PNCP_CONTRATOS, max_results=max_results, **params,
        )

    async def get_contratos_atualizacao(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search recently updated contratos."""
        return await self._get_paginated(
            PNCP_CONTRATOS_ATUALIZACAO, max_results=max_results, **params,
        )

    async def get_atas(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search atas de registro de preço by period."""
        return await self._get_paginated(
            PNCP_ATAS, max_results=max_results, **params,
        )

    async def get_atas_atualizacao(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search recently updated atas."""
        return await self._get_paginated(
            PNCP_ATAS_ATUALIZACAO, max_results=max_results, **params,
        )

    async def get_pca(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search PCA (Plano de Contratações Anual)."""
        return await self._get_paginated(
            PNCP_PCA, max_results=max_results, **params,
        )

    async def get_instrumentos_cobranca(self, max_results: int = 50, **params: Any) -> list[dict]:
        """Search instrumentos de cobrança (notas fiscais)."""
        return await self._get_paginated(
            PNCP_INSTRUMENTOS_COBRANCA, max_results=max_results, **params,
        )

    async def get_contratacao_detalhe(self, cnpj: str, ano: int, sequencial: int) -> dict:
        """Get full detail of a specific contratação."""
        resp = await self._get(
            f"/orgaos/{cnpj}/contratacoes/{ano}/{sequencial}",
        )
        items = resp.get("resultado", [])
        return items[0] if items else {}


# ── CNBS client ──────────────────────────────────────────────────────────────


class CNBSClient:
    """Async HTTP client for the CNBS (Serpro) material/service catalog."""

    def __init__(self, timeout: float = CNBS_TIMEOUT) -> None:
        self._timeout = timeout

    async def hint(self, palavra: str) -> list[dict]:
        """Search materials/services by name fragment.

        Returns a list of ``{"codigo": str, "nome": str, "tipo": "M"|"S"}``.
        """
        url = f"{CNBS_BASE}/item/v1/hint"
        async with httpx.AsyncClient(
            timeout=self._timeout, follow_redirects=True,
        ) as client:
            resp = await client.get(url, params={"palavra": palavra})
            resp.raise_for_status()
            return resp.json()

    async def buscar_servicos(self, palavra: str) -> list[dict]:
        """Search CATSER services by name via CNBS dedicated endpoint.

        Returns a list of service dicts from ``/servico/v1/palavra``.
        More reliable than the CATSER API for text search — no fallback set.
        """
        url = f"{CNBS_BASE}/servico/v1/palavra"
        async with httpx.AsyncClient(
            timeout=self._timeout, follow_redirects=True,
        ) as client:
            resp = await client.get(url, params={"palavra": palavra})
            resp.raise_for_status()
            return resp.json()

    async def buscar_materiais(self, palavra: str) -> list[dict]:
        """Search CATMAT materials by name via CNBS dedicated endpoint.

        Returns a list of material dicts from ``/material/v1/palavra``.
        """
        url = f"{CNBS_BASE}/material/v1/palavra"
        async with httpx.AsyncClient(
            timeout=self._timeout, follow_redirects=True,
        ) as client:
            resp = await client.get(url, params={"palavra": palavra})
            resp.raise_for_status()
            return resp.json()

    async def caracteristicas(self, codigo_pdm: str) -> list[dict]:
        """Get detailed characteristics for a material PDM code."""
        url = f"{CNBS_BASE}/material/v1/materialCaracteristcaValorporPDM"
        async with httpx.AsyncClient(
            timeout=self._timeout, follow_redirects=True,
        ) as client:
            resp = await client.get(url, params={"codigo_pdm": codigo_pdm})
            resp.raise_for_status()
            return resp.json()
