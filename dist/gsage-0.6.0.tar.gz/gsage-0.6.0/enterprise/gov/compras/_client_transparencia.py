"""gSage AI — Portal da Transparência API client (sanções + contratos).

Async HTTP client for the CGU/Portal da Transparência endpoints:
- Contracts by supplier CPF/CNPJ (``/contratos/cpf-cnpj``).
- Sanctions: CEIS, CNEP, CEPIM, CEAF.

Requires a ``chave-api-dados`` API key obtained from
https://portaldatransparencia.gov.br/api-de-dados.

All endpoints are public but require the API key in the ``chave-api-dados``
header.  The key is read from tool config (``config["api_key"]``) at
instantiation time.

.. note::

    The API returns a plain JSON array with a **fixed page size of 15**.
    There is no pagination envelope, no ``totalRegistros``, and no HTTP
    headers with pagination metadata.  The only way to detect the end of
    results is an empty array ``[]`` (HTTP 200).
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any, Optional

import httpx

from src.mcp_server.tools.enterprise.gov.compras._constants import (
    _TRANSPARENCIA_PAGE_SIZE,
)

log = logging.getLogger(__name__)

TRANSPARENCIA_BASE = "https://api.portaldatransparencia.gov.br/api-de-dados"
TRANSPARENCIA_TIMEOUT = 20.0
_PAGE_DELAY = 2.0
_DEFAULT_MAX_RESULTS = 500

# Endpoint paths
CONTRATOS_FORNECEDOR_PATH = "/contratos/cpf-cnpj"

# Map of base_key → endpoint path + display name
SANCOES_DATABASES: dict[str, dict[str, str]] = {
    "ceis": {
        "path": "/ceis",
        "param_cpf_cnpj": "codigoSancionado",
        "nome": "CEIS — Empresas Inidôneas e Suspensas",
    },
    "cnep": {
        "path": "/cnep",
        "param_cpf_cnpj": "codigoSancionado",
        "nome": "CNEP — Empresas Punidas (Lei Anticorrupção)",
    },
    "cepim": {
        "path": "/cepim",
        "param_cpf_cnpj": "cnpjSancionado",
        "nome": "CEPIM — Entidades sem Fins Lucrativos Impedidas",
    },
    "ceaf": {
        "path": "/ceaf",
        "param_cpf_cnpj": "cpfSancionado",
        "nome": "CEAF — Expulsões da Administração Federal",
    },
}


class TransparenciaError(Exception):
    """Raised on Portal da Transparência API errors."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


class TransparenciaClient:
    """Async HTTP client for Portal da Transparência sanctions endpoints."""

    def __init__(self, config: dict | None = None) -> None:
        self._api_key: str = (config or {}).get("api_key") or ""
        self._timeout: float = float((config or {}).get("timeout") or TRANSPARENCIA_TIMEOUT)
        self._last_call = 0.0
        self._lock = asyncio.Lock()

    @property
    def has_api_key(self) -> bool:
        """Whether an API key has been configured."""
        return bool(self._api_key)

    async def _rate_limit(self) -> None:
        async with self._lock:
            now = asyncio.get_event_loop().time()
            elapsed = now - self._last_call
            if elapsed < _PAGE_DELAY:
                await asyncio.sleep(_PAGE_DELAY - elapsed)
            self._last_call = asyncio.get_event_loop().time()

    def _headers(self) -> dict[str, str]:
        return {"chave-api-dados": self._api_key}

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> list[dict]:
        """GET a single page with auth header, rate limiting, and error handling.

        Returns ``[]`` on 404, timeout, or non-list response so the caller
        can continue with whatever data it already has.
        """
        await self._rate_limit()
        url = f"{TRANSPARENCIA_BASE}{path}"
        try:
            async with httpx.AsyncClient(
                timeout=self._timeout, follow_redirects=True,
            ) as client:
                resp = await client.get(url, params=params, headers=self._headers())
                if resp.status_code == 404:
                    return []
                if resp.status_code == 403:
                    log.warning("Transparência API 403 (acesso negado) — %s", path)
                    return []
                if resp.status_code >= 400:
                    log.error(
                        "Transparência API %s: %s params=%s",
                        resp.status_code, path, params,
                    )
                    return []
                data = resp.json()
                return data if isinstance(data, list) else []
        except httpx.TimeoutException:
            log.warning("Transparência API timeout (%ss): %s", self._timeout, path)
            return []
        except httpx.ConnectError as exc:
            log.warning("Transparência API connection error: %s | %s", path, exc)
            return []
        except Exception as exc:
            log.warning("Transparência API error: %s | %s", path, exc)
            return []

    # ── Pagination helper ─────────────────────────────────────────────────

    async def _get_paginated(
        self, path: str, max_results: int = _DEFAULT_MAX_RESULTS, **params: Any,
    ) -> tuple[list[dict], dict]:
        """Fetch all pages from *path*, stopping at empty page or *max_results*.

        The Portal da Transparência API returns a **plain JSON array** with a
        fixed 15-item page size.  There is no pagination envelope, so we loop
        ``pagina=1, 2, 3, …`` until the page comes back empty (``[]``) or the
        accumulated row count reaches *max_results*.

        Returns
        -------
        (rows, meta)
            ``meta`` is a dict with:
            - ``paginas_consumidas`` (int)
            - ``truncado`` (bool) — ``True`` when the loop stopped because
              *max_results* was reached (there **may** be more data).
        """
        all_rows: list[dict] = []
        pagina = 1
        truncated = False

        while len(all_rows) < max_results:
            page_params: dict[str, Any] = {**params, "pagina": pagina}
            page = await self._get(path, page_params)
            if not page:
                break  # empty page → end of results
            all_rows.extend(page)
            pagina += 1

        if len(all_rows) >= max_results:
            all_rows = all_rows[:max_results]
            truncated = True

        paginas_consumidas = pagina - 1 if all_rows else 0
        return all_rows, {
            "paginas_consumidas": paginas_consumidas,
            "truncado": truncated,
        }

    # ── Public query methods ──────────────────────────────────────────────

    async def buscar_sancoes(
        self,
        consulta: str,
        bases: list[str] | None = None,
        max_results: int = _DEFAULT_MAX_RESULTS,
    ) -> tuple[list[dict], dict]:
        """Search sanctions across CEIS, CNEP, CEPIM, CEAF — all pages.

        Each base is queried in parallel; within each base we paginate
        through all available pages (15 items per page).

        Args:
            consulta: CPF, CNPJ or name to search.  Non-digits are stripped.
            bases: Subset of bases (e.g. ``["ceis", "cnep"]``).  Default: all.
            max_results: Maximum records to return (default 500).

        Returns:
            ``(rows, meta)`` where *meta* has ``paginas_consumidas`` and
            ``truncado``.
        """
        if not self.has_api_key:
            log.info("TransparênciaClient: no api_key configured, skipping sanctions")
            return [], {"paginas_consumidas": 0, "truncado": False}

        cpf_cnpj = re.sub(r"\D", "", consulta)
        bases_alvo = bases or list(SANCOES_DATABASES.keys())

        async def _query_one(base_key: str) -> tuple[list[dict], int]:
            db = SANCOES_DATABASES.get(base_key)
            if not db:
                return [], 0
            path = db["path"]
            param_key = db["param_cpf_cnpj"]
            rows, meta = await self._get_paginated(
                path, max_results=max_results,
                **{param_key: cpf_cnpj},
            )
            # Tag each record with its source base
            for r in rows:
                r["_fonte"] = db["nome"]
            return rows, meta["paginas_consumidas"]

        # Query each base in parallel (each base paginates internally)
        all_results: list[dict] = []
        total_pages = 0
        gathered = await asyncio.gather(
            *[_query_one(b) for b in bases_alvo],
            return_exceptions=True,
        )
        for chunk in gathered:
            if isinstance(chunk, tuple):
                rows, pages = chunk
                all_results.extend(rows)
                total_pages += pages

        # Apply max_results across all bases combined
        truncated = len(all_results) >= max_results
        if len(all_results) > max_results:
            all_results = all_results[:max_results]

        return all_results, {
            "paginas_consumidas": total_pages,
            "truncado": truncated,
        }

    async def buscar_contratos_por_fornecedor(
        self, cpf_cnpj: str, max_results: int = _DEFAULT_MAX_RESULTS,
    ) -> tuple[list[dict], dict]:
        """Search federal contracts by supplier CPF/CNPJ — all pages.

        Uses the Portal da Transparência ``/contratos/cpf-cnpj`` endpoint.
        Pages through all available results (15 per page) until the API
        returns an empty array or *max_results* is reached.

        Args:
            cpf_cnpj: CPF or CNPJ (accepts formatted or digits-only).
            max_results: Maximum contracts to return (default 500).

        Returns:
            ``(rows, meta)`` where *meta* has ``paginas_consumidas`` and
            ``truncado``.
        """
        if not self.has_api_key:
            log.info("TransparenciaClient: no api_key configured, skipping contract search")
            return [], {"paginas_consumidas": 0, "truncado": False}

        cpf_cnpj_clean = re.sub(r"\D", "", cpf_cnpj)
        return await self._get_paginated(
            CONTRATOS_FORNECEDOR_PATH,
            max_results=max_results,
            cpfCnpj=cpf_cnpj_clean,
        )
