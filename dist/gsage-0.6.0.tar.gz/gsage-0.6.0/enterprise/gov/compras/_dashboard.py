"""gSage AI — Dashboard aggregation logic for Compras.gov.br.

Computes the ``dashboard`` view by calling multiple Compras.gov.br endpoints
and consolidating results into a single payload.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import date, timedelta
from typing import Optional

from src.mcp_server.tools.enterprise.gov.compras._client import ComprasClient
from src.mcp_server.tools.enterprise.gov.compras._views import (
    build_mermaid_dashboard,
    slim_arp,
    slim_contrato,
    slim_uasg,
)

log = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────
_CONTRATOS_MAX = 10000    # max contracts to fetch for dashboard
_ARP_MAX = 10000           # max ARPs to fetch
_TOP_FORNECEDORES = 15     # top suppliers in summary
_TOP_RECENTES = 10         # recent contracts in summary
_TOP_VENCENDO = 10          # expiring contracts in summary
_TOP_ATAS = 15             # atas in summary


async def build_dashboard(
    client: ComprasClient,
    codigo_orgao: int,
    codigo_uasg: Optional[str] = None,
) -> dict:
    """Build the aggregated dashboard for an org (or specific UASG).

    When *codigo_uasg* is provided, contracts and ARPs are filtered to that
    unit instead of returning data for the entire orgão.
    """
    errors: list[str] = []

    # ── Phase 1: resolve UASG ───────────────────────────────────────────
    org_info: dict = {"codigo": codigo_orgao, "nome": "", "cnpj": "", "codigo_siorg": "", "uf": ""}
    uasg_nome: str = ""

    # Always try to resolve orgão name (via get_orgaos_uasg).
    try:
        orgao_list = await client.get_orgaos_uasg(codigoOrgao=str(codigo_orgao))
        if orgao_list:
            o = orgao_list[0]
            org_info = {
                "codigo": o.get("codigoOrgao", codigo_orgao),
                "nome": o.get("nomeOrgao") or o.get("nomeUasg", ""),
                "cnpj": o.get("cnpjCpfOrgao", ""),
                "codigo_siorg": o.get("codigoSiorg", ""),
                "uf": o.get("siglaUf", ""),
            }
    except Exception as exc:
        errors.append(f"Orgao lookup: {exc}")

    # When codigo_uasg is provided, also resolve UASG display name.
    if codigo_uasg:
        try:
            uasg_list = await client.get_uasg(codigoUasg=str(codigo_uasg))
            if uasg_list:
                uasg_nome = uasg_list[0].get("nomeUasg", "")
        except Exception as exc:
            errors.append(f"UASG lookup: {exc}")

    # ── Phase 2: parallel fetch ─────────────────────────────────────────
    contratos_raw, arp_raw = await asyncio.gather(
        _fetch_contratos(client, codigo_orgao, codigo_uasg=codigo_uasg),
        _fetch_arp(client, codigo_uasg=codigo_uasg),
        return_exceptions=True,
    )

    contratos: list[dict] = []
    if isinstance(contratos_raw, Exception):
        errors.append(f"Contratos: {contratos_raw}")
    elif isinstance(contratos_raw, list):
        contratos = contratos_raw

    atas: list[dict] = []
    if isinstance(arp_raw, Exception):
        errors.append(f"ARP: {arp_raw}")
    elif isinstance(arp_raw, list):
        atas = arp_raw

    # ── Phase 3: aggregate ─────────────────────────────────────────────
    total_contratos = len(contratos)
    total_atas = len(atas)

    # Compute totals
    valor_total = sum(
        (c.get("valor") or 0) for c in contratos if c.get("valor")
    )
    fornecedores: dict[str, dict] = {}
    for c in contratos:
        cnpj = c.get("cnpj_fornecedor") or c.get("niFornecedor") or ""
        if cnpj:
            if cnpj not in fornecedores:
                fornecedores[cnpj] = {
                    "cnpj": cnpj,
                    "nome": c.get("fornecedor", ""),
                    "total_contratos": 0,
                    "valor": 0.0,
                }
            fornecedores[cnpj]["total_contratos"] += 1
            fornecedores[cnpj]["valor"] += c.get("valor") or 0

    top_fornecedores = sorted(
        fornecedores.values(),
        key=lambda f: f["valor"],
        reverse=True,
    )[: _TOP_FORNECEDORES]

    # Contracts expiring in 90 days (hoje ≤ data_fim ≤ hoje+90)
    from datetime import date as dt_date, timedelta as td
    hoje = dt_date.today()
    fim_vencendo = hoje + td(days=90)
    vencendo = [
        c for c in contratos
        if c.get("data_fim")
        and (d := _parse_date(c["data_fim"]))
        and hoje <= d <= fim_vencendo
    ]

    # Recently expired (hoje-30 ≤ data_fim < hoje)
    inicio_vencidos = hoje - td(days=30)
    vencidos_recentes = [
        c for c in contratos
        if c.get("data_fim")
        and (d := _parse_date(c["data_fim"]))
        and inicio_vencidos <= d < hoje
    ]

    # Recent contracts (last N)
    recentes = sorted(
        contratos,
        key=lambda c: c.get("data_inicio") or "",
        reverse=True,
    )[: _TOP_RECENTES]

    # Build Mermaid
    mermaid: Optional[str] = None
    try:
        mermaid = build_mermaid_dashboard(
            orgao_nome=org_info["nome"] or f"Órgão {codigo_orgao}",
            total_contratos=total_contratos,
            total_atas=total_atas,
            total_fornecedores=len(fornecedores),
            valor_total=valor_total if valor_total > 0 else None,
            top_fornecedores=top_fornecedores,
        )
    except Exception:
        pass

    return {
        "orgao": org_info,
        "uasg": {"codigo": codigo_uasg, "nome": uasg_nome} if codigo_uasg else None,
        "resumo": {
            "total_contratos_ativos": total_contratos,
            "total_contratos_vencendo_90dias": len(vencendo),
            "total_contratos_vencidos_30dias": len(vencidos_recentes),
            "total_atas_vigentes": total_atas,
            "valor_total_contratos": round(valor_total, 2) if valor_total else None,
            "fornecedores_unicos": len(fornecedores),
        },
        "top_fornecedores": top_fornecedores,
        "contratos_recentes": recentes,
        "contratos_vencendo": vencendo[: _TOP_VENCENDO],
        "contratos_vencidos_recentes": vencidos_recentes[: _TOP_VENCENDO],
        "atas_vigentes": atas[: _TOP_ATAS],
        "display_hint": (
            f"Showing top {_TOP_FORNECEDORES} suppliers, "
            f"{_TOP_RECENTES} recent contracts, "
            f"{_TOP_VENCENDO} expiring contracts, "
            f"{len(vencidos_recentes)} recently expired (last 30d), "
            f"{_TOP_ATAS} atas. "
            f"Full counts: {total_contratos} contracts fetched, "
            f"{total_atas} atas fetched, "
            f"{len(fornecedores)} unique suppliers."
        ),
        "mermaid": mermaid,
        "errors": errors or None,
    }


async def _fetch_contratos(
    client: ComprasClient, codigo_orgao: int,
    codigo_uasg: Optional[str] = None,
) -> list[dict]:
    """Fetch contracts for an org, then slim + optionally filter by UASG.

    The Contratos.gov.br API only supports ``codigoOrgao``‑level filtering;
    UASG filtering is applied locally.
    """
    from datetime import date
    hoje = date.today()
    raw = await client.get_contratos(
        max_results=_CONTRATOS_MAX,
        codigoOrgao=str(codigo_orgao),
        dataVigenciaInicialMin=hoje.replace(year=hoje.year - 1).isoformat(),
        dataVigenciaInicialMax=hoje.isoformat(),
    )
    records = [slim_contrato(r) for r in raw]
    if codigo_uasg:
        records = [c for c in records if c.get("uasg_codigo") == codigo_uasg]
    return records


async def _fetch_arp(
    client: ComprasClient,
    codigo_uasg: Optional[str] = None,
) -> list[dict]:
    """Fetch ARPs, optionally filtered by UASG via ``codigoUnidadeGerenciadora``."""
    from datetime import date
    hoje = date.today()
    params: dict = {
        "max_results": _ARP_MAX,
        "dataVigenciaInicialMin": hoje.replace(year=hoje.year - 1).isoformat(),
        "dataVigenciaInicialMax": hoje.isoformat(),
    }
    if codigo_uasg:
        params["codigoUnidadeGerenciadora"] = codigo_uasg
    raw = await client.get_arp(**params)
    return [slim_arp(r) for r in raw]


def _parse_date(text: str) -> Optional[date]:
    """Parse ISO date string."""
    from datetime import date as dt_date
    try:
        return dt_date.fromisoformat(text[:10])
    except (ValueError, TypeError):
        return None
