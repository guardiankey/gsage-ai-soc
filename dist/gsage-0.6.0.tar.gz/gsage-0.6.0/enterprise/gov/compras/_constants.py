"""gSage AI — Shared constants for Compras procurement tools.

Centralizes URLs, timeouts, pagination defaults, modalidade catalogues,
and cache TTLs used by all clients and tools in the compras/ package.
"""

from __future__ import annotations

# ═══════════════════════════════════════════════════════════════════════════════
# API base URLs
# ═══════════════════════════════════════════════════════════════════════════════

COMPRAS_BASE = "https://dadosabertos.compras.gov.br"
CNBS_BASE = "https://cnbs.estaleiro.serpro.gov.br/cnbs-api"
PNCP_API_BASE = "https://pncp.gov.br/api/consulta/v1"
CONTRATOSGOVBR_BASE = "https://contratos.comprasnet.gov.br/api/contrato"

# ═══════════════════════════════════════════════════════════════════════════════
# HTTP timeouts (seconds)
# ═══════════════════════════════════════════════════════════════════════════════

COMPRAS_TIMEOUT = 30.0
CNBS_TIMEOUT = 15.0
PNCP_TIMEOUT = 60.0
CONTRATOSGOVBR_TIMEOUT = 30.0

# ═══════════════════════════════════════════════════════════════════════════════
# Rate limiting (seconds)
# ═══════════════════════════════════════════════════════════════════════════════

_PAGE_DELAY = 2.0       # seconds between pages of the same endpoint
_MODULE_DELAY = 3.0     # seconds between different modules
_UASG_PAGE_SIZE = 10    # UASG endpoints reject larger page sizes

# ═══════════════════════════════════════════════════════════════════════════════
# Pagination defaults
# ═══════════════════════════════════════════════════════════════════════════════

_DEFAULT_PAGE_SIZE = 10
_MIN_PAGE_SIZE = 10
_MAX_PAGE_SIZE = 500
_MAX_PAGE_SIZE_CONTRATACOES = 50   # PNCP /contratacoes/publicacao limit
_DEFAULT_MAX_RESULTS = 100
_CSV_THRESHOLD = 100               # auto-generate CSV when rows > this

# ═══════════════════════════════════════════════════════════════════════════════
# Cache TTLs (seconds)
# ═══════════════════════════════════════════════════════════════════════════════

_CACHE_TTL_ESTRUTURA = 6 * 3600    # 6 hours  — UASG list, org structure
_CACHE_TTL_CONTRATOS = 1 * 3600    # 1 hour   — contract listings
_CACHE_TTL_DETALHE = 24 * 3600     # 24 hours — contract details
_CACHE_TTL_CATMAT = 24 * 3600      # 24 hours — material catalogue
_CACHE_TTL_CATSER = 24 * 3600      # 24 hours — service catalogue
_CACHE_TTL_MODALIDADES = 24 * 3600 # 24 hours — PNCP modalidades catalogue
_CACHE_TTL_ORGAO_PNCP = 6 * 3600   # 6 hours  — PNCP org lookups
_CACHE_TTL_PCA = 24 * 3600         # 24 hours — PCA (annual procurement plans)

# Portal da Transparência
_TRANSPARENCIA_PAGE_SIZE = 15       # Fixed by the API; pagination param is ignored
_CACHE_TTL_TRANSPARENCIA = 6 * 3600  # 6 hours — supplier contract & sanction lookups

# ═══════════════════════════════════════════════════════════════════════════════
# Date range limits
# ═══════════════════════════════════════════════════════════════════════════════

MAX_DATE_RANGE_DAYS = 365

# ═══════════════════════════════════════════════════════════════════════════════
# PNCP — Modalidades de contratação (Lei 14.133/2021)
# Source: https://pncp.gov.br/api/consulta/v1/modalidades
# ═══════════════════════════════════════════════════════════════════════════════

MODALIDADES_PNCP: dict[int, str] = {
    1: "Leilão - Eletrônico",
    2: "Diálogo Competitivo",
    3: "Concurso",
    4: "Concorrência - Eletrônica",
    5: "Concorrência - Presencial",
    6: "Pregão - Eletrônico",
    7: "Pregão - Presencial",
    8: "Dispensa",
    9: "Inexigibilidade",
    10: "Manifestação de Interesse",
    11: "Pré-qualificação",
    12: "Credenciamento",
    13: "Leilão - Presencial",
    14: "Inaplicabilidade da Licitação",
    15: "Chamada Pública",
    16: "Concorrência - Eletrônica Internacional",
    17: "Concorrência - Presencial Internacional",
    18: "Pregão - Eletrônico Internacional",
    19: "Pregão - Presencial Internacional",
}

# ═══════════════════════════════════════════════════════════════════════════════
# PNCP — Modos de disputa
# ═══════════════════════════════════════════════════════════════════════════════

MODOS_DISPUTA: dict[int, str] = {
    1: "Aberto",
    2: "Fechado",
    3: "Aberto-Fechado",
    4: "Dispensa Com Disputa",
    5: "Não se aplica",
}

# ═══════════════════════════════════════════════════════════════════════════════
# PNCP endpoint paths (relative to PNCP_API_BASE)
# ═══════════════════════════════════════════════════════════════════════════════

PNCP_CONTRATACOES = "/contratacoes/publicacao"
PNCP_CONTRATACOES_PROPOSTA = "/contratacoes/proposta"
PNCP_CONTRATACOES_ATUALIZACAO = "/contratacoes/atualizacao"
PNCP_CONTRATOS = "/contratos"
PNCP_CONTRATOS_ATUALIZACAO = "/contratos/atualizacao"
PNCP_ATAS = "/atas"
PNCP_ATAS_ATUALIZACAO = "/atas/atualizacao"
PNCP_PCA = "/pca"
PNCP_INSTRUMENTOS_COBRANCA = "/instrumentoscobranca/inclusao"

# ═══════════════════════════════════════════════════════════════════════════════
# Contratos.gov.br endpoint paths (relative to CONTRATOSGOVBR_BASE)
# ═══════════════════════════════════════════════════════════════════════════════

CONTRATOSGOVBR_UG = "/ug"          # GET /ug/{codigo}
CONTRATOSGOVBR_ID = "/id"          # GET /id/{id}
