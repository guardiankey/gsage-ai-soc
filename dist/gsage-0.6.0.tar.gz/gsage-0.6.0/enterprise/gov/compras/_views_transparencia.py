"""gSage AI — Slim view helpers for Portal da Transparência data."""

from __future__ import annotations


def slim_contrato_fornecedor(raw: dict) -> dict:
    """Normalize a contract record from the Portal da Transparência.

    Raw fields (validated against the ``/contratos/cpf-cnpj`` endpoint):
    - id — Portal da Transparência internal ID (**not** Contratos.gov.br ID)
    - numero, objeto, valorInicial, valorFinal
    - dataInicioVigencia, dataFimVigencia
    - fornecedor → dict with nome / razaoSocialReceita
    - unidadeGestora → dict with codigo (UASG), nome
    - orgaoVinculado → dict with descricao

    .. warning::

        The ``id`` field is from Portal da Transparência and is **NOT**
        compatible with Contratos.gov.br endpoints (detalhar_contrato_completo,
        detalhar_contrato_id, etc.).  Use ``buscar_contrato_ug_origem(codigo_uasg=...,
        numero_contrato=...)`` to obtain the Contratos.gov.br numeric ID.
    """
    fornecedor = raw.get("fornecedor") or {}
    unidade = raw.get("unidadeGestora") or {}
    orgao = raw.get("orgaoVinculado") or {}
    orgao_nome = (
        unidade.get("nome")
        or orgao.get("descricao")
        or orgao.get("nome")
        or "—"
    )
    uasg = unidade.get("codigo") or ""
    numero_contrato = raw.get("numero") or "—"
    return {
        "id": raw.get("id"),
        "id_fonte": "portal_transparencia",
        "_aviso": (
            "⚠️ Este 'id' é do Portal da Transparência, NÃO do Contratos.gov.br. "
            "Para detalhar este contrato, use buscar_contrato_ug_origem("
            f"codigo_uasg={uasg}, numero_contrato='{numero_contrato}') "
            "para obter o ID numérico do Contratos.gov.br."
        ) if uasg and numero_contrato != "—" else (
            "⚠️ Este 'id' é do Portal da Transparência, NÃO do Contratos.gov.br. "
            "Use listar_contratos_ug com o nome do órgão para encontrar o ID correto."
        ),
        "numero": numero_contrato,
        "uasg": uasg or None,
        "objeto": raw.get("objeto") or "—",
        "valor_inicial": raw.get("valorInicial"),
        "valor_final": raw.get("valorFinal"),
        "data_inicio": raw.get("dataInicioVigencia") or "—",
        "data_fim": raw.get("dataFimVigencia") or "—",
        "orgao": orgao_nome,
        "fornecedor": fornecedor.get("nome")
        or fornecedor.get("razaoSocialReceita")
        or "—",
    }


def slim_sancao(raw: dict) -> dict:
    """Normalize a sanction record from CEIS/CNEP/CEPIM/CEAF.

    Handles field name variations across the four databases.
    """
    return {
        "nome": raw.get("nome") or raw.get("nomeRazaoSocial") or raw.get("razaoSocial") or "—",
        "cpf_cnpj": raw.get("cpfCnpj") or raw.get("cpf") or raw.get("cnpj") or "—",
        "fonte": raw.get("_fonte") or "—",
        "tipo": raw.get("tipo") or raw.get("tipoSanacao") or raw.get("tipoSancao") or "—",
        "orgao_sancionador": raw.get("orgao") or raw.get("orgaoSancionador") or raw.get("orgaoResponsavel") or "—",
        "data_inicio": raw.get("dataInicio") or raw.get("dataInicioSancao") or "—",
        "data_fim": raw.get("dataFim") or raw.get("dataFinalSancao") or "—",
        "fundamentacao": raw.get("fundamentacao") or raw.get("fundamentacaoLegal") or "—",
        "processo": raw.get("processo") or raw.get("numeroProcesso") or "—",
    }
