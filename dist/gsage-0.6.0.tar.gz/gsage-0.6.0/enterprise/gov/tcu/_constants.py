"""gSage AI — TCU API constants."""

from __future__ import annotations

# ── API base URLs ────────────────────────────────────────────────────────────

TCU_CONDENACAO_BASE = "https://contas.tcu.gov.br/ords/condenacao/consulta"
TCU_DADOS_ABERTOS_BASE = "https://dados-abertos.apps.tcu.gov.br/api"
TCU_CERTIDOES_BASE = "https://certidoes-apf.apps.tcu.gov.br/api/rest/publico/certidoes"
TCU_SCN_BASE = "https://contas.tcu.gov.br/ords/api/publica/scn"
TCU_CALCULADORA_BASE = "https://divida.apps.tcu.gov.br/api/publico/calculadora"
TCU_CONTRATA_BASE = "https://contas.tcu.gov.br/contrata2RS/api/publico"

# ── Endpoint paths ───────────────────────────────────────────────────────────

INIDONEOS_URL = f"{TCU_CONDENACAO_BASE}/inidoneos"
INABILITADOS_URL = f"{TCU_CONDENACAO_BASE}/inabilitados"
CERTIDOES_URL = TCU_CERTIDOES_BASE
ACORDAOS_URL = f"{TCU_DADOS_ABERTOS_BASE}/acordao/recupera-acordaos"
CADIRREG_URL = f"{TCU_DADOS_ABERTOS_BASE}/recuperapessoacadirreg"
PAUTAS_URL = f"{TCU_DADOS_ABERTOS_BASE}/pautassessao"
PEDIDOS_CONGRESSO_URL = f"{TCU_SCN_BASE}/pedidos_congresso"
CALCULAR_DEBITO_URL = f"{TCU_CALCULADORA_BASE}/calcular-saldos-debito"
TERMOS_CONTRATUAIS_URL = f"{TCU_CONTRATA_BASE}/termos-contratuais"

# ── Timeouts ─────────────────────────────────────────────────────────────────

TCU_TIMEOUT = 30.0
TCU_LARGE_TIMEOUT = 120.0  # for large datasets (pautas, termos)
TCU_PAGE_DELAY = 2.0
