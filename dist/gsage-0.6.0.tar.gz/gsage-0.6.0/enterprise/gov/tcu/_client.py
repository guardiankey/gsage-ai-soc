"""gSage AI — TCU API HTTP client.

Async client for multiple public TCU APIs.  All TCU endpoints are public
(no authentication required).  Timeouts and errors are handled gracefully
— returns ``[]`` or ``None`` so upstream callers can proceed with partial
data.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

import httpx

from src.mcp_server.tools.enterprise.gov.tcu._constants import (
    ACORDAOS_URL,
    CADIRREG_URL,
    CALCULAR_DEBITO_URL,
    CERTIDOES_URL,
    INABILITADOS_URL,
    INIDONEOS_URL,
    PAUTAS_URL,
    PEDIDOS_CONGRESSO_URL,
    TCU_LARGE_TIMEOUT,
    TCU_PAGE_DELAY,
    TCU_TIMEOUT,
    TERMOS_CONTRATUAIS_URL,
)

log = logging.getLogger(__name__)


class TCUError(Exception):
    """Raised on TCU API errors that should not be silently swallowed."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


class TCUClient:
    """Async HTTP client for public TCU APIs."""

    def __init__(self) -> None:
        self._last_call = 0.0
        self._lock = asyncio.Lock()

    async def _rate_limit(self) -> None:
        async with self._lock:
            now = asyncio.get_event_loop().time()
            elapsed = now - self._last_call
            if elapsed < TCU_PAGE_DELAY:
                await asyncio.sleep(TCU_PAGE_DELAY - elapsed)
            self._last_call = asyncio.get_event_loop().time()

    async def _get(
        self, url: str, params: dict[str, Any] | None = None,
        timeout: float = TCU_TIMEOUT,
    ) -> Any:
        """GET with rate limiting and graceful error handling.

        Returns parsed JSON on success, ``[]`` or ``None`` on errors/timeouts.
        """
        await self._rate_limit()
        try:
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                resp = await client.get(url, params=params)
                if resp.status_code == 404:
                    return []
                if resp.status_code >= 400:
                    log.warning("TCU API %s: %s params=%s", resp.status_code, url, params)
                    return []
                return resp.json()
        except httpx.TimeoutException:
            log.warning("TCU API timeout (%ss): %s", timeout, url)
            return []
        except httpx.ConnectError as exc:
            log.warning("TCU API connection error: %s | %s", url, exc)
            return []
        except Exception as exc:
            log.warning("TCU API error: %s | %s", url, exc)
            return []

    async def _post(
        self, url: str, json_body: dict[str, Any],
        timeout: float = TCU_TIMEOUT,
    ) -> Any:
        """POST with rate limiting and graceful error handling."""
        await self._rate_limit()
        try:
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                resp = await client.post(url, json=json_body)
                if resp.status_code >= 400:
                    log.warning("TCU API POST %s: %s body=%s", resp.status_code, url, json_body)
                    return {}
                return resp.json()
        except httpx.TimeoutException:
            log.warning("TCU API POST timeout (%ss): %s", timeout, url)
            return {}
        except Exception as exc:
            log.warning("TCU API POST error: %s | %s", url, exc)
            return {}

    # ── Specific endpoints ────────────────────────────────────────────────

    async def consultar_inidoneos(
        self, cpf_cnpj: str | None = None,
        offset: int = 0, limit: int = 25,
    ) -> list[dict]:
        """Fetch licitantes declarados inidôneos pelo TCU.

        ``GET /inidoneos[/{cpf_cnpj}]?offset={n}&limit={n}``
        """
        url = f"{INIDONEOS_URL}/{cpf_cnpj}" if cpf_cnpj else INIDONEOS_URL
        data = await self._get(url, {"offset": offset, "limit": limit})
        if isinstance(data, dict):
            return data.get("items", data.get("resultado", []))
        if isinstance(data, list):
            return data
        return []

    async def consultar_inabilitados(
        self, cpf: str | None = None,
        offset: int = 0, limit: int = 25,
    ) -> list[dict]:
        """Fetch pessoas inabilitadas para função pública.

        ``GET /inabilitados[/{cpf}]?offset={n}&limit={n}``
        """
        url = f"{INABILITADOS_URL}/{cpf}" if cpf else INABILITADOS_URL
        data = await self._get(url, {"offset": offset, "limit": limit})
        if isinstance(data, dict):
            return data.get("items", data.get("resultado", []))
        if isinstance(data, list):
            return data
        return []

    async def consultar_certidoes(self, cnpj: str) -> Optional[dict]:
        """Fetch certidões consolidadas de PJ (TCU, CNJ, CGU).

        ``GET /certidoes/{cnpj}``

        Returns ``None`` when not found or on error.
        """
        data = await self._get(f"{CERTIDOES_URL}/{cnpj}")
        if isinstance(data, dict) and data.get("certidoes") is not None:
            return data
        if isinstance(data, dict) and data.get("razaoSocial"):
            return data
        return None

    async def consultar_acordaos(
        self, inicio: int = 0, quantidade: int = 10,
    ) -> list[dict]:
        """Fetch acórdãos (decisões colegiadas) do TCU.

        ``GET /acordao/recupera-acordaos?inicio={n}&quantidade={n}``
        """
        data = await self._get(ACORDAOS_URL, {"inicio": inicio, "quantidade": quantidade})
        if isinstance(data, list):
            return data
        return []

    async def download_arquivo(self, url: str) -> Optional[bytes]:
        """Download a binary file (PDF/DOC) from a TCU acórdão URL.

        Returns raw bytes on success, ``None`` on failure.
        """
        if not url:
            return None
        await self._rate_limit()
        try:
            async with httpx.AsyncClient(
                timeout=TCU_LARGE_TIMEOUT, follow_redirects=True,
            ) as client:
                resp = await client.get(url)
                if resp.status_code >= 400:
                    log.warning(
                        "TCU download failed: %s %s", resp.status_code, url,
                    )
                    return None
                return resp.content
        except Exception as exc:
            log.warning("TCU download error: %s | %s", url, exc)
            return None

    async def consultar_pedidos_congresso(
        self, numero_processo: str | None = None, page: int = 0,
    ) -> list[dict]:
        """Fetch solicitações do Congresso Nacional ao TCU.

        ``GET /pedidos_congresso[/{numero_processo}]``
        """
        if numero_processo:
            url = f"{PEDIDOS_CONGRESSO_URL}/{numero_processo}"
            data = await self._get(url)
        else:
            data = await self._get(PEDIDOS_CONGRESSO_URL, {"page": page})
        if isinstance(data, dict):
            return data.get("items", data.get("resultado", []))
        if isinstance(data, list):
            return data
        return []

    async def calcular_debito(
        self, data_atualizacao: str, parcelas: list[dict],
        aplica_juros: bool = True,
    ) -> Optional[dict]:
        """Calculate updated debt with SELIC correction.

        ``POST /calcular-saldos-debito``
        """
        body: dict[str, Any] = {
            "dataAtualizacao": data_atualizacao,
            "aplicaJuros": aplica_juros,
            "parcelasDebito": [
                {
                    "dataFato": p.get("data_fato", ""),
                    "indicativoDebitoCredito": p.get("indicativo", "D"),
                    "valorOriginal": p.get("valor_original", 0),
                }
                for p in parcelas
            ],
        }
        data = await self._post(CALCULAR_DEBITO_URL, body)
        if isinstance(data, dict) and data:
            return data
        return None

    async def consultar_termos_contratuais(self) -> list[dict]:
        """Fetch all termos contratuais firmados pelo TCU.

        ``GET /termos-contratuais``

        Note: Returns ALL records (~3800+). Filter client-side.
        """
        data = await self._get(TERMOS_CONTRATUAIS_URL, timeout=TCU_LARGE_TIMEOUT)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get("items", data.get("resultado", []))
        return []

    async def consultar_cadirreg(self, cpf: str) -> list[dict]:
        """Fetch pessoa com contas irregulares no CADIRREG.

        ``GET /recuperapessoacadirreg/{cpf}``
        """
        data = await self._get(f"{CADIRREG_URL}/{cpf}")
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get("items", data.get("resultado", [data]))
        return []

    async def consultar_pautas_sessao(self) -> list[dict]:
        """Fetch pautas de sessões de julgamento do TCU.

        ``GET /pautassessao``

        Note: Large dataset. Use TCU_LARGE_TIMEOUT.
        """
        data = await self._get(PAUTAS_URL, timeout=TCU_LARGE_TIMEOUT)
        if isinstance(data, list):
            return data
        return []
