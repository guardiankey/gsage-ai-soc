"""gSage AI — Slim view helpers for TCU data."""

from __future__ import annotations

from typing import Any


def slim_inidoneo(raw: dict) -> dict:
    """Normalize an inidôneo record from TCU."""
    return {
        "nome": raw.get("nome") or "—",
        "cpf_cnpj": raw.get("cpfCnpj") or raw.get("cpf_cnpj") or "—",
        "processo": raw.get("processo") or "—",
        "deliberacao": raw.get("deliberacao") or raw.get("deliberação") or "—",
        "data_final": raw.get("dataFim") or raw.get("data_fim") or "—",
        "uf": raw.get("uf") or raw.get("siglaUf") or "—",
    }


def slim_inabilitado(raw: dict) -> dict:
    """Normalize an inabilitado record from TCU."""
    return {
        "nome": raw.get("nome") or "—",
        "cpf": raw.get("cpf") or "—",
        "processo": raw.get("processo") or "—",
        "deliberacao": raw.get("deliberacao") or raw.get("deliberação") or "—",
        "data_final": raw.get("dataFim") or raw.get("data_fim") or "—",
        "uf": raw.get("uf") or raw.get("siglaUf") or "—",
    }


def slim_certidao(raw: dict) -> dict:
    """Normalize a single certidão entry from the consolidated response."""
    return {
        "emissor": raw.get("emissor") or raw.get("orgao") or "—",
        "tipo": raw.get("tipo") or raw.get("tipoCertidao") or "—",
        "situacao": raw.get("situacao") or raw.get("status") or "—",
        "observacao": raw.get("observacao") or raw.get("observacaoSobrePessoa") or "—",
    }


def slim_certidoes_consolidadas(raw: dict) -> dict:
    """Wrap the consolidated certidões response (APF)."""
    certidoes_raw = raw.get("certidoes") or []
    return {
        "razao_social": raw.get("razaoSocial") or raw.get("nome") or "—",
        "nome_fantasia": raw.get("nomeFantasia"),
        "cnpj": raw.get("cnpj") or raw.get("cpf") or "—",
        "certidoes": [slim_certidao(c) for c in certidoes_raw],
        "total": len(certidoes_raw),
    }


def slim_acordao(raw: dict) -> dict:
    """Normalize an acórdão record from TCU."""
    return {
        "numero": raw.get("numero") or raw.get("numeroAcordao") or "—",
        "ano": raw.get("ano") or raw.get("anoAcordao") or "—",
        "colegiado": raw.get("colegiado") or raw.get("colegiadoAcordao") or "—",
        "relator": raw.get("relator") or raw.get("nomeRelator") or "—",
        "data_sessao": raw.get("dataSessao") or raw.get("dataDaSessao") or "—",
        "titulo": raw.get("titulo") or raw.get("tituloAcordao") or "—",
        "sumario": raw.get("sumario") or raw.get("sumarioAcordao") or "—",
        "url_arquivo": raw.get("urlArquivo") or None,
        "url_arquivo_pdf": raw.get("urlArquivoPDF") or None,
        "url_acordao": raw.get("urlAcordao") or None,
    }


def slim_pedido_congresso(raw: dict) -> dict:
    """Normalize a congressional request record."""
    return {
        "tipo": raw.get("tipo") or "—",
        "numero": raw.get("numero") or "—",
        "data_aprovacao": raw.get("dataAprovacao") or raw.get("dataDaAprovacao") or "—",
        "autor": raw.get("autor") or raw.get("nomeAutor") or "—",
        "processo": raw.get("processoScn") or raw.get("processo") or "—",
        "assunto": raw.get("assunto") or "—",
    }


def slim_debito(raw: dict) -> dict:
    """Normalize a debt calculation result."""
    return {
        "saldo_debito": raw.get("saldoDebito") or 0.0,
        "saldo_variacao_selic": raw.get("saldoVariacaoSelic") or 0.0,
        "saldo_juros": raw.get("saldoJuros") or 0.0,
        "saldo_total": raw.get("saldoTotal") or 0.0,
    }


def slim_termo_contratual(raw: dict) -> dict:
    """Normalize a termo contratual (TCU contract) record."""
    return {
        "numero": raw.get("numero") or "—",
        "ano": raw.get("ano") or "—",
        "fornecedor": raw.get("nomeFornecedor") or raw.get("fornecedor") or "—",
        "objeto": raw.get("objeto") or "—",
        "valor": raw.get("valorAtualizado") or raw.get("valor") or 0.0,
        "modalidade": raw.get("modalidadeLicitacao") or raw.get("modalidade") or "—",
    }


def slim_cadirreg(raw: dict) -> dict:
    """Normalize a CADIRREG (contas irregulares) record."""
    return {
        "nome": raw.get("nome") or "—",
        "cpf": raw.get("cpf") or "—",
        "situacao": raw.get("situacao") or raw.get("situacaoCadastral") or "—",
        "processo": raw.get("processo") or raw.get("numeroProcesso") or "—",
        "orgao": raw.get("orgao") or raw.get("orgaoOrigem") or "—",
    }


def slim_pauta_sessao(raw: dict) -> dict:
    """Normalize a pauta de sessão record."""
    return {
        "data": raw.get("data") or raw.get("dataSessao") or "—",
        "colegiado": raw.get("colegiado") or raw.get("colegiadoSessao") or "—",
        "processo": raw.get("processo") or raw.get("numeroProcesso") or "—",
        "relator": raw.get("relator") or raw.get("nomeRelator") or "—",
        "tipo": raw.get("tipo") or raw.get("tipoProcesso") or "—",
    }
