"""gSage AI — TCU (Tribunal de Contas da União) tool.

Query public TCU data: inidôneos, inabilitados, certidões consolidadas,
acórdãos, pedidos do congresso, cálculo de débito, termos contratuais,
CADIRREG, and pautas de sessão.

All TCU APIs are public (no authentication required).

Permission: ``gov:tcu:read``.
"""

from __future__ import annotations

import logging
import re
import time
from typing import Any, ClassVar, Optional

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.mcp_server.tools.enterprise.gov.tcu._client import TCUClient
from src.mcp_server.tools.enterprise.gov.tcu._views import (
    slim_acordao,
    slim_cadirreg,
    slim_certidoes_consolidadas,
    slim_debito,
    slim_inabilitado,
    slim_inidoneo,
    slim_pauta_sessao,
    slim_pedido_congresso,
    slim_termo_contratual,
)
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

# ── Actions ──────────────────────────────────────────────────────────────────

_ACTIONS = frozenset({
    "consultar_inidoneos",
    "consultar_inabilitados",
    "consultar_certidoes",
    "consultar_acordaos",
    "consultar_pedidos_congresso",
    "calcular_debito",
    "consultar_termos_contratuais",
    "consultar_cadirreg",
    "consultar_pautas_sessao",
})

# Maximum rows inlined per section before CSV export is triggered
_PREVIEW_LIMIT: int = 20


# ── Tool ─────────────────────────────────────────────────────────────────────


class TCUTool(BaseTool):
    """Query public TCU data.

    Actions
    -------
    - ``consultar_inidoneos`` — licitantes declarados inidôneos pelo TCU.
    - ``consultar_inabilitados`` — pessoas inabilitadas para cargo/função pública.
    - ``consultar_certidoes`` — certidões consolidadas PJ (TCU, CNJ, CGU).
    - ``consultar_acordaos`` — acórdãos (decisões colegiadas) do TCU.
    - ``consultar_pedidos_congresso`` — solicitações do Congresso Nacional ao TCU.
    - ``calcular_debito`` — calcula débito atualizado com correção SELIC.
    - ``consultar_termos_contratuais`` — contratos firmados pelo próprio TCU.
    - ``consultar_cadirreg`` — pessoas com contas irregulares (CADIRREG).
    - ``consultar_pautas_sessao`` — pautas de sessões de julgamento do TCU.

    Permission: ``gov:tcu:read``.
    """

    name: ClassVar[str] = "tcu"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Query public TCU data: inidoneos, inabilitados, certidoes, "
        "acordaos, pedidos congresso, calculo de debito, termos contratuais, "
        "CADIRREG, and pautas de sessao."
    )
    category: ClassVar[str] = "gov"
    permissions: ClassVar[list[str]] = ["gov:tcu:read"]
    rate_limit_per_minute: ClassVar[int] = 30
    timeout_seconds: ClassVar[int] = 180
    use_circuit_breaker: ClassVar[bool] = False
    requires_approval: ClassVar[bool] = False
    supports_multiple_configs: ClassVar[bool] = False
    requires_config: ClassVar[bool] = False

    params_schema: ClassVar[dict] = {
        "type": "object",
        "required": ["action"],
        "properties": {
            "action": {
                "type": "string",
                "enum": sorted(_ACTIONS),
                "description": "Which TCU query to perform.",
            },
            "cpf_cnpj": {
                "type": "string",
                "description": (
                    "[consultar_inidoneos] CPF ou CNPJ (aceita formatado "
                    "ou só dígitos). Se omitido, lista todos os inidôneos."
                ),
            },
            "cpf": {
                "type": "string",
                "description": (
                    "[consultar_inabilitados, consultar_cadirreg] CPF "
                    "(somente números). Se omitido em inabilitados, lista todos."
                ),
            },
            "cnpj": {
                "type": "string",
                "description": (
                    "[consultar_certidoes] CNPJ da empresa "
                    "(somente números, sem formatação)."
                ),
            },
            "quantidade": {
                "type": "integer",
                "minimum": 1,
                "maximum": 500,
                "description": (
                    "[consultar_acordaos] Quantidade de acórdãos (default 10). "
                    "Quando filtros são aplicados, busca lote maior e filtra "
                    "localmente."
                ),
            },
            "inicio": {
                "type": "integer",
                "minimum": 0,
                "description": (
                    "[consultar_acordaos, consultar_inidoneos, "
                    "consultar_inabilitados] Offset para paginação (default 0)."
                ),
            },
            "limite": {
                "type": "integer",
                "minimum": 1,
                "maximum": 500,
                "description": (
                    "[consultar_inidoneos, consultar_inabilitados] "
                    "Registros por página (default 25)."
                ),
            },
            "colegiado": {
                "type": "string",
                "description": (
                    "[consultar_acordaos] Filtrar por colegiado: "
                    "'Plenário', '1ª Câmara' ou '2ª Câmara'."
                ),
            },
            "relator": {
                "type": "string",
                "description": (
                    "[consultar_acordaos] Filtrar por nome do relator "
                    "(case-insensitive, busca parcial)."
                ),
            },
            "ano": {
                "type": "integer",
                "description": (
                    "[consultar_acordaos, consultar_termos_contratuais] "
                    "Filtrar por ano (ex: 2025)."
                ),
            },
            "busca": {
                "type": "string",
                "description": (
                    "[consultar_acordaos] Busca textual no sumário e título "
                    "(case-insensitive)."
                ),
            },
            "numero_processo": {
                "type": "string",
                "description": (
                    "[consultar_pedidos_congresso] Número do processo TCU "
                    "para buscar pedido específico."
                ),
            },
            "pagina": {
                "type": "integer",
                "minimum": 0,
                "description": (
                    "[consultar_pedidos_congresso] Página dos resultados "
                    "(default 0)."
                ),
            },
            "data_atualizacao": {
                "type": "string",
                "description": (
                    "[calcular_debito] Data para atualização (DD/MM/AAAA)."
                ),
            },
            "data_fato": {
                "type": "string",
                "description": (
                    "[calcular_debito] Data do fato gerador (DD/MM/AAAA)."
                ),
            },
            "valor_original": {
                "type": "number",
                "description": (
                    "[calcular_debito] Valor original do débito em reais."
                ),
            },
            "aplica_juros": {
                "type": "boolean",
                "description": (
                    "[calcular_debito] Aplicar juros de mora (default true)."
                ),
            },
            "fornecedor": {
                "type": "string",
                "description": (
                    "[consultar_termos_contratuais] Nome do fornecedor para "
                    "filtrar (case-insensitive)."
                ),
            },
            "baixar_conteudo": {
                "type": "boolean",
                "description": (
                    "[consultar_acordaos] Se true, faz download do PDF e DOC "
                    "de cada acórdão retornado e os salva como artifacts da "
                    "conversa. Default: false (apenas retorna metadados + URLs). "
                    "⚠️ Quando ativado, cada acórdão gera até 2 artifacts "
                    "(PDF + DOC). Use com quantidade baixa (≤ 5)."
                ),
            },
        },
        "additionalProperties": False,
    }

    config_schema: ClassVar[Optional[dict]] = None
    config_defaults: ClassVar[dict] = {}
    state_schema: ClassVar[Optional[dict]] = None
    state_defaults: ClassVar[dict] = {}
    reset_policy: ClassVar[str] = "never"

    # ── Execute ───────────────────────────────────────────────────────────

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        t0 = time.monotonic()
        action = (params.get("action") or "").strip()
        if action not in _ACTIONS:
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "INVALID_PARAMS",
                f"action must be one of {sorted(_ACTIONS)}; got {action!r}.",
                execution_time_ms=elapsed,
            )

        try:
            data = await self._dispatch(action, params, agent_context)
        except Exception as exc:
            log.exception("tcu(%s): unexpected error", action)
            elapsed = int((time.monotonic() - t0) * 1000)
            return self._failure(
                "INTERNAL_ERROR", str(exc) or type(exc).__name__,
                execution_time_ms=elapsed,
            )

        elapsed = int((time.monotonic() - t0) * 1000)
        return self._success(data={"action": action, **data}, execution_time_ms=elapsed)

    # ── Dispatch ──────────────────────────────────────────────────────────

    async def _dispatch(
        self, action: str, params: dict, agent_context: AgentContext,
    ) -> dict:
        if action == "consultar_inidoneos":
            return await self._do_consultar_inidoneos(params)
        elif action == "consultar_inabilitados":
            return await self._do_consultar_inabilitados(params)
        elif action == "consultar_certidoes":
            return await self._do_consultar_certidoes(params)
        elif action == "consultar_acordaos":
            return await self._do_consultar_acordaos(params, agent_context)
        elif action == "consultar_pedidos_congresso":
            return await self._do_consultar_pedidos_congresso(params)
        elif action == "calcular_debito":
            return await self._do_calcular_debito(params)
        elif action == "consultar_termos_contratuais":
            return await self._do_consultar_termos_contratuais(params)
        elif action == "consultar_cadirreg":
            return await self._do_consultar_cadirreg(params)
        elif action == "consultar_pautas_sessao":
            return await self._do_consultar_pautas_sessao(params)
        else:
            raise ValueError(f"Unknown action: {action}")

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _max_results(params: dict) -> int:
        from src.mcp_server.tools.enterprise.gov.compras._constants import (  # noqa: PLC0415
            _DEFAULT_MAX_RESULTS,
        )
        return int(params.get("max_results") or _DEFAULT_MAX_RESULTS)

    # ── Action implementations ────────────────────────────────────────────

    async def _do_consultar_inidoneos(self, params: dict) -> dict:
        """List licitantes declarados inidôneos pelo TCU."""
        raw_cpf_cnpj = (params.get("cpf_cnpj") or "").strip()
        cpf_cnpj = re.sub(r"\D", "", raw_cpf_cnpj) if raw_cpf_cnpj else None
        limite = int(params.get("limite") or 25)
        inicio = int(params.get("inicio") or 0)

        client = TCUClient()
        raw = await client.consultar_inidoneos(
            cpf_cnpj=cpf_cnpj, offset=inicio, limit=limite,
        )
        registros = [slim_inidoneo(r) for r in raw]

        result: dict = {
            "registros": registros,
            "total": len(registros),
        }
        if cpf_cnpj:
            result["cpf_cnpj"] = cpf_cnpj

        if registros:
            result["agent_hint"] = (
                f"{len(registros)} inidôneo(s) encontrado(s). "
                "Use consultar_certidoes(cnpj=...) para certidões consolidadas."
            )
        else:
            result["agent_hint"] = (
                "Nenhum licitante inidôneo encontrado."
                if not cpf_cnpj else
                f"Nenhum inidôneo encontrado para CPF/CNPJ {cpf_cnpj}."
            )
        return result

    async def _do_consultar_inabilitados(self, params: dict) -> dict:
        """List pessoas inabilitadas para cargo/função pública."""
        raw_cpf = (params.get("cpf") or "").strip()
        cpf = re.sub(r"\D", "", raw_cpf) if raw_cpf else None
        limite = int(params.get("limite") or 25)
        inicio = int(params.get("inicio") or 0)

        client = TCUClient()
        raw = await client.consultar_inabilitados(
            cpf=cpf, offset=inicio, limit=limite,
        )
        registros = [slim_inabilitado(r) for r in raw]

        result: dict = {
            "registros": registros,
            "total": len(registros),
        }
        if cpf:
            result["cpf"] = cpf

        result["agent_hint"] = (
            f"{len(registros)} inabilitado(s) encontrado(s)."
            if registros else
            "Nenhum inabilitado encontrado."
        )
        return result

    async def _do_consultar_certidoes(self, params: dict) -> dict:
        """Consultar certidões consolidadas de PJ (TCU, CNJ, CGU)."""
        cnpj = re.sub(r"\D", "", (params.get("cnpj") or "").strip())
        if not cnpj:
            return {
                "error": "'cnpj' is required.",
                "agent_hint": "Informe o CNPJ da empresa (somente números).",
            }

        client = TCUClient()
        raw = await client.consultar_certidoes(cnpj)
        if not raw:
            return {
                "cnpj": cnpj,
                "error": "Certidões não encontradas ou API indisponível.",
                "agent_hint": (
                    f"Não foi possível obter certidões para CNPJ {cnpj}. "
                    "O CNPJ pode ser inválido ou a API pode estar temporariamente "
                    "indisponível."
                ),
            }

        consolidado = slim_certidoes_consolidadas(raw)
        return {
            "cnpj": cnpj,
            **consolidado,
            "agent_hint": (
                f"{consolidado['razao_social']}: "
                f"{consolidado['total']} certidão(ões) encontrada(s). "
                "Use consultar_inidoneos(cpf_cnpj=...) para detalhes de "
                "inidôneos específicos."
            ),
        }

    async def _do_consultar_acordaos(
        self, params: dict, agent_context: AgentContext,
    ) -> dict:
        """Consultar acórdãos (decisões colegiadas) do TCU."""
        quantidade = int(params.get("quantidade") or 10)
        inicio = int(params.get("inicio") or 0)
        colegiado = (params.get("colegiado") or "").strip() or None
        relator = (params.get("relator") or "").strip() or None
        ano = params.get("ano")
        busca = (params.get("busca") or "").strip() or None

        tem_filtro = any([colegiado, relator, ano, busca])
        qtd_fetch = max(quantidade * 10, 200) if tem_filtro else quantidade

        client = TCUClient()
        raw = await client.consultar_acordaos(inicio=inicio, quantidade=qtd_fetch)
        acordaos = [slim_acordao(r) for r in raw]

        # Client-side filters
        if colegiado:
            upper = colegiado.upper()
            acordaos = [a for a in acordaos if upper in (a.get("colegiado") or "").upper()]
        if relator:
            upper = relator.upper()
            acordaos = [a for a in acordaos if upper in (a.get("relator") or "").upper()]
        if ano:
            acordaos = [a for a in acordaos if str(a.get("ano")) == str(ano)]
        if busca:
            upper = busca.upper()
            acordaos = [
                a for a in acordaos
                if upper in (a.get("sumario") or "").upper()
                or upper in (a.get("titulo") or "").upper()
            ]

        exibir = acordaos[:quantidade]

        # ── Download artifacts (when requested) ──────────────────────────
        baixar = bool(params.get("baixar_conteudo"))
        arquivos_baixados: list[dict] = []
        if baixar:
            from src.mcp_server.tools.base import _tool_session_ctx  # noqa: PLC0415

            session = _tool_session_ctx.get()
            if session is not None:
                for acordao in exibir:
                    numero = acordao.get("numero", "desconhecido")
                    ano = acordao.get("ano", "desconhecido")
                    prefix = f"tcu_acordao_{numero}_{ano}"

                    for url_key, ext, label, mime in [
                        ("url_arquivo_pdf", "pdf", "PDF", "application/pdf"),
                        ("url_arquivo", "doc", "DOC", "application/msword"),
                    ]:
                        url = acordao.get(url_key)
                        if not url:
                            continue
                        content = await client.download_arquivo(url)
                        if content is None:
                            continue

                        artifact = await self._store_file(
                            data=content,
                            filename=f"{prefix}.{ext}",
                            content_type=mime,
                            agent_context=agent_context,
                            session=session,
                            description=f"Acórdão {numero}/{ano} — {label}",
                        )
                        if artifact:
                            arquivos_baixados.append({
                                **artifact,
                                "acordao": f"{numero}/{ano}",
                                "formato": ext,
                            })

        result: dict = {
            "acordaos": exibir,
            "total_encontrados": len(acordaos),
            "total_exibidos": len(exibir),
            "filtros": {
                "colegiado": colegiado,
                "relator": relator,
                "ano": ano,
                "busca": busca,
            },
        }

        if arquivos_baixados:
            result["arquivos_baixados"] = arquivos_baixados

        if acordaos:
            hint = (
                f"{len(acordaos)} acórdão(s) encontrado(s)"
                f"{' (aplicados filtros)' if tem_filtro else ''}."
            )
            if baixar:
                if arquivos_baixados:
                    hint += (
                        f" {len(arquivos_baixados)} arquivo(s) baixado(s) "
                        "e disponível(is) como artifacts. "
                        "Use list_recent_artifacts para acessá-los."
                    )
                else:
                    hint += (
                        " Nenhum arquivo pôde ser baixado "
                        "(URLs indisponíveis ou erro na API)."
                    )
            else:
                hint += (
                    " As URLs para download do conteúdo completo (PDF/DOC) "
                    "estão nos campos url_arquivo_pdf e url_arquivo de cada "
                    "acórdão. Use baixar_conteudo=true para baixá-los "
                    "automaticamente."
                )
            hint += (
                " Use consultar_inidoneos(cpf_cnpj=...) ou "
                "consultar_certidoes(cnpj=...) para due diligence."
            )
            result["agent_hint"] = hint
        else:
            result["agent_hint"] = "Nenhum acórdão encontrado com os filtros informados."
        return result

    async def _do_consultar_pedidos_congresso(self, params: dict) -> dict:
        """Consultar solicitações do Congresso Nacional ao TCU."""
        numero_processo = (params.get("numero_processo") or "").strip() or None
        pagina = int(params.get("pagina") or 0)

        client = TCUClient()
        raw = await client.consultar_pedidos_congresso(
            numero_processo=numero_processo, page=pagina,
        )
        pedidos = [slim_pedido_congresso(r) for r in raw]

        result: dict = {
            "pedidos": pedidos,
            "total": len(pedidos),
        }
        if numero_processo:
            result["numero_processo"] = numero_processo
        else:
            result["pagina"] = pagina

        result["agent_hint"] = (
            f"{len(pedidos)} pedido(s) encontrado(s)."
            if pedidos else
            "Nenhum pedido do Congresso encontrado."
        )
        return result

    async def _do_calcular_debito(self, params: dict) -> dict:
        """Calcular débito atualizado com correção SELIC."""
        data_atualizacao = (params.get("data_atualizacao") or "").strip()
        data_fato = (params.get("data_fato") or "").strip()
        valor_original = params.get("valor_original")
        aplica_juros = params.get("aplica_juros", True)

        if not data_atualizacao or not data_fato or valor_original is None:
            return {
                "error": "'data_atualizacao', 'data_fato', and 'valor_original' are required.",
            }

        client = TCUClient()
        parcelas = [{"data_fato": data_fato, "indicativo": "D", "valor_original": float(valor_original)}]
        raw = await client.calcular_debito(data_atualizacao, parcelas, bool(aplica_juros))

        if not raw:
            return {
                "error": "Cálculo de débito falhou — API pode estar indisponível.",
                "agent_hint": "Tente novamente mais tarde ou verifique os dados informados.",
            }

        resultado = slim_debito(raw)
        return {
            "data_atualizacao": data_atualizacao,
            "data_fato": data_fato,
            "valor_original": float(valor_original),
            "aplica_juros": bool(aplica_juros),
            **resultado,
            "agent_hint": (
                f"Débito calculado: R$ {resultado['saldo_debito']:.2f} original → "
                f"R$ {resultado['saldo_total']:.2f} atualizado "
                f"(juros: {'sim' if aplica_juros else 'não'})."
            ),
        }

    async def _do_consultar_termos_contratuais(self, params: dict) -> dict:
        """Consultar termos contratuais firmados pelo TCU."""
        ano = params.get("ano")
        fornecedor = (params.get("fornecedor") or "").strip() or None
        limite = int(params.get("limite") or 20)

        client = TCUClient()
        raw = await client.consultar_termos_contratuais()
        termos = [slim_termo_contratual(r) for r in raw]

        # Client-side filters
        if ano:
            termos = [t for t in termos if str(t.get("ano")) == str(ano)]
        if fornecedor:
            upper = fornecedor.upper()
            termos = [t for t in termos if upper in (t.get("fornecedor") or "").upper()]

        total = len(termos)
        exibir = termos[:limite]
        overflow = total > limite

        result: dict = {
            "termos": exibir,
            "total": total,
            "total_exibidos": len(exibir),
        }

        if overflow:
            result["overflow"] = True
            result["agent_hint"] = (
                f"{total} termos encontrados — exibindo os primeiros {limite}. "
                "Use 'fornecedor' ou 'ano' para filtrar."
            )
        else:
            result["agent_hint"] = (
                f"{len(exibir)} termo(s) contratual(is) encontrado(s)."
                if exibir else
                "Nenhum termo contratual encontrado."
            )
        return result

    async def _do_consultar_cadirreg(self, params: dict) -> dict:
        """Consultar pessoas com contas irregulares no CADIRREG."""
        cpf = re.sub(r"\D", "", (params.get("cpf") or "").strip())
        if not cpf:
            return {
                "error": "'cpf' is required.",
                "agent_hint": "Informe o CPF para consulta no CADIRREG.",
            }

        client = TCUClient()
        raw = await client.consultar_cadirreg(cpf)
        registros = [slim_cadirreg(r) for r in raw]

        result: dict = {
            "cpf": cpf,
            "registros": registros,
            "total": len(registros),
        }
        result["agent_hint"] = (
            f"{len(registros)} registro(s) encontrado(s) no CADIRREG para CPF {cpf}."
            if registros else
            f"Nenhum registro encontrado no CADIRREG para CPF {cpf}."
        )
        return result

    async def _do_consultar_pautas_sessao(self, params: dict) -> dict:
        """Consultar pautas de sessões de julgamento do TCU."""
        client = TCUClient()
        raw = await client.consultar_pautas_sessao()
        pautas = [slim_pauta_sessao(r) for r in raw]

        total = len(pautas)
        exibir = pautas[:_PREVIEW_LIMIT]
        overflow = total > _PREVIEW_LIMIT

        result: dict = {
            "pautas": exibir,
            "total": total,
        }
        if overflow:
            result["overflow"] = True
            result["agent_hint"] = (
                f"{total} pautas encontradas — exibindo as primeiras "
                f"{_PREVIEW_LIMIT} devido ao volume de dados."
            )
        else:
            result["agent_hint"] = (
                f"{total} pauta(s) encontrada(s)."
                if pautas else
                "Nenhuma pauta de sessão encontrada."
            )
        return result
