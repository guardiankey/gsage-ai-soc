"""gSage AI — TCU (Tribunal de Contas da União) tools.

This package provides tools to query public TCU APIs:
- Inidôneos e Inabilitados
- Certidões consolidadas (TCU, CNJ, CGU)
- Acórdãos (decisões colegiadas)
- Pedidos do Congresso, Cálculo de Débito
- Termos Contratuais, CADIRREG, Pautas de Sessão
"""
