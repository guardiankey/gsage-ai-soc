# Enterprise tools package — business-domain tool families (gov, process catalog, etc.).
# Auto-discovered by the MCP server registry at startup.
