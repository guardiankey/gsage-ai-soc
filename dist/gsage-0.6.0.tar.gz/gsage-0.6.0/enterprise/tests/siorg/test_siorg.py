"""Unit tests for SiorgTool (siorg.py).

Tests mock SiorgClient, cache, and DB session — no real API calls.
Covers: all 6 actions, B1-B5 bugs, Mermaid generation, error handling.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.mcp_server.tools.enterprise.gov.siorg.siorg import SiorgTool, _get_orgaos_cache
from src.mcp_server.tools.enterprise.gov.siorg._client import SiorgError

# ═══════════════════════════════════════════════════════════════════════════════
# Sample data
# ═══════════════════════════════════════════════════════════════════════════════

SAMPLE_ORGAOS_SLIM = [
    {"codigo": 26, "sigla": "PR", "nome": "Presidência da República",
     "tipo": "orgao", "natureza_juridica": "administracao-direta", "codigo_pai": None},
    {"codigo": 2837, "sigla": "CC-PR", "nome": "Casa Civil da Presidência da República",
     "tipo": "orgao", "natureza_juridica": "administracao-direta", "codigo_pai": 26},
    {"codigo": 244460, "sigla": "SA", "nome": "Secretaria de Administração",
     "tipo": "orgao", "natureza_juridica": "administracao-direta", "codigo_pai": 2837},
    {"codigo": 27, "sigla": "GSI/PR", "nome": "Gabinete de Segurança Institucional",
     "tipo": "orgao", "natureza_juridica": "administracao-direta", "codigo_pai": 26},
    {"codigo": 999, "sigla": "ENAP", "nome": "Escola Nacional de Administração Pública",
     "tipo": "entidade", "natureza_juridica": "autarquia", "codigo_pai": None},
]

SAMPLE_UNIDADE = {
    "codigoUnidade": "https://.../id/unidade-organizacional/26",
    "sigla": "PR", "nome": "Presidência da República",
    "codigoTipoUnidade": "https://.../id/tipo-unidade/orgao",
    "codigoNaturezaJuridica": "https://.../id/natureza-juridica/administracao-direta",
}

SAMPLE_ESTRUTURA_RAW = {
    "codigoUnidade": 2837,
    "estrutura": [
        {"codigoUnidade": 2837, "estrutura": [
            {"codigoUnidade": 244460, "estrutura": [
                {"codigoUnidade": 256358, "estrutura": []},
                {"codigoUnidade": 256360, "estrutura": []},
                {"codigoUnidade": 250001, "estrutura": []},
            ]},
        ]},
    ],
}

SAMPLE_ESTRUTURA_ROOT = {
    "codigoUnidade": 26,
    "estrutura": [
        {"codigoUnidade": 26, "estrutura": [
            {"codigoUnidade": 2837, "estrutura": []},
            {"codigoUnidade": 27, "estrutura": []},
        ]},
    ],
}

SAMPLE_CONTATO = {
    "endereco": [{"logradouro": "Praça dos Três Poderes", "bairro": "Zona Cívica",
                   "municipio": "https://.../id/municipio/5300108", "uf": "DF"}],
    "contato": [{"telefone": ["(61) 3411-1000"], "email": ["gabinete@pr.gov.br"],
                  "site": [{"site": "https://www.gov.br/planalto"}]}],
}

SAMPLE_CARGOS = {
    "servico": {"codigoErro": 0},
    "totais": [{"tipoCargo": "DAS", "total": 120}, {"tipoCargo": "FCPE", "total": 45}],
}

SAMPLE_OCUPANTES = [
    {"cargo": "Secretário-Executivo", "funcao": "", "codigo_instancia": 1,
     "nome_titular": None, "cpf_titular": None},
    {"cargo": "Diretor de Programa", "funcao": "DAS 101.5", "codigo_instancia": 2,
     "nome_titular": None, "cpf_titular": None},
]


# ═══════════════════════════════════════════════════════════════════════════════
# Mock helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _mock_siorg_client(**overrides) -> AsyncMock:
    defaults = {
        "get_unidade_resumida": AsyncMock(return_value=SAMPLE_UNIDADE),
        "get_estrutura": AsyncMock(return_value=SAMPLE_ESTRUTURA_RAW),
        "get_contato": AsyncMock(return_value=SAMPLE_CONTATO),
        "get_cargos_totais": AsyncMock(return_value=SAMPLE_CARGOS),
        "get_ocupantes": AsyncMock(return_value=SAMPLE_OCUPANTES),
        **overrides,
    }
    return AsyncMock(**defaults)


def _setup_session_and_cache():
    """Set up mocks for _tool_session_ctx and _get_orgaos_cache.

    Returns the patch stack that must be used as context manager.
    """
    mock_session = MagicMock()
    session_patch = patch(
        "src.mcp_server.tools.enterprise.gov.siorg.siorg._tool_session_ctx",
        new_callable=MagicMock,
    )
    # Also patch the cache decorator wrapper
    cache_patch = patch(
        "src.mcp_server.tools.enterprise.gov.siorg.siorg._get_orgaos_cache",
        AsyncMock(return_value=SAMPLE_ORGAOS_SLIM),
    )
    return session_patch, cache_patch


pytestmark = pytest.mark.asyncio


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — list_orgaos
# ═══════════════════════════════════════════════════════════════════════════════

class TestListOrgaos:
    @pytest.fixture(autouse=True)
    def _setup(self):
        self._cache_patch = patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg._get_orgaos_cache",
            AsyncMock(return_value=SAMPLE_ORGAOS_SLIM),
        )
        self._cache_patch.start()
        yield
        self._cache_patch.stop()

    async def test_list_all(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "list_orgaos"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["rows_total"] >= 1

    async def test_filter_tipo_orgao__bug_b5(self, agent_context, mock_session_ctx):
        """B5: tipo='orgao' filters correctly."""
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "list_orgaos", "tipo": "orgao"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        for row in data.get("rows", []):
            assert row.get("tipo") == "orgao"

    async def test_filter_tipo_autarquia_zero__bug_b5(self, agent_context, mock_session_ctx):
        """B5: 'autarquia' is natureza_juridica, not tipo — filter returns 0."""
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "list_orgaos", "tipo": "autarquia"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["rows_total"] == 0


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — search_orgaos (B1)
# ═══════════════════════════════════════════════════════════════════════════════

class TestSearchOrgaos:
    @pytest.fixture(autouse=True)
    def _setup(self):
        self._cache_patch = patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg._get_orgaos_cache",
            AsyncMock(return_value=SAMPLE_ORGAOS_SLIM),
        )
        self._cache_patch.start()
        yield
        self._cache_patch.stop()

    async def test_search_simple(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "search_orgaos", "nome": "Presidência"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] >= 1

    async def test_search_compound_term__bug_b1(self, agent_context, mock_session_ctx):
        """B1: 'Secretaria de Administração' should find SA."""
        tool = SiorgTool()
        result = await tool.execute(
            agent_context, {"action": "search_orgaos", "nome": "Secretaria de Administração"}, {}, {},
        )
        assert result.status == "success"
        data = result.data
        assert data is not None
        found = any("Administração" in (r.get("nome") or "") for r in data.get("orgaos", []))
        assert found, "BUG B1: 'Secretaria de Administração' not found"

    async def test_search_partial(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "search_orgaos", "nome": "Administração"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        found = any("Administração" in (r.get("nome") or "") for r in data.get("orgaos", []))
        assert found

    async def test_empty_name_error(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "search_orgaos", "nome": ""}, {}, {})
        assert result.status == "error"


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — get_orgao (B2, B3)
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetOrgao:
    async def test_get_orgao_full_dossier(self, agent_context, mock_session_ctx):
        """B2: get_orgao returns composite dossier with all sections."""
        tool = SiorgTool()
        mock = _mock_siorg_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ), patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg._get_orgaos_cache",
            AsyncMock(return_value=SAMPLE_ORGAOS_SLIM),
        ):
            result = await tool.execute(agent_context, {"action": "get_orgao", "codigo_unidade": 26}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["orgao"]["nome"] == "Presidência da República"
        assert "contato" in data
        assert "estrutura" in data
        assert "cargos_alocados" in data

    async def test_mermaid_generated(self, agent_context, mock_session_ctx):
        """Mermaid diagram should be generated in get_orgao."""
        tool = SiorgTool()
        mock = _mock_siorg_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ), patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg._get_orgaos_cache",
            AsyncMock(return_value=SAMPLE_ORGAOS_SLIM),
        ):
            result = await tool.execute(agent_context, {"action": "get_orgao", "codigo_unidade": 26}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        mermaid = data["estrutura"].get("mermaid", "")
        assert "graph TD" in mermaid or "flowchart" in mermaid, f"Mermaid: {mermaid[:100]}..."

    async def test_invalid_code_errors_in_data__bug_b3(self, agent_context, mock_session_ctx):
        """B3: get_orgao returns success with errors in data.errors, not status=error."""
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_unidade_resumida=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
            get_estrutura=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
            get_contato=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
            get_cargos_totais=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(agent_context, {"action": "get_orgao", "codigo_unidade": 99999999}, {}, {})
        # B3: get_orgao returns success, errors are in data.errors
        assert result.status == "success"
        data = result.data
        assert data is not None
        errors = data.get("errors") or []
        assert len(errors) >= 1
        assert any("102" in str(e) for e in errors)


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — get_estrutura (B2, B4)
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetEstrutura:
    @pytest.fixture(autouse=True)
    def _setup(self):
        self._cache_patch = patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg._get_orgaos_cache",
            AsyncMock(return_value=SAMPLE_ORGAOS_SLIM),
        )
        self._cache_patch.start()
        yield
        self._cache_patch.stop()

    async def test_estrutura_ok(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_estrutura=AsyncMock(return_value=SAMPLE_ESTRUTURA_RAW),
            get_unidade_resumida=AsyncMock(return_value=SAMPLE_UNIDADE),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_estrutura", "codigo_unidade": 2837, "max_depth": 3,
                                "resolve_depth": 0}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert "mermaid" in data
        assert data["total_unidades"] >= 1

    async def test_blank_names__bug_b4(self, agent_context, mock_session_ctx):
        """B4: Units with blank nome/sigla still appear in tree with codigo."""
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_estrutura=AsyncMock(return_value=SAMPLE_ESTRUTURA_RAW),
            get_unidade_resumida=AsyncMock(return_value=SAMPLE_UNIDADE),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_estrutura", "codigo_unidade": 2837, "max_depth": 3,
                                "resolve_depth": 0}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        rows = data.get("rows", [])
        # B4: blank-name units should exist with codigo
        blank_rows = [r for r in rows if not r.get("nome") and not r.get("sigla")]
        assert len(blank_rows) >= 2
        for br in blank_rows:
            assert br.get("codigo") is not None

    async def test_max_depth_respected__bug_b2(self, agent_context, mock_session_ctx):
        """B2: max_depth limits tree depth in get_estrutura."""
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_estrutura=AsyncMock(return_value=SAMPLE_ESTRUTURA_RAW),
            get_unidade_resumida=AsyncMock(return_value=SAMPLE_UNIDADE),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_estrutura", "codigo_unidade": 2837, "max_depth": 1,
                                "resolve_depth": 0}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["niveis_maximos"] == 1

    async def test_mermaid_generated(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_estrutura=AsyncMock(return_value=SAMPLE_ESTRUTURA_ROOT),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_estrutura", "codigo_unidade": 26, "resolve_depth": 0}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        mermaid = data.get("mermaid", "")
        assert "graph TD" in mermaid or "flowchart" in mermaid

    async def test_estrutura_invalid_code(self, agent_context, mock_session_ctx):
        """B3: get_estrutura returns error status for invalid code."""
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_estrutura=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_estrutura", "codigo_unidade": 99999999, "resolve_depth": 0}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "102" in err["code"]


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — get_ocupantes (B3)
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetOcupantes:
    async def test_get_ocupantes_ok(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_ocupantes", "codigo_unidade": 26}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["rows_total"] >= 1
        assert "Secretário-Executivo" in str(data.get("rows", []))

    async def test_invalid_code__bug_b3(self, agent_context, mock_session_ctx):
        """B3: get_ocupantes uses error 108 vs 102 for invalid codes."""
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_ocupantes=AsyncMock(side_effect=SiorgError(108, "não foi encontrada unidade com cargos")),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_ocupantes", "codigo_unidade": 99999999}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "108" in err["code"]


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — get_contato
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetContato:
    async def test_get_contato_ok(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_contato", "codigo_unidade": 26}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["contato"]["uf"] == "DF"

    async def test_invalid_code(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_contato=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_contato", "codigo_unidade": 99999999}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "102" in err["code"]

    async def test_sem_codigo_erro(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "get_contato"}, {}, {})
        assert result.status == "error"


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — Invalid action
# ═══════════════════════════════════════════════════════════════════════════════

class TestInvalidAction:
    async def test_acao_invalida(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        result = await tool.execute(agent_context, {"action": "nao_existe"}, {}, {})
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "INVALID_PARAMS" in err["code"]


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — Error consistency (B3)
# ═══════════════════════════════════════════════════════════════════════════════

class TestErrorConsistency:
    """B3: Verify error code consistency across endpoints."""

    async def test_get_estrutura_error_code_102(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_estrutura=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_estrutura", "codigo_unidade": 99999999, "resolve_depth": 0}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "102" in err["code"]

    async def test_get_ocupantes_error_code_108(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_ocupantes=AsyncMock(side_effect=SiorgError(108, "sem cargos")),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_ocupantes", "codigo_unidade": 99999999}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "108" in err["code"]

    async def test_get_contato_error_code_102(self, agent_context, mock_session_ctx):
        tool = SiorgTool()
        mock = _mock_siorg_client(
            get_contato=AsyncMock(side_effect=SiorgError(102, "não encontrado")),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.siorg.siorg.SiorgClient", return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "get_contato", "codigo_unidade": 99999999}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "102" in err["code"]
