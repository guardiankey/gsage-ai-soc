"""Shared fixtures for SIORG tool unit tests."""

from __future__ import annotations

import sys
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

_PROJECT_ROOT = Path(__file__).resolve().parents[6]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import pytest

from src.shared.security.context import AgentContext, RequestSource


@pytest.fixture
def agent_context() -> AgentContext:
    """Minimal AgentContext for unit tests."""
    return AgentContext(
        org_id=uuid.uuid4(),
        user_id=uuid.uuid4(),
        group_ids=[],
        permissions=["gov:siorg:read"],
        request_id=uuid.uuid4(),
        source=RequestSource.API,
    )


@pytest.fixture
def mock_session_ctx():
    """Mock _tool_session_ctx so DB session-dependent actions don't crash."""
    mock_ctx = MagicMock()
    mock_ctx.get.return_value = MagicMock()  # non-None session
    with patch(
        "src.mcp_server.tools.base._tool_session_ctx",
        mock_ctx,
    ):
        yield mock_ctx
