"""Standalone diagnostic script for SEI external document upload.

Reproduces the ``POST /documento/{procedimento}/externo/criar`` WSSEI call
directly via httpx (bypassing the gSage tool layer) so the raw SEI response
— including the ``exception`` field — is visible.

Usage
-----
.. code-block:: bash

    # Source the SEI credentials (same as other live tests)
    source limbo/sei.sh

    # Override test parameters via env (optional — defaults below)
    export SEI_TEST_PROCEDIMENTO=65
    export SEI_TEST_ID_SERIE=305
    export SEI_TEST_FILE=/path/to/test.pdf

    # Run directly
    python src/mcp_server/tools/enterprise/tests/sei_pen/test_sei_external_doc_upload.py

Requires the same environment variables as the other SEI-PEN live tests:
``SEI_BASE_URL`` (or ``SEI_AMBIENTE``), ``SEI_ORGAO_ID``, ``SEI_USERNAME``,
``SEI_PASSWORD``.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import httpx

# ── Resolve connection params ───────────────────────────────────────────────

BASE_URL = os.getenv("SEI_BASE_URL") or ""
AMBIENTE = os.getenv("SEI_AMBIENTE") or ""
ORGAO_ID = (os.getenv("SEI_ORGAO_ID") or "").strip()
USERNAME = (os.getenv("SEI_USERNAME") or "").strip()
PASSWORD = os.getenv("SEI_PASSWORD") or ""
UNIDADE_ID = (os.getenv("SEI_UNIDADE_ID") or "").strip() or None

# ── Test parameters ─────────────────────────────────────────────────────────

PROCEDIMENTO = os.getenv("SEI_TEST_PROCEDIMENTO") or "65"
ID_SERIE = os.getenv("SEI_TEST_ID_SERIE_EXT") or os.getenv("SEI_TEST_ID_SERIE") or "305"
DATA_ELABORACAO = os.getenv("SEI_TEST_DATA_ELABORACAO") or "20/06/2026"
NIVEL_ACESSO = os.getenv("SEI_TEST_NIVEL_ACESSO") or "0"
DESCRICAO = os.getenv("SEI_TEST_DESCRICAO") or "Teste de upload via WSSEI API"
TEST_FILE = os.getenv("SEI_TEST_FILE") or ""
# idUnidadeGeradoraProtocolo is required by the SEI framework to set
# IdUnidadeResponsavel on the document DTO.  Defaults to the same value
# as the unidade header but can be overridden independently.
UNIDADE_GERADORA = os.getenv("SEI_TEST_UNIDADE_GERADORA") or UNIDADE_ID or ""

# ── Environment presets (same as _client.py) ────────────────────────────────

_SEI_PATH = "/sei/modulos/wssei/controlador_ws.php/api/v2"
_TRAMITA_HOST = "tramita.processoeletronico.gov.br"

AMBIENTE_URLS: dict[str, str] = {
    **{f"producao_orgao{n}": f"http://sei.orgao{n}.{_TRAMITA_HOST}{_SEI_PATH}"
       for n in range(1, 6)},
    **{f"homologacao_orgao{n}": f"http://sei-hom.orgao{n}.{_TRAMITA_HOST}{_SEI_PATH}"
       for n in range(1, 6)},
}


def resolve_base_url() -> str:
    if BASE_URL:
        return BASE_URL.rstrip("/")
    if AMBIENTE:
        url = AMBIENTE_URLS.get(AMBIENTE)
        if url:
            return url
        print(f"[ERROR] Unknown ambiente '{AMBIENTE}'.")
        print(f"  Valid: {', '.join(sorted(AMBIENTE_URLS.keys()))}")
        sys.exit(1)
    print("[ERROR] Set SEI_BASE_URL or SEI_AMBIENTE.")
    sys.exit(1)


def check_required() -> None:
    missing = []
    if not USERNAME:
        missing.append("SEI_USERNAME")
    if not PASSWORD:
        missing.append("SEI_PASSWORD")
    if not ORGAO_ID:
        missing.append("SEI_ORGAO_ID")
    if missing:
        print(f"[ERROR] Missing env vars: {', '.join(missing)}")
        print("  Source your SEI credentials file first (e.g. 'source limbo/sei.sh')")
        sys.exit(1)


# ── Main ────────────────────────────────────────────────────────────────────

async def main() -> None:
    check_required()
    base_url = resolve_base_url()

    print("=" * 72)
    print("  SEI External Document Upload — Diagnostic Test")
    print("=" * 72)
    print(f"  Base URL:     {base_url}")
    print(f"  Username:     {USERNAME}")
    print(f"  Orgao ID:     {ORGAO_ID}")
    print(f"  Unidade ID:   {UNIDADE_ID or '(not set)'}")
    print(f"  Unid Geradora:{UNIDADE_GERADORA or '(not set)'}")
    print(f"  Procedimento: {PROCEDIMENTO}")
    print(f"  idSerie:      {ID_SERIE}")
    print(f"  Data:         {DATA_ELABORACAO}")
    print(f"  Nivel Acesso: {NIVEL_ACESSO}")
    print(f"  Descricao:    {DESCRICAO}")
    print()

    # ── 1. Authenticate ─────────────────────────────────────────────────
    print("── 1. Authenticating …")
    auth_url = f"{base_url}/autenticar"
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        auth_resp = await client.post(auth_url, data={
            "usuario": USERNAME,
            "senha": PASSWORD,
            "orgao": int(ORGAO_ID),
        })
    auth_resp.raise_for_status()
    auth_body = auth_resp.json()
    if not auth_body.get("sucesso"):
        print(f"[FAIL] Authentication failed: {auth_body.get('mensagem', auth_body)}")
        return
    token = auth_body["data"]["token"]
    print(f"  Token obtained: {token[:20]}…")
    print()

    # ── 2. Upload external document ─────────────────────────────────────
    print("── 2. Uploading external document …")
    upload_url = f"{base_url}/documento/{PROCEDIMENTO}/externo/criar"
    headers = {"token": token}
    if UNIDADE_ID:
        headers["unidade"] = UNIDADE_ID

    form_data = {
        "idSerie": ID_SERIE,
        "dataElaboracao": DATA_ELABORACAO,
        "nivelAcesso": NIVEL_ACESSO,
        "grauSigilo": "",
        "numero": "",  # auto-generated by SEI when empty
    }
    if UNIDADE_GERADORA:
        form_data["idUnidadeGeradoraProtocolo"] = UNIDADE_GERADORA
    if DESCRICAO:
        form_data["descricao"] = DESCRICAO

    if TEST_FILE and Path(TEST_FILE).exists():
        file_name = Path(TEST_FILE).name
        file_content = Path(TEST_FILE).read_bytes()
        print(f"  File: {file_name} ({len(file_content)} bytes)")
        files = {"anexo": (file_name, file_content, "application/pdf")}
    else:
        print("  ⚠  No test file provided (set SEI_TEST_FILE env var).")
        print("  Sending a minimal 1-byte PDF to test endpoint acceptance.")
        # Minimal valid PDF
        minimal_pdf = (
            b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj "
            b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj "
            b"3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R>>endobj "
            b"xref\n0 4\n0000000000 65535 f \n0000000009 00000 n \n"
            b"0000000058 00000 n \n0000000115 00000 n \n"
            b"trailer<</Size 4/Root 1 0 R>>\nstartxref\n190\n%%EOF"
        )
        files = {"anexo": ("test_minimal.pdf", minimal_pdf, "application/pdf")}

    async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
        resp = await client.post(
            upload_url,
            headers=headers,
            data=form_data,
            files=files,
        )

    print(f"  HTTP status: {resp.status_code}")
    print(f"  Response headers: {dict(resp.headers)}")
    print()

    # ── 3. Parse response ───────────────────────────────────────────────
    try:
        body = resp.json()
    except Exception:
        print(f"[RAW RESPONSE (non-JSON)]:")
        print(resp.text[:2000])
        return

    print("── 3. Parsed response ──")
    print(json.dumps(body, indent=2, ensure_ascii=False, default=str))
    print()

    # ── 4. Summary ──────────────────────────────────────────────────────
    if body.get("sucesso"):
        print("✅ SUCCESS — document created:")
        data = body.get("data", {})
        print(f"   idDocumento: {data.get('idDocumento')}")
        print(f"   protocolo:   {data.get('protocoloDocumentoFormatado')}")
    else:
        print("❌ FAILED:")
        print(f"   mensagem:  {body.get('mensagem', '(empty)')!r}")
        exc = body.get("exception") or body.get("exceptionDetails") or ""
        print(f"   exception: {str(exc)[:500]!r}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
