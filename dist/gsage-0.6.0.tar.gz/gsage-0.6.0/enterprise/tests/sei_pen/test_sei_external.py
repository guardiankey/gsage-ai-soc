"""Live integration tests for SEI-PEN external document operations.

Tests download of external documents and metadata discovery.
Gated behind ``sei_live`` marker.

Run with::

    source limbo/sei.sh
    python -m pytest src/mcp_server/tools/enterprise/tests/sei_pen/test_sei_external.py -v --tb=long
"""

from __future__ import annotations

import os

import pytest

from src.mcp_server.tools.enterprise.gov.sei_pen.sei_read import SeiPenReadTool

pytestmark = [
    pytest.mark.sei_live,
    pytest.mark.asyncio(loop_scope="session"),
]


async def _run(tool, context, config, params):
    return await tool.execute(
        agent_context=context, params=params, config=config, state={}
    )


def _assert_success(result, operation: str) -> dict:
    if result.status != "success":
        err = result.error or {}
        pytest.fail(
            f"operation '{operation}' failed: "
            f"code={err.get('code')} message={err.get('message')}"
        )
    assert result.data is not None
    # High-level helpers wrap data in {"operation": ..., "result": ...}
    data = result.data
    inner = data.get("result", data)
    return inner if isinstance(inner, dict) else data


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — External Document Download (documento.baixar_externo)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDocumentoBaixarExterno:
    """Tests for downloading external documents from SEI.

    These tests first try to discover a valid external document by listing
    processes and their documents, then test the download itself.
    """

    @pytest.fixture(scope="function")
    async def external_doc_id(
        self, read_tool, agent_context, sei_config,
    ) -> str:
        """Try to find an external document automatically.

        Strategy:
        1. List open processes (up to 10)
        2. For each, list documents looking for external ones
        3. Return the first external document ID found
        """
        # First try env override
        doc_id = os.getenv("SEI_TEST_EXTERNAL_DOC_ID") or ""
        if doc_id:
            return doc_id

        # Auto-discovery: list recent processes, look for external docs
        result = await _run(
            read_tool, agent_context, sei_config,
            {"operation": "processo.listar", "limit": 10},
        )
        data = _assert_success(result, "processo.listar")
        processos = data.get("result", data.get("rows", []))
        if not processos:
            # Try other discovery methods
            result2 = await _run(
                read_tool, agent_context, sei_config,
                {"operation": "processo.pesquisar_geral", "limit": 10},
            )
            data2 = _assert_success(result2, "processo.pesquisar_geral")
            processos = data2.get("result", data2.get("rows", []))

        if not processos:
            pytest.skip(
                "Could not discover any processes. "
                "Set SEI_TEST_EXTERNAL_DOC_ID env var with a known external "
                "document ID to run this test."
            )

        # Try to find an external document in these processes
        for proc in processos:
            atributos = proc.get("atributos") or {}
            proc_id = (
                str(proc.get("id"))
                or str(atributos.get("idProcedimento"))
                or str(proc.get("IdProcedimento"))
                or ""
            )
            if not proc_id:
                continue
            docs_result = await _run(
                read_tool, agent_context, sei_config,
                {"operation": "documento.listar_em_processo",
                 "procedimento": proc_id},
            )
            if docs_result.status != "success":
                continue
            docs_data = docs_result.data or {}
            docs = docs_data.get("result", docs_data.get("rows", []))
            for doc in docs:
                atributos = doc.get("atributos") or {}
                tipo_doc = atributos.get("tipoDocumento", "")
                # Only external docs (tipo "E" or "X") can be used with
                # documento.baixar_externo.
                if tipo_doc.upper() not in ("E", "X"):
                    continue
                doc_id = (
                    str(doc.get("id"))
                    or str(doc.get("idDocumento"))
                    or str(doc.get("IdDocumento"))
                    or ""
                )
                if doc_id:
                    return doc_id

        pytest.skip(
            "Could not discover any documents. "
            "Set SEI_TEST_EXTERNAL_DOC_ID env var with a known external "
            "document ID to run this test."
        )
        return ""

    async def test_baixar_externo_metadados(
        self, read_tool, agent_context, sei_config, external_doc_id,
    ):
        """Verify that baixar_externo returns metadata + file references (not base64)."""
        data = _assert_success(
            await _run(
                read_tool, agent_context, sei_config,
                {"operation": "documento.baixar_externo",
                 "documento": external_doc_id},
            ),
            "documento.baixar_externo",
        )

        doc = data.get("documento", {})
        assert "id" in doc, f"Missing 'id' in documento metadata: {doc}"
        assert doc["id"] == external_doc_id
        assert "nome" in doc, f"Missing 'nome' in documento metadata: {doc}"
        assert "mime" in doc, f"Missing 'mime' in documento metadata: {doc}"

        # The download endpoint /documento/baixar/anexo/{protocolo}
        # returns the file content when available (saved via _store_file).
        download_available = data.get("download_available", False)
        assert isinstance(download_available, bool)

        if download_available:
            assert data.get("bytes", 0) > 0, "Expected file bytes"
            # Should have file artifact reference (when file store is available).
            # In unit test environments _store_file may return None, but the
            # artifacts dict structure should be present.
            artifacts = data.get("artifacts", {})
            assert "file" in artifacts, f"Missing 'file' key in artifacts: {artifacts}"
            assert "metadados" in artifacts, (
                f"Missing 'metadados' key in artifacts: {artifacts}"
            )
            if artifacts["file"] is not None:
                file_ref = artifacts["file"]
                assert "file_id" in file_ref, f"Missing file_id in artifact: {file_ref}"
                assert "download_path" in file_ref, (
                    f"Missing download_path in artifact: {file_ref}"
                )
        else:
            assert data.get("bytes", 0) >= 0

        # No base64 in response
        assert "conteudo_base64" not in data, (
            "Response should not contain base64 content"
        )

        # agent_hint should be present
        assert "agent_hint" in data, "Missing agent_hint in response"
        assert isinstance(data.get("agent_hint"), str)

        formato_suportado = data.get("formato_suportado_md", False)
        assert isinstance(formato_suportado, bool)

        print(f"  Document: {doc['nome']} ({doc['mime']})")
        print(f"  Size: {data['bytes']} bytes")
        print(f"  Download available: {download_available}")
        if download_available:
            file_ref = data.get("artifacts", {}).get("file")
            file_id = file_ref.get("file_id", "N/A") if file_ref else "N/A"
            print(f"  File ID: {file_id}")

    async def test_baixar_externo_documento_invalido(
        self, read_tool, agent_context, sei_config,
    ):
        """Verify error handling for invalid document ID."""
        result = await _run(
            read_tool, agent_context, sei_config,
            {"operation": "documento.baixar_externo", "documento": "999999999"},
        )
        assert result.status == "error", (
            f"Expected error for invalid doc ID, got {result.status}"
        )
        err = result.error or {}
        assert err.get("code") in (
            "SEI_API_ERROR", "INVALID_PARAMS",
        ), f"Unexpected error code: {err.get('code')}"


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — External Document Consultation (via raw helper endpoints)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDocumentoExternoConsultar:
    """Tests for documento.externo_consultar endpoint.

    Note: ``documento.externo_visualizar`` does NOT exist in this WSSEI
    version — the swagger only defines GET /documento/externo/consultar
    for external documents. No download endpoint is available.
    """

    async def test_consultar_externo(
        self, read_tool, agent_context, sei_config,
    ):
        """Verify external document consultation returns metadata.

        ``documento.externo_consultar`` uses ``protocolo`` as its path
        parameter (the external document's protocol, not internal ID).
        """
        doc_id = os.getenv("SEI_TEST_EXTERNAL_DOC_ID") or ""
        if not doc_id:
            pytest.skip("SEI_TEST_EXTERNAL_DOC_ID not set")

        data = _assert_success(
            await _run(
                read_tool, agent_context, sei_config,
                {"operation": "documento.externo_consultar",
                 "protocolo": doc_id},
            ),
            "documento.externo_consultar",
        )
        result = data.get("result", data)
        assert isinstance(result, dict), (
            f"Expected dict result, got {type(result)}"
        )
        doc_name = (
            result.get("nomeDocumento")
            or result.get("nome")
            or ""
        )
        assert doc_name, f"No document name found in result: {result}"
        assert result.get("idDocumento"), (
            f"Missing idDocumento in result: {result}"
        )
        print(f"  External doc: {doc_name} (id={result.get('idDocumento')})")
