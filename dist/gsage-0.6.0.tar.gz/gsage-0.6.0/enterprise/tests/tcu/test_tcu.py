"""Tests for the TCU tool."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from src.mcp_server.tools.enterprise.gov.tcu.tcu import TCUTool

# ── Sample data ──────────────────────────────────────────────────────────────

SAMPLE_INIDONEO = {
    "nome": "EMPRESA EXEMPLO LTDA",
    "cpfCnpj": "00394411000109",
    "processo": "TC 123.456/2020-0",
    "deliberacao": "Acórdão 1234/2021",
    "dataFim": "2026-12-31",
    "siglaUf": "DF",
}

SAMPLE_INABILITADO = {
    "nome": "JOAO DA SILVA",
    "cpf": "12345678901",
    "processo": "TC 789.012/2021-0",
    "deliberacao": "Acórdão 5678/2022",
    "dataFim": "2027-06-30",
    "siglaUf": "SP",
}

SAMPLE_CERTIDAO = {
    "razaoSocial": "EMPRESA EXEMPLO LTDA",
    "cnpj": "00394411000109",
    "certidoes": [
        {"emissor": "TCU", "tipo": "Inidôneos", "situacao": "Nada Consta"},
        {"emissor": "CGU", "tipo": "CEIS", "situacao": "Nada Consta"},
    ],
}

SAMPLE_ACORDAO = {
    "numero": "1234",
    "ano": "2025",
    "colegiado": "Plenário",
    "relator": "Ministro João",
    "dataSessao": "2025-06-10",
    "titulo": "Licitação pública",
    "sumario": "Análise de edital de licitação para contratação de serviços",
}

SAMPLE_PEDIDO = {
    "tipo": "REQ",
    "numero": "123/2025",
    "dataAprovacao": "2025-05-15",
    "autor": "Dep. Maria",
    "processoScn": "TC 456.789/2025-0",
    "assunto": "Solicitação de auditoria",
}

SAMPLE_DEBITO = {
    "saldoDebito": 50000.0,
    "saldoVariacaoSelic": 8234.56,
    "saldoJuros": 1234.56,
    "saldoTotal": 59469.12,
}

SAMPLE_TERMO = {
    "numero": "001",
    "ano": "2025",
    "nomeFornecedor": "CONSULTORIA EXEMPLO LTDA",
    "objeto": "Prestação de serviços de consultoria",
    "valorAtualizado": 150000.0,
    "modalidadeLicitacao": "Pregão",
}

SAMPLE_CADIRREG = {
    "nome": "JOAO DA SILVA",
    "cpf": "12345678901",
    "situacao": "Irregular",
    "processo": "TC 789.012/2021-0",
    "orgao": "Ministério da Saúde",
}

SAMPLE_PAUTA = {
    "data": "2025-07-01",
    "colegiado": "Plenário",
    "processo": "TC 123.456/2025-0",
    "relator": "Ministro João",
    "tipo": "Processo Administrativo",
}


# ── Fixtures ─────────────────────────────────────────────────────────────────


def _mock_client(**overrides: Any) -> AsyncMock:
    """Build a mocked TCUClient with defaults returning empty lists."""
    defaults = {
        "consultar_inidoneos": AsyncMock(return_value=[]),
        "consultar_inabilitados": AsyncMock(return_value=[]),
        "consultar_certidoes": AsyncMock(return_value=None),
        "consultar_acordaos": AsyncMock(return_value=[]),
        "consultar_pedidos_congresso": AsyncMock(return_value=[]),
        "calcular_debito": AsyncMock(return_value=None),
        "consultar_termos_contratuais": AsyncMock(return_value=[]),
        "consultar_cadirreg": AsyncMock(return_value=[]),
        "consultar_pautas_sessao": AsyncMock(return_value=[]),
    }
    defaults.update(overrides)
    mock = AsyncMock(**defaults)
    # _rate_limit is called internally — make it a no-op
    mock._rate_limit = AsyncMock()
    return mock


# ── Tests ────────────────────────────────────────────────────────────────────


class TestConsultarInidoneos:
    async def test_com_resultados(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_inidoneos=AsyncMock(return_value=[SAMPLE_INIDONEO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_inidoneos"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1
        assert "EMPRESA EXEMPLO" in data["registros"][0]["nome"]

    async def test_com_cpf_cnpj(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_inidoneos=AsyncMock(return_value=[SAMPLE_INIDONEO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_inidoneos", "cpf_cnpj": "00394411000109"},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        mock.consultar_inidoneos.assert_called_once()
        assert mock.consultar_inidoneos.call_args[1].get("cpf_cnpj") == "00394411000109"

    async def test_sem_resultados(self, agent_context):
        tool = TCUTool()
        mock = _mock_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_inidoneos"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 0


class TestConsultarInabilitados:
    async def test_com_resultados(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_inabilitados=AsyncMock(return_value=[SAMPLE_INABILITADO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_inabilitados"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1
        assert data["registros"][0]["nome"] == "JOAO DA SILVA"

    async def test_sem_resultados(self, agent_context):
        tool = TCUTool()
        mock = _mock_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_inabilitados"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 0


class TestConsultarCertidoes:
    async def test_com_certidoes(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_certidoes=AsyncMock(return_value=SAMPLE_CERTIDAO),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_certidoes", "cnpj": "00394411000109"},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 2
        assert data["razao_social"] == "EMPRESA EXEMPLO LTDA"

    async def test_cnpj_invalido(self, agent_context):
        tool = TCUTool()
        result = await tool.execute(
            agent_context,
            {"action": "consultar_certidoes", "cnpj": ""},
            {}, {},
        )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert "error" in data

    async def test_api_indisponivel(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(consultar_certidoes=AsyncMock(return_value=None))
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_certidoes", "cnpj": "00394411000109"},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert "error" in data


class TestConsultarAcordaos:
    async def test_sem_filtros(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_acordaos=AsyncMock(return_value=[SAMPLE_ACORDAO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_acordaos"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total_encontrados"] == 1

    async def test_com_filtro_colegiado(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_acordaos=AsyncMock(return_value=[SAMPLE_ACORDAO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_acordaos", "colegiado": "Plenário"},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total_encontrados"] == 1

    async def test_com_filtro_sem_resultados(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_acordaos=AsyncMock(return_value=[SAMPLE_ACORDAO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_acordaos", "colegiado": "2ª Câmara"},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total_encontrados"] == 0


class TestCalcularDebito:
    async def test_valores_positivos(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            calcular_debito=AsyncMock(return_value=SAMPLE_DEBITO),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {
                    "action": "calcular_debito",
                    "data_atualizacao": "25/06/2026",
                    "data_fato": "01/01/2020",
                    "valor_original": 50000.0,
                },
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["saldo_total"] == 59469.12

    async def test_parametros_faltando(self, agent_context):
        tool = TCUTool()
        result = await tool.execute(
            agent_context,
            {"action": "calcular_debito", "valor_original": 50000.0},
            {}, {},
        )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert "error" in data


class TestConsultarTermosContratuais:
    async def test_sem_filtros(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_termos_contratuais=AsyncMock(return_value=[SAMPLE_TERMO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_termos_contratuais"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1

    async def test_com_filtro_ano(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_termos_contratuais=AsyncMock(return_value=[SAMPLE_TERMO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_termos_contratuais", "ano": 2025},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestConsultarCadirreg:
    async def test_cpf_encontrado(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_cadirreg=AsyncMock(return_value=[SAMPLE_CADIRREG]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_cadirreg", "cpf": "12345678901"},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1

    async def test_cpf_nao_encontrado(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(consultar_cadirreg=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "consultar_cadirreg", "cpf": "00000000000"},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 0

    async def test_cpf_vazio(self, agent_context):
        tool = TCUTool()
        result = await tool.execute(
            agent_context,
            {"action": "consultar_cadirreg", "cpf": ""},
            {}, {},
        )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert "error" in data


class TestConsultarPautasSessao:
    async def test_com_resultados(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(
            consultar_pautas_sessao=AsyncMock(return_value=[SAMPLE_PAUTA]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_pautas_sessao"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1

    async def test_sem_resultados(self, agent_context):
        tool = TCUTool()
        mock = _mock_client(consultar_pautas_sessao=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.tcu.tcu.TCUClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "consultar_pautas_sessao"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 0


class TestInvalidAction:
    async def test_acao_invalida(self, agent_context):
        tool = TCUTool()
        result = await tool.execute(
            agent_context, {"action": "nao_existe"}, {}, {},
        )
        assert result.status == "error"
