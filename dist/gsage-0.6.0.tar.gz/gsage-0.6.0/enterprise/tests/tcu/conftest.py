"""Shared fixtures for tcu tool unit tests."""

from __future__ import annotations

import sys
import uuid
from pathlib import Path

# Ensure project root is on sys.path
_PROJECT_ROOT = Path(__file__).resolve().parents[6]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import pytest

from src.shared.security.context import AgentContext, RequestSource


@pytest.fixture
def agent_context() -> AgentContext:
    """Minimal AgentContext for unit tests."""
    return AgentContext(
        org_id=uuid.uuid4(),
        user_id=uuid.uuid4(),
        group_ids=[],
        permissions=["gov:tcu:read"],
        request_id=uuid.uuid4(),
        source=RequestSource.API,
    )
