"""Shared fixtures for compras tool unit tests."""

from __future__ import annotations

import sys
import uuid
from pathlib import Path

# Ensure project root is on sys.path (needed when running `pytest` directly)
_PROJECT_ROOT = Path(__file__).resolve().parents[6]  # compras → ... → gsage-ai-soc
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import pytest

from src.shared.security.context import AgentContext, RequestSource


@pytest.fixture
def agent_context() -> AgentContext:
    """Minimal AgentContext for unit tests (no DB session needed for mocked tests)."""
    return AgentContext(
        org_id=uuid.uuid4(),
        user_id=uuid.uuid4(),
        group_ids=[],
        permissions=["gov:compras:comprasgovbr:read", "gov:compras:pncp_contratos:read"],
        request_id=uuid.uuid4(),
        source=RequestSource.API,
    )


def assert_success(result) -> dict:
    """Assert tool result is success and return non-None data dict."""
    assert result.status == "success", (
        f"Expected success, got {result.status}: {result.error}"
    )
    assert result.data is not None
    return result.data


def assert_failure(result, expected_code_fragment: str = "") -> dict:
    """Assert tool result is failure and return error dict."""
    assert result.status == "failure", (
        f"Expected failure, got {result.status}"
    )
    assert result.error is not None
    if expected_code_fragment:
        assert expected_code_fragment in result.error.get("code", ""), (
            f"Expected error code containing '{expected_code_fragment}', "
            f"got {result.error.get('code')}"
        )
    return result.error
