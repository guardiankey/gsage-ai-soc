"""Unit tests for PncpContratosTool (pncp_contratos.py).

Tests mock PNCPClient — no real API calls.
Covers: all 10 PNCP-native actions, B11 (sequencial_compra), date normalisation,
error handling.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from src.mcp_server.tools.enterprise.gov.compras.pncp_contratos import PncpContratosTool


# ═══════════════════════════════════════════════════════════════════════════════
# Sample PNCP data (mirrors MCP Brasil test data)
# ═══════════════════════════════════════════════════════════════════════════════

SAMPLE_CONTRATACAO = [{
    "orgaoEntidade": {"razaoSocial": "Ministério da Educação", "cnpj": "00394460000141"},
    "objetoCompra": "Aquisição de computadores",
    "modalidadeId": 6, "situacaoCompraNome": "Publicada",
    "valorEstimado": 500000.0, "valorHomologado": 480000.0,
    "dataPublicacaoPncp": "2024-03-15", "uf": "DF", "municipio": "Brasília",
    "linkPncp": "https://pncp.gov.br/app/editais/123",
}]

SAMPLE_CONTRATO = [{
    "orgaoEntidade": {"razaoSocial": "Ministério da Saúde"},
    "objetoContrato": "Fornecimento de medicamentos",
    "fornecedor": {"razaoSocial": "Empresa Pharma LTDA", "cnpj": "12345678000199"},
    "numeroContrato": "2024/001", "valorFinal": 95000.0,
    "vigenciaInicio": "2024-01-01", "vigenciaFim": "2024-12-31",
    "situacaoContrato": "Vigente",
}]

SAMPLE_ATA = [{
    "orgaoEntidade": {"razaoSocial": "Universidade Federal"},
    "objetoAta": "Registro de preços para material de escritório",
    "fornecedor": {"razaoSocial": "Papelaria Central LTDA", "cnpj": "98765432000155"},
    "numeroAta": "2024/010", "valorTotal": 250000.0,
    "vigenciaInicio": "2024-06-01", "vigenciaFim": "2025-05-31",
}]

SAMPLE_CONTRATACAO_DETALHE = {
    "orgaoEntidade": {"razaoSocial": "Ministério da Educação", "cnpj": "00394460000141"},
    "objetoCompra": "Aquisição de mobiliário escolar",
    "anoCompra": 2024, "sequencialCompra": 1,
    "numeroControlePNCP": "00394460000141-1-000001/2024",
    "modalidadeNome": "Pregão - Eletrônico",
    "situacaoCompraNome": "Homologada",
    "valorEstimado": 1000000.0, "valorHomologado": 950000.0,
}

SAMPLE_PCA = [{
    "orgaoEntidade": {"razaoSocial": "Ministério da Educação", "cnpj": "00394460000141"},
    "anoPca": 2025, "unidadeNome": "Secretaria de Educação Básica",
    "idPca": "PCA-2025-001", "dataPublicacaoPca": "2024-12-20",
}]


# ═══════════════════════════════════════════════════════════════════════════════
# Mock helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _mock_pncp_client(**overrides) -> AsyncMock:
    defaults = {
        "get_contratacoes": AsyncMock(return_value=[]),
        "get_contratacoes_proposta": AsyncMock(return_value=[]),
        "get_contratacoes_atualizacao": AsyncMock(return_value=[]),
        "get_contratos": AsyncMock(return_value=[]),
        "get_contratos_atualizacao": AsyncMock(return_value=[]),
        "get_atas": AsyncMock(return_value=[]),
        "get_atas_atualizacao": AsyncMock(return_value=[]),
        "get_contratacao_detalhe": AsyncMock(return_value={}),
        "get_pca": AsyncMock(return_value=[]),
        "get_instrumentos_cobranca": AsyncMock(return_value=[]),
        **overrides,
    }
    return AsyncMock(**defaults)


pytestmark = pytest.mark.asyncio


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — listar_contratacoes
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratacoes:
    async def test_com_modalidade_6(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_contratacoes=AsyncMock(return_value=SAMPLE_CONTRATACAO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratacoes", "modalidade": 6,
                 "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1
        assert data["modalidade"]["nome"] == "Pregão - Eletrônico"

    async def test_datas_aceita_iso(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_contratacoes=AsyncMock(return_value=SAMPLE_CONTRATACAO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratacoes", "modalidade": 6,
                 "data_inicial": "2024-01-01", "data_final": "2024-03-31"}, {}, {},
            )
        assert result.status == "success"
        call_kwargs = mock.get_contratacoes.call_args.kwargs
        assert call_kwargs["dataInicial"] == "20240101"

    async def test_datas_aceita_ddmmyyyy(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_contratacoes=AsyncMock(return_value=SAMPLE_CONTRATACAO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratacoes", "modalidade": 6,
                 "data_inicial": "01/01/2024", "data_final": "31/03/2024"}, {}, {},
            )
        assert result.status == "success"

    async def test_sem_modalidade_erro(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {"action": "listar_contratacoes", "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
        )
        assert result.status == "error"

    async def test_periodo_excede_365_erro(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context,
            {"action": "listar_contratacoes", "modalidade": 6,
             "data_inicial": "20230101", "data_final": "20241231"}, {}, {},
        )
        assert result.status == "error"


# ═══════════════════════════════════════════════════════════════════════════════
# listar_contratos
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratos:
    async def test_listar_ok(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_contratos=AsyncMock(return_value=SAMPLE_CONTRATO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratos", "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


# ═══════════════════════════════════════════════════════════════════════════════
# listar_atas
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarAtas:
    async def test_listar_ok(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_atas=AsyncMock(return_value=SAMPLE_ATA))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_atas", "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# detalhar_contratacao (B11)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDetalharContratacao:
    async def test_sequencial_compra_respeitado__bug_b11(self, agent_context):
        """B11 regression: sequencial_compra MUST be sent to API."""
        tool = PncpContratosTool()
        mock = _mock_pncp_client(
            get_contratacao_detalhe=AsyncMock(return_value=SAMPLE_CONTRATACAO_DETALHE),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "detalhar_contratacao", "cnpj_orgao": "00394460000141",
                 "ano": 2024, "sequencial_compra": 89}, {}, {},
            )
        assert result.status == "success"
        call_args = mock.get_contratacao_detalhe.call_args
        assert call_args[0][2] == 89, f"BUG B11: sequencial should be 89, got {call_args[0][2]}"

    async def test_sem_sequencial_erro(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context,
            {"action": "detalhar_contratacao", "cnpj_orgao": "00394460000141", "ano": 2024}, {}, {},
        )
        assert result.status == "error"


# ═══════════════════════════════════════════════════════════════════════════════
# listar_pca
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarPca:
    async def test_listar_ok(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_pca=AsyncMock(return_value=SAMPLE_PCA))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_pca", "ano": 2025}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


# ═══════════════════════════════════════════════════════════════════════════════
# _atualizadas (B13 fix)
# ═══════════════════════════════════════════════════════════════════════════════

class TestAtualizadas:
    async def test_contratacoes_atualizadas_envia_datas__bug_b13(self, agent_context):
        """B13 regression: _atualizadas MUST send date params + codigoModalidade."""
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_contratacoes_atualizacao=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratacoes_atualizadas",
                 "modalidade": 6,
                 "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "success"
        call_kwargs = mock.get_contratacoes_atualizacao.call_args.kwargs
        assert "dataInicial" in call_kwargs, "BUG B13: dates not sent"
        assert "codigoModalidadeContratacao" in call_kwargs, (
            "BUG: codigoModalidadeContratacao not sent to PNCP API"
        )
        assert call_kwargs["codigoModalidadeContratacao"] == "6"

    async def test_sem_modalidade_erro_com_lista(self, agent_context):
        """Error when modalidade is missing — must list available options."""
        tool = PncpContratosTool()
        mock = _mock_pncp_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratacoes_atualizadas",
                 "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "modalidade" in err.get("message", "").lower()
        # Must include the modalidades list for debugging
        assert "Pregão" in err.get("message", "")


# ═══════════════════════════════════════════════════════════════════════════════
# listar_contratacoes_abertas
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratacoesAbertas:
    async def test_data_final_futuro_ok(self, agent_context):
        """Success when data_final >= today (future dates)."""
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_contratacoes_proposta=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratacoes_abertas",
                 "data_inicial": "20990101", "data_final": "20991231"}, {}, {},
            )
        assert result.status == "success"

    async def test_data_final_passado_erro(self, agent_context):
        """Error when data_final < today for open proposals."""
        tool = PncpContratosTool()
        mock = _mock_pncp_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratacoes_abertas",
                 "data_inicial": "20200101", "data_final": "20200131"}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "data_final" in err.get("message", "").lower()


# ═══════════════════════════════════════════════════════════════════════════════
# listar_contratos_atualizados
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratosAtualizados:
    async def test_listar_ok(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_contratos_atualizacao=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_contratos_atualizados",
                 "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "success"


# ═══════════════════════════════════════════════════════════════════════════════
# listar_atas_atualizadas
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarAtasAtualizadas:
    async def test_listar_ok(self, agent_context):
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_atas_atualizacao=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_atas_atualizadas",
                 "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "success"


# ═══════════════════════════════════════════════════════════════════════════════
# listar_instrumentos_cobranca
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarInstrumentosCobranca:
    async def test_periodo_ate_30_dias_ok(self, agent_context):
        """Success with period <= 30 days."""
        tool = PncpContratosTool()
        mock = _mock_pncp_client(get_instrumentos_cobranca=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_instrumentos_cobranca",
                 "data_inicial": "20240101", "data_final": "20240115"}, {}, {},
            )
        assert result.status == "success"
        call_kwargs = mock.get_instrumentos_cobranca.call_args.kwargs
        assert call_kwargs["dataInicial"] == "20240101"
        assert call_kwargs["dataFinal"] == "20240115"

    async def test_periodo_maior_30_dias_erro(self, agent_context):
        """Error when period > 30 days for instrumentos_cobranca."""
        tool = PncpContratosTool()
        mock = _mock_pncp_client()
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.pncp_contratos.PNCPClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_instrumentos_cobranca",
                 "data_inicial": "20240101", "data_final": "20240331"}, {}, {},
            )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "30 dias" in err.get("message", "")


class TestInvalidAction:
    async def test_acao_invalida(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(agent_context, {"action": "nao_existe"}, {}, {})
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "INVALID_PARAMS" in err["code"]
