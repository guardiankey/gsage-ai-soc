"""Live integration tests for PncpContratosTool.

Bats real PNCP API — gated behind ``COMPRAS_LIVE=1``.
Run with::

    COMPRAS_LIVE=1 pytest src/mcp_server/tools/enterprise/tests/compras/test_pncp_contratos_live.py -m compras_live -v

Covers all 10 actions with structural assertions and error-path validation.
"""

from __future__ import annotations

import os
from datetime import date, timedelta

import pytest

from src.mcp_server.tools.enterprise.gov.compras.pncp_contratos import PncpContratosTool

from src.mcp_server.tools.enterprise.tests.compras.conftest import agent_context  # noqa: F401

pytestmark = [
    pytest.mark.compras_live,
    pytest.mark.asyncio,
]


@pytest.fixture(scope="module", autouse=True)
def _require_live() -> None:
    if os.getenv("COMPRAS_LIVE") != "1":
        pytest.skip("Set COMPRAS_LIVE=1 to run live API tests")


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _hoje_ymd() -> str:
    return date.today().strftime("%Y%m%d")


def _daqui_a(dias: int) -> str:
    return (date.today() + timedelta(days=dias)).strftime("%Y%m%d")


def _atras(dias: int) -> str:
    return (date.today() - timedelta(days=dias)).strftime("%Y%m%d")


# ═══════════════════════════════════════════════════════════════════════════════
# 1. listar_contratacoes
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratacoesLive:
    """listar_contratacoes — most commonly used action."""

    async def test_pregao_eletronico_30d(self, agent_context):
        """Pregão Eletrônico (modalidade 6) — last 30 days."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes",
                "modalidade": 6,
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratacoes" in data
        assert "modalidade" in data
        assert data["modalidade"]["codigo"] == 6
        assert data["modalidade"]["nome"] == "Pregão - Eletrônico"

    async def test_dispensa_90d(self, agent_context):
        """Dispensa (modalidade 8) — broader window."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes",
                "modalidade": 8,
                "data_inicial": _atras(90),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratacoes" in data

    async def test_com_uf_df(self, agent_context):
        """Filter by UF=DF."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes",
                "modalidade": 6,
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "uf": "DF",
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_sem_modalidade_erro(self, agent_context):
        """modalidade is required — should return clear error."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
            }, {}, {},
        )
        assert result.status == "error", (
            f"Expected error for missing modalidade, got: {result.status}"
        )
        err = result.error
        assert err is not None
        assert "modalidade" in err.get("message", "").lower()

    async def test_data_invertida_erro(self, agent_context):
        """data_final < data_inicial should return validation error."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes",
                "modalidade": 6,
                "data_inicial": _hoje_ymd(),
                "data_final": _atras(7),
            }, {}, {},
        )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "anterior" in err.get("message", "").lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 2. listar_contratos
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratosLive:
    """listar_contratos — contratos by period."""

    async def test_basico_30d(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratos",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratos" in data

    async def test_com_cnpj_orgao(self, agent_context):
        """Filter by CNPJ of contracting org."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratos",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "cnpj_orgao": "00394502000144",
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"


# ═══════════════════════════════════════════════════════════════════════════════
# 3. listar_atas
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarAtasLive:
    """listar_atas — atas de registro de preço."""

    async def test_basico_30d(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_atas",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "atas" in data


# ═══════════════════════════════════════════════════════════════════════════════
# 4. listar_contratacoes_abertas
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratacoesAbertasLive:
    """listar_contratacoes_abertas — open proposals (requires future dates)."""

    async def test_futuro_30d(self, agent_context):
        """data_final >= hoje is required by PNCP API."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes_abertas",
                "data_inicial": _hoje_ymd(),
                "data_final": _daqui_a(30),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratacoes_abertas" in data

    async def test_data_final_passado_erro(self, agent_context):
        """data_final < hoje must fail with clear error."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes_abertas",
                "data_inicial": _atras(60),
                "data_final": _atras(30),
            }, {}, {},
        )
        assert result.status == "error", (
            f"Expected error for past data_final, got: {result.status}"
        )
        err = result.error
        assert err is not None
        assert "data_final" in err.get("message", "").lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 5. listar_contratacoes_atualizadas
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratacoesAtualizadasLive:
    """listar_contratacoes_atualizadas — feed of recently updated contratações."""

    async def test_com_modalidade_6(self, agent_context):
        """modalidade is now required — must pass codigoModalidadeContratacao."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes_atualizadas",
                "modalidade": 6,
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratacoes_atualizadas" in data

    async def test_sem_modalidade_erro_com_lista(self, agent_context):
        """Missing modalidade must return error with available options list."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratacoes_atualizadas",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
            }, {}, {},
        )
        assert result.status == "error", (
            f"Expected error for missing modalidade, got: {result.status}"
        )
        err = result.error
        assert err is not None
        msg = err.get("message", "")
        assert "modalidade" in msg.lower()
        # Must include the modalidades list for debugging
        assert "Pregão" in msg or "6" in msg, (
            f"Error message should list modalidades, got: {msg[:200]}"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# 6. listar_contratos_atualizados
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratosAtualizadosLive:
    """listar_contratos_atualizados — feed of recently updated contratos."""

    async def test_basico_30d(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratos_atualizados",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratos_atualizados" in data


# ═══════════════════════════════════════════════════════════════════════════════
# 7. listar_atas_atualizadas
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarAtasAtualizadasLive:
    """listar_atas_atualizadas — feed of recently updated atas."""

    async def test_basico_30d(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_atas_atualizadas",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "atas_atualizadas" in data


# ═══════════════════════════════════════════════════════════════════════════════
# 8. listar_instrumentos_cobranca
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarInstrumentosCobrancaLive:
    """listar_instrumentos_cobranca — max 30-day period enforced by PNCP."""

    async def test_periodo_30d(self, agent_context):
        """30-day period should succeed."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_instrumentos_cobranca",
                "data_inicial": _atras(30),
                "data_final": _hoje_ymd(),
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "instrumentos_cobranca" in data

    async def test_periodo_31d_erro(self, agent_context):
        """31+ day period must fail with clear message."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_instrumentos_cobranca",
                "data_inicial": _atras(31),
                "data_final": _hoje_ymd(),
            }, {}, {},
        )
        assert result.status == "error", (
            f"Expected error for >30 day period, got: {result.status}"
        )
        err = result.error
        assert err is not None
        assert "30 dias" in err.get("message", "")


# ═══════════════════════════════════════════════════════════════════════════════
# 9. listar_pca
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarPcaLive:
    """listar_pca — Plano de Contratações Anual."""

    async def test_ano_2025(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_pca",
                "ano": 2025,
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "pca" in data

    async def test_ano_corrente(self, agent_context):
        """Current year (2026)."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_pca",
                "ano": 2026,
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"


# ═══════════════════════════════════════════════════════════════════════════════
# 10. detalhar_contratacao
# ═══════════════════════════════════════════════════════════════════════════════

class TestDetalharContratacaoLive:
    """detalhar_contratacao — detail of a specific contratação."""

    async def test_cnpj_00394502000144_2025(self, agent_context):
        """Known CNPJ with contratações. May return not_found — that's OK."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "detalhar_contratacao",
                "cnpj_orgao": "00394502000144",
                "ano": 2025,
                "sequencial_compra": 1,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        # May be not_found or full detail — both are valid success responses
        assert "not_found" in data or "contratacao" in data

    async def test_sem_sequencial_erro(self, agent_context):
        """sequencial_compra is required."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "detalhar_contratacao",
                "cnpj_orgao": "00394502000144",
                "ano": 2025,
            }, {}, {},
        )
        assert result.status == "error", (
            f"Expected error for missing sequencial_compra, got: {result.status}"
        )
        err = result.error
        assert err is not None
        assert "sequencial_compra" in err.get("message", "").lower()


# ═══════════════════════════════════════════════════════════════════════════════
# Error / edge cases
# ═══════════════════════════════════════════════════════════════════════════════

class TestPncpContratosErrorCases:
    """Cross-cutting error handling."""

    async def test_invalid_action(self, agent_context):
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {"action": "nao_existe"}, {}, {},
        )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "INVALID_PARAMS" in err.get("code", "")

    async def test_periodo_excede_365_dias_erro(self, agent_context):
        """Any action with period > 365 days must fail."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratos",
                "data_inicial": "20230101",
                "data_final": "20241231",
            }, {}, {},
        )
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "365" in err.get("message", "") or "excede" in err.get("message", "").lower()

    async def test_formato_data_ddmmyyyy(self, agent_context):
        """DD/MM/YYYY date format must be accepted and normalized."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratos",
                "data_inicial": f"{_atras(30)[6:8]}/{_atras(30)[4:6]}/{_atras(30)[0:4]}",
                "data_final": f"{_hoje_ymd()[6:8]}/{_hoje_ymd()[4:6]}/{_hoje_ymd()[0:4]}",
                "max_results": 3,
            }, {}, {},
        )
        assert result.status == "success", f"Date parse error: {result.error}"

    async def test_formato_data_iso(self, agent_context):
        """YYYY-MM-DD date format must be accepted."""
        tool = PncpContratosTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_contratos",
                "data_inicial": f"{_atras(30)[0:4]}-{_atras(30)[4:6]}-{_atras(30)[6:8]}",
                "data_final": f"{_hoje_ymd()[0:4]}-{_hoje_ymd()[4:6]}-{_hoje_ymd()[6:8]}",
                "max_results": 3,
            }, {}, {},
        )
        assert result.status == "success", f"Date parse error: {result.error}"

