"""Live integration tests for ComprasGovbrTool.

Bats real APIs — gated behind ``COMPRAS_LIVE=1``.
Run with::

    COMPRAS_LIVE=1 pytest ... -m compras_live -v

WARNING: May hit rate limits (30 req/min for Compras.gov.br).
"""

from __future__ import annotations

import os

import pytest
import pytest_asyncio

from src.mcp_server.tools.enterprise.gov.compras.comprasgovbr import ComprasGovbrTool
from src.mcp_server.tools.enterprise.gov.compras._client import ComprasClient
from src.mcp_server.tools.enterprise.gov.compras._client_contratosgovbr import ContratosGovbrClient

from src.mcp_server.tools.enterprise.tests.compras.conftest import agent_context  # noqa: F401

pytestmark = [
    pytest.mark.compras_live,
    pytest.mark.asyncio,
]


@pytest.fixture(scope="module", autouse=True)
def _require_live() -> None:
    if os.getenv("COMPRAS_LIVE") != "1":
        pytest.skip("Set COMPRAS_LIVE=1 to run live API tests")


# ═══════════════════════════════════════════════════════════════════════════════
# comprasgovbr — Dados Abertos (known working params from curl tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestComprasGovbrLive:
    """Tests that hit the real Compras.gov.br API (Dados Abertos)."""

    async def test_buscar_orgao_uasg_110001(self, agent_context):
        """Known UASG 110001 → SECRETARIA DE GESTAO."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_orgao", "codigo_uasg": "110001"}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert data["total"] >= 1
        assert data["orgaos"][0]["codigo_uasg"] == "110001"

    async def test_listar_contratos_mec(self, agent_context):
        """Órgão 26000 (MEC) should return contracts."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_contratos", "codigo_orgao": 26000,
                            "vigencia_min": "2024-01-01", "vigencia_max": "2024-12-31",
                            "max_results": 5}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_buscar_materiais(self, agent_context):
        """CATMAT search for 'notebook' should return results."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_materiais", "palavra": "notebook", "max_results": 5}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert data["total"] >= 1

    async def test_dashboard_mec(self, agent_context):
        """Dashboard for MEC (26000)."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "dashboard", "codigo_orgao": 26000}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_contratacoes_mec(self, agent_context):
        """Contratações PNCP via Compras.gov.br module."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_contratacoes", "codigo_orgao": 26000,
                            "vigencia_min": "2024-01-01", "vigencia_max": "2024-12-31",
                            "max_results": 5}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_atas(self, agent_context):
        """Atas de RP."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_atas", "codigo_uasg": "150002",
                            "vigencia_min": "2024-01-01", "vigencia_max": "2024-12-31",
                            "max_results": 5}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_pesquisar_precos(self, agent_context):
        """Price research for CATMAT item 637211 (microcomputador)."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "pesquisar_precos", "codigo_item": 637211,
                            "uf": "DF", "max_results": 5}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        # total >= 0 is acceptable (may have no purchases for this item in DF)
        assert "total_compras" in data["estatisticas"]

    # ── Bug #1 regression: codigo_uasg as int ───────────────────────────

    async def test_buscar_orgao_uasg_int(self, agent_context):
        """Bug #1: codigo_uasg as int must be coerced to str."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_orgao", "codigo_uasg": 110001}, {}, {},
        )
        assert result.status == "success", (
            f"BUG #1 REGRESSION (int→str coercion): {result.error}"
        )
        data = result.data
        assert data is not None
        assert data["total"] >= 1
        assert data["orgaos"][0]["codigo_uasg"] == "110001"

    # ── buscar_orgao variants ───────────────────────────────────────────

    async def test_buscar_orgao_cnpj(self, agent_context):
        """buscar_orgao by CNPJ via Contratos.gov.br fallback."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_orgao", "cnpj": "00394411000109"}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        # May return 0 or more results — both are valid
        assert data["total"] >= 0

    # ── Catálogo / serviços ─────────────────────────────────────────────

    async def test_buscar_servicos(self, agent_context):
        """CATSER service lookup."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_servicos", "codigo_servico": 1,
                            "max_results": 3}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_materiais_por_pdm(self, agent_context):
        """CATMAT items within a PDM group."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_materiais_por_pdm",
                            "codigo_pdm": 6661, "max_results": 10}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "total" in data

    # ── Fornecedores ────────────────────────────────────────────────────

    async def test_listar_fornecedores(self, agent_context):
        """Supplier lookup by CNPJ."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_fornecedores",
                            "cnpj": "00394411000109"}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "fornecedor" in data

    async def test_buscar_contratos_fornecedor(self, agent_context):
        """Contracts by supplier CNPJ/CPF — requires Portal da Transparência API key."""
        api_key = os.getenv("TOOL_COMPRASGOVBR__API_KEY", "")
        if not api_key:
            pytest.skip("TOOL_COMPRASGOVBR__API_KEY not configured — Portal da Transparência unavailable")
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_contratos_fornecedor",
                            "cpf_cnpj": "00394411000109", "max_results": 5},
            {"api_key": api_key}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratos" in data

    # ── Legado 8.666 ────────────────────────────────────────────────────

    async def test_listar_licitacoes(self, agent_context):
        """Legacy licitações (Lei 8.666)."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_licitacoes",
                "data_publicacao_inicial": "2020-01-01",
                "data_publicacao_final": "2020-12-31",
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_pregoes(self, agent_context):
        """Legacy pregões (Lei 8.666)."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {
                "action": "listar_pregoes",
                "data_publicacao_inicial": "2020-01-01",
                "data_publicacao_final": "2020-12-31",
                "max_results": 5,
            }, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_dispensas(self, agent_context):
        """Dispensas by year."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_dispensas",
                            "ano_aviso": 2025, "max_results": 5}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    # ── PGC ─────────────────────────────────────────────────────────────

    async def test_listar_pgc(self, agent_context):
        """Plano de Gerenciamento de Contratações."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_pgc",
                            "codigo_orgao": 30802, "ano": 2025,
                            "max_results": 5}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"


# ═══════════════════════════════════════════════════════════════════════════════
# comprasgovbr — Contratos.gov.br (known working from curl)
# ═══════════════════════════════════════════════════════════════════════════════

class TestContratosGovbrLive:
    """Tests that hit the real Contratos.gov.br API."""

    async def test_listar_contratos_ug_110161(self, agent_context):
        """UG 110161 (AGU) → should return contracts."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_contratos_ug", "unidade_codigo": 110161}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None

    async def test_detalhar_contrato_2957(self, agent_context):
        """Contract 2957 (AGU/energia) should have detalhe."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "detalhar_contrato_id", "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert data["contrato"]["id"] == 2957

    async def test_listar_empenhos_2957(self, agent_context):
        """Empenhos do contrato 2957 (B1 fix: valores brasileiros)."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_empenhos", "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"B1 REGRESSION: {result.error}"
        data = result.data
        assert data is not None
        assert data["total"] >= 1  # Known to return 18 empenhos

    async def test_listar_faturas_2957(self, agent_context):
        """Faturas do contrato 2957."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_faturas", "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert data["total"] >= 1  # 57 faturas known

    async def test_listar_historico_2957(self, agent_context):
        """Histórico do contrato 2957."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_historico_contrato", "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_itens_2957(self, agent_context):
        """Itens do contrato 2957."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_itens_contrato", "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_terceirizados_2957(self, agent_context):
        """Terceirizados — contrato de energia não tem."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_terceirizados", "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    # ── detalhar_contrato (idCompra variant) ─────────────────────────────

    async def test_detalhar_contrato_id_compra(self, agent_context):
        """Detalhar contrato by idCompra:... format."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "detalhar_contrato",
                            "id_contrato": "idCompra:20010905900032025"}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None

    # ── detalhar_contrato_completo ───────────────────────────────────────

    async def test_detalhar_contrato_completo(self, agent_context):
        """Aggregated contract view — all sections in one call."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "detalhar_contrato_completo",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert data["contrato"]["id"] == 2957
        assert "secoes_carregadas" in data

    # ── contratos inativos UG ────────────────────────────────────────────

    async def test_listar_contratos_inativos_ug(self, agent_context):
        """Inactive contracts for AGU (110161)."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_contratos_inativos_ug",
                            "unidade_codigo": 110161}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert "contratos" in data

    # ── Bug #2 regression: listar_domicilio_bancario ─────────────────────

    async def test_listar_domicilio_bancario(self, agent_context):
        """Bug #2: standalone domicilio_bancario must call correct method."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_domicilio_bancario",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", (
            f"BUG #2 REGRESSION (domicilio_bancario mapping): {result.error}"
        )
        data = result.data
        assert data is not None
        assert data["contrato_id"] == 2957

    # ── Garantias / Cronograma / Ocorrências ─────────────────────────────

    async def test_listar_garantias_contrato(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_garantias_contrato",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"
        data = result.data
        assert data is not None
        assert data["contrato_id"] == 2957

    async def test_listar_cronograma_contrato(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_cronograma_contrato",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_ocorrencias_contrato(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_ocorrencias_contrato",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    # ── Publicações / Responsáveis / Prepostos ───────────────────────────

    async def test_listar_publicacoes_contrato(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_publicacoes_contrato",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_responsaveis_contrato(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_responsaveis_contrato",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_prepostos_contrato(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_prepostos_contrato",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    # ── Despesas / Arquivos ─────────────────────────────────────────────

    async def test_listar_despesas_acessorias(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_despesas_acessorias",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    async def test_listar_arquivos_contrato(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_arquivos_contrato",
                            "contrato_id": 2957}, {}, {},
        )
        assert result.status == "success", f"Erro: {result.error}"

    # ── buscar_contrato_ug_origem ────────────────────────────────────────

    async def test_buscar_contrato_ug_origem(self, agent_context):
        """Find contract by UASG origin + number."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_contrato_ug_origem",
                            "codigo_uasg": 110001,
                            "numero_contrato": "00001/2024"}, {}, {},
        )
        # May return not_found or found — both are valid success responses
        assert result.status == "success", f"Erro: {result.error}"


class TestComprasGovbrErrorCases:
    """Error handling with real API."""

    async def test_invalid_action(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "nao_existe"}, {}, {})
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "INVALID_PARAMS" in err["code"]

    async def test_sem_parametro(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "listar_contratos"}, {}, {})
        assert result.status == "error"

    async def test_buscar_orgao_vazio(self, agent_context):
        """buscar_orgao without any param should return error."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_orgao", "codigo_uasg": ""}, {}, {},
        )
        assert result.status == "error", (
            f"Expected error for empty codigo_uasg, got: {result.status}"
        )

    async def test_buscar_orgao_codigo_uasg_int__bug1_regression(self, agent_context):
        """Bug #1 regression: int must work after fix (live validation)."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "buscar_orgao", "codigo_uasg": 110001}, {}, {},
        )
        assert result.status == "success", (
            f"BUG #1 LIVE REGRESSION (int coercion): {result.error}"
        )
        data = result.data
        assert data is not None
        assert data["total"] >= 1

    async def test_data_formato_invalido_erro(self, agent_context):
        """Invalid date format must return validation error."""
        tool = ComprasGovbrTool()
        result = await tool.execute(
            agent_context, {"action": "listar_contratos",
                            "vigencia_min": "invalid-date"}, {}, {},
        )
        # Should either fail gracefully or return error — must not crash
        assert result.status in ("success", "error"), (
            f"Unexpected status with invalid date: {result.status}"
        )
