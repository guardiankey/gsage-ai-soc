"""Unit tests for ComprasGovbrTool (comprasgovbr.py).

Tests mock HTTP clients — no real API calls.
Covers: all 21 actions, error handling, B1 scenario (Brazilian number format).
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from src.mcp_server.tools.enterprise.gov.compras.comprasgovbr import ComprasGovbrTool


# ═══════════════════════════════════════════════════════════════════════════════
# Sample data
# ═══════════════════════════════════════════════════════════════════════════════

SAMPLE_UASG = [{
    "codigoUasg": "110001", "nomeUasg": "SECRETARIA DE GESTAO",
    "cnpjCpfUasg": "00394411000109", "codigoOrgao": "20101",
    "cnpjCpfOrgao": "00394460000141", "codigoSiorg": "334",
    "siglaUf": "DF", "nomeMunicipioIbge": "BRASILIA", "statusUasg": "1",
}]

SAMPLE_CONTRATO = {
    "idCompra": "123456", "tipo": "idCompra", "numeroContrato": "001/2023",
    "objeto": "Prestação de serviços de limpeza",
    "nomeRazaoSocialFornecedor": "Empresa XYZ Ltda", "niFornecedor": "12345678000199",
    "valorGlobal": "1200000.00", "dataVigenciaInicial": "2023-02-01",
    "dataVigenciaFinal": "2024-01-31", "nomeTipo": "Ativo",
    "codigoOrgao": "26000", "nomeOrgao": "Ministério da Educação",
    "nomeModalidadeCompra": "Pregão Eletrônico", "nomeCategoria": "Serviço",
}

SAMPLE_CONTRATO_DETALHE = {
    "idCompra": "123456", "tipo": "idCompra", "numeroContrato": "001/2023",
    "objeto": "Prestação de serviços de limpeza", "valorGlobal": "1200000.00",
    "dataVigenciaInicial": "2023-02-01", "dataVigenciaFinal": "2024-01-31",
    "nomeRazaoSocialFornecedor": "Empresa XYZ Ltda", "niFornecedor": "12345678000199",
    "codigoOrgao": "26000", "nomeOrgao": "Ministério da Educação",
}

SAMPLE_FORNECEDOR = [{
    "cnpj": "12345678000199", "nomeRazaoSocialFornecedor": "Empresa Teste LTDA",
    "nomeFantasia": "Teste Corp", "ufSigla": "SP", "habilitadoLicitar": True,
}]

SAMPLE_ARP = [{
    "numeroAtaRegistroPreco": "2024/010",
    "objeto": "Registro de preços para material de escritório",
    "dataVigenciaInicial": "2024-06-01", "dataVigenciaFinal": "2025-05-31",
    "nomeUnidadeGerenciadora": "Universidade Federal",
    "codigoUnidadeGerenciadora": "26000",
}]

# ── Dashboard sample data ─────────────────────────────────────────────────────

SAMPLE_ORGAO = [{
    "codigoOrgao": "20101", "nomeOrgao": "PRESIDENCIA DA REPUBLICA",
    "cnpjCpfOrgao": "00394411000109", "codigoSiorg": "39263", "siglaUf": "DF",
}]

SAMPLE_CONTRATO_COM_UASG = {
    "idCompra": "654321", "tipo": "idCompra", "numeroContrato": "002/2024",
    "objeto": "Serviço de vigilância",
    "nomeRazaoSocialFornecedor": "Segurança Total Ltda", "niFornecedor": "98765432000199",
    "valorGlobal": "500000.00",
    "dataVigenciaInicial": "2024-01-01", "dataVigenciaFinal": "2024-12-31",
    "codigoUnidadeGestora": "110001",
    "codigoOrgao": "20101", "nomeOrgao": "PRESIDENCIA DA REPUBLICA",
    "nomeModalidadeCompra": "Pregão Eletrônico", "nomeCategoria": "Serviço",
}

SAMPLE_CONTRATO_OUTRA_UASG = {
    "idCompra": "789012", "tipo": "idCompra", "numeroContrato": "003/2024",
    "objeto": "Fornecimento de energia",
    "nomeRazaoSocialFornecedor": "Energia S/A", "niFornecedor": "11111111000199",
    "valorGlobal": "999999.99",
    "dataVigenciaInicial": "2024-03-01", "dataVigenciaFinal": "2025-02-28",
    "codigoUnidadeGestora": "110322",  # UASG diferente
    "codigoOrgao": "20101", "nomeOrgao": "PRESIDENCIA DA REPUBLICA",
    "nomeModalidadeCompra": "Pregão Eletrônico", "nomeCategoria": "Serviço",
}

SAMPLE_ARP_MESMA_UASG = [{
    "numeroAtaRegistroPreco": "2025/001",
    "objeto": "Registro de preços para material de escritório",
    "dataVigenciaInicial": "2025-01-01", "dataVigenciaFinal": "2025-12-31",
    "nomeUnidadeGerenciadora": "SECRETARIA DE ADMINISTRACAO/PR",
    "codigoUnidadeGerenciadora": "110001",
}]

SAMPLE_ARP_OUTRA_UASG = [{
    "numeroAtaRegistroPreco": "2024/999",
    "objeto": "Registro de preços para equipamentos",
    "dataVigenciaInicial": "2024-06-01", "dataVigenciaFinal": "2025-05-31",
    "nomeUnidadeGerenciadora": "OUTRO ORGAO",
    "codigoUnidadeGerenciadora": "999999",
}]

SAMPLE_PRECO = [{
    "dataCompra": "2024-03-15", "nomeOrgao": "Ministério da Educação",
    "descricaoItem": "Notebook 15 pol", "precoUnitario": "4500.00",
    "valorTotal": "45000.00", "quantidade": "10",
}]

SAMPLE_CONTRATACAO = [{
    "objetoCompra": "Aquisição de computadores",
    "orgaoEntidade": {"razaoSocial": "Ministério da Educação"},
    "modalidadeId": 6, "situacaoCompraNome": "Publicada",
}]

SAMPLE_MATERIAL_CATMAT = [{
    "codigoItem": 12345, "descricaoItem": "Notebook 15 pol", "codigoPdm": 8435,
}]

SAMPLE_LICITACAO = [{
    "id_compra": "12345", "objeto": "Aquisição de material",
    "nome_modalidade": "Pregão", "situacao_aviso": "Homologado",
    "data_publicacao": "2020-01-15",
}]

SAMPLE_SERVICO = [{
    "codigoServico": 1, "nomeServico": "Serviço de Limpeza",
}]

SAMPLE_PGC = [{"anoPcaProjetoCompra": "2025", "codigoOrgao": "20101"}]

# ── Contratos.gov.br ─────────────────────────────────────────────────────────

SAMPLE_CG_CONTRATO = {
    "id": 2957, "numero": "00059/2009",
    "orgao_nome": "ADVOCACIA-GERAL DA UNIAO",
    "fornecedor_nome": "BOA VISTA ENERGIA S.A.",
    "objeto": "Fornecimento de energia elétrica",
    "valor_global": "82892.76", "situacao": "Ativo",
}

SAMPLE_EMPENHO = [
    {"id": 1, "numero": "2023NE000123", "credor": "Empresa XYZ",
     "empenhado": "42.290,89", "liquidado": "21.500,00", "pago": "21.500,00"},
    {"id": 2, "numero": "2023NE000456",
     "empenhado": "192.500,00", "liquidado": "100.000,00", "pago": "100.000,00"},
    {"id": 3, "numero": "2023NE000789",
     "empenhado": "207.000,00", "liquidado": "0,00", "pago": "0,00"},
]

SAMPLE_FATURA = [
    {"id": 1, "numero": "NF-001", "emissao": "2023-03-01",
     "valor": "100.000,00", "valorliquido": "95.000,00", "situacao": "Paga"},
]

SAMPLE_HISTORICO = [
    {"id": 1, "tipo": "Termo Aditivo", "numero": "01/2023",
     "fornecedor": {"nome": "Empresa XYZ"}, "data_assinatura": "2023-06-01",
     "valor_global": "1.500.000,00", "situacao_contrato": "Ativo"},
]

SAMPLE_ITEM = [
    {"tipo_item": "Serviço", "codigo_item": "SRV001",
     "descricao_item": "Limpeza predial", "unidade": "m2",
     "quantidade": "500", "valor_unitario": "25,00", "valor_total": "12.500,00"},
]


# ═══════════════════════════════════════════════════════════════════════════════
# Mock helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _mock_compras_client(**overrides) -> AsyncMock:
    defaults = {
        "get_uasg": AsyncMock(return_value=[]),
        "get_orgaos_uasg": AsyncMock(return_value=[]),
        "get_contratos": AsyncMock(return_value=[]),
        "get_contrato_by_id": AsyncMock(return_value={}),
        "get_contratos_itens": AsyncMock(return_value=[]),
        "get_licitacoes": AsyncMock(return_value=[]),
        "get_contratacoes": AsyncMock(return_value=[]),
        "get_fornecedor": AsyncMock(return_value=[]),
        "get_arp": AsyncMock(return_value=[]),
        "get_precos": AsyncMock(return_value=[]),
        "get_pgc": AsyncMock(return_value=[]),
        "get_item_material": AsyncMock(return_value=[]),
        "get_itens_servico": AsyncMock(return_value=[]),
        **overrides,
    }
    return AsyncMock(**defaults)


def _mock_cg_client(**overrides) -> AsyncMock:
    defaults = {
        "listar_contratos_ug": AsyncMock(return_value=[]),
        "consultar_contrato": AsyncMock(return_value=None),
        "listar_empenhos": AsyncMock(return_value=[]),
        "listar_faturas": AsyncMock(return_value=[]),
        "listar_itens": AsyncMock(return_value=[]),
        "listar_historico": AsyncMock(return_value=[]),
        "listar_terceirizados": AsyncMock(return_value=[]),
        "listar_garantias": AsyncMock(return_value=[]),
        "listar_cronograma": AsyncMock(return_value=[]),
        "listar_ocorrencias": AsyncMock(return_value=[]),
        "listar_publicacoes": AsyncMock(return_value=[]),
        "listar_responsaveis": AsyncMock(return_value=[]),
        "listar_prepostos": AsyncMock(return_value=[]),
        "listar_despesas_acessorias": AsyncMock(return_value=[]),
        "listar_arquivos": AsyncMock(return_value=[]),
        "listar_domicilio_bancario": AsyncMock(return_value=None),
        "listar_contratos_inativos_ug": AsyncMock(return_value=[]),
        "buscar_contrato_ug_origem": AsyncMock(return_value=None),
        **overrides,
    }
    return AsyncMock(**defaults)


# ═══════════════════════════════════════════════════════════════════════════════
# Tests
# ═══════════════════════════════════════════════════════════════════════════════

pytestmark = pytest.mark.asyncio


class TestBuscarOrgao:
    async def test_buscar_por_uasg(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_uasg=AsyncMock(return_value=SAMPLE_UASG))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(agent_context, {"action": "buscar_orgao", "codigo_uasg": "110001"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1
        assert data["orgaos"][0]["codigo_uasg"] == "110001"

    async def test_sem_parametros_erro(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "buscar_orgao"}, {}, {})
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "400" in err["code"]

    async def test_codigo_uasg_int__bug_coercao(self, agent_context):
        """Bug fix: codigo_uasg as int must be coerced to str before .strip()."""
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_uasg=AsyncMock(return_value=SAMPLE_UASG))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            # Passing int (not string) — must NOT raise AttributeError
            result = await tool.execute(
                agent_context, {"action": "buscar_orgao", "codigo_uasg": 110001}, {}, {},
            )
        assert result.status == "success", (
            f"int coercion failed: {result.error}"
        )
        data = result.data
        assert data is not None
        assert data["total"] == 1
        assert data["orgaos"][0]["codigo_uasg"] == "110001"

    async def test_codigo_uasg_zero_int(self, agent_context):
        """Edge case: codigo_uasg=0 (falsy int) should become '0' (truthy str)."""
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_uasg=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "buscar_orgao", "codigo_uasg": 0}, {}, {},
            )
        # 0 as UASG will likely return empty, but must NOT crash with AttributeError
        assert result.status in ("success", "error")
        if result.status == "error" and result.error is not None:
            # Acceptable: API may reject UASG=0, but must not be a coercion crash
            assert "strip" not in str(result.error.get("message", "")).lower()


class TestBuscarMateriais:
    async def test_catmat_primario(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_item_material=AsyncMock(return_value=SAMPLE_MATERIAL_CATMAT))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(agent_context, {"action": "buscar_materiais", "palavra": "notebook"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] >= 1

    async def test_sem_palavra_erro(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "buscar_materiais"}, {}, {})
        assert result.status == "error"


class TestListarContratos:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(
            get_uasg=AsyncMock(return_value=SAMPLE_UASG),
            get_contratos=AsyncMock(return_value=[SAMPLE_CONTRATO]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(agent_context, {"action": "listar_contratos", "codigo_uasg": "110001"}, {}, {})
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1

    async def test_sem_orgao_erro(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "listar_contratos"}, {}, {})
        assert result.status == "error"


class TestDetalharContrato:
    async def test_detalhar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(
            get_contrato_by_id=AsyncMock(return_value=SAMPLE_CONTRATO_DETALHE),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "detalhar_contrato", "id_contrato": "idCompra:123456", "codigo_orgao": 26000},
                {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["contrato"]["numero"] == "001/2023"

    async def test_id_invalido_erro(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "detalhar_contrato", "id_contrato": "abc"}, {}, {})
        assert result.status == "error"


class TestListarFornecedores:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_fornecedor=AsyncMock(return_value=SAMPLE_FORNECEDOR))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_fornecedores", "cnpj": "12345678000199"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestListarAtas:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_arp=AsyncMock(return_value=SAMPLE_ARP))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_atas", "codigo_uasg": "150002"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestPesquisarPrecos:
    async def test_pesquisar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_precos=AsyncMock(return_value=SAMPLE_PRECO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "pesquisar_precos", "codigo_material": 8435, "uf": "DF"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] >= 1
        assert "estatisticas" in data

    async def test_sem_codigo_erro(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "pesquisar_precos"}, {}, {})
        assert result.status == "error"


class TestListarLicitacoes:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(get_licitacoes=AsyncMock(return_value=SAMPLE_LICITACAO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_licitacoes", "data_publicacao_inicial": "2020-01-01",
                 "data_publicacao_final": "2020-12-31"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestListarDispensas:
    async def test_sem_ano_erro(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "listar_dispensas"}, {}, {})
        assert result.status == "error"


# ═══════════════════════════════════════════════════════════════════════════════
# Contratos.gov.br actions
# ═══════════════════════════════════════════════════════════════════════════════

class TestListarContratosUG:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_contratos_ug=AsyncMock(return_value=[SAMPLE_CG_CONTRATO]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_contratos_ug", "unidade_codigo": 110161}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestDetalharContratoID:
    async def test_not_found(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(consultar_contrato=AsyncMock(return_value=None))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "detalhar_contrato_id", "contrato_id": 999}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["contrato"].get("not_found") is True


class TestListarEmpenhos:
    async def test_com_valores_brasileiros__bug_b1(self, agent_context):
        """B1 regression: Brazilian number format MUST NOT crash."""
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_empenhos=AsyncMock(return_value=SAMPLE_EMPENHO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_empenhos", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success", f"BUG B1 REGRESSION: {result.error}"
        data = result.data
        assert data is not None
        assert data["total"] == 3
        assert data["empenhos"][0]["empenhado"] == "42.290,89"

    async def test_valores_zerados(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_empenhos=AsyncMock(return_value=[
            {"id": 1, "numero": "X", "credor": "Y",
             "empenhado": "0,00", "liquidado": "0,00", "pago": "0,00"},
        ]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(agent_context, {"action": "listar_empenhos", "contrato_id": 12345}, {}, {})
        assert result.status == "success"


class TestListarFaturas:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_faturas=AsyncMock(return_value=SAMPLE_FATURA))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_faturas", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestListarHistoricoContrato:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_historico=AsyncMock(return_value=SAMPLE_HISTORICO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_historico_contrato", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestListarItensContrato:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_itens=AsyncMock(return_value=SAMPLE_ITEM))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_itens_contrato", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1


class TestListarTerceirizados:
    async def test_vazio_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_terceirizados=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_terceirizados", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 0


class TestListarGarantiasContrato:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_garantias=AsyncMock(return_value=[{"id": 1, "tipo": "Seguro", "valor": 50000}]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_garantias_contrato", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1

    async def test_vazio_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_garantias=AsyncMock(return_value=[]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_garantias_contrato", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 0


class TestListarContratosInativosUG:
    async def test_listar_ok(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(listar_contratos_inativos_ug=AsyncMock(return_value=[SAMPLE_CG_CONTRATO]))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "listar_contratos_inativos_ug", "unidade_codigo": 110001}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["total"] == 1
        assert data["contratos"][0]["numero"] == "00059/2009"


class TestBuscarContratoUgOrigem:
    async def test_encontrado(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(buscar_contrato_ug_origem=AsyncMock(return_value=SAMPLE_CG_CONTRATO))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "buscar_contrato_ug_origem", "codigo_uasg": 110001, "numero_contrato": "00059/2009"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert not data["not_found"]
        assert data["contrato"]["numero"] == "00059/2009"

    async def test_nao_encontrado(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(buscar_contrato_ug_origem=AsyncMock(return_value=None))
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "buscar_contrato_ug_origem", "codigo_uasg": 999999, "numero_contrato": "00000/2000"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["not_found"]


class TestDetalharContratoCompleto:
    async def test_com_dados(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(
            consultar_contrato=AsyncMock(return_value=SAMPLE_CG_CONTRATO),
            listar_itens=AsyncMock(return_value=[SAMPLE_ITEM[0]]),
            listar_empenhos=AsyncMock(return_value=[SAMPLE_EMPENHO[0]]),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "detalhar_contrato_completo", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["contrato"]["id"] == 2957
        assert "itens" in data["secoes_carregadas"]
        assert "empenhos" in data["secoes_carregadas"]

    async def test_sem_dados(self, agent_context):
        tool = ComprasGovbrTool()
        mock = _mock_cg_client()  # all return empty
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "detalhar_contrato_completo", "contrato_id": 999}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert "contrato" not in data  # no data section


class TestDashboard:
    """Dashboard consolidation — tests UASG filtering and aggregation."""

    async def test_dashboard_por_orgao(self, agent_context):
        """Dashboard with codigo_orgao returns all contracts+ARPs for the org."""
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(
            get_orgaos_uasg=AsyncMock(return_value=SAMPLE_ORGAO),
            get_contratos=AsyncMock(return_value=[
                SAMPLE_CONTRATO_COM_UASG, SAMPLE_CONTRATO_OUTRA_UASG,
            ]),
            get_arp=AsyncMock(return_value=SAMPLE_ARP_MESMA_UASG + SAMPLE_ARP_OUTRA_UASG),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "dashboard", "codigo_orgao": 20101}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        assert data["orgao"]["nome"] == "PRESIDENCIA DA REPUBLICA"
        assert data["resumo"]["total_contratos_ativos"] == 2
        assert data["resumo"]["total_atas_vigentes"] == 2
        assert data["uasg"] is None

    async def test_dashboard_por_uasg_filtra_contratos(self, agent_context):
        """Dashboard with codigo_uasg filters contracts locally by uasg_codigo."""
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(
            get_orgaos_uasg=AsyncMock(return_value=SAMPLE_ORGAO),
            get_uasg=AsyncMock(return_value=[{
                "codigoUasg": "110001", "nomeUasg": "SECRETARIA DE ADMINISTRACAO/PR",
                "codigoOrgao": "20101",
            }]),
            get_contratos=AsyncMock(return_value=[
                SAMPLE_CONTRATO_COM_UASG,        # UASG 110001
                SAMPLE_CONTRATO_OUTRA_UASG,       # UASG 110322
            ]),
            get_arp=AsyncMock(return_value=SAMPLE_ARP_MESMA_UASG),  # filtered by API
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "dashboard", "codigo_uasg": "110001"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None

        # orgão name resolved via get_orgaos_uasg
        assert data["orgao"]["nome"] == "PRESIDENCIA DA REPUBLICA"

        # Only contracts for UASG 110001 should remain
        assert data["resumo"]["total_contratos_ativos"] == 1
        assert data["resumo"]["fornecedores_unicos"] == 1

        # UASG info should be present
        assert data["uasg"] is not None
        assert data["uasg"]["codigo"] == "110001"
        assert data["uasg"]["nome"] == "SECRETARIA DE ADMINISTRACAO/PR"

        # ARP should have been filtered via codigoUnidadeGerenciadora
        # (the mock returns only the matching ARP)
        assert data["resumo"]["total_atas_vigentes"] == 1

    async def test_dashboard_uasg_arp_filtra_por_api(self, agent_context):
        """Dashboard passes codigoUnidadeGerenciadora to ARP API when UASG given."""
        tool = ComprasGovbrTool()
        mock = _mock_compras_client(
            get_orgaos_uasg=AsyncMock(return_value=SAMPLE_ORGAO),
            get_uasg=AsyncMock(return_value=[{
                "codigoUasg": "110001", "nomeUasg": "SECRETARIA",
                "codigoOrgao": "20101",
            }]),
            get_contratos=AsyncMock(return_value=[SAMPLE_CONTRATO_COM_UASG]),
            get_arp=AsyncMock(return_value=SAMPLE_ARP_MESMA_UASG),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ComprasClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context, {"action": "dashboard", "codigo_uasg": "110001"}, {}, {},
            )
        assert result.status == "success"
        data = result.data
        assert data is not None
        # Verify ARP was called with codigoUnidadeGerenciadora
        call_kwargs = mock.get_arp.call_args[1] if mock.get_arp.call_args else {}
        assert call_kwargs.get("codigoUnidadeGerenciadora") == "110001", (
            f"Expected codigoUnidadeGerenciadora=110001, got {call_kwargs}"
        )

    async def test_dashboard_sem_parametros_erro(self, agent_context):
        """Dashboard without params returns error."""
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "dashboard"}, {}, {})
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "400" in err["code"]


class TestListarDomicilioBancario:
    """Tests for listar_domicilio_bancario — Bug #2 fix (mapping key)."""

    def test_cg_detalhe_map_contem_key_correta(self):
        """_CG_DETALHE_MAP must use 'domicilio_bancario' (with underscore).

        The generic dispatcher builds the client method name as
        f"listar_{endpoint}". If the endpoint is "domiciliobancario"
        (no underscore), it generates "listar_domiciliobancario" — which
        does NOT exist on ContratosGovbrClient (the real method is
        "listar_domicilio_bancario").
        """
        endpoint, slim_fn = ComprasGovbrTool._CG_DETALHE_MAP["listar_domicilio_bancario"]
        assert endpoint == "domicilio_bancario", (
            f"BUG #2 REGRESSION: expected 'domicilio_bancario', got '{endpoint}'"
        )
        # Verify the generated method name would match the client
        method_name = f"listar_{endpoint}"
        assert method_name == "listar_domicilio_bancario", (
            f"Generated method '{method_name}' != 'listar_domicilio_bancario'"
        )

    async def test_standalone_chama_metodo_correto(self, agent_context):
        """listar_domicilio_bancario standalone calls correct client method."""
        tool = ComprasGovbrTool()
        mock = _mock_cg_client(
            listar_domicilio_bancario=AsyncMock(return_value={
                "banco": "001", "agencia": "1234", "conta": "56789-0", "tipo": "Corrente",
            }),
        )
        with patch(
            "src.mcp_server.tools.enterprise.gov.compras.comprasgovbr.ContratosGovbrClient",
            return_value=mock,
        ):
            result = await tool.execute(
                agent_context,
                {"action": "listar_domicilio_bancario", "contrato_id": 2957}, {}, {},
            )
        assert result.status == "success", (
            f"BUG #2 REGRESSION: {result.error}"
        )
        data = result.data
        assert data is not None
        assert data["contrato_id"] == 2957
        # Verify the correct method was called on the client
        mock.listar_domicilio_bancario.assert_called_once_with(2957)


class TestInvalidAction:
    async def test_acao_invalida(self, agent_context):
        tool = ComprasGovbrTool()
        result = await tool.execute(agent_context, {"action": "nao_existe"}, {}, {})
        assert result.status == "error"
        err = result.error
        assert err is not None
        assert "INVALID_PARAMS" in err["code"]
