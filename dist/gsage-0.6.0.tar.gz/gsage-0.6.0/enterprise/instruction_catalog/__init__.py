# Instruction Catalog — structured instructions for the AI agent.
# Auto-discovered by the MCP server registry at startup.
