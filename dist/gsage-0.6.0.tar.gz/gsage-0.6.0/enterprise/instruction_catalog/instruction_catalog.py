"""gSage AI — Instruction Catalog MCP tool.

Provides the LLM agent with structured, on-demand access to domain-specific
instructions stored as version-controlled YAML files.

Instructions are NOT prompts — they are structured cognitive assets
(rules, checklists, templates, examples, schemas) that the agent loads
before executing a task and discards after use (lazy loading).

See: docs-local/prompts/SPEC-prompts.md
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, ClassVar, Optional

import yaml

from src.mcp_server.tools.base import BaseTool, ToolResult
from src.shared.security.context import AgentContext

log = logging.getLogger(__name__)

# ── Paths ──────────────────────────────────────────────────────────────────
_DEFINITIONS_DIR = Path(__file__).parent / "definitions"
_INDEX_PATH = _DEFINITIONS_DIR / "INDEX.yaml"
_INSTRUCTIONS_DIR = _DEFINITIONS_DIR / "instructions"


# ── Helpers ────────────────────────────────────────────────────────────────


def _load_index() -> dict:
    """Load the instruction catalog index (INDEX.yaml)."""
    if not _INDEX_PATH.exists():
        return {"instructions": []}
    data = yaml.safe_load(_INDEX_PATH.read_text(encoding="utf-8")) or {}
    return data


def _find_instruction_in_index(instruction_id: str) -> Optional[dict]:
    """Locate an instruction entry in INDEX.yaml by id."""
    index = _load_index()
    for inst in index.get("instructions", []):
        if inst.get("id") == instruction_id:
            return inst
    return None


def _resolve_yaml_path(instruction_id: str) -> Optional[Path]:
    """Resolve the filesystem path for an instruction YAML file via INDEX.yaml."""
    entry = _find_instruction_in_index(instruction_id)
    if not entry:
        return None
    file_rel = entry.get("file", "")
    if not file_rel:
        return None
    path = _DEFINITIONS_DIR / file_rel
    if path.exists():
        return path
    return None


def _load_yaml(instruction_id: str) -> Optional[dict]:
    """Load and parse an instruction definition YAML file."""
    path = _resolve_yaml_path(instruction_id)
    if path is None:
        return None
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return data


def _build_list_response(
    index: dict,
    query: Optional[str] = None,
    category: Optional[str] = None,
    asset_type: Optional[str] = None,
    tag: Optional[str] = None,
) -> tuple[list[dict], int]:
    """Build the filtered instruction list for action='list'."""
    instructions: list[dict] = index.get("instructions", [])

    if category:
        instructions = [i for i in instructions if i.get("category") == category]

    if asset_type:
        instructions = [
            i for i in instructions
            if asset_type in (i.get("asset_types") or [])
        ]

    if tag:
        instructions = [
            i for i in instructions
            if tag in (i.get("tags") or [])
        ]

    if query:
        q = query.lower()
        instructions = [
            i
            for i in instructions
            if q in i.get("title", "").lower()
            or q in i.get("summary", "").lower()
            or any(q in t.lower() for t in i.get("tags", []))
        ]

    return instructions, len(instructions)


def _search_in_content(instruction_id: str, query: str) -> bool:
    """Check if a query string appears in the instruction's asset content."""
    yaml_data = _load_yaml(instruction_id)
    if yaml_data is None:
        return False
    inst = yaml_data.get("instruction", {})
    q = query.lower()

    # Search in title and summary
    if q in inst.get("title", "").lower():
        return True
    if q in inst.get("summary", "").lower():
        return True

    # Search in asset content
    for asset in inst.get("assets", []):
        content = asset.get("content", "")
        if isinstance(content, str) and q in content.lower():
            return True
        if isinstance(content, dict) and q in str(content).lower():
            return True

    return False


# ── Tool class ─────────────────────────────────────────────────────────────


class InstructionCatalogTool(BaseTool):
    """
    Discover and load structured instructions from the Instruction Catalog.

    Instructions are structured cognitive assets (rules, checklists, templates,
    examples, schemas) that provide domain knowledge for specific tasks.
    Use this tool BEFORE executing a task to load relevant guidance.

    Actions
    -------
    - ``list`` — discover available instructions (filter by category, asset_type, tag, query).
    - ``get`` — retrieve the full definition of an instruction (metadata + assets + asset_refs).
    - ``search`` — full-text search across title, summary, tags, and asset content.
    - ``resolve`` — evaluate ``applies_when`` rules against ``runtime_context`` and return applicable instructions.

    Examples
    --------
    - ``{"action": "list"}``
    - ``{"action": "list", "category": "soc"}``
    - ``{"action": "get", "instruction_id": "whois_extraction"}``
    - ``{"action": "get", "instruction_id": "whois_extraction", "expand_refs": true}``
    - ``{"action": "search", "query": "LGPD"}``
    - ``{"action": "resolve", "runtime_context": {...}}``
    """

    name: ClassVar[str] = "instruction_catalog"
    version: ClassVar[str] = "1.0.0"
    summary: ClassVar[str] = (
        "Discover and load structured instructions (rules, checklists, "
        "templates, examples, schemas) from the Instruction Catalog. "
        "Use BEFORE executing a task to load relevant domain guidance."
    )
    category: ClassVar[str] = "utility"
    core_tool: ClassVar[bool] = True

    permissions: ClassVar[list[str]] = []
    use_circuit_breaker: ClassVar[bool] = False
    rate_limit_per_minute: ClassVar[int] = 120
    timeout_seconds: ClassVar[int] = 10

    params_schema: ClassVar[dict] = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["list", "get", "search", "resolve"],
                "description": (
                    "What to do: 'list' available instructions, "
                    "'get' a full instruction by id, "
                    "'search' by query across title/summary/tags/content, "
                    "'resolve' applicable instructions from runtime_context."
                ),
                "default": "list",
            },
            "instruction_id": {
                "type": "string",
                "description": "Instruction identifier. Required for 'get'.",
            },
            "query": {
                "type": "string",
                "description": "Free-text search. Used with 'list' and 'search'.",
            },
            "category": {
                "type": "string",
                "description": "Filter by category. Used with 'list'.",
            },
            "asset_type": {
                "type": "string",
                "enum": ["rule", "checklist", "template", "example", "schema", "reasoning_policy", "validation_policy"],
                "description": "Filter by asset type. Used with 'list'.",
            },
            "tag": {
                "type": "string",
                "description": "Filter by tag. Used with 'list'.",
            },
            "runtime_context": {
                "type": "object",
                "description": (
                    "Runtime context from process_catalog resolve. "
                    "Used with action='resolve' to evaluate applies_when rules. "
                    "Should contain facts, inferences, active_capabilities, etc."
                ),
            },
            "expand_refs": {
                "type": "boolean",
                "default": False,
                "description": (
                    "If true, resolve asset_refs by loading referenced "
                    "instructions and document models. Used with action='get'."
                ),
            },
        },
        "required": [],
        "additionalProperties": False,
    }

    async def execute(
        self,
        agent_context: AgentContext,
        params: dict,
        config: dict,
        state: dict,
    ) -> ToolResult:
        start = time.monotonic()
        action: str = params.get("action", "list")

        # ── action: list ──────────────────────────────────────────────
        if action == "list":
            index = _load_index()
            instructions, count = _build_list_response(
                index,
                query=params.get("query"),
                category=params.get("category"),
                asset_type=params.get("asset_type"),
                tag=params.get("tag"),
            )
            return self._success(
                data={"instructions": instructions, "count": count},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: get ───────────────────────────────────────────────
        if action == "get":
            instruction_id: str = (params.get("instruction_id") or "").strip()
            if not instruction_id:
                return self._failure(
                    code="MISSING_INSTRUCTION_ID",
                    message="The 'instruction_id' parameter is required for action='get'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

            yaml_data = _load_yaml(instruction_id)
            if yaml_data is None:
                return self._failure(
                    code="INSTRUCTION_NOT_FOUND",
                    message=f"Instruction '{instruction_id}' not found in the catalog.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

            inst = yaml_data.get("instruction", {})
            result: dict = {
                "id": inst.get("id"),
                "version": inst.get("version"),
                "title": inst.get("title"),
                "summary": inst.get("summary"),
                "category": inst.get("category"),
                "tags": inst.get("tags"),
                "priority": inst.get("priority", 50),
                "applies_when": inst.get("applies_when"),
                "extends": inst.get("extends"),
                "assets": inst.get("assets", []),
                "asset_refs": inst.get("asset_refs", []),
                "metadata": inst.get("metadata", {}),
                "asset_count": len(inst.get("assets", [])),
                "asset_ref_count": len(inst.get("asset_refs", [])),
            }

            # ── expand_refs: resolve referenced instructions ──────
            if params.get("expand_refs"):
                expanded_refs: list[dict] = []
                for ref in inst.get("asset_refs", []):
                    ref_source = ref.get("source", "")
                    resolved_item: dict = dict(ref)  # copy original ref metadata

                    if ref_source == "instruction_catalog":
                        ref_id = ref.get("ref_id", "")
                        ref_yaml = _load_yaml(ref_id)
                        if ref_yaml:
                            ref_inst = ref_yaml.get("instruction", {})
                            resolved_item["_resolved"] = {
                                "title": ref_inst.get("title"),
                                "summary": ref_inst.get("summary"),
                                "assets": ref_inst.get("assets", []),
                                "asset_refs": ref_inst.get("asset_refs", []),
                            }
                        else:
                            resolved_item["_resolved"] = {"error": f"Referenced instruction '{ref_id}' not found."}
                    elif ref_source == "process_catalog":
                        resolved_item["_hint"] = (
                            f"Use process_catalog(action='get_document', document_id='{ref.get('ref_id', '')}') "
                            "to load the document model."
                        )
                    elif ref_source == "user_templates":
                        resolved_item["_hint"] = (
                            f"Use document_templates to find the template with id '{ref.get('ref_id', '')}', "
                            "then generate_document to produce the document."
                        )
                    elif ref_source == "knowledge_base":
                        resolved_item["_hint"] = (
                            f"Use knowledge_base to search for '{ref.get('ref_id', '')}'."
                        )

                    expanded_refs.append(resolved_item)

                result["asset_refs"] = expanded_refs

            return self._success(
                data={"instruction": result},
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: resolve ────────────────────────────────────────────
        if action == "resolve":
            from src.shared.decision.rule_evaluator import SimpleRuleEvaluator

            runtime_context: dict = params.get("runtime_context") or {}
            if not runtime_context:
                return self._failure(
                    code="MISSING_RUNTIME_CONTEXT",
                    message="The 'runtime_context' parameter is required for action='resolve'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

            evaluator = SimpleRuleEvaluator()
            index = _load_index()
            resolved_list: list[dict] = []

            # Build combined facts: merge top-level non-reserved keys from
            # runtime_context into facts so that fields like 'tool_name'
            # at the top level are discoverable by the rule evaluator.
            # (type: ignore — evaluator._resolve_field handles both dict and model at runtime)
            raw_facts: Any = dict(runtime_context.get("facts", {}))
            _reserved_keys = {"facts", "inferences", "active_capabilities", "active_obligations", "decisions"}
            for key, value in runtime_context.items():
                if key not in _reserved_keys:
                    raw_facts[key] = value

            raw_inferences: Any = dict(runtime_context.get("inferences", {}))

            for entry in index.get("instructions", []):
                inst_id = entry.get("id", "")
                yaml_data = _load_yaml(inst_id)
                if yaml_data is None:
                    continue

                inst = yaml_data.get("instruction", {})
                applies_when = inst.get("applies_when")

                # Evaluate applies_when if present
                if applies_when:
                    try:
                        matches = evaluator.evaluate(
                            applies_when,
                            raw_facts,
                            raw_inferences,
                        )
                    except Exception:
                        log.warning("Failed to evaluate applies_when for %s", inst_id, exc_info=True)
                        matches = False
                else:
                    # No applies_when → skip (don't auto-include)
                    continue

                if matches:
                    resolved_list.append({
                        "id": inst_id,
                        "title": inst.get("title"),
                        "summary": inst.get("summary"),
                        "category": inst.get("category"),
                        "priority": inst.get("priority", 50),
                        "tags": inst.get("tags"),
                        "asset_count": len(inst.get("assets", [])),
                        "asset_ref_count": len(inst.get("asset_refs", [])),
                    })

            # Sort by priority desc
            resolved_list.sort(key=lambda x: x.get("priority", 0), reverse=True)

            return self._success(
                data={
                    "instructions": resolved_list,
                    "count": len(resolved_list),
                },
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── action: search ────────────────────────────────────────────
        if action == "search":
            query: str = (params.get("query") or "").strip()
            if not query:
                return self._failure(
                    code="MISSING_QUERY",
                    message="The 'query' parameter is required for action='search'.",
                    retryable=False,
                    execution_time_ms=int((time.monotonic() - start) * 1000),
                )

            index = _load_index()
            results: list[dict] = []
            for entry in index.get("instructions", []):
                inst_id = entry.get("id", "")
                if _search_in_content(inst_id, query):
                    results.append(entry)

            return self._success(
                data={
                    "results": results,
                    "count": len(results),
                    "query": query,
                },
                execution_time_ms=int((time.monotonic() - start) * 1000),
            )

        # ── Unknown action ────────────────────────────────────────────
        return self._failure(
            code="UNKNOWN_ACTION",
            message=(
                f"Unknown action: '{action}'. "
                "Valid actions: list, get, search, resolve."
            ),
            retryable=False,
            execution_time_ms=int((time.monotonic() - start) * 1000),
        )
